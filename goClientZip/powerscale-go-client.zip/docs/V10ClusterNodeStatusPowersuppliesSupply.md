# V10ClusterNodeStatusPowersuppliesSupply

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Chassis** | Pointer to **int32** | Which node chassis is this power supply in. | [optional] 
**Firmware** | Pointer to **string** | The current firmware revision of this power supply. | [optional] 
**Good** | Pointer to **string** | Is this power supply in a failure state. | [optional] 
**Id** | **int32** | Identifying index for this power supply. | 
**Name** | Pointer to **string** | Complete identifying string for this power supply. | [optional] 
**Status** | Pointer to **string** | A descriptive status string for this power supply. | [optional] 
**Type** | Pointer to **string** | The type of this power supply. | [optional] 

## Methods

### NewV10ClusterNodeStatusPowersuppliesSupply

`func NewV10ClusterNodeStatusPowersuppliesSupply(id int32, ) *V10ClusterNodeStatusPowersuppliesSupply`

NewV10ClusterNodeStatusPowersuppliesSupply instantiates a new V10ClusterNodeStatusPowersuppliesSupply object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeStatusPowersuppliesSupplyWithDefaults

`func NewV10ClusterNodeStatusPowersuppliesSupplyWithDefaults() *V10ClusterNodeStatusPowersuppliesSupply`

NewV10ClusterNodeStatusPowersuppliesSupplyWithDefaults instantiates a new V10ClusterNodeStatusPowersuppliesSupply object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetChassis

`func (o *V10ClusterNodeStatusPowersuppliesSupply) GetChassis() int32`

GetChassis returns the Chassis field if non-nil, zero value otherwise.

### GetChassisOk

`func (o *V10ClusterNodeStatusPowersuppliesSupply) GetChassisOk() (*int32, bool)`

GetChassisOk returns a tuple with the Chassis field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChassis

`func (o *V10ClusterNodeStatusPowersuppliesSupply) SetChassis(v int32)`

SetChassis sets Chassis field to given value.

### HasChassis

`func (o *V10ClusterNodeStatusPowersuppliesSupply) HasChassis() bool`

HasChassis returns a boolean if a field has been set.

### GetFirmware

`func (o *V10ClusterNodeStatusPowersuppliesSupply) GetFirmware() string`

GetFirmware returns the Firmware field if non-nil, zero value otherwise.

### GetFirmwareOk

`func (o *V10ClusterNodeStatusPowersuppliesSupply) GetFirmwareOk() (*string, bool)`

GetFirmwareOk returns a tuple with the Firmware field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirmware

`func (o *V10ClusterNodeStatusPowersuppliesSupply) SetFirmware(v string)`

SetFirmware sets Firmware field to given value.

### HasFirmware

`func (o *V10ClusterNodeStatusPowersuppliesSupply) HasFirmware() bool`

HasFirmware returns a boolean if a field has been set.

### GetGood

`func (o *V10ClusterNodeStatusPowersuppliesSupply) GetGood() string`

GetGood returns the Good field if non-nil, zero value otherwise.

### GetGoodOk

`func (o *V10ClusterNodeStatusPowersuppliesSupply) GetGoodOk() (*string, bool)`

GetGoodOk returns a tuple with the Good field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGood

`func (o *V10ClusterNodeStatusPowersuppliesSupply) SetGood(v string)`

SetGood sets Good field to given value.

### HasGood

`func (o *V10ClusterNodeStatusPowersuppliesSupply) HasGood() bool`

HasGood returns a boolean if a field has been set.

### GetId

`func (o *V10ClusterNodeStatusPowersuppliesSupply) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V10ClusterNodeStatusPowersuppliesSupply) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V10ClusterNodeStatusPowersuppliesSupply) SetId(v int32)`

SetId sets Id field to given value.


### GetName

`func (o *V10ClusterNodeStatusPowersuppliesSupply) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V10ClusterNodeStatusPowersuppliesSupply) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V10ClusterNodeStatusPowersuppliesSupply) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V10ClusterNodeStatusPowersuppliesSupply) HasName() bool`

HasName returns a boolean if a field has been set.

### GetStatus

`func (o *V10ClusterNodeStatusPowersuppliesSupply) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V10ClusterNodeStatusPowersuppliesSupply) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V10ClusterNodeStatusPowersuppliesSupply) SetStatus(v string)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V10ClusterNodeStatusPowersuppliesSupply) HasStatus() bool`

HasStatus returns a boolean if a field has been set.

### GetType

`func (o *V10ClusterNodeStatusPowersuppliesSupply) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *V10ClusterNodeStatusPowersuppliesSupply) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *V10ClusterNodeStatusPowersuppliesSupply) SetType(v string)`

SetType sets Type field to given value.

### HasType

`func (o *V10ClusterNodeStatusPowersuppliesSupply) HasType() bool`

HasType returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


