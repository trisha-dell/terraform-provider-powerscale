# V10ChangelistsChangelistDiffRegionsDiffRegion

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ByteCount** | **int32** | Byte count of change region. | 
**RegionType** | **string** | Type of change region. | 
**StartOffset** | **int32** | Starting byte offset of change region. | 

## Methods

### NewV10ChangelistsChangelistDiffRegionsDiffRegion

`func NewV10ChangelistsChangelistDiffRegionsDiffRegion(byteCount int32, regionType string, startOffset int32, ) *V10ChangelistsChangelistDiffRegionsDiffRegion`

NewV10ChangelistsChangelistDiffRegionsDiffRegion instantiates a new V10ChangelistsChangelistDiffRegionsDiffRegion object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ChangelistsChangelistDiffRegionsDiffRegionWithDefaults

`func NewV10ChangelistsChangelistDiffRegionsDiffRegionWithDefaults() *V10ChangelistsChangelistDiffRegionsDiffRegion`

NewV10ChangelistsChangelistDiffRegionsDiffRegionWithDefaults instantiates a new V10ChangelistsChangelistDiffRegionsDiffRegion object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetByteCount

`func (o *V10ChangelistsChangelistDiffRegionsDiffRegion) GetByteCount() int32`

GetByteCount returns the ByteCount field if non-nil, zero value otherwise.

### GetByteCountOk

`func (o *V10ChangelistsChangelistDiffRegionsDiffRegion) GetByteCountOk() (*int32, bool)`

GetByteCountOk returns a tuple with the ByteCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetByteCount

`func (o *V10ChangelistsChangelistDiffRegionsDiffRegion) SetByteCount(v int32)`

SetByteCount sets ByteCount field to given value.


### GetRegionType

`func (o *V10ChangelistsChangelistDiffRegionsDiffRegion) GetRegionType() string`

GetRegionType returns the RegionType field if non-nil, zero value otherwise.

### GetRegionTypeOk

`func (o *V10ChangelistsChangelistDiffRegionsDiffRegion) GetRegionTypeOk() (*string, bool)`

GetRegionTypeOk returns a tuple with the RegionType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRegionType

`func (o *V10ChangelistsChangelistDiffRegionsDiffRegion) SetRegionType(v string)`

SetRegionType sets RegionType field to given value.


### GetStartOffset

`func (o *V10ChangelistsChangelistDiffRegionsDiffRegion) GetStartOffset() int32`

GetStartOffset returns the StartOffset field if non-nil, zero value otherwise.

### GetStartOffsetOk

`func (o *V10ChangelistsChangelistDiffRegionsDiffRegion) GetStartOffsetOk() (*int32, bool)`

GetStartOffsetOk returns a tuple with the StartOffset field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartOffset

`func (o *V10ChangelistsChangelistDiffRegionsDiffRegion) SetStartOffset(v int32)`

SetStartOffset sets StartOffset field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


