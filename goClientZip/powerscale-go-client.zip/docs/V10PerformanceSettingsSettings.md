# V10PerformanceSettingsSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MaxDatasetCount** | **int32** | The maximum number of datasets that can be configured on the system. | 
**MaxFilterCount** | **int32** | The maximum number of filters that can be applied to a configured performance dataset. | 
**MaxStatSize** | **int32** | The maximum size in bytes of a single performance dataset sample. | 
**MaxTopNCollectionCount** | **int32** | The maximum valid value for the &#39;top_n_collection_count&#39; setting. | 
**MaxWorkloadCount** | **int32** | The maximum number of workloads that can be pinned to a configured performance dataset. | 
**TopNCollectionCount** | **int32** | The number of highest resource-consuming workloads tracked and collected by the system per configured performance dataset. The number of workloads pinned to a configured performance dataset does not count towards this value. | 

## Methods

### NewV10PerformanceSettingsSettings

`func NewV10PerformanceSettingsSettings(maxDatasetCount int32, maxFilterCount int32, maxStatSize int32, maxTopNCollectionCount int32, maxWorkloadCount int32, topNCollectionCount int32, ) *V10PerformanceSettingsSettings`

NewV10PerformanceSettingsSettings instantiates a new V10PerformanceSettingsSettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10PerformanceSettingsSettingsWithDefaults

`func NewV10PerformanceSettingsSettingsWithDefaults() *V10PerformanceSettingsSettings`

NewV10PerformanceSettingsSettingsWithDefaults instantiates a new V10PerformanceSettingsSettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMaxDatasetCount

`func (o *V10PerformanceSettingsSettings) GetMaxDatasetCount() int32`

GetMaxDatasetCount returns the MaxDatasetCount field if non-nil, zero value otherwise.

### GetMaxDatasetCountOk

`func (o *V10PerformanceSettingsSettings) GetMaxDatasetCountOk() (*int32, bool)`

GetMaxDatasetCountOk returns a tuple with the MaxDatasetCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaxDatasetCount

`func (o *V10PerformanceSettingsSettings) SetMaxDatasetCount(v int32)`

SetMaxDatasetCount sets MaxDatasetCount field to given value.


### GetMaxFilterCount

`func (o *V10PerformanceSettingsSettings) GetMaxFilterCount() int32`

GetMaxFilterCount returns the MaxFilterCount field if non-nil, zero value otherwise.

### GetMaxFilterCountOk

`func (o *V10PerformanceSettingsSettings) GetMaxFilterCountOk() (*int32, bool)`

GetMaxFilterCountOk returns a tuple with the MaxFilterCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaxFilterCount

`func (o *V10PerformanceSettingsSettings) SetMaxFilterCount(v int32)`

SetMaxFilterCount sets MaxFilterCount field to given value.


### GetMaxStatSize

`func (o *V10PerformanceSettingsSettings) GetMaxStatSize() int32`

GetMaxStatSize returns the MaxStatSize field if non-nil, zero value otherwise.

### GetMaxStatSizeOk

`func (o *V10PerformanceSettingsSettings) GetMaxStatSizeOk() (*int32, bool)`

GetMaxStatSizeOk returns a tuple with the MaxStatSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaxStatSize

`func (o *V10PerformanceSettingsSettings) SetMaxStatSize(v int32)`

SetMaxStatSize sets MaxStatSize field to given value.


### GetMaxTopNCollectionCount

`func (o *V10PerformanceSettingsSettings) GetMaxTopNCollectionCount() int32`

GetMaxTopNCollectionCount returns the MaxTopNCollectionCount field if non-nil, zero value otherwise.

### GetMaxTopNCollectionCountOk

`func (o *V10PerformanceSettingsSettings) GetMaxTopNCollectionCountOk() (*int32, bool)`

GetMaxTopNCollectionCountOk returns a tuple with the MaxTopNCollectionCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaxTopNCollectionCount

`func (o *V10PerformanceSettingsSettings) SetMaxTopNCollectionCount(v int32)`

SetMaxTopNCollectionCount sets MaxTopNCollectionCount field to given value.


### GetMaxWorkloadCount

`func (o *V10PerformanceSettingsSettings) GetMaxWorkloadCount() int32`

GetMaxWorkloadCount returns the MaxWorkloadCount field if non-nil, zero value otherwise.

### GetMaxWorkloadCountOk

`func (o *V10PerformanceSettingsSettings) GetMaxWorkloadCountOk() (*int32, bool)`

GetMaxWorkloadCountOk returns a tuple with the MaxWorkloadCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaxWorkloadCount

`func (o *V10PerformanceSettingsSettings) SetMaxWorkloadCount(v int32)`

SetMaxWorkloadCount sets MaxWorkloadCount field to given value.


### GetTopNCollectionCount

`func (o *V10PerformanceSettingsSettings) GetTopNCollectionCount() int32`

GetTopNCollectionCount returns the TopNCollectionCount field if non-nil, zero value otherwise.

### GetTopNCollectionCountOk

`func (o *V10PerformanceSettingsSettings) GetTopNCollectionCountOk() (*int32, bool)`

GetTopNCollectionCountOk returns a tuple with the TopNCollectionCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTopNCollectionCount

`func (o *V10PerformanceSettingsSettings) SetTopNCollectionCount(v int32)`

SetTopNCollectionCount sets TopNCollectionCount field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


