# \CertificateApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateCertificatev4CertificateServerItem**](CertificateApi.md#CreateCertificatev4CertificateServerItem) | **Post** /platform/4/certificate/server | 
[**CreateCertificatev7CertificateAuthorityItem**](CertificateApi.md#CreateCertificatev7CertificateAuthorityItem) | **Post** /platform/7/certificate/authority | 
[**DeleteCertificatev4CertificateServerById**](CertificateApi.md#DeleteCertificatev4CertificateServerById) | **Delete** /platform/4/certificate/server/{v4CertificateServerId} | 
[**DeleteCertificatev7CertificateAuthorityById**](CertificateApi.md#DeleteCertificatev7CertificateAuthorityById) | **Delete** /platform/7/certificate/authority/{v7CertificateAuthorityId} | 
[**GetCertificatev4CertificateServerById**](CertificateApi.md#GetCertificatev4CertificateServerById) | **Get** /platform/4/certificate/server/{v4CertificateServerId} | 
[**GetCertificatev7CertificateAuthorityById**](CertificateApi.md#GetCertificatev7CertificateAuthorityById) | **Get** /platform/7/certificate/authority/{v7CertificateAuthorityId} | 
[**GetCertificatev7CertificateSettings**](CertificateApi.md#GetCertificatev7CertificateSettings) | **Get** /platform/7/certificate/settings | 
[**ListCertificatev4CertificateServer**](CertificateApi.md#ListCertificatev4CertificateServer) | **Get** /platform/4/certificate/server | 
[**ListCertificatev7CertificateAuthority**](CertificateApi.md#ListCertificatev7CertificateAuthority) | **Get** /platform/7/certificate/authority | 
[**UpdateCertificatev4CertificateServerById**](CertificateApi.md#UpdateCertificatev4CertificateServerById) | **Put** /platform/4/certificate/server/{v4CertificateServerId} | 
[**UpdateCertificatev7CertificateAuthorityById**](CertificateApi.md#UpdateCertificatev7CertificateAuthorityById) | **Put** /platform/7/certificate/authority/{v7CertificateAuthorityId} | 
[**UpdateCertificatev7CertificateSettings**](CertificateApi.md#UpdateCertificatev7CertificateSettings) | **Put** /platform/7/certificate/settings | 



## CreateCertificatev4CertificateServerItem

> CreateResponse CreateCertificatev4CertificateServerItem(ctx).V4CertificateServerItem(v4CertificateServerItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4CertificateServerItem := *openapiclient.NewV16CertificatesSyslogItem("CertificateKeyPath_example", "CertificatePath_example") // V16CertificatesSyslogItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CertificateApi.CreateCertificatev4CertificateServerItem(context.Background()).V4CertificateServerItem(v4CertificateServerItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CertificateApi.CreateCertificatev4CertificateServerItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateCertificatev4CertificateServerItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `CertificateApi.CreateCertificatev4CertificateServerItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateCertificatev4CertificateServerItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v4CertificateServerItem** | [**V16CertificatesSyslogItem**](V16CertificatesSyslogItem.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateCertificatev7CertificateAuthorityItem

> CreateResponse CreateCertificatev7CertificateAuthorityItem(ctx).V7CertificateAuthorityItem(v7CertificateAuthorityItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CertificateAuthorityItem := *openapiclient.NewV7CertificateAuthorityItem("CertificatePath_example") // V7CertificateAuthorityItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CertificateApi.CreateCertificatev7CertificateAuthorityItem(context.Background()).V7CertificateAuthorityItem(v7CertificateAuthorityItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CertificateApi.CreateCertificatev7CertificateAuthorityItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateCertificatev7CertificateAuthorityItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `CertificateApi.CreateCertificatev7CertificateAuthorityItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateCertificatev7CertificateAuthorityItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7CertificateAuthorityItem** | [**V7CertificateAuthorityItem**](V7CertificateAuthorityItem.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteCertificatev4CertificateServerById

> DeleteCertificatev4CertificateServerById(ctx, v4CertificateServerId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4CertificateServerId := "v4CertificateServerId_example" // string | Delete a TLS server certificate.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CertificateApi.DeleteCertificatev4CertificateServerById(context.Background(), v4CertificateServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CertificateApi.DeleteCertificatev4CertificateServerById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4CertificateServerId** | **string** | Delete a TLS server certificate. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteCertificatev4CertificateServerByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteCertificatev7CertificateAuthorityById

> DeleteCertificatev7CertificateAuthorityById(ctx, v7CertificateAuthorityId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CertificateAuthorityId := "v7CertificateAuthorityId_example" // string | Delete a TLS certificate authority.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CertificateApi.DeleteCertificatev7CertificateAuthorityById(context.Background(), v7CertificateAuthorityId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CertificateApi.DeleteCertificatev7CertificateAuthorityById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7CertificateAuthorityId** | **string** | Delete a TLS certificate authority. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteCertificatev7CertificateAuthorityByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetCertificatev4CertificateServerById

> V4CertificateServerExtended GetCertificatev4CertificateServerById(ctx, v4CertificateServerId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4CertificateServerId := "v4CertificateServerId_example" // string | Retrieve a single TLS server certificate.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CertificateApi.GetCertificatev4CertificateServerById(context.Background(), v4CertificateServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CertificateApi.GetCertificatev4CertificateServerById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetCertificatev4CertificateServerById`: V4CertificateServerExtended
    fmt.Fprintf(os.Stdout, "Response from `CertificateApi.GetCertificatev4CertificateServerById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4CertificateServerId** | **string** | Retrieve a single TLS server certificate. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetCertificatev4CertificateServerByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V4CertificateServerExtended**](V4CertificateServerExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetCertificatev7CertificateAuthorityById

> V16CertificatesSyslogExtended GetCertificatev7CertificateAuthorityById(ctx, v7CertificateAuthorityId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CertificateAuthorityId := "v7CertificateAuthorityId_example" // string | Retrieve a single TLS certificate authority.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CertificateApi.GetCertificatev7CertificateAuthorityById(context.Background(), v7CertificateAuthorityId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CertificateApi.GetCertificatev7CertificateAuthorityById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetCertificatev7CertificateAuthorityById`: V16CertificatesSyslogExtended
    fmt.Fprintf(os.Stdout, "Response from `CertificateApi.GetCertificatev7CertificateAuthorityById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7CertificateAuthorityId** | **string** | Retrieve a single TLS certificate authority. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetCertificatev7CertificateAuthorityByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V16CertificatesSyslogExtended**](V16CertificatesSyslogExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetCertificatev7CertificateSettings

> V7CertificateSettings GetCertificatev7CertificateSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CertificateApi.GetCertificatev7CertificateSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CertificateApi.GetCertificatev7CertificateSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetCertificatev7CertificateSettings`: V7CertificateSettings
    fmt.Fprintf(os.Stdout, "Response from `CertificateApi.GetCertificatev7CertificateSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetCertificatev7CertificateSettingsRequest struct via the builder pattern


### Return type

[**V7CertificateSettings**](V7CertificateSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListCertificatev4CertificateServer

> V4CertificateServer ListCertificatev4CertificateServer(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CertificateApi.ListCertificatev4CertificateServer(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CertificateApi.ListCertificatev4CertificateServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListCertificatev4CertificateServer`: V4CertificateServer
    fmt.Fprintf(os.Stdout, "Response from `CertificateApi.ListCertificatev4CertificateServer`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListCertificatev4CertificateServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V4CertificateServer**](V4CertificateServer.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListCertificatev7CertificateAuthority

> V16CertificatesSyslog ListCertificatev7CertificateAuthority(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CertificateApi.ListCertificatev7CertificateAuthority(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CertificateApi.ListCertificatev7CertificateAuthority``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListCertificatev7CertificateAuthority`: V16CertificatesSyslog
    fmt.Fprintf(os.Stdout, "Response from `CertificateApi.ListCertificatev7CertificateAuthority`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListCertificatev7CertificateAuthorityRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V16CertificatesSyslog**](V16CertificatesSyslog.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateCertificatev4CertificateServerById

> UpdateCertificatev4CertificateServerById(ctx, v4CertificateServerId).V4CertificateServerIdParams(v4CertificateServerIdParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4CertificateServerId := "v4CertificateServerId_example" // string | Modify a TLS server certificate.
    v4CertificateServerIdParams := *openapiclient.NewV16CertificatesSyslogIdParams() // V16CertificatesSyslogIdParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CertificateApi.UpdateCertificatev4CertificateServerById(context.Background(), v4CertificateServerId).V4CertificateServerIdParams(v4CertificateServerIdParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CertificateApi.UpdateCertificatev4CertificateServerById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4CertificateServerId** | **string** | Modify a TLS server certificate. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateCertificatev4CertificateServerByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v4CertificateServerIdParams** | [**V16CertificatesSyslogIdParams**](V16CertificatesSyslogIdParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateCertificatev7CertificateAuthorityById

> UpdateCertificatev7CertificateAuthorityById(ctx, v7CertificateAuthorityId).V7CertificateAuthorityIdParams(v7CertificateAuthorityIdParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CertificateAuthorityId := "v7CertificateAuthorityId_example" // string | Modify a TLS certificate authority.
    v7CertificateAuthorityIdParams := *openapiclient.NewV16CertificatesSyslogIdParams() // V16CertificatesSyslogIdParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CertificateApi.UpdateCertificatev7CertificateAuthorityById(context.Background(), v7CertificateAuthorityId).V7CertificateAuthorityIdParams(v7CertificateAuthorityIdParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CertificateApi.UpdateCertificatev7CertificateAuthorityById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7CertificateAuthorityId** | **string** | Modify a TLS certificate authority. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateCertificatev7CertificateAuthorityByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7CertificateAuthorityIdParams** | [**V16CertificatesSyslogIdParams**](V16CertificatesSyslogIdParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateCertificatev7CertificateSettings

> UpdateCertificatev7CertificateSettings(ctx).V7CertificateSettings(v7CertificateSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CertificateSettings := *openapiclient.NewV7CertificateSettingsExtended() // V7CertificateSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CertificateApi.UpdateCertificatev7CertificateSettings(context.Background()).V7CertificateSettings(v7CertificateSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CertificateApi.UpdateCertificatev7CertificateSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateCertificatev7CertificateSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7CertificateSettings** | [**V7CertificateSettingsExtended**](V7CertificateSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

