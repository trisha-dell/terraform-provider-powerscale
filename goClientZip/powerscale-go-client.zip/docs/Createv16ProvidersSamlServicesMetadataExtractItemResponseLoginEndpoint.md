# Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Binding** | Pointer to **string** | SAML binding that PowerScale can use. | [optional] 
**IsDefault** | Pointer to **bool** | When true this is the endpoint that PowerScale will use if this same metadata is used to create an IDP on PowerScale. There will be at most one item in the list set to true. | [optional] 
**Url** | Pointer to **string** | URL specifying the location of the endpoint. | [optional] 

## Methods

### NewCreatev16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint

`func NewCreatev16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint() *Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint`

NewCreatev16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint instantiates a new Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpointWithDefaults

`func NewCreatev16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpointWithDefaults() *Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint`

NewCreatev16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpointWithDefaults instantiates a new Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBinding

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint) GetBinding() string`

GetBinding returns the Binding field if non-nil, zero value otherwise.

### GetBindingOk

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint) GetBindingOk() (*string, bool)`

GetBindingOk returns a tuple with the Binding field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBinding

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint) SetBinding(v string)`

SetBinding sets Binding field to given value.

### HasBinding

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint) HasBinding() bool`

HasBinding returns a boolean if a field has been set.

### GetIsDefault

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint) GetIsDefault() bool`

GetIsDefault returns the IsDefault field if non-nil, zero value otherwise.

### GetIsDefaultOk

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint) GetIsDefaultOk() (*bool, bool)`

GetIsDefaultOk returns a tuple with the IsDefault field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIsDefault

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint) SetIsDefault(v bool)`

SetIsDefault sets IsDefault field to given value.

### HasIsDefault

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint) HasIsDefault() bool`

HasIsDefault returns a boolean if a field has been set.

### GetUrl

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint) GetUrl() string`

GetUrl returns the Url field if non-nil, zero value otherwise.

### GetUrlOk

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint) GetUrlOk() (*string, bool)`

GetUrlOk returns a tuple with the Url field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUrl

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint) SetUrl(v string)`

SetUrl sets Url field to given value.

### HasUrl

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint) HasUrl() bool`

HasUrl returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


