# V10S3Buckets

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Buckets** | [**[]V10S3BucketExtended**](V10S3BucketExtended.md) |  | 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV10S3Buckets

`func NewV10S3Buckets(buckets []V10S3BucketExtended, ) *V10S3Buckets`

NewV10S3Buckets instantiates a new V10S3Buckets object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10S3BucketsWithDefaults

`func NewV10S3BucketsWithDefaults() *V10S3Buckets`

NewV10S3BucketsWithDefaults instantiates a new V10S3Buckets object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBuckets

`func (o *V10S3Buckets) GetBuckets() []V10S3BucketExtended`

GetBuckets returns the Buckets field if non-nil, zero value otherwise.

### GetBucketsOk

`func (o *V10S3Buckets) GetBucketsOk() (*[]V10S3BucketExtended, bool)`

GetBucketsOk returns a tuple with the Buckets field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBuckets

`func (o *V10S3Buckets) SetBuckets(v []V10S3BucketExtended)`

SetBuckets sets Buckets field to given value.


### GetResume

`func (o *V10S3Buckets) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V10S3Buckets) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V10S3Buckets) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V10S3Buckets) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V10S3Buckets) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V10S3Buckets) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V10S3Buckets) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V10S3Buckets) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


