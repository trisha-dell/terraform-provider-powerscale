# V11EventThresholdExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Defaults** | Pointer to [**V11EventThresholdThresholds**](V11EventThresholdThresholds.md) |  | [optional] 
**IdName** | Pointer to **string** | Name for event. | [optional] 
**ThresholdDescription** | Pointer to **string** | Verbose, human-readable description of event. | [optional] 
**Thresholds** | Pointer to [**V11EventThresholdThresholds**](V11EventThresholdThresholds.md) |  | [optional] 

## Methods

### NewV11EventThresholdExtended

`func NewV11EventThresholdExtended() *V11EventThresholdExtended`

NewV11EventThresholdExtended instantiates a new V11EventThresholdExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11EventThresholdExtendedWithDefaults

`func NewV11EventThresholdExtendedWithDefaults() *V11EventThresholdExtended`

NewV11EventThresholdExtendedWithDefaults instantiates a new V11EventThresholdExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDefaults

`func (o *V11EventThresholdExtended) GetDefaults() V11EventThresholdThresholds`

GetDefaults returns the Defaults field if non-nil, zero value otherwise.

### GetDefaultsOk

`func (o *V11EventThresholdExtended) GetDefaultsOk() (*V11EventThresholdThresholds, bool)`

GetDefaultsOk returns a tuple with the Defaults field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDefaults

`func (o *V11EventThresholdExtended) SetDefaults(v V11EventThresholdThresholds)`

SetDefaults sets Defaults field to given value.

### HasDefaults

`func (o *V11EventThresholdExtended) HasDefaults() bool`

HasDefaults returns a boolean if a field has been set.

### GetIdName

`func (o *V11EventThresholdExtended) GetIdName() string`

GetIdName returns the IdName field if non-nil, zero value otherwise.

### GetIdNameOk

`func (o *V11EventThresholdExtended) GetIdNameOk() (*string, bool)`

GetIdNameOk returns a tuple with the IdName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIdName

`func (o *V11EventThresholdExtended) SetIdName(v string)`

SetIdName sets IdName field to given value.

### HasIdName

`func (o *V11EventThresholdExtended) HasIdName() bool`

HasIdName returns a boolean if a field has been set.

### GetThresholdDescription

`func (o *V11EventThresholdExtended) GetThresholdDescription() string`

GetThresholdDescription returns the ThresholdDescription field if non-nil, zero value otherwise.

### GetThresholdDescriptionOk

`func (o *V11EventThresholdExtended) GetThresholdDescriptionOk() (*string, bool)`

GetThresholdDescriptionOk returns a tuple with the ThresholdDescription field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetThresholdDescription

`func (o *V11EventThresholdExtended) SetThresholdDescription(v string)`

SetThresholdDescription sets ThresholdDescription field to given value.

### HasThresholdDescription

`func (o *V11EventThresholdExtended) HasThresholdDescription() bool`

HasThresholdDescription returns a boolean if a field has been set.

### GetThresholds

`func (o *V11EventThresholdExtended) GetThresholds() V11EventThresholdThresholds`

GetThresholds returns the Thresholds field if non-nil, zero value otherwise.

### GetThresholdsOk

`func (o *V11EventThresholdExtended) GetThresholdsOk() (*V11EventThresholdThresholds, bool)`

GetThresholdsOk returns a tuple with the Thresholds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetThresholds

`func (o *V11EventThresholdExtended) SetThresholds(v V11EventThresholdThresholds)`

SetThresholds sets Thresholds field to given value.

### HasThresholds

`func (o *V11EventThresholdExtended) HasThresholds() bool`

HasThresholds returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


