# V12SubnetsSubnetPoolStaticRoute

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Gateway** | **string** | Address of the gateway in the format: yyy.yyy.yyy.yyy | 
**Prefixlen** | **int32** | Prefix length in the format: nn. | 
**Subnet** | **string** | Network address in the format: xxx.xxx.xxx.xxx | 

## Methods

### NewV12SubnetsSubnetPoolStaticRoute

`func NewV12SubnetsSubnetPoolStaticRoute(gateway string, prefixlen int32, subnet string, ) *V12SubnetsSubnetPoolStaticRoute`

NewV12SubnetsSubnetPoolStaticRoute instantiates a new V12SubnetsSubnetPoolStaticRoute object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12SubnetsSubnetPoolStaticRouteWithDefaults

`func NewV12SubnetsSubnetPoolStaticRouteWithDefaults() *V12SubnetsSubnetPoolStaticRoute`

NewV12SubnetsSubnetPoolStaticRouteWithDefaults instantiates a new V12SubnetsSubnetPoolStaticRoute object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetGateway

`func (o *V12SubnetsSubnetPoolStaticRoute) GetGateway() string`

GetGateway returns the Gateway field if non-nil, zero value otherwise.

### GetGatewayOk

`func (o *V12SubnetsSubnetPoolStaticRoute) GetGatewayOk() (*string, bool)`

GetGatewayOk returns a tuple with the Gateway field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGateway

`func (o *V12SubnetsSubnetPoolStaticRoute) SetGateway(v string)`

SetGateway sets Gateway field to given value.


### GetPrefixlen

`func (o *V12SubnetsSubnetPoolStaticRoute) GetPrefixlen() int32`

GetPrefixlen returns the Prefixlen field if non-nil, zero value otherwise.

### GetPrefixlenOk

`func (o *V12SubnetsSubnetPoolStaticRoute) GetPrefixlenOk() (*int32, bool)`

GetPrefixlenOk returns a tuple with the Prefixlen field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrefixlen

`func (o *V12SubnetsSubnetPoolStaticRoute) SetPrefixlen(v int32)`

SetPrefixlen sets Prefixlen field to given value.


### GetSubnet

`func (o *V12SubnetsSubnetPoolStaticRoute) GetSubnet() string`

GetSubnet returns the Subnet field if non-nil, zero value otherwise.

### GetSubnetOk

`func (o *V12SubnetsSubnetPoolStaticRoute) GetSubnetOk() (*string, bool)`

GetSubnetOk returns a tuple with the Subnet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSubnet

`func (o *V12SubnetsSubnetPoolStaticRoute) SetSubnet(v string)`

SetSubnet sets Subnet field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


