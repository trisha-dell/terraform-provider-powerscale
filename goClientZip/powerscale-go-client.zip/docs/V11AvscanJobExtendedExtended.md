# V11AvscanJobExtendedExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Description** | Pointer to **string** | Free-form customer description of job. | [optional] 
**Enabled** | Pointer to **bool** | Whether the job is enabled. | [optional] 
**FileExtensionAction** | Pointer to **string** | When a file matches an entry in the list of file extensions, do we include or exclude it?. | [optional] 
**FileExtensions** | Pointer to **[]string** | Array of file extensions to use in scanning decision. | [optional] 
**Id** | Pointer to **string** | A unique identifier for the job. | [optional] 
**IgnorePreviousScanStatus** | Pointer to **bool** | If True, force a scan of a previously scanned file. | [optional] 
**Impact** | Pointer to **string** | Specifies an impact policy for the antivirus scan jobs. | [optional] 
**NewName** | Pointer to **string** | New unique short name for job. | [optional] 
**PathsToExclude** | Pointer to **[]string** | Array of relative paths under paths_to_include not to scan. | [optional] 
**PathsToInclude** | Pointer to **[]string** | Array of absolute paths under /ifs to scan. | [optional] 
**ScanCloudpoolFiles** | Pointer to **bool** | Perform real-time scans of cloudpool files? | [optional] 
**ScanIfNoExtension** | Pointer to **bool** | Scan files without extensions? | [optional] 
**Schedule** | Pointer to **string** | The ever-unfortunate &#39;schedule&#39; string type, e.g. &#39;every Thursday at 01:00&#39;. | [optional] 

## Methods

### NewV11AvscanJobExtendedExtended

`func NewV11AvscanJobExtendedExtended() *V11AvscanJobExtendedExtended`

NewV11AvscanJobExtendedExtended instantiates a new V11AvscanJobExtendedExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11AvscanJobExtendedExtendedWithDefaults

`func NewV11AvscanJobExtendedExtendedWithDefaults() *V11AvscanJobExtendedExtended`

NewV11AvscanJobExtendedExtendedWithDefaults instantiates a new V11AvscanJobExtendedExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDescription

`func (o *V11AvscanJobExtendedExtended) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V11AvscanJobExtendedExtended) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V11AvscanJobExtendedExtended) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *V11AvscanJobExtendedExtended) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetEnabled

`func (o *V11AvscanJobExtendedExtended) GetEnabled() bool`

GetEnabled returns the Enabled field if non-nil, zero value otherwise.

### GetEnabledOk

`func (o *V11AvscanJobExtendedExtended) GetEnabledOk() (*bool, bool)`

GetEnabledOk returns a tuple with the Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabled

`func (o *V11AvscanJobExtendedExtended) SetEnabled(v bool)`

SetEnabled sets Enabled field to given value.

### HasEnabled

`func (o *V11AvscanJobExtendedExtended) HasEnabled() bool`

HasEnabled returns a boolean if a field has been set.

### GetFileExtensionAction

`func (o *V11AvscanJobExtendedExtended) GetFileExtensionAction() string`

GetFileExtensionAction returns the FileExtensionAction field if non-nil, zero value otherwise.

### GetFileExtensionActionOk

`func (o *V11AvscanJobExtendedExtended) GetFileExtensionActionOk() (*string, bool)`

GetFileExtensionActionOk returns a tuple with the FileExtensionAction field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFileExtensionAction

`func (o *V11AvscanJobExtendedExtended) SetFileExtensionAction(v string)`

SetFileExtensionAction sets FileExtensionAction field to given value.

### HasFileExtensionAction

`func (o *V11AvscanJobExtendedExtended) HasFileExtensionAction() bool`

HasFileExtensionAction returns a boolean if a field has been set.

### GetFileExtensions

`func (o *V11AvscanJobExtendedExtended) GetFileExtensions() []string`

GetFileExtensions returns the FileExtensions field if non-nil, zero value otherwise.

### GetFileExtensionsOk

`func (o *V11AvscanJobExtendedExtended) GetFileExtensionsOk() (*[]string, bool)`

GetFileExtensionsOk returns a tuple with the FileExtensions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFileExtensions

`func (o *V11AvscanJobExtendedExtended) SetFileExtensions(v []string)`

SetFileExtensions sets FileExtensions field to given value.

### HasFileExtensions

`func (o *V11AvscanJobExtendedExtended) HasFileExtensions() bool`

HasFileExtensions returns a boolean if a field has been set.

### GetId

`func (o *V11AvscanJobExtendedExtended) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V11AvscanJobExtendedExtended) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V11AvscanJobExtendedExtended) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V11AvscanJobExtendedExtended) HasId() bool`

HasId returns a boolean if a field has been set.

### GetIgnorePreviousScanStatus

`func (o *V11AvscanJobExtendedExtended) GetIgnorePreviousScanStatus() bool`

GetIgnorePreviousScanStatus returns the IgnorePreviousScanStatus field if non-nil, zero value otherwise.

### GetIgnorePreviousScanStatusOk

`func (o *V11AvscanJobExtendedExtended) GetIgnorePreviousScanStatusOk() (*bool, bool)`

GetIgnorePreviousScanStatusOk returns a tuple with the IgnorePreviousScanStatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIgnorePreviousScanStatus

`func (o *V11AvscanJobExtendedExtended) SetIgnorePreviousScanStatus(v bool)`

SetIgnorePreviousScanStatus sets IgnorePreviousScanStatus field to given value.

### HasIgnorePreviousScanStatus

`func (o *V11AvscanJobExtendedExtended) HasIgnorePreviousScanStatus() bool`

HasIgnorePreviousScanStatus returns a boolean if a field has been set.

### GetImpact

`func (o *V11AvscanJobExtendedExtended) GetImpact() string`

GetImpact returns the Impact field if non-nil, zero value otherwise.

### GetImpactOk

`func (o *V11AvscanJobExtendedExtended) GetImpactOk() (*string, bool)`

GetImpactOk returns a tuple with the Impact field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetImpact

`func (o *V11AvscanJobExtendedExtended) SetImpact(v string)`

SetImpact sets Impact field to given value.

### HasImpact

`func (o *V11AvscanJobExtendedExtended) HasImpact() bool`

HasImpact returns a boolean if a field has been set.

### GetNewName

`func (o *V11AvscanJobExtendedExtended) GetNewName() string`

GetNewName returns the NewName field if non-nil, zero value otherwise.

### GetNewNameOk

`func (o *V11AvscanJobExtendedExtended) GetNewNameOk() (*string, bool)`

GetNewNameOk returns a tuple with the NewName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNewName

`func (o *V11AvscanJobExtendedExtended) SetNewName(v string)`

SetNewName sets NewName field to given value.

### HasNewName

`func (o *V11AvscanJobExtendedExtended) HasNewName() bool`

HasNewName returns a boolean if a field has been set.

### GetPathsToExclude

`func (o *V11AvscanJobExtendedExtended) GetPathsToExclude() []string`

GetPathsToExclude returns the PathsToExclude field if non-nil, zero value otherwise.

### GetPathsToExcludeOk

`func (o *V11AvscanJobExtendedExtended) GetPathsToExcludeOk() (*[]string, bool)`

GetPathsToExcludeOk returns a tuple with the PathsToExclude field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPathsToExclude

`func (o *V11AvscanJobExtendedExtended) SetPathsToExclude(v []string)`

SetPathsToExclude sets PathsToExclude field to given value.

### HasPathsToExclude

`func (o *V11AvscanJobExtendedExtended) HasPathsToExclude() bool`

HasPathsToExclude returns a boolean if a field has been set.

### GetPathsToInclude

`func (o *V11AvscanJobExtendedExtended) GetPathsToInclude() []string`

GetPathsToInclude returns the PathsToInclude field if non-nil, zero value otherwise.

### GetPathsToIncludeOk

`func (o *V11AvscanJobExtendedExtended) GetPathsToIncludeOk() (*[]string, bool)`

GetPathsToIncludeOk returns a tuple with the PathsToInclude field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPathsToInclude

`func (o *V11AvscanJobExtendedExtended) SetPathsToInclude(v []string)`

SetPathsToInclude sets PathsToInclude field to given value.

### HasPathsToInclude

`func (o *V11AvscanJobExtendedExtended) HasPathsToInclude() bool`

HasPathsToInclude returns a boolean if a field has been set.

### GetScanCloudpoolFiles

`func (o *V11AvscanJobExtendedExtended) GetScanCloudpoolFiles() bool`

GetScanCloudpoolFiles returns the ScanCloudpoolFiles field if non-nil, zero value otherwise.

### GetScanCloudpoolFilesOk

`func (o *V11AvscanJobExtendedExtended) GetScanCloudpoolFilesOk() (*bool, bool)`

GetScanCloudpoolFilesOk returns a tuple with the ScanCloudpoolFiles field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanCloudpoolFiles

`func (o *V11AvscanJobExtendedExtended) SetScanCloudpoolFiles(v bool)`

SetScanCloudpoolFiles sets ScanCloudpoolFiles field to given value.

### HasScanCloudpoolFiles

`func (o *V11AvscanJobExtendedExtended) HasScanCloudpoolFiles() bool`

HasScanCloudpoolFiles returns a boolean if a field has been set.

### GetScanIfNoExtension

`func (o *V11AvscanJobExtendedExtended) GetScanIfNoExtension() bool`

GetScanIfNoExtension returns the ScanIfNoExtension field if non-nil, zero value otherwise.

### GetScanIfNoExtensionOk

`func (o *V11AvscanJobExtendedExtended) GetScanIfNoExtensionOk() (*bool, bool)`

GetScanIfNoExtensionOk returns a tuple with the ScanIfNoExtension field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanIfNoExtension

`func (o *V11AvscanJobExtendedExtended) SetScanIfNoExtension(v bool)`

SetScanIfNoExtension sets ScanIfNoExtension field to given value.

### HasScanIfNoExtension

`func (o *V11AvscanJobExtendedExtended) HasScanIfNoExtension() bool`

HasScanIfNoExtension returns a boolean if a field has been set.

### GetSchedule

`func (o *V11AvscanJobExtendedExtended) GetSchedule() string`

GetSchedule returns the Schedule field if non-nil, zero value otherwise.

### GetScheduleOk

`func (o *V11AvscanJobExtendedExtended) GetScheduleOk() (*string, bool)`

GetScheduleOk returns a tuple with the Schedule field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSchedule

`func (o *V11AvscanJobExtendedExtended) SetSchedule(v string)`

SetSchedule sets Schedule field to given value.

### HasSchedule

`func (o *V11AvscanJobExtendedExtended) HasSchedule() bool`

HasSchedule returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


