# V10ClusterNodeStatus

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Batterystatus** | Pointer to [**V10ClusterNodeStatusBatterystatus**](V10ClusterNodeStatusBatterystatus.md) |  | [optional] 
**Capacity** | Pointer to [**[]V10ClusterNodeStatusCapacityItem**](V10ClusterNodeStatusCapacityItem.md) | Storage capacity of this node. | [optional] 
**Cpu** | Pointer to [**V10ClusterNodeStatusCpu**](V10ClusterNodeStatusCpu.md) |  | [optional] 
**Nvram** | Pointer to [**V10ClusterNodeStatusNvram**](V10ClusterNodeStatusNvram.md) |  | [optional] 
**Powersupplies** | Pointer to [**V10ClusterNodeStatusPowersupplies**](V10ClusterNodeStatusPowersupplies.md) |  | [optional] 
**Release** | Pointer to **string** | OneFS release. | [optional] 
**Uptime** | Pointer to **int32** | Seconds this node has been online. | [optional] 
**Version** | Pointer to **string** | OneFS version. | [optional] 

## Methods

### NewV10ClusterNodeStatus

`func NewV10ClusterNodeStatus() *V10ClusterNodeStatus`

NewV10ClusterNodeStatus instantiates a new V10ClusterNodeStatus object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeStatusWithDefaults

`func NewV10ClusterNodeStatusWithDefaults() *V10ClusterNodeStatus`

NewV10ClusterNodeStatusWithDefaults instantiates a new V10ClusterNodeStatus object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBatterystatus

`func (o *V10ClusterNodeStatus) GetBatterystatus() V10ClusterNodeStatusBatterystatus`

GetBatterystatus returns the Batterystatus field if non-nil, zero value otherwise.

### GetBatterystatusOk

`func (o *V10ClusterNodeStatus) GetBatterystatusOk() (*V10ClusterNodeStatusBatterystatus, bool)`

GetBatterystatusOk returns a tuple with the Batterystatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBatterystatus

`func (o *V10ClusterNodeStatus) SetBatterystatus(v V10ClusterNodeStatusBatterystatus)`

SetBatterystatus sets Batterystatus field to given value.

### HasBatterystatus

`func (o *V10ClusterNodeStatus) HasBatterystatus() bool`

HasBatterystatus returns a boolean if a field has been set.

### GetCapacity

`func (o *V10ClusterNodeStatus) GetCapacity() []V10ClusterNodeStatusCapacityItem`

GetCapacity returns the Capacity field if non-nil, zero value otherwise.

### GetCapacityOk

`func (o *V10ClusterNodeStatus) GetCapacityOk() (*[]V10ClusterNodeStatusCapacityItem, bool)`

GetCapacityOk returns a tuple with the Capacity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCapacity

`func (o *V10ClusterNodeStatus) SetCapacity(v []V10ClusterNodeStatusCapacityItem)`

SetCapacity sets Capacity field to given value.

### HasCapacity

`func (o *V10ClusterNodeStatus) HasCapacity() bool`

HasCapacity returns a boolean if a field has been set.

### GetCpu

`func (o *V10ClusterNodeStatus) GetCpu() V10ClusterNodeStatusCpu`

GetCpu returns the Cpu field if non-nil, zero value otherwise.

### GetCpuOk

`func (o *V10ClusterNodeStatus) GetCpuOk() (*V10ClusterNodeStatusCpu, bool)`

GetCpuOk returns a tuple with the Cpu field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCpu

`func (o *V10ClusterNodeStatus) SetCpu(v V10ClusterNodeStatusCpu)`

SetCpu sets Cpu field to given value.

### HasCpu

`func (o *V10ClusterNodeStatus) HasCpu() bool`

HasCpu returns a boolean if a field has been set.

### GetNvram

`func (o *V10ClusterNodeStatus) GetNvram() V10ClusterNodeStatusNvram`

GetNvram returns the Nvram field if non-nil, zero value otherwise.

### GetNvramOk

`func (o *V10ClusterNodeStatus) GetNvramOk() (*V10ClusterNodeStatusNvram, bool)`

GetNvramOk returns a tuple with the Nvram field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNvram

`func (o *V10ClusterNodeStatus) SetNvram(v V10ClusterNodeStatusNvram)`

SetNvram sets Nvram field to given value.

### HasNvram

`func (o *V10ClusterNodeStatus) HasNvram() bool`

HasNvram returns a boolean if a field has been set.

### GetPowersupplies

`func (o *V10ClusterNodeStatus) GetPowersupplies() V10ClusterNodeStatusPowersupplies`

GetPowersupplies returns the Powersupplies field if non-nil, zero value otherwise.

### GetPowersuppliesOk

`func (o *V10ClusterNodeStatus) GetPowersuppliesOk() (*V10ClusterNodeStatusPowersupplies, bool)`

GetPowersuppliesOk returns a tuple with the Powersupplies field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPowersupplies

`func (o *V10ClusterNodeStatus) SetPowersupplies(v V10ClusterNodeStatusPowersupplies)`

SetPowersupplies sets Powersupplies field to given value.

### HasPowersupplies

`func (o *V10ClusterNodeStatus) HasPowersupplies() bool`

HasPowersupplies returns a boolean if a field has been set.

### GetRelease

`func (o *V10ClusterNodeStatus) GetRelease() string`

GetRelease returns the Release field if non-nil, zero value otherwise.

### GetReleaseOk

`func (o *V10ClusterNodeStatus) GetReleaseOk() (*string, bool)`

GetReleaseOk returns a tuple with the Release field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRelease

`func (o *V10ClusterNodeStatus) SetRelease(v string)`

SetRelease sets Release field to given value.

### HasRelease

`func (o *V10ClusterNodeStatus) HasRelease() bool`

HasRelease returns a boolean if a field has been set.

### GetUptime

`func (o *V10ClusterNodeStatus) GetUptime() int32`

GetUptime returns the Uptime field if non-nil, zero value otherwise.

### GetUptimeOk

`func (o *V10ClusterNodeStatus) GetUptimeOk() (*int32, bool)`

GetUptimeOk returns a tuple with the Uptime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUptime

`func (o *V10ClusterNodeStatus) SetUptime(v int32)`

SetUptime sets Uptime field to given value.

### HasUptime

`func (o *V10ClusterNodeStatus) HasUptime() bool`

HasUptime returns a boolean if a field has been set.

### GetVersion

`func (o *V10ClusterNodeStatus) GetVersion() string`

GetVersion returns the Version field if non-nil, zero value otherwise.

### GetVersionOk

`func (o *V10ClusterNodeStatus) GetVersionOk() (*string, bool)`

GetVersionOk returns a tuple with the Version field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVersion

`func (o *V10ClusterNodeStatus) SetVersion(v string)`

SetVersion sets Version field to given value.

### HasVersion

`func (o *V10ClusterNodeStatus) HasVersion() bool`

HasVersion returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


