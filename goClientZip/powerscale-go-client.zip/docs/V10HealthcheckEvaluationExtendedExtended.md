# V10HealthcheckEvaluationExtendedExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Action** | Pointer to **string** | Pause or Resume | [optional] 

## Methods

### NewV10HealthcheckEvaluationExtendedExtended

`func NewV10HealthcheckEvaluationExtendedExtended() *V10HealthcheckEvaluationExtendedExtended`

NewV10HealthcheckEvaluationExtendedExtended instantiates a new V10HealthcheckEvaluationExtendedExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10HealthcheckEvaluationExtendedExtendedWithDefaults

`func NewV10HealthcheckEvaluationExtendedExtendedWithDefaults() *V10HealthcheckEvaluationExtendedExtended`

NewV10HealthcheckEvaluationExtendedExtendedWithDefaults instantiates a new V10HealthcheckEvaluationExtendedExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAction

`func (o *V10HealthcheckEvaluationExtendedExtended) GetAction() string`

GetAction returns the Action field if non-nil, zero value otherwise.

### GetActionOk

`func (o *V10HealthcheckEvaluationExtendedExtended) GetActionOk() (*string, bool)`

GetActionOk returns a tuple with the Action field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAction

`func (o *V10HealthcheckEvaluationExtendedExtended) SetAction(v string)`

SetAction sets Action field to given value.

### HasAction

`func (o *V10HealthcheckEvaluationExtendedExtended) HasAction() bool`

HasAction returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


