# V12GroupnetSubnet

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AddrFamily** | **string** | IP address format. | 
**Description** | Pointer to **string** | A description of the subnet. | [optional] 
**DsrAddrs** | Pointer to **[]string** | List of Direct Server Return addresses. | [optional] 
**Gateway** | Pointer to **string** | Gateway IP address. | [optional] 
**GatewayPriority** | Pointer to **int32** | Gateway priority. | [optional] 
**Mtu** | Pointer to **int32** | MTU of the subnet. | [optional] 
**Name** | **string** | The name of the subnet. | 
**Prefixlen** | **int32** | Subnet Prefix Length. | 
**ScServiceAddrs** | Pointer to [**[]V12GroupnetSubnetScServiceAddr**](V12GroupnetSubnetScServiceAddr.md) | List of IP addresses that SmartConnect listens for DNS requests. | [optional] 
**ScServiceName** | Pointer to **string** | Domain Name corresponding to the SmartConnect Service Address. | [optional] 
**VlanEnabled** | Pointer to **bool** | VLAN tagging enabled or disabled. | [optional] 
**VlanId** | Pointer to **int32** | VLAN ID for all interfaces in the subnet. | [optional] 

## Methods

### NewV12GroupnetSubnet

`func NewV12GroupnetSubnet(addrFamily string, name string, prefixlen int32, ) *V12GroupnetSubnet`

NewV12GroupnetSubnet instantiates a new V12GroupnetSubnet object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12GroupnetSubnetWithDefaults

`func NewV12GroupnetSubnetWithDefaults() *V12GroupnetSubnet`

NewV12GroupnetSubnetWithDefaults instantiates a new V12GroupnetSubnet object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAddrFamily

`func (o *V12GroupnetSubnet) GetAddrFamily() string`

GetAddrFamily returns the AddrFamily field if non-nil, zero value otherwise.

### GetAddrFamilyOk

`func (o *V12GroupnetSubnet) GetAddrFamilyOk() (*string, bool)`

GetAddrFamilyOk returns a tuple with the AddrFamily field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddrFamily

`func (o *V12GroupnetSubnet) SetAddrFamily(v string)`

SetAddrFamily sets AddrFamily field to given value.


### GetDescription

`func (o *V12GroupnetSubnet) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V12GroupnetSubnet) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V12GroupnetSubnet) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *V12GroupnetSubnet) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetDsrAddrs

`func (o *V12GroupnetSubnet) GetDsrAddrs() []string`

GetDsrAddrs returns the DsrAddrs field if non-nil, zero value otherwise.

### GetDsrAddrsOk

`func (o *V12GroupnetSubnet) GetDsrAddrsOk() (*[]string, bool)`

GetDsrAddrsOk returns a tuple with the DsrAddrs field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDsrAddrs

`func (o *V12GroupnetSubnet) SetDsrAddrs(v []string)`

SetDsrAddrs sets DsrAddrs field to given value.

### HasDsrAddrs

`func (o *V12GroupnetSubnet) HasDsrAddrs() bool`

HasDsrAddrs returns a boolean if a field has been set.

### GetGateway

`func (o *V12GroupnetSubnet) GetGateway() string`

GetGateway returns the Gateway field if non-nil, zero value otherwise.

### GetGatewayOk

`func (o *V12GroupnetSubnet) GetGatewayOk() (*string, bool)`

GetGatewayOk returns a tuple with the Gateway field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGateway

`func (o *V12GroupnetSubnet) SetGateway(v string)`

SetGateway sets Gateway field to given value.

### HasGateway

`func (o *V12GroupnetSubnet) HasGateway() bool`

HasGateway returns a boolean if a field has been set.

### GetGatewayPriority

`func (o *V12GroupnetSubnet) GetGatewayPriority() int32`

GetGatewayPriority returns the GatewayPriority field if non-nil, zero value otherwise.

### GetGatewayPriorityOk

`func (o *V12GroupnetSubnet) GetGatewayPriorityOk() (*int32, bool)`

GetGatewayPriorityOk returns a tuple with the GatewayPriority field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGatewayPriority

`func (o *V12GroupnetSubnet) SetGatewayPriority(v int32)`

SetGatewayPriority sets GatewayPriority field to given value.

### HasGatewayPriority

`func (o *V12GroupnetSubnet) HasGatewayPriority() bool`

HasGatewayPriority returns a boolean if a field has been set.

### GetMtu

`func (o *V12GroupnetSubnet) GetMtu() int32`

GetMtu returns the Mtu field if non-nil, zero value otherwise.

### GetMtuOk

`func (o *V12GroupnetSubnet) GetMtuOk() (*int32, bool)`

GetMtuOk returns a tuple with the Mtu field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMtu

`func (o *V12GroupnetSubnet) SetMtu(v int32)`

SetMtu sets Mtu field to given value.

### HasMtu

`func (o *V12GroupnetSubnet) HasMtu() bool`

HasMtu returns a boolean if a field has been set.

### GetName

`func (o *V12GroupnetSubnet) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V12GroupnetSubnet) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V12GroupnetSubnet) SetName(v string)`

SetName sets Name field to given value.


### GetPrefixlen

`func (o *V12GroupnetSubnet) GetPrefixlen() int32`

GetPrefixlen returns the Prefixlen field if non-nil, zero value otherwise.

### GetPrefixlenOk

`func (o *V12GroupnetSubnet) GetPrefixlenOk() (*int32, bool)`

GetPrefixlenOk returns a tuple with the Prefixlen field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrefixlen

`func (o *V12GroupnetSubnet) SetPrefixlen(v int32)`

SetPrefixlen sets Prefixlen field to given value.


### GetScServiceAddrs

`func (o *V12GroupnetSubnet) GetScServiceAddrs() []V12GroupnetSubnetScServiceAddr`

GetScServiceAddrs returns the ScServiceAddrs field if non-nil, zero value otherwise.

### GetScServiceAddrsOk

`func (o *V12GroupnetSubnet) GetScServiceAddrsOk() (*[]V12GroupnetSubnetScServiceAddr, bool)`

GetScServiceAddrsOk returns a tuple with the ScServiceAddrs field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScServiceAddrs

`func (o *V12GroupnetSubnet) SetScServiceAddrs(v []V12GroupnetSubnetScServiceAddr)`

SetScServiceAddrs sets ScServiceAddrs field to given value.

### HasScServiceAddrs

`func (o *V12GroupnetSubnet) HasScServiceAddrs() bool`

HasScServiceAddrs returns a boolean if a field has been set.

### GetScServiceName

`func (o *V12GroupnetSubnet) GetScServiceName() string`

GetScServiceName returns the ScServiceName field if non-nil, zero value otherwise.

### GetScServiceNameOk

`func (o *V12GroupnetSubnet) GetScServiceNameOk() (*string, bool)`

GetScServiceNameOk returns a tuple with the ScServiceName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScServiceName

`func (o *V12GroupnetSubnet) SetScServiceName(v string)`

SetScServiceName sets ScServiceName field to given value.

### HasScServiceName

`func (o *V12GroupnetSubnet) HasScServiceName() bool`

HasScServiceName returns a boolean if a field has been set.

### GetVlanEnabled

`func (o *V12GroupnetSubnet) GetVlanEnabled() bool`

GetVlanEnabled returns the VlanEnabled field if non-nil, zero value otherwise.

### GetVlanEnabledOk

`func (o *V12GroupnetSubnet) GetVlanEnabledOk() (*bool, bool)`

GetVlanEnabledOk returns a tuple with the VlanEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVlanEnabled

`func (o *V12GroupnetSubnet) SetVlanEnabled(v bool)`

SetVlanEnabled sets VlanEnabled field to given value.

### HasVlanEnabled

`func (o *V12GroupnetSubnet) HasVlanEnabled() bool`

HasVlanEnabled returns a boolean if a field has been set.

### GetVlanId

`func (o *V12GroupnetSubnet) GetVlanId() int32`

GetVlanId returns the VlanId field if non-nil, zero value otherwise.

### GetVlanIdOk

`func (o *V12GroupnetSubnet) GetVlanIdOk() (*int32, bool)`

GetVlanIdOk returns a tuple with the VlanId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVlanId

`func (o *V12GroupnetSubnet) SetVlanId(v int32)`

SetVlanId sets VlanId field to given value.

### HasVlanId

`func (o *V12GroupnetSubnet) HasVlanId() bool`

HasVlanId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


