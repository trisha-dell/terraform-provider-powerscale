# \UpgradeClusterApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateUpgradeClusterv4NodesNodePatchSyncItem**](UpgradeClusterApi.md#CreateUpgradeClusterv4NodesNodePatchSyncItem) | **Post** /platform/4/upgrade/cluster/nodes/{Lnn}/patch/sync | 
[**GetUpgradeClusterv10NodesNodeFirmwareDevice**](UpgradeClusterApi.md#GetUpgradeClusterv10NodesNodeFirmwareDevice) | **Get** /platform/10/upgrade/cluster/nodes/{Lnn}/firmware/device | 
[**GetUpgradeClusterv10NodesNodeFirmwareStatus**](UpgradeClusterApi.md#GetUpgradeClusterv10NodesNodeFirmwareStatus) | **Get** /platform/10/upgrade/cluster/nodes/{Lnn}/firmware/status | 
[**GetUpgradeClusterv3NodesNodeFirmwareStatus**](UpgradeClusterApi.md#GetUpgradeClusterv3NodesNodeFirmwareStatus) | **Get** /platform/3/upgrade/cluster/nodes/{Lnn}/firmware/status | 



## CreateUpgradeClusterv4NodesNodePatchSyncItem

> map[string]interface{} CreateUpgradeClusterv4NodesNodePatchSyncItem(ctx, lnn).V4NodesNodePatchSyncItem(v4NodesNodePatchSyncItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    v4NodesNodePatchSyncItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeClusterApi.CreateUpgradeClusterv4NodesNodePatchSyncItem(context.Background(), lnn).V4NodesNodePatchSyncItem(v4NodesNodePatchSyncItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeClusterApi.CreateUpgradeClusterv4NodesNodePatchSyncItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradeClusterv4NodesNodePatchSyncItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `UpgradeClusterApi.CreateUpgradeClusterv4NodesNodePatchSyncItem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradeClusterv4NodesNodePatchSyncItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v4NodesNodePatchSyncItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUpgradeClusterv10NodesNodeFirmwareDevice

> V10NodesNodeFirmwareDevice GetUpgradeClusterv10NodesNodeFirmwareDevice(ctx, lnn).Devices(devices).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    devices := true // bool | Show devices. If false, this returns an empty list. Default is false. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeClusterApi.GetUpgradeClusterv10NodesNodeFirmwareDevice(context.Background(), lnn).Devices(devices).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeClusterApi.GetUpgradeClusterv10NodesNodeFirmwareDevice``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUpgradeClusterv10NodesNodeFirmwareDevice`: V10NodesNodeFirmwareDevice
    fmt.Fprintf(os.Stdout, "Response from `UpgradeClusterApi.GetUpgradeClusterv10NodesNodeFirmwareDevice`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetUpgradeClusterv10NodesNodeFirmwareDeviceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **devices** | **bool** | Show devices. If false, this returns an empty list. Default is false. | 

### Return type

[**V10NodesNodeFirmwareDevice**](V10NodesNodeFirmwareDevice.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUpgradeClusterv10NodesNodeFirmwareStatus

> V10NodesNodeFirmwareDevice GetUpgradeClusterv10NodesNodeFirmwareStatus(ctx, lnn).Devices(devices).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    devices := true // bool | Show devices. If false, this returns an empty list. Default is false. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeClusterApi.GetUpgradeClusterv10NodesNodeFirmwareStatus(context.Background(), lnn).Devices(devices).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeClusterApi.GetUpgradeClusterv10NodesNodeFirmwareStatus``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUpgradeClusterv10NodesNodeFirmwareStatus`: V10NodesNodeFirmwareDevice
    fmt.Fprintf(os.Stdout, "Response from `UpgradeClusterApi.GetUpgradeClusterv10NodesNodeFirmwareStatus`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetUpgradeClusterv10NodesNodeFirmwareStatusRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **devices** | **bool** | Show devices. If false, this returns an empty list. Default is false. | 

### Return type

[**V10NodesNodeFirmwareDevice**](V10NodesNodeFirmwareDevice.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUpgradeClusterv3NodesNodeFirmwareStatus

> V3NodesNodeFirmwareStatus GetUpgradeClusterv3NodesNodeFirmwareStatus(ctx, lnn).Devices(devices).Package_(package_).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    devices := true // bool | Show devices. If false, this returns an empty list. Default is false. (optional)
    package_ := true // bool | Show package. If false, this returns an empty list.Default is false. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeClusterApi.GetUpgradeClusterv3NodesNodeFirmwareStatus(context.Background(), lnn).Devices(devices).Package_(package_).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeClusterApi.GetUpgradeClusterv3NodesNodeFirmwareStatus``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUpgradeClusterv3NodesNodeFirmwareStatus`: V3NodesNodeFirmwareStatus
    fmt.Fprintf(os.Stdout, "Response from `UpgradeClusterApi.GetUpgradeClusterv3NodesNodeFirmwareStatus`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetUpgradeClusterv3NodesNodeFirmwareStatusRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **devices** | **bool** | Show devices. If false, this returns an empty list. Default is false. | 
 **package_** | **bool** | Show package. If false, this returns an empty list.Default is false. | 

### Return type

[**V3NodesNodeFirmwareStatus**](V3NodesNodeFirmwareStatus.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

