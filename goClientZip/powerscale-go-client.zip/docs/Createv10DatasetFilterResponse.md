# Createv10DatasetFilterResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | The filter ID. Unique and automatically assigned. | 
**Name** | Pointer to **string** | The name of the filter. User specified. | [optional] 

## Methods

### NewCreatev10DatasetFilterResponse

`func NewCreatev10DatasetFilterResponse(id int32, ) *Createv10DatasetFilterResponse`

NewCreatev10DatasetFilterResponse instantiates a new Createv10DatasetFilterResponse object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev10DatasetFilterResponseWithDefaults

`func NewCreatev10DatasetFilterResponseWithDefaults() *Createv10DatasetFilterResponse`

NewCreatev10DatasetFilterResponseWithDefaults instantiates a new Createv10DatasetFilterResponse object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *Createv10DatasetFilterResponse) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *Createv10DatasetFilterResponse) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *Createv10DatasetFilterResponse) SetId(v int32)`

SetId sets Id field to given value.


### GetName

`func (o *Createv10DatasetFilterResponse) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *Createv10DatasetFilterResponse) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *Createv10DatasetFilterResponse) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *Createv10DatasetFilterResponse) HasName() bool`

HasName returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


