# V10HealthcheckChecklists

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Checklists** | Pointer to [**[]V10HealthcheckChecklist**](V10HealthcheckChecklist.md) |  | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV10HealthcheckChecklists

`func NewV10HealthcheckChecklists() *V10HealthcheckChecklists`

NewV10HealthcheckChecklists instantiates a new V10HealthcheckChecklists object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10HealthcheckChecklistsWithDefaults

`func NewV10HealthcheckChecklistsWithDefaults() *V10HealthcheckChecklists`

NewV10HealthcheckChecklistsWithDefaults instantiates a new V10HealthcheckChecklists object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetChecklists

`func (o *V10HealthcheckChecklists) GetChecklists() []V10HealthcheckChecklist`

GetChecklists returns the Checklists field if non-nil, zero value otherwise.

### GetChecklistsOk

`func (o *V10HealthcheckChecklists) GetChecklistsOk() (*[]V10HealthcheckChecklist, bool)`

GetChecklistsOk returns a tuple with the Checklists field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChecklists

`func (o *V10HealthcheckChecklists) SetChecklists(v []V10HealthcheckChecklist)`

SetChecklists sets Checklists field to given value.

### HasChecklists

`func (o *V10HealthcheckChecklists) HasChecklists() bool`

HasChecklists returns a boolean if a field has been set.

### GetResume

`func (o *V10HealthcheckChecklists) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V10HealthcheckChecklists) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V10HealthcheckChecklists) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V10HealthcheckChecklists) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V10HealthcheckChecklists) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V10HealthcheckChecklists) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V10HealthcheckChecklists) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V10HealthcheckChecklists) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


