# V10HealthcheckEvaluationExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ChecklistId** | Pointer to **string** | Checklist to be run | [optional] 
**Delivery** | Pointer to [**[]V10HealthcheckChecklistDeliveryItem**](V10HealthcheckChecklistDeliveryItem.md) | List of delivery addresses/methods for results | [optional] 
**Details** | Pointer to [**[]V10HealthcheckEvaluationDetail**](V10HealthcheckEvaluationDetail.md) | Evaluation results by item - only if COMPLETED | [optional] 
**Id** | Pointer to **string** | Unique identifier | [optional] 
**Overrides** | Pointer to [**[]V10HealthcheckEvaluationOverride**](V10HealthcheckEvaluationOverride.md) | Optional overrides for thresholds etc. | [optional] 
**Parameters** | Pointer to **map[string]interface{}** |  | [optional] 
**Result** | Pointer to **string** | Overall result of evaluation - only if COMPLETED | [optional] 
**RunStatus** | Pointer to **string** | Execution status | [optional] 
**StartTime** | Pointer to **float32** | Specifies the start time for a checklist or item. | [optional] 

## Methods

### NewV10HealthcheckEvaluationExtended

`func NewV10HealthcheckEvaluationExtended() *V10HealthcheckEvaluationExtended`

NewV10HealthcheckEvaluationExtended instantiates a new V10HealthcheckEvaluationExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10HealthcheckEvaluationExtendedWithDefaults

`func NewV10HealthcheckEvaluationExtendedWithDefaults() *V10HealthcheckEvaluationExtended`

NewV10HealthcheckEvaluationExtendedWithDefaults instantiates a new V10HealthcheckEvaluationExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetChecklistId

`func (o *V10HealthcheckEvaluationExtended) GetChecklistId() string`

GetChecklistId returns the ChecklistId field if non-nil, zero value otherwise.

### GetChecklistIdOk

`func (o *V10HealthcheckEvaluationExtended) GetChecklistIdOk() (*string, bool)`

GetChecklistIdOk returns a tuple with the ChecklistId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChecklistId

`func (o *V10HealthcheckEvaluationExtended) SetChecklistId(v string)`

SetChecklistId sets ChecklistId field to given value.

### HasChecklistId

`func (o *V10HealthcheckEvaluationExtended) HasChecklistId() bool`

HasChecklistId returns a boolean if a field has been set.

### GetDelivery

`func (o *V10HealthcheckEvaluationExtended) GetDelivery() []V10HealthcheckChecklistDeliveryItem`

GetDelivery returns the Delivery field if non-nil, zero value otherwise.

### GetDeliveryOk

`func (o *V10HealthcheckEvaluationExtended) GetDeliveryOk() (*[]V10HealthcheckChecklistDeliveryItem, bool)`

GetDeliveryOk returns a tuple with the Delivery field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDelivery

`func (o *V10HealthcheckEvaluationExtended) SetDelivery(v []V10HealthcheckChecklistDeliveryItem)`

SetDelivery sets Delivery field to given value.

### HasDelivery

`func (o *V10HealthcheckEvaluationExtended) HasDelivery() bool`

HasDelivery returns a boolean if a field has been set.

### GetDetails

`func (o *V10HealthcheckEvaluationExtended) GetDetails() []V10HealthcheckEvaluationDetail`

GetDetails returns the Details field if non-nil, zero value otherwise.

### GetDetailsOk

`func (o *V10HealthcheckEvaluationExtended) GetDetailsOk() (*[]V10HealthcheckEvaluationDetail, bool)`

GetDetailsOk returns a tuple with the Details field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDetails

`func (o *V10HealthcheckEvaluationExtended) SetDetails(v []V10HealthcheckEvaluationDetail)`

SetDetails sets Details field to given value.

### HasDetails

`func (o *V10HealthcheckEvaluationExtended) HasDetails() bool`

HasDetails returns a boolean if a field has been set.

### GetId

`func (o *V10HealthcheckEvaluationExtended) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V10HealthcheckEvaluationExtended) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V10HealthcheckEvaluationExtended) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V10HealthcheckEvaluationExtended) HasId() bool`

HasId returns a boolean if a field has been set.

### GetOverrides

`func (o *V10HealthcheckEvaluationExtended) GetOverrides() []V10HealthcheckEvaluationOverride`

GetOverrides returns the Overrides field if non-nil, zero value otherwise.

### GetOverridesOk

`func (o *V10HealthcheckEvaluationExtended) GetOverridesOk() (*[]V10HealthcheckEvaluationOverride, bool)`

GetOverridesOk returns a tuple with the Overrides field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOverrides

`func (o *V10HealthcheckEvaluationExtended) SetOverrides(v []V10HealthcheckEvaluationOverride)`

SetOverrides sets Overrides field to given value.

### HasOverrides

`func (o *V10HealthcheckEvaluationExtended) HasOverrides() bool`

HasOverrides returns a boolean if a field has been set.

### GetParameters

`func (o *V10HealthcheckEvaluationExtended) GetParameters() map[string]interface{}`

GetParameters returns the Parameters field if non-nil, zero value otherwise.

### GetParametersOk

`func (o *V10HealthcheckEvaluationExtended) GetParametersOk() (*map[string]interface{}, bool)`

GetParametersOk returns a tuple with the Parameters field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetParameters

`func (o *V10HealthcheckEvaluationExtended) SetParameters(v map[string]interface{})`

SetParameters sets Parameters field to given value.

### HasParameters

`func (o *V10HealthcheckEvaluationExtended) HasParameters() bool`

HasParameters returns a boolean if a field has been set.

### GetResult

`func (o *V10HealthcheckEvaluationExtended) GetResult() string`

GetResult returns the Result field if non-nil, zero value otherwise.

### GetResultOk

`func (o *V10HealthcheckEvaluationExtended) GetResultOk() (*string, bool)`

GetResultOk returns a tuple with the Result field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResult

`func (o *V10HealthcheckEvaluationExtended) SetResult(v string)`

SetResult sets Result field to given value.

### HasResult

`func (o *V10HealthcheckEvaluationExtended) HasResult() bool`

HasResult returns a boolean if a field has been set.

### GetRunStatus

`func (o *V10HealthcheckEvaluationExtended) GetRunStatus() string`

GetRunStatus returns the RunStatus field if non-nil, zero value otherwise.

### GetRunStatusOk

`func (o *V10HealthcheckEvaluationExtended) GetRunStatusOk() (*string, bool)`

GetRunStatusOk returns a tuple with the RunStatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRunStatus

`func (o *V10HealthcheckEvaluationExtended) SetRunStatus(v string)`

SetRunStatus sets RunStatus field to given value.

### HasRunStatus

`func (o *V10HealthcheckEvaluationExtended) HasRunStatus() bool`

HasRunStatus returns a boolean if a field has been set.

### GetStartTime

`func (o *V10HealthcheckEvaluationExtended) GetStartTime() float32`

GetStartTime returns the StartTime field if non-nil, zero value otherwise.

### GetStartTimeOk

`func (o *V10HealthcheckEvaluationExtended) GetStartTimeOk() (*float32, bool)`

GetStartTimeOk returns a tuple with the StartTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartTime

`func (o *V10HealthcheckEvaluationExtended) SetStartTime(v float32)`

SetStartTime sets StartTime field to given value.

### HasStartTime

`func (o *V10HealthcheckEvaluationExtended) HasStartTime() bool`

HasStartTime returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


