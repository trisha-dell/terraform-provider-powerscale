# \NetworkApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateNetworkv10NetworkGroupnet**](NetworkApi.md#CreateNetworkv10NetworkGroupnet) | **Post** /platform/10/network/groupnets | 
[**CreateNetworkv16FirewallPolicy**](NetworkApi.md#CreateNetworkv16FirewallPolicy) | **Post** /platform/16/network/firewall/policies | 
[**CreateNetworkv16FirewallResetGlobalPolicyItem**](NetworkApi.md#CreateNetworkv16FirewallResetGlobalPolicyItem) | **Post** /platform/16/network/firewall/reset-global-policy | 
[**CreateNetworkv3DnscacheFlushItem**](NetworkApi.md#CreateNetworkv3DnscacheFlushItem) | **Post** /platform/3/network/dnscache/flush | 
[**CreateNetworkv3NetworkGroupnet**](NetworkApi.md#CreateNetworkv3NetworkGroupnet) | **Post** /platform/3/network/groupnets | 
[**CreateNetworkv3NetworkScRebalanceAllItem**](NetworkApi.md#CreateNetworkv3NetworkScRebalanceAllItem) | **Post** /platform/3/network/sc-rebalance-all | 
[**DeleteNetworkv10NetworkGroupnet**](NetworkApi.md#DeleteNetworkv10NetworkGroupnet) | **Delete** /platform/10/network/groupnets/{v10NetworkGroupnetId} | 
[**DeleteNetworkv12GroupnetsGroupnetSubnetsSubnetPool**](NetworkApi.md#DeleteNetworkv12GroupnetsGroupnetSubnetsSubnetPool) | **Delete** /platform/12/network/groupnets/{Groupnet}/subnets/{Subnet}/pools/{v12GroupnetsGroupnetSubnetsSubnetPoolId} | 
[**DeleteNetworkv16FirewallPoliciesPolicyRule**](NetworkApi.md#DeleteNetworkv16FirewallPoliciesPolicyRule) | **Delete** /platform/16/network/firewall/policies/{Policy}/rules/{v16FirewallPoliciesPolicyRuleId} | 
[**DeleteNetworkv16FirewallPolicy**](NetworkApi.md#DeleteNetworkv16FirewallPolicy) | **Delete** /platform/16/network/firewall/policies/{v16FirewallPolicyId} | 
[**DeleteNetworkv16GroupnetsGroupnetSubnet**](NetworkApi.md#DeleteNetworkv16GroupnetsGroupnetSubnet) | **Delete** /platform/16/network/groupnets/{Groupnet}/subnets/{v16GroupnetsGroupnetSubnetId} | 
[**DeleteNetworkv16GroupnetsGroupnetSubnetsSubnetPool**](NetworkApi.md#DeleteNetworkv16GroupnetsGroupnetSubnetsSubnetPool) | **Delete** /platform/16/network/groupnets/{Groupnet}/subnets/{Subnet}/pools/{v16GroupnetsGroupnetSubnetsSubnetPoolId} | 
[**DeleteNetworkv3GroupnetsGroupnetSubnet**](NetworkApi.md#DeleteNetworkv3GroupnetsGroupnetSubnet) | **Delete** /platform/3/network/groupnets/{Groupnet}/subnets/{v3GroupnetsGroupnetSubnetId} | 
[**DeleteNetworkv3GroupnetsGroupnetSubnetsSubnetPool**](NetworkApi.md#DeleteNetworkv3GroupnetsGroupnetSubnetsSubnetPool) | **Delete** /platform/3/network/groupnets/{Groupnet}/subnets/{Subnet}/pools/{v3GroupnetsGroupnetSubnetsSubnetPoolId} | 
[**DeleteNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule**](NetworkApi.md#DeleteNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule) | **Delete** /platform/3/network/groupnets/{Groupnet}/subnets/{Subnet}/pools/{Pool}/rules/{v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRuleId} | 
[**DeleteNetworkv3NetworkGroupnet**](NetworkApi.md#DeleteNetworkv3NetworkGroupnet) | **Delete** /platform/3/network/groupnets/{v3NetworkGroupnetId} | 
[**DeleteNetworkv4GroupnetsGroupnetSubnet**](NetworkApi.md#DeleteNetworkv4GroupnetsGroupnetSubnet) | **Delete** /platform/4/network/groupnets/{Groupnet}/subnets/{v4GroupnetsGroupnetSubnetId} | 
[**DeleteNetworkv7GroupnetsGroupnetSubnet**](NetworkApi.md#DeleteNetworkv7GroupnetsGroupnetSubnet) | **Delete** /platform/7/network/groupnets/{Groupnet}/subnets/{v7GroupnetsGroupnetSubnetId} | 
[**GetNetworkv10NetworkGroupnet**](NetworkApi.md#GetNetworkv10NetworkGroupnet) | **Get** /platform/10/network/groupnets/{v10NetworkGroupnetId} | 
[**GetNetworkv12GroupnetsGroupnetSubnetsSubnetPool**](NetworkApi.md#GetNetworkv12GroupnetsGroupnetSubnetsSubnetPool) | **Get** /platform/12/network/groupnets/{Groupnet}/subnets/{Subnet}/pools/{v12GroupnetsGroupnetSubnetsSubnetPoolId} | 
[**GetNetworkv12NetworkExternal**](NetworkApi.md#GetNetworkv12NetworkExternal) | **Get** /platform/12/network/external | 
[**GetNetworkv12NetworkInterfaces**](NetworkApi.md#GetNetworkv12NetworkInterfaces) | **Get** /platform/12/network/interfaces | 
[**GetNetworkv12NetworkPools**](NetworkApi.md#GetNetworkv12NetworkPools) | **Get** /platform/12/network/pools | 
[**GetNetworkv14NetworkInterfaces**](NetworkApi.md#GetNetworkv14NetworkInterfaces) | **Get** /platform/14/network/interfaces | 
[**GetNetworkv16FirewallPoliciesPolicyRule**](NetworkApi.md#GetNetworkv16FirewallPoliciesPolicyRule) | **Get** /platform/16/network/firewall/policies/{Policy}/rules/{v16FirewallPoliciesPolicyRuleId} | 
[**GetNetworkv16FirewallPolicy**](NetworkApi.md#GetNetworkv16FirewallPolicy) | **Get** /platform/16/network/firewall/policies/{v16FirewallPolicyId} | 
[**GetNetworkv16FirewallRules**](NetworkApi.md#GetNetworkv16FirewallRules) | **Get** /platform/16/network/firewall/rules | 
[**GetNetworkv16FirewallServices**](NetworkApi.md#GetNetworkv16FirewallServices) | **Get** /platform/16/network/firewall/services | 
[**GetNetworkv16FirewallSettings**](NetworkApi.md#GetNetworkv16FirewallSettings) | **Get** /platform/16/network/firewall/settings | 
[**GetNetworkv16GroupnetsGroupnetSubnet**](NetworkApi.md#GetNetworkv16GroupnetsGroupnetSubnet) | **Get** /platform/16/network/groupnets/{Groupnet}/subnets/{v16GroupnetsGroupnetSubnetId} | 
[**GetNetworkv16GroupnetsGroupnetSubnetsSubnetPool**](NetworkApi.md#GetNetworkv16GroupnetsGroupnetSubnetsSubnetPool) | **Get** /platform/16/network/groupnets/{Groupnet}/subnets/{Subnet}/pools/{v16GroupnetsGroupnetSubnetsSubnetPoolId} | 
[**GetNetworkv16NetworkExternal**](NetworkApi.md#GetNetworkv16NetworkExternal) | **Get** /platform/16/network/external | 
[**GetNetworkv16NetworkInterfaces**](NetworkApi.md#GetNetworkv16NetworkInterfaces) | **Get** /platform/16/network/interfaces | 
[**GetNetworkv16NetworkPools**](NetworkApi.md#GetNetworkv16NetworkPools) | **Get** /platform/16/network/pools | 
[**GetNetworkv16NetworkSubnets**](NetworkApi.md#GetNetworkv16NetworkSubnets) | **Get** /platform/16/network/subnets | 
[**GetNetworkv3GroupnetsGroupnetSubnet**](NetworkApi.md#GetNetworkv3GroupnetsGroupnetSubnet) | **Get** /platform/3/network/groupnets/{Groupnet}/subnets/{v3GroupnetsGroupnetSubnetId} | 
[**GetNetworkv3GroupnetsGroupnetSubnetsSubnetPool**](NetworkApi.md#GetNetworkv3GroupnetsGroupnetSubnetsSubnetPool) | **Get** /platform/3/network/groupnets/{Groupnet}/subnets/{Subnet}/pools/{v3GroupnetsGroupnetSubnetsSubnetPoolId} | 
[**GetNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule**](NetworkApi.md#GetNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule) | **Get** /platform/3/network/groupnets/{Groupnet}/subnets/{Subnet}/pools/{Pool}/rules/{v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRuleId} | 
[**GetNetworkv3NetworkDnscache**](NetworkApi.md#GetNetworkv3NetworkDnscache) | **Get** /platform/3/network/dnscache | 
[**GetNetworkv3NetworkExternal**](NetworkApi.md#GetNetworkv3NetworkExternal) | **Get** /platform/3/network/external | 
[**GetNetworkv3NetworkGroupnet**](NetworkApi.md#GetNetworkv3NetworkGroupnet) | **Get** /platform/3/network/groupnets/{v3NetworkGroupnetId} | 
[**GetNetworkv3NetworkPools**](NetworkApi.md#GetNetworkv3NetworkPools) | **Get** /platform/3/network/pools | 
[**GetNetworkv3NetworkRules**](NetworkApi.md#GetNetworkv3NetworkRules) | **Get** /platform/3/network/rules | 
[**GetNetworkv3NetworkSubnets**](NetworkApi.md#GetNetworkv3NetworkSubnets) | **Get** /platform/3/network/subnets | 
[**GetNetworkv4GroupnetsGroupnetSubnet**](NetworkApi.md#GetNetworkv4GroupnetsGroupnetSubnet) | **Get** /platform/4/network/groupnets/{Groupnet}/subnets/{v4GroupnetsGroupnetSubnetId} | 
[**GetNetworkv4NetworkSubnets**](NetworkApi.md#GetNetworkv4NetworkSubnets) | **Get** /platform/4/network/subnets | 
[**GetNetworkv7GroupnetsGroupnetSubnet**](NetworkApi.md#GetNetworkv7GroupnetsGroupnetSubnet) | **Get** /platform/7/network/groupnets/{Groupnet}/subnets/{v7GroupnetsGroupnetSubnetId} | 
[**GetNetworkv7NetworkInterfaces**](NetworkApi.md#GetNetworkv7NetworkInterfaces) | **Get** /platform/7/network/interfaces | 
[**GetNetworkv7NetworkSubnets**](NetworkApi.md#GetNetworkv7NetworkSubnets) | **Get** /platform/7/network/subnets | 
[**ListNetworkv10NetworkGroupnets**](NetworkApi.md#ListNetworkv10NetworkGroupnets) | **Get** /platform/10/network/groupnets | 
[**ListNetworkv16FirewallPolicies**](NetworkApi.md#ListNetworkv16FirewallPolicies) | **Get** /platform/16/network/firewall/policies | 
[**ListNetworkv3NetworkGroupnets**](NetworkApi.md#ListNetworkv3NetworkGroupnets) | **Get** /platform/3/network/groupnets | 
[**UpdateNetworkv10NetworkGroupnet**](NetworkApi.md#UpdateNetworkv10NetworkGroupnet) | **Put** /platform/10/network/groupnets/{v10NetworkGroupnetId} | 
[**UpdateNetworkv12GroupnetsGroupnetSubnetsSubnetPool**](NetworkApi.md#UpdateNetworkv12GroupnetsGroupnetSubnetsSubnetPool) | **Put** /platform/12/network/groupnets/{Groupnet}/subnets/{Subnet}/pools/{v12GroupnetsGroupnetSubnetsSubnetPoolId} | 
[**UpdateNetworkv12NetworkExternal**](NetworkApi.md#UpdateNetworkv12NetworkExternal) | **Put** /platform/12/network/external | 
[**UpdateNetworkv16FirewallPoliciesPolicyRule**](NetworkApi.md#UpdateNetworkv16FirewallPoliciesPolicyRule) | **Put** /platform/16/network/firewall/policies/{Policy}/rules/{v16FirewallPoliciesPolicyRuleId} | 
[**UpdateNetworkv16FirewallPolicy**](NetworkApi.md#UpdateNetworkv16FirewallPolicy) | **Put** /platform/16/network/firewall/policies/{v16FirewallPolicyId} | 
[**UpdateNetworkv16FirewallSettings**](NetworkApi.md#UpdateNetworkv16FirewallSettings) | **Put** /platform/16/network/firewall/settings | 
[**UpdateNetworkv16GroupnetsGroupnetSubnet**](NetworkApi.md#UpdateNetworkv16GroupnetsGroupnetSubnet) | **Put** /platform/16/network/groupnets/{Groupnet}/subnets/{v16GroupnetsGroupnetSubnetId} | 
[**UpdateNetworkv16GroupnetsGroupnetSubnetsSubnetPool**](NetworkApi.md#UpdateNetworkv16GroupnetsGroupnetSubnetsSubnetPool) | **Put** /platform/16/network/groupnets/{Groupnet}/subnets/{Subnet}/pools/{v16GroupnetsGroupnetSubnetsSubnetPoolId} | 
[**UpdateNetworkv16NetworkExternal**](NetworkApi.md#UpdateNetworkv16NetworkExternal) | **Put** /platform/16/network/external | 
[**UpdateNetworkv3GroupnetsGroupnetSubnet**](NetworkApi.md#UpdateNetworkv3GroupnetsGroupnetSubnet) | **Put** /platform/3/network/groupnets/{Groupnet}/subnets/{v3GroupnetsGroupnetSubnetId} | 
[**UpdateNetworkv3GroupnetsGroupnetSubnetsSubnetPool**](NetworkApi.md#UpdateNetworkv3GroupnetsGroupnetSubnetsSubnetPool) | **Put** /platform/3/network/groupnets/{Groupnet}/subnets/{Subnet}/pools/{v3GroupnetsGroupnetSubnetsSubnetPoolId} | 
[**UpdateNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule**](NetworkApi.md#UpdateNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule) | **Put** /platform/3/network/groupnets/{Groupnet}/subnets/{Subnet}/pools/{Pool}/rules/{v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRuleId} | 
[**UpdateNetworkv3NetworkDnscache**](NetworkApi.md#UpdateNetworkv3NetworkDnscache) | **Put** /platform/3/network/dnscache | 
[**UpdateNetworkv3NetworkExternal**](NetworkApi.md#UpdateNetworkv3NetworkExternal) | **Put** /platform/3/network/external | 
[**UpdateNetworkv3NetworkGroupnet**](NetworkApi.md#UpdateNetworkv3NetworkGroupnet) | **Put** /platform/3/network/groupnets/{v3NetworkGroupnetId} | 
[**UpdateNetworkv4GroupnetsGroupnetSubnet**](NetworkApi.md#UpdateNetworkv4GroupnetsGroupnetSubnet) | **Put** /platform/4/network/groupnets/{Groupnet}/subnets/{v4GroupnetsGroupnetSubnetId} | 
[**UpdateNetworkv7GroupnetsGroupnetSubnet**](NetworkApi.md#UpdateNetworkv7GroupnetsGroupnetSubnet) | **Put** /platform/7/network/groupnets/{Groupnet}/subnets/{v7GroupnetsGroupnetSubnetId} | 



## CreateNetworkv10NetworkGroupnet

> CreateResponse CreateNetworkv10NetworkGroupnet(ctx).V10NetworkGroupnet(v10NetworkGroupnet).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10NetworkGroupnet := *openapiclient.NewV10NetworkGroupnet("Name_example") // V10NetworkGroupnet | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.CreateNetworkv10NetworkGroupnet(context.Background()).V10NetworkGroupnet(v10NetworkGroupnet).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.CreateNetworkv10NetworkGroupnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNetworkv10NetworkGroupnet`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.CreateNetworkv10NetworkGroupnet`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateNetworkv10NetworkGroupnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v10NetworkGroupnet** | [**V10NetworkGroupnet**](V10NetworkGroupnet.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateNetworkv16FirewallPolicy

> CreateResponse CreateNetworkv16FirewallPolicy(ctx).V16FirewallPolicy(v16FirewallPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16FirewallPolicy := *openapiclient.NewV16FirewallPolicy("Name_example") // V16FirewallPolicy | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.CreateNetworkv16FirewallPolicy(context.Background()).V16FirewallPolicy(v16FirewallPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.CreateNetworkv16FirewallPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNetworkv16FirewallPolicy`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.CreateNetworkv16FirewallPolicy`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateNetworkv16FirewallPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16FirewallPolicy** | [**V16FirewallPolicy**](V16FirewallPolicy.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateNetworkv16FirewallResetGlobalPolicyItem

> map[string]interface{} CreateNetworkv16FirewallResetGlobalPolicyItem(ctx).V16FirewallResetGlobalPolicyItem(v16FirewallResetGlobalPolicyItem).Live(live).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16FirewallResetGlobalPolicyItem := map[string]interface{}{ ... } // map[string]interface{} | 
    live := true // bool | Live option must be used with global policies. Such reset will take effect immediately. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.CreateNetworkv16FirewallResetGlobalPolicyItem(context.Background()).V16FirewallResetGlobalPolicyItem(v16FirewallResetGlobalPolicyItem).Live(live).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.CreateNetworkv16FirewallResetGlobalPolicyItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNetworkv16FirewallResetGlobalPolicyItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.CreateNetworkv16FirewallResetGlobalPolicyItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateNetworkv16FirewallResetGlobalPolicyItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16FirewallResetGlobalPolicyItem** | **map[string]interface{}** |  | 
 **live** | **bool** | Live option must be used with global policies. Such reset will take effect immediately. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateNetworkv3DnscacheFlushItem

> map[string]interface{} CreateNetworkv3DnscacheFlushItem(ctx).V3DnscacheFlushItem(v3DnscacheFlushItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3DnscacheFlushItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.CreateNetworkv3DnscacheFlushItem(context.Background()).V3DnscacheFlushItem(v3DnscacheFlushItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.CreateNetworkv3DnscacheFlushItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNetworkv3DnscacheFlushItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.CreateNetworkv3DnscacheFlushItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateNetworkv3DnscacheFlushItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3DnscacheFlushItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateNetworkv3NetworkGroupnet

> CreateResponse CreateNetworkv3NetworkGroupnet(ctx).V3NetworkGroupnet(v3NetworkGroupnet).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NetworkGroupnet := *openapiclient.NewV3NetworkGroupnet("Name_example") // V3NetworkGroupnet | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.CreateNetworkv3NetworkGroupnet(context.Background()).V3NetworkGroupnet(v3NetworkGroupnet).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.CreateNetworkv3NetworkGroupnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNetworkv3NetworkGroupnet`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.CreateNetworkv3NetworkGroupnet`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateNetworkv3NetworkGroupnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3NetworkGroupnet** | [**V3NetworkGroupnet**](V3NetworkGroupnet.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateNetworkv3NetworkScRebalanceAllItem

> map[string]interface{} CreateNetworkv3NetworkScRebalanceAllItem(ctx).V3NetworkScRebalanceAllItem(v3NetworkScRebalanceAllItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NetworkScRebalanceAllItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.CreateNetworkv3NetworkScRebalanceAllItem(context.Background()).V3NetworkScRebalanceAllItem(v3NetworkScRebalanceAllItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.CreateNetworkv3NetworkScRebalanceAllItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNetworkv3NetworkScRebalanceAllItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.CreateNetworkv3NetworkScRebalanceAllItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateNetworkv3NetworkScRebalanceAllItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3NetworkScRebalanceAllItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteNetworkv10NetworkGroupnet

> DeleteNetworkv10NetworkGroupnet(ctx, v10NetworkGroupnetId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10NetworkGroupnetId := "v10NetworkGroupnetId_example" // string | Delete a network groupnet.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.DeleteNetworkv10NetworkGroupnet(context.Background(), v10NetworkGroupnetId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.DeleteNetworkv10NetworkGroupnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10NetworkGroupnetId** | **string** | Delete a network groupnet. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteNetworkv10NetworkGroupnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteNetworkv12GroupnetsGroupnetSubnetsSubnetPool

> DeleteNetworkv12GroupnetsGroupnetSubnetsSubnetPool(ctx, v12GroupnetsGroupnetSubnetsSubnetPoolId, groupnet, subnet).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12GroupnetsGroupnetSubnetsSubnetPoolId := "v12GroupnetsGroupnetSubnetsSubnetPoolId_example" // string | Delete a network pool.
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.DeleteNetworkv12GroupnetsGroupnetSubnetsSubnetPool(context.Background(), v12GroupnetsGroupnetSubnetsSubnetPoolId, groupnet, subnet).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.DeleteNetworkv12GroupnetsGroupnetSubnetsSubnetPool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12GroupnetsGroupnetSubnetsSubnetPoolId** | **string** | Delete a network pool. | 
**groupnet** | **string** |  | 
**subnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteNetworkv12GroupnetsGroupnetSubnetsSubnetPoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------




### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteNetworkv16FirewallPoliciesPolicyRule

> DeleteNetworkv16FirewallPoliciesPolicyRule(ctx, v16FirewallPoliciesPolicyRuleId, policy).Live(live).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16FirewallPoliciesPolicyRuleId := "v16FirewallPoliciesPolicyRuleId_example" // string | Delete a network firewall rule.
    policy := "policy_example" // string | 
    live := true // bool | Live flag can only be used with active rules. Update will take effect immediately on all related network pools. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.DeleteNetworkv16FirewallPoliciesPolicyRule(context.Background(), v16FirewallPoliciesPolicyRuleId, policy).Live(live).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.DeleteNetworkv16FirewallPoliciesPolicyRule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v16FirewallPoliciesPolicyRuleId** | **string** | Delete a network firewall rule. | 
**policy** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteNetworkv16FirewallPoliciesPolicyRuleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **live** | **bool** | Live flag can only be used with active rules. Update will take effect immediately on all related network pools. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteNetworkv16FirewallPolicy

> DeleteNetworkv16FirewallPolicy(ctx, v16FirewallPolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16FirewallPolicyId := "v16FirewallPolicyId_example" // string | Delete a network firewall policy.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.DeleteNetworkv16FirewallPolicy(context.Background(), v16FirewallPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.DeleteNetworkv16FirewallPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v16FirewallPolicyId** | **string** | Delete a network firewall policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteNetworkv16FirewallPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteNetworkv16GroupnetsGroupnetSubnet

> DeleteNetworkv16GroupnetsGroupnetSubnet(ctx, v16GroupnetsGroupnetSubnetId, groupnet).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16GroupnetsGroupnetSubnetId := "v16GroupnetsGroupnetSubnetId_example" // string | Delete a network subnet.
    groupnet := "groupnet_example" // string | 
    force := true // bool | Force deleting this subnet even if pools in other subnets rely on this subnet's SC VIP. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.DeleteNetworkv16GroupnetsGroupnetSubnet(context.Background(), v16GroupnetsGroupnetSubnetId, groupnet).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.DeleteNetworkv16GroupnetsGroupnetSubnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v16GroupnetsGroupnetSubnetId** | **string** | Delete a network subnet. | 
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteNetworkv16GroupnetsGroupnetSubnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **force** | **bool** | Force deleting this subnet even if pools in other subnets rely on this subnet&#39;s SC VIP. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteNetworkv16GroupnetsGroupnetSubnetsSubnetPool

> DeleteNetworkv16GroupnetsGroupnetSubnetsSubnetPool(ctx, v16GroupnetsGroupnetSubnetsSubnetPoolId, groupnet, subnet).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16GroupnetsGroupnetSubnetsSubnetPoolId := "v16GroupnetsGroupnetSubnetsSubnetPoolId_example" // string | Delete a network pool.
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.DeleteNetworkv16GroupnetsGroupnetSubnetsSubnetPool(context.Background(), v16GroupnetsGroupnetSubnetsSubnetPoolId, groupnet, subnet).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.DeleteNetworkv16GroupnetsGroupnetSubnetsSubnetPool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v16GroupnetsGroupnetSubnetsSubnetPoolId** | **string** | Delete a network pool. | 
**groupnet** | **string** |  | 
**subnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteNetworkv16GroupnetsGroupnetSubnetsSubnetPoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------




### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteNetworkv3GroupnetsGroupnetSubnet

> DeleteNetworkv3GroupnetsGroupnetSubnet(ctx, v3GroupnetsGroupnetSubnetId, groupnet).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3GroupnetsGroupnetSubnetId := "v3GroupnetsGroupnetSubnetId_example" // string | Delete a network subnet.
    groupnet := "groupnet_example" // string | 
    force := true // bool | Force deleting this subnet even if pools in other subnets rely on this subnet's SC VIP. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.DeleteNetworkv3GroupnetsGroupnetSubnet(context.Background(), v3GroupnetsGroupnetSubnetId, groupnet).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.DeleteNetworkv3GroupnetsGroupnetSubnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3GroupnetsGroupnetSubnetId** | **string** | Delete a network subnet. | 
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteNetworkv3GroupnetsGroupnetSubnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **force** | **bool** | Force deleting this subnet even if pools in other subnets rely on this subnet&#39;s SC VIP. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteNetworkv3GroupnetsGroupnetSubnetsSubnetPool

> DeleteNetworkv3GroupnetsGroupnetSubnetsSubnetPool(ctx, v3GroupnetsGroupnetSubnetsSubnetPoolId, groupnet, subnet).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3GroupnetsGroupnetSubnetsSubnetPoolId := "v3GroupnetsGroupnetSubnetsSubnetPoolId_example" // string | Delete a network pool.
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.DeleteNetworkv3GroupnetsGroupnetSubnetsSubnetPool(context.Background(), v3GroupnetsGroupnetSubnetsSubnetPoolId, groupnet, subnet).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.DeleteNetworkv3GroupnetsGroupnetSubnetsSubnetPool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3GroupnetsGroupnetSubnetsSubnetPoolId** | **string** | Delete a network pool. | 
**groupnet** | **string** |  | 
**subnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteNetworkv3GroupnetsGroupnetSubnetsSubnetPoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------




### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule

> DeleteNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule(ctx, v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRuleId, groupnet, subnet, pool).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRuleId := "v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRuleId_example" // string | Delete a network rule.
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 
    pool := "pool_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.DeleteNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule(context.Background(), v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRuleId, groupnet, subnet, pool).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.DeleteNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRuleId** | **string** | Delete a network rule. | 
**groupnet** | **string** |  | 
**subnet** | **string** |  | 
**pool** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRuleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------





### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteNetworkv3NetworkGroupnet

> DeleteNetworkv3NetworkGroupnet(ctx, v3NetworkGroupnetId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NetworkGroupnetId := "v3NetworkGroupnetId_example" // string | Delete a network groupnet.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.DeleteNetworkv3NetworkGroupnet(context.Background(), v3NetworkGroupnetId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.DeleteNetworkv3NetworkGroupnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NetworkGroupnetId** | **string** | Delete a network groupnet. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteNetworkv3NetworkGroupnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteNetworkv4GroupnetsGroupnetSubnet

> DeleteNetworkv4GroupnetsGroupnetSubnet(ctx, v4GroupnetsGroupnetSubnetId, groupnet).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4GroupnetsGroupnetSubnetId := "v4GroupnetsGroupnetSubnetId_example" // string | Delete a network subnet.
    groupnet := "groupnet_example" // string | 
    force := true // bool | Force deleting this subnet even if pools in other subnets rely on this subnet's SC VIP. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.DeleteNetworkv4GroupnetsGroupnetSubnet(context.Background(), v4GroupnetsGroupnetSubnetId, groupnet).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.DeleteNetworkv4GroupnetsGroupnetSubnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4GroupnetsGroupnetSubnetId** | **string** | Delete a network subnet. | 
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteNetworkv4GroupnetsGroupnetSubnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **force** | **bool** | Force deleting this subnet even if pools in other subnets rely on this subnet&#39;s SC VIP. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteNetworkv7GroupnetsGroupnetSubnet

> DeleteNetworkv7GroupnetsGroupnetSubnet(ctx, v7GroupnetsGroupnetSubnetId, groupnet).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7GroupnetsGroupnetSubnetId := "v7GroupnetsGroupnetSubnetId_example" // string | Delete a network subnet.
    groupnet := "groupnet_example" // string | 
    force := true // bool | Force deleting this subnet even if pools in other subnets rely on this subnet's SC VIP. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.DeleteNetworkv7GroupnetsGroupnetSubnet(context.Background(), v7GroupnetsGroupnetSubnetId, groupnet).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.DeleteNetworkv7GroupnetsGroupnetSubnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7GroupnetsGroupnetSubnetId** | **string** | Delete a network subnet. | 
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteNetworkv7GroupnetsGroupnetSubnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **force** | **bool** | Force deleting this subnet even if pools in other subnets rely on this subnet&#39;s SC VIP. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv10NetworkGroupnet

> V10NetworkGroupnetsExtended GetNetworkv10NetworkGroupnet(ctx, v10NetworkGroupnetId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10NetworkGroupnetId := "v10NetworkGroupnetId_example" // string | View a network groupnet.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv10NetworkGroupnet(context.Background(), v10NetworkGroupnetId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv10NetworkGroupnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv10NetworkGroupnet`: V10NetworkGroupnetsExtended
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv10NetworkGroupnet`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10NetworkGroupnetId** | **string** | View a network groupnet. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv10NetworkGroupnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V10NetworkGroupnetsExtended**](V10NetworkGroupnetsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv12GroupnetsGroupnetSubnetsSubnetPool

> V12GroupnetsGroupnetSubnetsSubnetPools GetNetworkv12GroupnetsGroupnetSubnetsSubnetPool(ctx, v12GroupnetsGroupnetSubnetsSubnetPoolId, groupnet, subnet).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12GroupnetsGroupnetSubnetsSubnetPoolId := "v12GroupnetsGroupnetSubnetsSubnetPoolId_example" // string | View a single network pool.
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv12GroupnetsGroupnetSubnetsSubnetPool(context.Background(), v12GroupnetsGroupnetSubnetsSubnetPoolId, groupnet, subnet).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv12GroupnetsGroupnetSubnetsSubnetPool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv12GroupnetsGroupnetSubnetsSubnetPool`: V12GroupnetsGroupnetSubnetsSubnetPools
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv12GroupnetsGroupnetSubnetsSubnetPool`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12GroupnetsGroupnetSubnetsSubnetPoolId** | **string** | View a single network pool. | 
**groupnet** | **string** |  | 
**subnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv12GroupnetsGroupnetSubnetsSubnetPoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------




### Return type

[**V12GroupnetsGroupnetSubnetsSubnetPools**](V12GroupnetsGroupnetSubnetsSubnetPools.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv12NetworkExternal

> V12NetworkExternal GetNetworkv12NetworkExternal(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv12NetworkExternal(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv12NetworkExternal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv12NetworkExternal`: V12NetworkExternal
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv12NetworkExternal`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv12NetworkExternalRequest struct via the builder pattern


### Return type

[**V12NetworkExternal**](V12NetworkExternal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv12NetworkInterfaces

> V12NetworkInterfaces GetNetworkv12NetworkInterfaces(ctx).Sort(sort).Network(network).Resume(resume).Cache(cache).Lnn(lnn).Limit(limit).Dir(dir).VlanId(vlanId).Owner(owner).Type_(type_).IncludeVlans(includeVlans).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    network := "network_example" // string | Show interfaces associated with external and/or internal networks. Default is 'external' (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    cache := "cache_example" // string | Control where interface data is source from. no-cache only returns live data from a running node, and if a node can't be reached, no results will be returned. cache-only only returns cached data, some fields are set as null/unknown if they can't be determined, and IPs listed are the IPs that should be configured. Finally, nodes-first will try to query live nodes, and fall back to the cache for any nodes that fail. Default: nodes-first (optional)
    lnn := []int32{int32(123)} // []int32 | Get a list of interfaces for the specified lnns. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    vlanId := int32(56) // int32 | Only return IPs/interfaces configured in the specified VLAN ID (optional)
    owner := "owner_example" // string | Filter results by owner id. Support partials matches too. Ex owner=groupnet0 or owner=groupnet0.subnet0.pool0. (optional)
    type_ := "type__example" // string | Filter the returned IPs by IP type. (optional)
    includeVlans := true // bool | If include_vlans is set to true, all vlans are returned unless further filtered by vlan_id. If include_vlans is set to false, no vlans are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv12NetworkInterfaces(context.Background()).Sort(sort).Network(network).Resume(resume).Cache(cache).Lnn(lnn).Limit(limit).Dir(dir).VlanId(vlanId).Owner(owner).Type_(type_).IncludeVlans(includeVlans).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv12NetworkInterfaces``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv12NetworkInterfaces`: V12NetworkInterfaces
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv12NetworkInterfaces`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv12NetworkInterfacesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **network** | **string** | Show interfaces associated with external and/or internal networks. Default is &#39;external&#39; | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **cache** | **string** | Control where interface data is source from. no-cache only returns live data from a running node, and if a node can&#39;t be reached, no results will be returned. cache-only only returns cached data, some fields are set as null/unknown if they can&#39;t be determined, and IPs listed are the IPs that should be configured. Finally, nodes-first will try to query live nodes, and fall back to the cache for any nodes that fail. Default: nodes-first | 
 **lnn** | **[]int32** | Get a list of interfaces for the specified lnns. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **vlanId** | **int32** | Only return IPs/interfaces configured in the specified VLAN ID | 
 **owner** | **string** | Filter results by owner id. Support partials matches too. Ex owner&#x3D;groupnet0 or owner&#x3D;groupnet0.subnet0.pool0. | 
 **type_** | **string** | Filter the returned IPs by IP type. | 
 **includeVlans** | **bool** | If include_vlans is set to true, all vlans are returned unless further filtered by vlan_id. If include_vlans is set to false, no vlans are returned. | 

### Return type

[**V12NetworkInterfaces**](V12NetworkInterfaces.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv12NetworkPools

> V12NetworkPools GetNetworkv12NetworkPools(ctx).Sort(sort).Subnet(subnet).Resume(resume).AccessZone(accessZone).AllocMethod(allocMethod).Limit(limit).Groupnet(groupnet).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    subnet := "subnet_example" // string | If specified, only pools for this subnet will be returned. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    accessZone := "accessZone_example" // string | If specified, only pools with this zone name will be returned. (optional)
    allocMethod := "allocMethod_example" // string | If specified, only pools with this allocation type will be returned. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    groupnet := "groupnet_example" // string | If specified, only pools for this groupnet will be returned. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv12NetworkPools(context.Background()).Sort(sort).Subnet(subnet).Resume(resume).AccessZone(accessZone).AllocMethod(allocMethod).Limit(limit).Groupnet(groupnet).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv12NetworkPools``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv12NetworkPools`: V12NetworkPools
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv12NetworkPools`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv12NetworkPoolsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **subnet** | **string** | If specified, only pools for this subnet will be returned. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **accessZone** | **string** | If specified, only pools with this zone name will be returned. | 
 **allocMethod** | **string** | If specified, only pools with this allocation type will be returned. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **groupnet** | **string** | If specified, only pools for this groupnet will be returned. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V12NetworkPools**](V12NetworkPools.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv14NetworkInterfaces

> V14NetworkInterfaces GetNetworkv14NetworkInterfaces(ctx).Sort(sort).Network(network).Resume(resume).Cache(cache).Lnn(lnn).Limit(limit).Dir(dir).VlanId(vlanId).Owner(owner).Type_(type_).IncludeVlans(includeVlans).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    network := "network_example" // string | Show interfaces associated with external and/or internal networks. Default is 'external' (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    cache := "cache_example" // string | Control where interface data is source from. no-cache only returns live data from a running node, and if a node can't be reached, no results will be returned. cache-only only returns cached data, some fields are set as null/unknown if they can't be determined, and IPs listed are the IPs that should be configured. Finally, nodes-first will try to query live nodes, and fall back to the cache for any nodes that fail. Default: nodes-first (optional)
    lnn := []int32{int32(123)} // []int32 | Get a list of interfaces for the specified lnns. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    vlanId := int32(56) // int32 | Only return IPs/interfaces configured in the specified VLAN ID (optional)
    owner := "owner_example" // string | Filter results by owner id. Support partials matches too. Ex owner=groupnet0 or owner=groupnet0.subnet0.pool0. (optional)
    type_ := "type__example" // string | Filter the returned IPs by IP type. (optional)
    includeVlans := true // bool | If include_vlans is set to true, all vlans are returned unless further filtered by vlan_id. If include_vlans is set to false, no vlans are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv14NetworkInterfaces(context.Background()).Sort(sort).Network(network).Resume(resume).Cache(cache).Lnn(lnn).Limit(limit).Dir(dir).VlanId(vlanId).Owner(owner).Type_(type_).IncludeVlans(includeVlans).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv14NetworkInterfaces``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv14NetworkInterfaces`: V14NetworkInterfaces
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv14NetworkInterfaces`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv14NetworkInterfacesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **network** | **string** | Show interfaces associated with external and/or internal networks. Default is &#39;external&#39; | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **cache** | **string** | Control where interface data is source from. no-cache only returns live data from a running node, and if a node can&#39;t be reached, no results will be returned. cache-only only returns cached data, some fields are set as null/unknown if they can&#39;t be determined, and IPs listed are the IPs that should be configured. Finally, nodes-first will try to query live nodes, and fall back to the cache for any nodes that fail. Default: nodes-first | 
 **lnn** | **[]int32** | Get a list of interfaces for the specified lnns. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **vlanId** | **int32** | Only return IPs/interfaces configured in the specified VLAN ID | 
 **owner** | **string** | Filter results by owner id. Support partials matches too. Ex owner&#x3D;groupnet0 or owner&#x3D;groupnet0.subnet0.pool0. | 
 **type_** | **string** | Filter the returned IPs by IP type. | 
 **includeVlans** | **bool** | If include_vlans is set to true, all vlans are returned unless further filtered by vlan_id. If include_vlans is set to false, no vlans are returned. | 

### Return type

[**V14NetworkInterfaces**](V14NetworkInterfaces.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv16FirewallPoliciesPolicyRule

> V16FirewallPoliciesPolicyRules GetNetworkv16FirewallPoliciesPolicyRule(ctx, v16FirewallPoliciesPolicyRuleId, policy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16FirewallPoliciesPolicyRuleId := "v16FirewallPoliciesPolicyRuleId_example" // string | View a network firewall rule.
    policy := "policy_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv16FirewallPoliciesPolicyRule(context.Background(), v16FirewallPoliciesPolicyRuleId, policy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv16FirewallPoliciesPolicyRule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv16FirewallPoliciesPolicyRule`: V16FirewallPoliciesPolicyRules
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv16FirewallPoliciesPolicyRule`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v16FirewallPoliciesPolicyRuleId** | **string** | View a network firewall rule. | 
**policy** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv16FirewallPoliciesPolicyRuleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V16FirewallPoliciesPolicyRules**](V16FirewallPoliciesPolicyRules.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv16FirewallPolicy

> V16FirewallPoliciesExtended GetNetworkv16FirewallPolicy(ctx, v16FirewallPolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16FirewallPolicyId := "v16FirewallPolicyId_example" // string | View a network firewall policy.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv16FirewallPolicy(context.Background(), v16FirewallPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv16FirewallPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv16FirewallPolicy`: V16FirewallPoliciesExtended
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv16FirewallPolicy`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v16FirewallPolicyId** | **string** | View a network firewall policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv16FirewallPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V16FirewallPoliciesExtended**](V16FirewallPoliciesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv16FirewallRules

> V16FirewallRules GetNetworkv16FirewallRules(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv16FirewallRules(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv16FirewallRules``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv16FirewallRules`: V16FirewallRules
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv16FirewallRules`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv16FirewallRulesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V16FirewallRules**](V16FirewallRules.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv16FirewallServices

> V16FirewallServices GetNetworkv16FirewallServices(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv16FirewallServices(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv16FirewallServices``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv16FirewallServices`: V16FirewallServices
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv16FirewallServices`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv16FirewallServicesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V16FirewallServices**](V16FirewallServices.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv16FirewallSettings

> V16FirewallSettings GetNetworkv16FirewallSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv16FirewallSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv16FirewallSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv16FirewallSettings`: V16FirewallSettings
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv16FirewallSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv16FirewallSettingsRequest struct via the builder pattern


### Return type

[**V16FirewallSettings**](V16FirewallSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv16GroupnetsGroupnetSubnet

> V16GroupnetsGroupnetSubnets GetNetworkv16GroupnetsGroupnetSubnet(ctx, v16GroupnetsGroupnetSubnetId, groupnet).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16GroupnetsGroupnetSubnetId := "v16GroupnetsGroupnetSubnetId_example" // string | View a network subnet.
    groupnet := "groupnet_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv16GroupnetsGroupnetSubnet(context.Background(), v16GroupnetsGroupnetSubnetId, groupnet).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv16GroupnetsGroupnetSubnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv16GroupnetsGroupnetSubnet`: V16GroupnetsGroupnetSubnets
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv16GroupnetsGroupnetSubnet`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v16GroupnetsGroupnetSubnetId** | **string** | View a network subnet. | 
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv16GroupnetsGroupnetSubnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V16GroupnetsGroupnetSubnets**](V16GroupnetsGroupnetSubnets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv16GroupnetsGroupnetSubnetsSubnetPool

> V16GroupnetsGroupnetSubnetsSubnetPools GetNetworkv16GroupnetsGroupnetSubnetsSubnetPool(ctx, v16GroupnetsGroupnetSubnetsSubnetPoolId, groupnet, subnet).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16GroupnetsGroupnetSubnetsSubnetPoolId := "v16GroupnetsGroupnetSubnetsSubnetPoolId_example" // string | View a single network pool.
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv16GroupnetsGroupnetSubnetsSubnetPool(context.Background(), v16GroupnetsGroupnetSubnetsSubnetPoolId, groupnet, subnet).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv16GroupnetsGroupnetSubnetsSubnetPool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv16GroupnetsGroupnetSubnetsSubnetPool`: V16GroupnetsGroupnetSubnetsSubnetPools
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv16GroupnetsGroupnetSubnetsSubnetPool`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v16GroupnetsGroupnetSubnetsSubnetPoolId** | **string** | View a single network pool. | 
**groupnet** | **string** |  | 
**subnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv16GroupnetsGroupnetSubnetsSubnetPoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------




### Return type

[**V16GroupnetsGroupnetSubnetsSubnetPools**](V16GroupnetsGroupnetSubnetsSubnetPools.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv16NetworkExternal

> V16NetworkExternal GetNetworkv16NetworkExternal(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv16NetworkExternal(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv16NetworkExternal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv16NetworkExternal`: V16NetworkExternal
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv16NetworkExternal`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv16NetworkExternalRequest struct via the builder pattern


### Return type

[**V16NetworkExternal**](V16NetworkExternal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv16NetworkInterfaces

> V14NetworkInterfaces GetNetworkv16NetworkInterfaces(ctx).Sort(sort).IncludeAccessZones(includeAccessZones).Network(network).Resume(resume).Cache(cache).Lnn(lnn).Limit(limit).Dir(dir).VlanId(vlanId).Owner(owner).Type_(type_).IncludeVlans(includeVlans).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    includeAccessZones := true // bool | If include_access_zones is set to false, the \"access_zone\" field will be set to an empty string. (optional)
    network := "network_example" // string | Show interfaces associated with external and/or internal networks. Default is 'external' (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    cache := "cache_example" // string | Control where interface data is source from. no-cache only returns live data from a running node, and if a node can't be reached, no results will be returned. cache-only only returns cached data, some fields are set as null/unknown if they can't be determined, and IPs listed are the IPs that should be configured. Finally, nodes-first will try to query live nodes, and fall back to the cache for any nodes that fail. Default: nodes-first (optional)
    lnn := []int32{int32(123)} // []int32 | Get a list of interfaces for the specified lnns. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    vlanId := int32(56) // int32 | Only return IPs/interfaces configured in the specified VLAN ID (optional)
    owner := "owner_example" // string | Filter results by owner id. Support partials matches too. Ex owner=groupnet0 or owner=groupnet0.subnet0.pool0. (optional)
    type_ := "type__example" // string | Filter the returned IPs by IP type. (optional)
    includeVlans := true // bool | If include_vlans is set to true, all vlans are returned unless further filtered by vlan_id. If include_vlans is set to false, no vlans are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv16NetworkInterfaces(context.Background()).Sort(sort).IncludeAccessZones(includeAccessZones).Network(network).Resume(resume).Cache(cache).Lnn(lnn).Limit(limit).Dir(dir).VlanId(vlanId).Owner(owner).Type_(type_).IncludeVlans(includeVlans).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv16NetworkInterfaces``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv16NetworkInterfaces`: V14NetworkInterfaces
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv16NetworkInterfaces`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv16NetworkInterfacesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **includeAccessZones** | **bool** | If include_access_zones is set to false, the \&quot;access_zone\&quot; field will be set to an empty string. | 
 **network** | **string** | Show interfaces associated with external and/or internal networks. Default is &#39;external&#39; | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **cache** | **string** | Control where interface data is source from. no-cache only returns live data from a running node, and if a node can&#39;t be reached, no results will be returned. cache-only only returns cached data, some fields are set as null/unknown if they can&#39;t be determined, and IPs listed are the IPs that should be configured. Finally, nodes-first will try to query live nodes, and fall back to the cache for any nodes that fail. Default: nodes-first | 
 **lnn** | **[]int32** | Get a list of interfaces for the specified lnns. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **vlanId** | **int32** | Only return IPs/interfaces configured in the specified VLAN ID | 
 **owner** | **string** | Filter results by owner id. Support partials matches too. Ex owner&#x3D;groupnet0 or owner&#x3D;groupnet0.subnet0.pool0. | 
 **type_** | **string** | Filter the returned IPs by IP type. | 
 **includeVlans** | **bool** | If include_vlans is set to true, all vlans are returned unless further filtered by vlan_id. If include_vlans is set to false, no vlans are returned. | 

### Return type

[**V14NetworkInterfaces**](V14NetworkInterfaces.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv16NetworkPools

> V16NetworkPools GetNetworkv16NetworkPools(ctx).Sort(sort).Subnet(subnet).Resume(resume).AccessZone(accessZone).AllocMethod(allocMethod).Limit(limit).Groupnet(groupnet).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    subnet := "subnet_example" // string | If specified, only pools for this subnet will be returned. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    accessZone := "accessZone_example" // string | If specified, only pools with this zone name will be returned. (optional)
    allocMethod := "allocMethod_example" // string | If specified, only pools with this allocation type will be returned. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    groupnet := "groupnet_example" // string | If specified, only pools for this groupnet will be returned. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv16NetworkPools(context.Background()).Sort(sort).Subnet(subnet).Resume(resume).AccessZone(accessZone).AllocMethod(allocMethod).Limit(limit).Groupnet(groupnet).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv16NetworkPools``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv16NetworkPools`: V16NetworkPools
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv16NetworkPools`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv16NetworkPoolsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **subnet** | **string** | If specified, only pools for this subnet will be returned. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **accessZone** | **string** | If specified, only pools with this zone name will be returned. | 
 **allocMethod** | **string** | If specified, only pools with this allocation type will be returned. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **groupnet** | **string** | If specified, only pools for this groupnet will be returned. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V16NetworkPools**](V16NetworkPools.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv16NetworkSubnets

> V16GroupnetSubnets GetNetworkv16NetworkSubnets(ctx).Sort(sort).Groupnet(groupnet).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    groupnet := "groupnet_example" // string | If specified, only subnets for this groupnet will be returned. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv16NetworkSubnets(context.Background()).Sort(sort).Groupnet(groupnet).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv16NetworkSubnets``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv16NetworkSubnets`: V16GroupnetSubnets
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv16NetworkSubnets`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv16NetworkSubnetsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **groupnet** | **string** | If specified, only subnets for this groupnet will be returned. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V16GroupnetSubnets**](V16GroupnetSubnets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv3GroupnetsGroupnetSubnet

> V3GroupnetsGroupnetSubnets GetNetworkv3GroupnetsGroupnetSubnet(ctx, v3GroupnetsGroupnetSubnetId, groupnet).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3GroupnetsGroupnetSubnetId := "v3GroupnetsGroupnetSubnetId_example" // string | View a network subnet.
    groupnet := "groupnet_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv3GroupnetsGroupnetSubnet(context.Background(), v3GroupnetsGroupnetSubnetId, groupnet).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv3GroupnetsGroupnetSubnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv3GroupnetsGroupnetSubnet`: V3GroupnetsGroupnetSubnets
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv3GroupnetsGroupnetSubnet`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3GroupnetsGroupnetSubnetId** | **string** | View a network subnet. | 
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv3GroupnetsGroupnetSubnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V3GroupnetsGroupnetSubnets**](V3GroupnetsGroupnetSubnets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv3GroupnetsGroupnetSubnetsSubnetPool

> V3GroupnetsGroupnetSubnetsSubnetPools GetNetworkv3GroupnetsGroupnetSubnetsSubnetPool(ctx, v3GroupnetsGroupnetSubnetsSubnetPoolId, groupnet, subnet).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3GroupnetsGroupnetSubnetsSubnetPoolId := "v3GroupnetsGroupnetSubnetsSubnetPoolId_example" // string | View a single network pool.
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv3GroupnetsGroupnetSubnetsSubnetPool(context.Background(), v3GroupnetsGroupnetSubnetsSubnetPoolId, groupnet, subnet).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv3GroupnetsGroupnetSubnetsSubnetPool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv3GroupnetsGroupnetSubnetsSubnetPool`: V3GroupnetsGroupnetSubnetsSubnetPools
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv3GroupnetsGroupnetSubnetsSubnetPool`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3GroupnetsGroupnetSubnetsSubnetPoolId** | **string** | View a single network pool. | 
**groupnet** | **string** |  | 
**subnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv3GroupnetsGroupnetSubnetsSubnetPoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------




### Return type

[**V3GroupnetsGroupnetSubnetsSubnetPools**](V3GroupnetsGroupnetSubnetsSubnetPools.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule

> V3GroupnetsGroupnetSubnetsSubnetPoolsPoolRules GetNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule(ctx, v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRuleId, groupnet, subnet, pool).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRuleId := "v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRuleId_example" // string | View a single network rule.
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 
    pool := "pool_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule(context.Background(), v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRuleId, groupnet, subnet, pool).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule`: V3GroupnetsGroupnetSubnetsSubnetPoolsPoolRules
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRuleId** | **string** | View a single network rule. | 
**groupnet** | **string** |  | 
**subnet** | **string** |  | 
**pool** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRuleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------





### Return type

[**V3GroupnetsGroupnetSubnetsSubnetPoolsPoolRules**](V3GroupnetsGroupnetSubnetsSubnetPoolsPoolRules.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv3NetworkDnscache

> V3NetworkDnscache GetNetworkv3NetworkDnscache(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv3NetworkDnscache(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv3NetworkDnscache``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv3NetworkDnscache`: V3NetworkDnscache
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv3NetworkDnscache`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv3NetworkDnscacheRequest struct via the builder pattern


### Return type

[**V3NetworkDnscache**](V3NetworkDnscache.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv3NetworkExternal

> V3NetworkExternal GetNetworkv3NetworkExternal(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv3NetworkExternal(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv3NetworkExternal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv3NetworkExternal`: V3NetworkExternal
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv3NetworkExternal`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv3NetworkExternalRequest struct via the builder pattern


### Return type

[**V3NetworkExternal**](V3NetworkExternal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv3NetworkGroupnet

> V3NetworkGroupnetsExtended GetNetworkv3NetworkGroupnet(ctx, v3NetworkGroupnetId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NetworkGroupnetId := "v3NetworkGroupnetId_example" // string | View a network groupnet.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv3NetworkGroupnet(context.Background(), v3NetworkGroupnetId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv3NetworkGroupnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv3NetworkGroupnet`: V3NetworkGroupnetsExtended
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv3NetworkGroupnet`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NetworkGroupnetId** | **string** | View a network groupnet. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv3NetworkGroupnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3NetworkGroupnetsExtended**](V3NetworkGroupnetsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv3NetworkPools

> V3NetworkPools GetNetworkv3NetworkPools(ctx).Sort(sort).Subnet(subnet).Resume(resume).AccessZone(accessZone).AllocMethod(allocMethod).Limit(limit).Groupnet(groupnet).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    subnet := "subnet_example" // string | If specified, only pools for this subnet will be returned. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    accessZone := "accessZone_example" // string | If specified, only pools with this zone name will be returned. (optional)
    allocMethod := "allocMethod_example" // string | If specified, only pools with this allocation type will be returned. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    groupnet := "groupnet_example" // string | If specified, only pools for this groupnet will be returned. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv3NetworkPools(context.Background()).Sort(sort).Subnet(subnet).Resume(resume).AccessZone(accessZone).AllocMethod(allocMethod).Limit(limit).Groupnet(groupnet).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv3NetworkPools``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv3NetworkPools`: V3NetworkPools
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv3NetworkPools`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv3NetworkPoolsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **subnet** | **string** | If specified, only pools for this subnet will be returned. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **accessZone** | **string** | If specified, only pools with this zone name will be returned. | 
 **allocMethod** | **string** | If specified, only pools with this allocation type will be returned. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **groupnet** | **string** | If specified, only pools for this groupnet will be returned. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V3NetworkPools**](V3NetworkPools.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv3NetworkRules

> V3PoolsPoolRules GetNetworkv3NetworkRules(ctx).Sort(sort).Subnet(subnet).Resume(resume).Limit(limit).Dir(dir).Groupnet(groupnet).Pool(pool).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    subnet := "subnet_example" // string | Name of the subnet to list rules from. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    groupnet := "groupnet_example" // string | Name of the groupnet to list rules from. (optional)
    pool := "pool_example" // string | Name of the pool to list rules from. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv3NetworkRules(context.Background()).Sort(sort).Subnet(subnet).Resume(resume).Limit(limit).Dir(dir).Groupnet(groupnet).Pool(pool).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv3NetworkRules``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv3NetworkRules`: V3PoolsPoolRules
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv3NetworkRules`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv3NetworkRulesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **subnet** | **string** | Name of the subnet to list rules from. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **groupnet** | **string** | Name of the groupnet to list rules from. | 
 **pool** | **string** | Name of the pool to list rules from. | 

### Return type

[**V3PoolsPoolRules**](V3PoolsPoolRules.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv3NetworkSubnets

> V3GroupnetSubnets GetNetworkv3NetworkSubnets(ctx).Sort(sort).Groupnet(groupnet).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    groupnet := "groupnet_example" // string | If specified, only subnets for this groupnet will be returned. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv3NetworkSubnets(context.Background()).Sort(sort).Groupnet(groupnet).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv3NetworkSubnets``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv3NetworkSubnets`: V3GroupnetSubnets
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv3NetworkSubnets`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv3NetworkSubnetsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **groupnet** | **string** | If specified, only subnets for this groupnet will be returned. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3GroupnetSubnets**](V3GroupnetSubnets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv4GroupnetsGroupnetSubnet

> V4GroupnetsGroupnetSubnets GetNetworkv4GroupnetsGroupnetSubnet(ctx, v4GroupnetsGroupnetSubnetId, groupnet).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4GroupnetsGroupnetSubnetId := "v4GroupnetsGroupnetSubnetId_example" // string | View a network subnet.
    groupnet := "groupnet_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv4GroupnetsGroupnetSubnet(context.Background(), v4GroupnetsGroupnetSubnetId, groupnet).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv4GroupnetsGroupnetSubnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv4GroupnetsGroupnetSubnet`: V4GroupnetsGroupnetSubnets
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv4GroupnetsGroupnetSubnet`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4GroupnetsGroupnetSubnetId** | **string** | View a network subnet. | 
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv4GroupnetsGroupnetSubnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V4GroupnetsGroupnetSubnets**](V4GroupnetsGroupnetSubnets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv4NetworkSubnets

> V4GroupnetSubnets GetNetworkv4NetworkSubnets(ctx).Sort(sort).Groupnet(groupnet).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    groupnet := "groupnet_example" // string | If specified, only subnets for this groupnet will be returned. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv4NetworkSubnets(context.Background()).Sort(sort).Groupnet(groupnet).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv4NetworkSubnets``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv4NetworkSubnets`: V4GroupnetSubnets
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv4NetworkSubnets`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv4NetworkSubnetsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **groupnet** | **string** | If specified, only subnets for this groupnet will be returned. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V4GroupnetSubnets**](V4GroupnetSubnets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv7GroupnetsGroupnetSubnet

> V7GroupnetsGroupnetSubnets GetNetworkv7GroupnetsGroupnetSubnet(ctx, v7GroupnetsGroupnetSubnetId, groupnet).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7GroupnetsGroupnetSubnetId := "v7GroupnetsGroupnetSubnetId_example" // string | View a network subnet.
    groupnet := "groupnet_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv7GroupnetsGroupnetSubnet(context.Background(), v7GroupnetsGroupnetSubnetId, groupnet).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv7GroupnetsGroupnetSubnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv7GroupnetsGroupnetSubnet`: V7GroupnetsGroupnetSubnets
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv7GroupnetsGroupnetSubnet`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7GroupnetsGroupnetSubnetId** | **string** | View a network subnet. | 
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv7GroupnetsGroupnetSubnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V7GroupnetsGroupnetSubnets**](V7GroupnetsGroupnetSubnets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv7NetworkInterfaces

> V7PoolsPoolInterfaces GetNetworkv7NetworkInterfaces(ctx).Sort(sort).Network(network).Resume(resume).Lnns(lnns).AllocMethod(allocMethod).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    network := "network_example" // string | Show interfaces associated with external and/or internal networks. Default is 'external' (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    lnns := "lnns_example" // string | Get a list of interfaces for the specified lnn. (optional)
    allocMethod := "allocMethod_example" // string | Filter addresses and owners by pool address allocation method. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv7NetworkInterfaces(context.Background()).Sort(sort).Network(network).Resume(resume).Lnns(lnns).AllocMethod(allocMethod).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv7NetworkInterfaces``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv7NetworkInterfaces`: V7PoolsPoolInterfaces
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv7NetworkInterfaces`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv7NetworkInterfacesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **network** | **string** | Show interfaces associated with external and/or internal networks. Default is &#39;external&#39; | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **lnns** | **string** | Get a list of interfaces for the specified lnn. | 
 **allocMethod** | **string** | Filter addresses and owners by pool address allocation method. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V7PoolsPoolInterfaces**](V7PoolsPoolInterfaces.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkv7NetworkSubnets

> V12GroupnetSubnets GetNetworkv7NetworkSubnets(ctx).Sort(sort).Groupnet(groupnet).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    groupnet := "groupnet_example" // string | If specified, only subnets for this groupnet will be returned. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.GetNetworkv7NetworkSubnets(context.Background()).Sort(sort).Groupnet(groupnet).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.GetNetworkv7NetworkSubnets``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkv7NetworkSubnets`: V12GroupnetSubnets
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.GetNetworkv7NetworkSubnets`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkv7NetworkSubnetsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **groupnet** | **string** | If specified, only subnets for this groupnet will be returned. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V12GroupnetSubnets**](V12GroupnetSubnets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListNetworkv10NetworkGroupnets

> V10NetworkGroupnets ListNetworkv10NetworkGroupnets(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.ListNetworkv10NetworkGroupnets(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.ListNetworkv10NetworkGroupnets``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListNetworkv10NetworkGroupnets`: V10NetworkGroupnets
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.ListNetworkv10NetworkGroupnets`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListNetworkv10NetworkGroupnetsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V10NetworkGroupnets**](V10NetworkGroupnets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListNetworkv16FirewallPolicies

> V16FirewallPolicies ListNetworkv16FirewallPolicies(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.ListNetworkv16FirewallPolicies(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.ListNetworkv16FirewallPolicies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListNetworkv16FirewallPolicies`: V16FirewallPolicies
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.ListNetworkv16FirewallPolicies`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListNetworkv16FirewallPoliciesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V16FirewallPolicies**](V16FirewallPolicies.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListNetworkv3NetworkGroupnets

> V3NetworkGroupnets ListNetworkv3NetworkGroupnets(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkApi.ListNetworkv3NetworkGroupnets(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.ListNetworkv3NetworkGroupnets``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListNetworkv3NetworkGroupnets`: V3NetworkGroupnets
    fmt.Fprintf(os.Stdout, "Response from `NetworkApi.ListNetworkv3NetworkGroupnets`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListNetworkv3NetworkGroupnetsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3NetworkGroupnets**](V3NetworkGroupnets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateNetworkv10NetworkGroupnet

> UpdateNetworkv10NetworkGroupnet(ctx, v10NetworkGroupnetId).V10NetworkGroupnet(v10NetworkGroupnet).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10NetworkGroupnetId := "v10NetworkGroupnetId_example" // string | Modify a network groupnet.
    v10NetworkGroupnet := *openapiclient.NewV10NetworkGroupnetExtendedExtended() // V10NetworkGroupnetExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.UpdateNetworkv10NetworkGroupnet(context.Background(), v10NetworkGroupnetId).V10NetworkGroupnet(v10NetworkGroupnet).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.UpdateNetworkv10NetworkGroupnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10NetworkGroupnetId** | **string** | Modify a network groupnet. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateNetworkv10NetworkGroupnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v10NetworkGroupnet** | [**V10NetworkGroupnetExtendedExtended**](V10NetworkGroupnetExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateNetworkv12GroupnetsGroupnetSubnetsSubnetPool

> UpdateNetworkv12GroupnetsGroupnetSubnetsSubnetPool(ctx, v12GroupnetsGroupnetSubnetsSubnetPoolId, groupnet, subnet).V12GroupnetsGroupnetSubnetsSubnetPool(v12GroupnetsGroupnetSubnetsSubnetPool).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12GroupnetsGroupnetSubnetsSubnetPoolId := "v12GroupnetsGroupnetSubnetsSubnetPoolId_example" // string | Modify a network pool.
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 
    v12GroupnetsGroupnetSubnetsSubnetPool := *openapiclient.NewV12GroupnetsGroupnetSubnetsSubnetPool() // V12GroupnetsGroupnetSubnetsSubnetPool | 
    force := true // bool | Force creating this pool even if it causes an MTU conflict. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.UpdateNetworkv12GroupnetsGroupnetSubnetsSubnetPool(context.Background(), v12GroupnetsGroupnetSubnetsSubnetPoolId, groupnet, subnet).V12GroupnetsGroupnetSubnetsSubnetPool(v12GroupnetsGroupnetSubnetsSubnetPool).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.UpdateNetworkv12GroupnetsGroupnetSubnetsSubnetPool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12GroupnetsGroupnetSubnetsSubnetPoolId** | **string** | Modify a network pool. | 
**groupnet** | **string** |  | 
**subnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateNetworkv12GroupnetsGroupnetSubnetsSubnetPoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



 **v12GroupnetsGroupnetSubnetsSubnetPool** | [**V12GroupnetsGroupnetSubnetsSubnetPool**](V12GroupnetsGroupnetSubnetsSubnetPool.md) |  | 
 **force** | **bool** | Force creating this pool even if it causes an MTU conflict. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateNetworkv12NetworkExternal

> UpdateNetworkv12NetworkExternal(ctx).V12NetworkExternal(v12NetworkExternal).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12NetworkExternal := *openapiclient.NewV12NetworkExternalExtended() // V12NetworkExternalExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.UpdateNetworkv12NetworkExternal(context.Background()).V12NetworkExternal(v12NetworkExternal).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.UpdateNetworkv12NetworkExternal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateNetworkv12NetworkExternalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12NetworkExternal** | [**V12NetworkExternalExtended**](V12NetworkExternalExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateNetworkv16FirewallPoliciesPolicyRule

> UpdateNetworkv16FirewallPoliciesPolicyRule(ctx, v16FirewallPoliciesPolicyRuleId, policy).V16FirewallPoliciesPolicyRule(v16FirewallPoliciesPolicyRule).Live(live).AllowRenumbering(allowRenumbering).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16FirewallPoliciesPolicyRuleId := "v16FirewallPoliciesPolicyRuleId_example" // string | Modify a network firewall rule.
    policy := "policy_example" // string | 
    v16FirewallPoliciesPolicyRule := *openapiclient.NewV16FirewallPoliciesPolicyRule() // V16FirewallPoliciesPolicyRule | 
    live := true // bool | Live flag can only be used with active rules. Update will take effect immediately on all related network pools. (optional)
    allowRenumbering := true // bool | Indicates whether to allow renumbering of other rules when an index already exists (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.UpdateNetworkv16FirewallPoliciesPolicyRule(context.Background(), v16FirewallPoliciesPolicyRuleId, policy).V16FirewallPoliciesPolicyRule(v16FirewallPoliciesPolicyRule).Live(live).AllowRenumbering(allowRenumbering).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.UpdateNetworkv16FirewallPoliciesPolicyRule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v16FirewallPoliciesPolicyRuleId** | **string** | Modify a network firewall rule. | 
**policy** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateNetworkv16FirewallPoliciesPolicyRuleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v16FirewallPoliciesPolicyRule** | [**V16FirewallPoliciesPolicyRule**](V16FirewallPoliciesPolicyRule.md) |  | 
 **live** | **bool** | Live flag can only be used with active rules. Update will take effect immediately on all related network pools. | 
 **allowRenumbering** | **bool** | Indicates whether to allow renumbering of other rules when an index already exists | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateNetworkv16FirewallPolicy

> UpdateNetworkv16FirewallPolicy(ctx, v16FirewallPolicyId).V16FirewallPolicy(v16FirewallPolicy).Clone(clone).Live(live).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16FirewallPolicyId := "v16FirewallPolicyId_example" // string | Modify a network firewall policy.
    v16FirewallPolicy := *openapiclient.NewV16FirewallPolicyExtendedExtended() // V16FirewallPolicyExtendedExtended | 
    clone := true // bool | Clone an existing policy to a new one. (optional)
    live := true // bool | Live flag can only be used with active rules. Update will take effect immediately on all related network pools. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.UpdateNetworkv16FirewallPolicy(context.Background(), v16FirewallPolicyId).V16FirewallPolicy(v16FirewallPolicy).Clone(clone).Live(live).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.UpdateNetworkv16FirewallPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v16FirewallPolicyId** | **string** | Modify a network firewall policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateNetworkv16FirewallPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v16FirewallPolicy** | [**V16FirewallPolicyExtendedExtended**](V16FirewallPolicyExtendedExtended.md) |  | 
 **clone** | **bool** | Clone an existing policy to a new one. | 
 **live** | **bool** | Live flag can only be used with active rules. Update will take effect immediately on all related network pools. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateNetworkv16FirewallSettings

> UpdateNetworkv16FirewallSettings(ctx).V16FirewallSettings(v16FirewallSettings).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16FirewallSettings := *openapiclient.NewV16FirewallSettingsExtended() // V16FirewallSettingsExtended | 
    force := true // bool | Force modify firewall settings, even if it leads to FTP service being blocked (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.UpdateNetworkv16FirewallSettings(context.Background()).V16FirewallSettings(v16FirewallSettings).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.UpdateNetworkv16FirewallSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateNetworkv16FirewallSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16FirewallSettings** | [**V16FirewallSettingsExtended**](V16FirewallSettingsExtended.md) |  | 
 **force** | **bool** | Force modify firewall settings, even if it leads to FTP service being blocked | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateNetworkv16GroupnetsGroupnetSubnet

> UpdateNetworkv16GroupnetsGroupnetSubnet(ctx, v16GroupnetsGroupnetSubnetId, groupnet).V16GroupnetsGroupnetSubnet(v16GroupnetsGroupnetSubnet).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16GroupnetsGroupnetSubnetId := "v16GroupnetsGroupnetSubnetId_example" // string | Modify a network subnet.
    groupnet := "groupnet_example" // string | 
    v16GroupnetsGroupnetSubnet := *openapiclient.NewV16GroupnetsGroupnetSubnet() // V16GroupnetsGroupnetSubnet | 
    force := true // bool | Force modifying this subnet even if it causes an MTU conflict. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.UpdateNetworkv16GroupnetsGroupnetSubnet(context.Background(), v16GroupnetsGroupnetSubnetId, groupnet).V16GroupnetsGroupnetSubnet(v16GroupnetsGroupnetSubnet).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.UpdateNetworkv16GroupnetsGroupnetSubnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v16GroupnetsGroupnetSubnetId** | **string** | Modify a network subnet. | 
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateNetworkv16GroupnetsGroupnetSubnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v16GroupnetsGroupnetSubnet** | [**V16GroupnetsGroupnetSubnet**](V16GroupnetsGroupnetSubnet.md) |  | 
 **force** | **bool** | Force modifying this subnet even if it causes an MTU conflict. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateNetworkv16GroupnetsGroupnetSubnetsSubnetPool

> UpdateNetworkv16GroupnetsGroupnetSubnetsSubnetPool(ctx, v16GroupnetsGroupnetSubnetsSubnetPoolId, groupnet, subnet).V16GroupnetsGroupnetSubnetsSubnetPool(v16GroupnetsGroupnetSubnetsSubnetPool).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16GroupnetsGroupnetSubnetsSubnetPoolId := "v16GroupnetsGroupnetSubnetsSubnetPoolId_example" // string | Modify a network pool.
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 
    v16GroupnetsGroupnetSubnetsSubnetPool := *openapiclient.NewV16GroupnetsGroupnetSubnetsSubnetPool() // V16GroupnetsGroupnetSubnetsSubnetPool | 
    force := true // bool | Force creating this pool even if it causes an MTU conflict. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.UpdateNetworkv16GroupnetsGroupnetSubnetsSubnetPool(context.Background(), v16GroupnetsGroupnetSubnetsSubnetPoolId, groupnet, subnet).V16GroupnetsGroupnetSubnetsSubnetPool(v16GroupnetsGroupnetSubnetsSubnetPool).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.UpdateNetworkv16GroupnetsGroupnetSubnetsSubnetPool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v16GroupnetsGroupnetSubnetsSubnetPoolId** | **string** | Modify a network pool. | 
**groupnet** | **string** |  | 
**subnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateNetworkv16GroupnetsGroupnetSubnetsSubnetPoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



 **v16GroupnetsGroupnetSubnetsSubnetPool** | [**V16GroupnetsGroupnetSubnetsSubnetPool**](V16GroupnetsGroupnetSubnetsSubnetPool.md) |  | 
 **force** | **bool** | Force creating this pool even if it causes an MTU conflict. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateNetworkv16NetworkExternal

> UpdateNetworkv16NetworkExternal(ctx).V16NetworkExternal(v16NetworkExternal).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16NetworkExternal := *openapiclient.NewV16NetworkExternalExtended() // V16NetworkExternalExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.UpdateNetworkv16NetworkExternal(context.Background()).V16NetworkExternal(v16NetworkExternal).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.UpdateNetworkv16NetworkExternal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateNetworkv16NetworkExternalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16NetworkExternal** | [**V16NetworkExternalExtended**](V16NetworkExternalExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateNetworkv3GroupnetsGroupnetSubnet

> UpdateNetworkv3GroupnetsGroupnetSubnet(ctx, v3GroupnetsGroupnetSubnetId, groupnet).V3GroupnetsGroupnetSubnet(v3GroupnetsGroupnetSubnet).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3GroupnetsGroupnetSubnetId := "v3GroupnetsGroupnetSubnetId_example" // string | Modify a network subnet.
    groupnet := "groupnet_example" // string | 
    v3GroupnetsGroupnetSubnet := *openapiclient.NewV3GroupnetsGroupnetSubnet() // V3GroupnetsGroupnetSubnet | 
    force := true // bool | Force modifying this subnet even if it causes an MTU conflict. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.UpdateNetworkv3GroupnetsGroupnetSubnet(context.Background(), v3GroupnetsGroupnetSubnetId, groupnet).V3GroupnetsGroupnetSubnet(v3GroupnetsGroupnetSubnet).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.UpdateNetworkv3GroupnetsGroupnetSubnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3GroupnetsGroupnetSubnetId** | **string** | Modify a network subnet. | 
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateNetworkv3GroupnetsGroupnetSubnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v3GroupnetsGroupnetSubnet** | [**V3GroupnetsGroupnetSubnet**](V3GroupnetsGroupnetSubnet.md) |  | 
 **force** | **bool** | Force modifying this subnet even if it causes an MTU conflict. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateNetworkv3GroupnetsGroupnetSubnetsSubnetPool

> UpdateNetworkv3GroupnetsGroupnetSubnetsSubnetPool(ctx, v3GroupnetsGroupnetSubnetsSubnetPoolId, groupnet, subnet).V3GroupnetsGroupnetSubnetsSubnetPool(v3GroupnetsGroupnetSubnetsSubnetPool).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3GroupnetsGroupnetSubnetsSubnetPoolId := "v3GroupnetsGroupnetSubnetsSubnetPoolId_example" // string | Modify a network pool.
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 
    v3GroupnetsGroupnetSubnetsSubnetPool := *openapiclient.NewV3GroupnetsGroupnetSubnetsSubnetPool() // V3GroupnetsGroupnetSubnetsSubnetPool | 
    force := true // bool | Force creating this pool even if it causes an MTU conflict. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.UpdateNetworkv3GroupnetsGroupnetSubnetsSubnetPool(context.Background(), v3GroupnetsGroupnetSubnetsSubnetPoolId, groupnet, subnet).V3GroupnetsGroupnetSubnetsSubnetPool(v3GroupnetsGroupnetSubnetsSubnetPool).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.UpdateNetworkv3GroupnetsGroupnetSubnetsSubnetPool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3GroupnetsGroupnetSubnetsSubnetPoolId** | **string** | Modify a network pool. | 
**groupnet** | **string** |  | 
**subnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateNetworkv3GroupnetsGroupnetSubnetsSubnetPoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



 **v3GroupnetsGroupnetSubnetsSubnetPool** | [**V3GroupnetsGroupnetSubnetsSubnetPool**](V3GroupnetsGroupnetSubnetsSubnetPool.md) |  | 
 **force** | **bool** | Force creating this pool even if it causes an MTU conflict. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule

> UpdateNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule(ctx, v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRuleId, groupnet, subnet, pool).V3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule(v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRuleId := "v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRuleId_example" // string | Modify a network rule.
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 
    pool := "pool_example" // string | 
    v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule := *openapiclient.NewV3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule() // V3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.UpdateNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule(context.Background(), v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRuleId, groupnet, subnet, pool).V3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule(v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.UpdateNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRuleId** | **string** | Modify a network rule. | 
**groupnet** | **string** |  | 
**subnet** | **string** |  | 
**pool** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateNetworkv3GroupnetsGroupnetSubnetsSubnetPoolsPoolRuleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------




 **v3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule** | [**V3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule**](V3GroupnetsGroupnetSubnetsSubnetPoolsPoolRule.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateNetworkv3NetworkDnscache

> UpdateNetworkv3NetworkDnscache(ctx).V3NetworkDnscache(v3NetworkDnscache).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NetworkDnscache := *openapiclient.NewV3NetworkDnscacheExtended() // V3NetworkDnscacheExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.UpdateNetworkv3NetworkDnscache(context.Background()).V3NetworkDnscache(v3NetworkDnscache).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.UpdateNetworkv3NetworkDnscache``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateNetworkv3NetworkDnscacheRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3NetworkDnscache** | [**V3NetworkDnscacheExtended**](V3NetworkDnscacheExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateNetworkv3NetworkExternal

> UpdateNetworkv3NetworkExternal(ctx).V3NetworkExternal(v3NetworkExternal).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NetworkExternal := *openapiclient.NewV3NetworkExternalExtended() // V3NetworkExternalExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.UpdateNetworkv3NetworkExternal(context.Background()).V3NetworkExternal(v3NetworkExternal).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.UpdateNetworkv3NetworkExternal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateNetworkv3NetworkExternalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3NetworkExternal** | [**V3NetworkExternalExtended**](V3NetworkExternalExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateNetworkv3NetworkGroupnet

> UpdateNetworkv3NetworkGroupnet(ctx, v3NetworkGroupnetId).V3NetworkGroupnet(v3NetworkGroupnet).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NetworkGroupnetId := "v3NetworkGroupnetId_example" // string | Modify a network groupnet.
    v3NetworkGroupnet := *openapiclient.NewV3NetworkGroupnetExtendedExtended() // V3NetworkGroupnetExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.UpdateNetworkv3NetworkGroupnet(context.Background(), v3NetworkGroupnetId).V3NetworkGroupnet(v3NetworkGroupnet).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.UpdateNetworkv3NetworkGroupnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NetworkGroupnetId** | **string** | Modify a network groupnet. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateNetworkv3NetworkGroupnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3NetworkGroupnet** | [**V3NetworkGroupnetExtendedExtended**](V3NetworkGroupnetExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateNetworkv4GroupnetsGroupnetSubnet

> UpdateNetworkv4GroupnetsGroupnetSubnet(ctx, v4GroupnetsGroupnetSubnetId, groupnet).V4GroupnetsGroupnetSubnet(v4GroupnetsGroupnetSubnet).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4GroupnetsGroupnetSubnetId := "v4GroupnetsGroupnetSubnetId_example" // string | Modify a network subnet.
    groupnet := "groupnet_example" // string | 
    v4GroupnetsGroupnetSubnet := *openapiclient.NewV4GroupnetsGroupnetSubnet() // V4GroupnetsGroupnetSubnet | 
    force := true // bool | Force modifying this subnet even if it causes an MTU conflict. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.UpdateNetworkv4GroupnetsGroupnetSubnet(context.Background(), v4GroupnetsGroupnetSubnetId, groupnet).V4GroupnetsGroupnetSubnet(v4GroupnetsGroupnetSubnet).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.UpdateNetworkv4GroupnetsGroupnetSubnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4GroupnetsGroupnetSubnetId** | **string** | Modify a network subnet. | 
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateNetworkv4GroupnetsGroupnetSubnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v4GroupnetsGroupnetSubnet** | [**V4GroupnetsGroupnetSubnet**](V4GroupnetsGroupnetSubnet.md) |  | 
 **force** | **bool** | Force modifying this subnet even if it causes an MTU conflict. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateNetworkv7GroupnetsGroupnetSubnet

> UpdateNetworkv7GroupnetsGroupnetSubnet(ctx, v7GroupnetsGroupnetSubnetId, groupnet).V7GroupnetsGroupnetSubnet(v7GroupnetsGroupnetSubnet).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7GroupnetsGroupnetSubnetId := "v7GroupnetsGroupnetSubnetId_example" // string | Modify a network subnet.
    groupnet := "groupnet_example" // string | 
    v7GroupnetsGroupnetSubnet := *openapiclient.NewV16GroupnetsGroupnetSubnet() // V16GroupnetsGroupnetSubnet | 
    force := true // bool | Force modifying this subnet even if it causes an MTU conflict. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.NetworkApi.UpdateNetworkv7GroupnetsGroupnetSubnet(context.Background(), v7GroupnetsGroupnetSubnetId, groupnet).V7GroupnetsGroupnetSubnet(v7GroupnetsGroupnetSubnet).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkApi.UpdateNetworkv7GroupnetsGroupnetSubnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7GroupnetsGroupnetSubnetId** | **string** | Modify a network subnet. | 
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateNetworkv7GroupnetsGroupnetSubnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v7GroupnetsGroupnetSubnet** | [**V16GroupnetsGroupnetSubnet**](V16GroupnetsGroupnetSubnet.md) |  | 
 **force** | **bool** | Force modifying this subnet even if it causes an MTU conflict. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

