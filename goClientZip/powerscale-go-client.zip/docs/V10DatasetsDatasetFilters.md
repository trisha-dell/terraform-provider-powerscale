# V10DatasetsDatasetFilters

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Filters** | [**[]V10DatasetFilterExtended**](V10DatasetFilterExtended.md) |  | 

## Methods

### NewV10DatasetsDatasetFilters

`func NewV10DatasetsDatasetFilters(filters []V10DatasetFilterExtended, ) *V10DatasetsDatasetFilters`

NewV10DatasetsDatasetFilters instantiates a new V10DatasetsDatasetFilters object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10DatasetsDatasetFiltersWithDefaults

`func NewV10DatasetsDatasetFiltersWithDefaults() *V10DatasetsDatasetFilters`

NewV10DatasetsDatasetFiltersWithDefaults instantiates a new V10DatasetsDatasetFilters object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFilters

`func (o *V10DatasetsDatasetFilters) GetFilters() []V10DatasetFilterExtended`

GetFilters returns the Filters field if non-nil, zero value otherwise.

### GetFiltersOk

`func (o *V10DatasetsDatasetFilters) GetFiltersOk() (*[]V10DatasetFilterExtended, bool)`

GetFiltersOk returns a tuple with the Filters field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFilters

`func (o *V10DatasetsDatasetFilters) SetFilters(v []V10DatasetFilterExtended)`

SetFilters sets Filters field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


