# V12ClusterUpgrade

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NodesToRollingUpgrade** | Pointer to **[]int32** | The nodes (to be) scheduled for an existing upgrade ordered by queue position number: [&lt;lnn-1&gt;, &lt;lnn-2&gt;, ... ] | [optional] 

## Methods

### NewV12ClusterUpgrade

`func NewV12ClusterUpgrade() *V12ClusterUpgrade`

NewV12ClusterUpgrade instantiates a new V12ClusterUpgrade object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12ClusterUpgradeWithDefaults

`func NewV12ClusterUpgradeWithDefaults() *V12ClusterUpgrade`

NewV12ClusterUpgradeWithDefaults instantiates a new V12ClusterUpgrade object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNodesToRollingUpgrade

`func (o *V12ClusterUpgrade) GetNodesToRollingUpgrade() []int32`

GetNodesToRollingUpgrade returns the NodesToRollingUpgrade field if non-nil, zero value otherwise.

### GetNodesToRollingUpgradeOk

`func (o *V12ClusterUpgrade) GetNodesToRollingUpgradeOk() (*[]int32, bool)`

GetNodesToRollingUpgradeOk returns a tuple with the NodesToRollingUpgrade field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodesToRollingUpgrade

`func (o *V12ClusterUpgrade) SetNodesToRollingUpgrade(v []int32)`

SetNodesToRollingUpgrade sets NodesToRollingUpgrade field to given value.

### HasNodesToRollingUpgrade

`func (o *V12ClusterUpgrade) HasNodesToRollingUpgrade() bool`

HasNodesToRollingUpgrade returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


