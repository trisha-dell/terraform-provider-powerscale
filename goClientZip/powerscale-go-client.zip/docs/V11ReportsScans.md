# V11ReportsScans

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Reports** | Pointer to [**[]V11ReportsScansReport**](V11ReportsScansReport.md) |  | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV11ReportsScans

`func NewV11ReportsScans() *V11ReportsScans`

NewV11ReportsScans instantiates a new V11ReportsScans object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11ReportsScansWithDefaults

`func NewV11ReportsScansWithDefaults() *V11ReportsScans`

NewV11ReportsScansWithDefaults instantiates a new V11ReportsScans object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetReports

`func (o *V11ReportsScans) GetReports() []V11ReportsScansReport`

GetReports returns the Reports field if non-nil, zero value otherwise.

### GetReportsOk

`func (o *V11ReportsScans) GetReportsOk() (*[]V11ReportsScansReport, bool)`

GetReportsOk returns a tuple with the Reports field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReports

`func (o *V11ReportsScans) SetReports(v []V11ReportsScansReport)`

SetReports sets Reports field to given value.

### HasReports

`func (o *V11ReportsScans) HasReports() bool`

HasReports returns a boolean if a field has been set.

### GetResume

`func (o *V11ReportsScans) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V11ReportsScans) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V11ReportsScans) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V11ReportsScans) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V11ReportsScans) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V11ReportsScans) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V11ReportsScans) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V11ReportsScans) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


