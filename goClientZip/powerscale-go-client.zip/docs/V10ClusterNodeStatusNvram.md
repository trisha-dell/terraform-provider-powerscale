# V10ClusterNodeStatusNvram

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Batteries** | Pointer to [**[]V10ClusterNodeStatusNvramBattery**](V10ClusterNodeStatusNvramBattery.md) | This node&#39;s NVRAM battery status information. | [optional] 
**BatteryCount** | Pointer to **int32** | This node&#39;s NVRAM battery count. On failure: -1, otherwise 1 or 2. | [optional] 
**ChargeStatus** | Pointer to **string** | This node&#39;s NVRAM battery charge status, as a color. | [optional] 
**ChargeStatusNumber** | Pointer to **int32** | This node&#39;s NVRAM battery charge status, as a number. Error or not supported: -1. BR_BLACK: 0. BR_GREEN: 1. BR_YELLOW: 2. BR_RED: 3. | [optional] 
**Device** | Pointer to **string** | This node&#39;s NVRAM device name with path. | [optional] 
**Present** | Pointer to **bool** | This node has NVRAM. | [optional] 
**PresentFlash** | Pointer to **bool** | This node has NVRAM with flash storage. | [optional] 
**PresentSize** | Pointer to **int32** | The size of the NVRAM, in bytes. | [optional] 
**PresentType** | Pointer to **string** | This node&#39;s NVRAM type. | [optional] 
**ShipMode** | Pointer to **int32** | This node&#39;s current ship mode state for NVRAM batteries. If not supported or on failure: -1. Disabled: 0. Enabled: 1. | [optional] 
**Supported** | Pointer to **bool** | This node supports NVRAM. | [optional] 
**SupportedFlash** | Pointer to **bool** | This node supports NVRAM with flash storage. | [optional] 
**SupportedSize** | Pointer to **int64** | The maximum size of the NVRAM, in bytes. | [optional] 
**SupportedType** | Pointer to **string** | This node&#39;s supported NVRAM type. | [optional] 

## Methods

### NewV10ClusterNodeStatusNvram

`func NewV10ClusterNodeStatusNvram() *V10ClusterNodeStatusNvram`

NewV10ClusterNodeStatusNvram instantiates a new V10ClusterNodeStatusNvram object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeStatusNvramWithDefaults

`func NewV10ClusterNodeStatusNvramWithDefaults() *V10ClusterNodeStatusNvram`

NewV10ClusterNodeStatusNvramWithDefaults instantiates a new V10ClusterNodeStatusNvram object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBatteries

`func (o *V10ClusterNodeStatusNvram) GetBatteries() []V10ClusterNodeStatusNvramBattery`

GetBatteries returns the Batteries field if non-nil, zero value otherwise.

### GetBatteriesOk

`func (o *V10ClusterNodeStatusNvram) GetBatteriesOk() (*[]V10ClusterNodeStatusNvramBattery, bool)`

GetBatteriesOk returns a tuple with the Batteries field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBatteries

`func (o *V10ClusterNodeStatusNvram) SetBatteries(v []V10ClusterNodeStatusNvramBattery)`

SetBatteries sets Batteries field to given value.

### HasBatteries

`func (o *V10ClusterNodeStatusNvram) HasBatteries() bool`

HasBatteries returns a boolean if a field has been set.

### GetBatteryCount

`func (o *V10ClusterNodeStatusNvram) GetBatteryCount() int32`

GetBatteryCount returns the BatteryCount field if non-nil, zero value otherwise.

### GetBatteryCountOk

`func (o *V10ClusterNodeStatusNvram) GetBatteryCountOk() (*int32, bool)`

GetBatteryCountOk returns a tuple with the BatteryCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBatteryCount

`func (o *V10ClusterNodeStatusNvram) SetBatteryCount(v int32)`

SetBatteryCount sets BatteryCount field to given value.

### HasBatteryCount

`func (o *V10ClusterNodeStatusNvram) HasBatteryCount() bool`

HasBatteryCount returns a boolean if a field has been set.

### GetChargeStatus

`func (o *V10ClusterNodeStatusNvram) GetChargeStatus() string`

GetChargeStatus returns the ChargeStatus field if non-nil, zero value otherwise.

### GetChargeStatusOk

`func (o *V10ClusterNodeStatusNvram) GetChargeStatusOk() (*string, bool)`

GetChargeStatusOk returns a tuple with the ChargeStatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChargeStatus

`func (o *V10ClusterNodeStatusNvram) SetChargeStatus(v string)`

SetChargeStatus sets ChargeStatus field to given value.

### HasChargeStatus

`func (o *V10ClusterNodeStatusNvram) HasChargeStatus() bool`

HasChargeStatus returns a boolean if a field has been set.

### GetChargeStatusNumber

`func (o *V10ClusterNodeStatusNvram) GetChargeStatusNumber() int32`

GetChargeStatusNumber returns the ChargeStatusNumber field if non-nil, zero value otherwise.

### GetChargeStatusNumberOk

`func (o *V10ClusterNodeStatusNvram) GetChargeStatusNumberOk() (*int32, bool)`

GetChargeStatusNumberOk returns a tuple with the ChargeStatusNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChargeStatusNumber

`func (o *V10ClusterNodeStatusNvram) SetChargeStatusNumber(v int32)`

SetChargeStatusNumber sets ChargeStatusNumber field to given value.

### HasChargeStatusNumber

`func (o *V10ClusterNodeStatusNvram) HasChargeStatusNumber() bool`

HasChargeStatusNumber returns a boolean if a field has been set.

### GetDevice

`func (o *V10ClusterNodeStatusNvram) GetDevice() string`

GetDevice returns the Device field if non-nil, zero value otherwise.

### GetDeviceOk

`func (o *V10ClusterNodeStatusNvram) GetDeviceOk() (*string, bool)`

GetDeviceOk returns a tuple with the Device field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDevice

`func (o *V10ClusterNodeStatusNvram) SetDevice(v string)`

SetDevice sets Device field to given value.

### HasDevice

`func (o *V10ClusterNodeStatusNvram) HasDevice() bool`

HasDevice returns a boolean if a field has been set.

### GetPresent

`func (o *V10ClusterNodeStatusNvram) GetPresent() bool`

GetPresent returns the Present field if non-nil, zero value otherwise.

### GetPresentOk

`func (o *V10ClusterNodeStatusNvram) GetPresentOk() (*bool, bool)`

GetPresentOk returns a tuple with the Present field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPresent

`func (o *V10ClusterNodeStatusNvram) SetPresent(v bool)`

SetPresent sets Present field to given value.

### HasPresent

`func (o *V10ClusterNodeStatusNvram) HasPresent() bool`

HasPresent returns a boolean if a field has been set.

### GetPresentFlash

`func (o *V10ClusterNodeStatusNvram) GetPresentFlash() bool`

GetPresentFlash returns the PresentFlash field if non-nil, zero value otherwise.

### GetPresentFlashOk

`func (o *V10ClusterNodeStatusNvram) GetPresentFlashOk() (*bool, bool)`

GetPresentFlashOk returns a tuple with the PresentFlash field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPresentFlash

`func (o *V10ClusterNodeStatusNvram) SetPresentFlash(v bool)`

SetPresentFlash sets PresentFlash field to given value.

### HasPresentFlash

`func (o *V10ClusterNodeStatusNvram) HasPresentFlash() bool`

HasPresentFlash returns a boolean if a field has been set.

### GetPresentSize

`func (o *V10ClusterNodeStatusNvram) GetPresentSize() int32`

GetPresentSize returns the PresentSize field if non-nil, zero value otherwise.

### GetPresentSizeOk

`func (o *V10ClusterNodeStatusNvram) GetPresentSizeOk() (*int32, bool)`

GetPresentSizeOk returns a tuple with the PresentSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPresentSize

`func (o *V10ClusterNodeStatusNvram) SetPresentSize(v int32)`

SetPresentSize sets PresentSize field to given value.

### HasPresentSize

`func (o *V10ClusterNodeStatusNvram) HasPresentSize() bool`

HasPresentSize returns a boolean if a field has been set.

### GetPresentType

`func (o *V10ClusterNodeStatusNvram) GetPresentType() string`

GetPresentType returns the PresentType field if non-nil, zero value otherwise.

### GetPresentTypeOk

`func (o *V10ClusterNodeStatusNvram) GetPresentTypeOk() (*string, bool)`

GetPresentTypeOk returns a tuple with the PresentType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPresentType

`func (o *V10ClusterNodeStatusNvram) SetPresentType(v string)`

SetPresentType sets PresentType field to given value.

### HasPresentType

`func (o *V10ClusterNodeStatusNvram) HasPresentType() bool`

HasPresentType returns a boolean if a field has been set.

### GetShipMode

`func (o *V10ClusterNodeStatusNvram) GetShipMode() int32`

GetShipMode returns the ShipMode field if non-nil, zero value otherwise.

### GetShipModeOk

`func (o *V10ClusterNodeStatusNvram) GetShipModeOk() (*int32, bool)`

GetShipModeOk returns a tuple with the ShipMode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShipMode

`func (o *V10ClusterNodeStatusNvram) SetShipMode(v int32)`

SetShipMode sets ShipMode field to given value.

### HasShipMode

`func (o *V10ClusterNodeStatusNvram) HasShipMode() bool`

HasShipMode returns a boolean if a field has been set.

### GetSupported

`func (o *V10ClusterNodeStatusNvram) GetSupported() bool`

GetSupported returns the Supported field if non-nil, zero value otherwise.

### GetSupportedOk

`func (o *V10ClusterNodeStatusNvram) GetSupportedOk() (*bool, bool)`

GetSupportedOk returns a tuple with the Supported field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSupported

`func (o *V10ClusterNodeStatusNvram) SetSupported(v bool)`

SetSupported sets Supported field to given value.

### HasSupported

`func (o *V10ClusterNodeStatusNvram) HasSupported() bool`

HasSupported returns a boolean if a field has been set.

### GetSupportedFlash

`func (o *V10ClusterNodeStatusNvram) GetSupportedFlash() bool`

GetSupportedFlash returns the SupportedFlash field if non-nil, zero value otherwise.

### GetSupportedFlashOk

`func (o *V10ClusterNodeStatusNvram) GetSupportedFlashOk() (*bool, bool)`

GetSupportedFlashOk returns a tuple with the SupportedFlash field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSupportedFlash

`func (o *V10ClusterNodeStatusNvram) SetSupportedFlash(v bool)`

SetSupportedFlash sets SupportedFlash field to given value.

### HasSupportedFlash

`func (o *V10ClusterNodeStatusNvram) HasSupportedFlash() bool`

HasSupportedFlash returns a boolean if a field has been set.

### GetSupportedSize

`func (o *V10ClusterNodeStatusNvram) GetSupportedSize() int64`

GetSupportedSize returns the SupportedSize field if non-nil, zero value otherwise.

### GetSupportedSizeOk

`func (o *V10ClusterNodeStatusNvram) GetSupportedSizeOk() (*int64, bool)`

GetSupportedSizeOk returns a tuple with the SupportedSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSupportedSize

`func (o *V10ClusterNodeStatusNvram) SetSupportedSize(v int64)`

SetSupportedSize sets SupportedSize field to given value.

### HasSupportedSize

`func (o *V10ClusterNodeStatusNvram) HasSupportedSize() bool`

HasSupportedSize returns a boolean if a field has been set.

### GetSupportedType

`func (o *V10ClusterNodeStatusNvram) GetSupportedType() string`

GetSupportedType returns the SupportedType field if non-nil, zero value otherwise.

### GetSupportedTypeOk

`func (o *V10ClusterNodeStatusNvram) GetSupportedTypeOk() (*string, bool)`

GetSupportedTypeOk returns a tuple with the SupportedType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSupportedType

`func (o *V10ClusterNodeStatusNvram) SetSupportedType(v string)`

SetSupportedType sets SupportedType field to given value.

### HasSupportedType

`func (o *V10ClusterNodeStatusNvram) HasSupportedType() bool`

HasSupportedType returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


