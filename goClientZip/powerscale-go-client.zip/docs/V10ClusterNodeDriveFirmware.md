# V10ClusterNodeDriveFirmware

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CurrentFirmware** | Pointer to **string** | This drive&#39;s current firmware revision | [optional] 
**DesiredFirmware** | Pointer to **string** | This drive&#39;s desired firmware revision. | [optional] 

## Methods

### NewV10ClusterNodeDriveFirmware

`func NewV10ClusterNodeDriveFirmware() *V10ClusterNodeDriveFirmware`

NewV10ClusterNodeDriveFirmware instantiates a new V10ClusterNodeDriveFirmware object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeDriveFirmwareWithDefaults

`func NewV10ClusterNodeDriveFirmwareWithDefaults() *V10ClusterNodeDriveFirmware`

NewV10ClusterNodeDriveFirmwareWithDefaults instantiates a new V10ClusterNodeDriveFirmware object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCurrentFirmware

`func (o *V10ClusterNodeDriveFirmware) GetCurrentFirmware() string`

GetCurrentFirmware returns the CurrentFirmware field if non-nil, zero value otherwise.

### GetCurrentFirmwareOk

`func (o *V10ClusterNodeDriveFirmware) GetCurrentFirmwareOk() (*string, bool)`

GetCurrentFirmwareOk returns a tuple with the CurrentFirmware field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCurrentFirmware

`func (o *V10ClusterNodeDriveFirmware) SetCurrentFirmware(v string)`

SetCurrentFirmware sets CurrentFirmware field to given value.

### HasCurrentFirmware

`func (o *V10ClusterNodeDriveFirmware) HasCurrentFirmware() bool`

HasCurrentFirmware returns a boolean if a field has been set.

### GetDesiredFirmware

`func (o *V10ClusterNodeDriveFirmware) GetDesiredFirmware() string`

GetDesiredFirmware returns the DesiredFirmware field if non-nil, zero value otherwise.

### GetDesiredFirmwareOk

`func (o *V10ClusterNodeDriveFirmware) GetDesiredFirmwareOk() (*string, bool)`

GetDesiredFirmwareOk returns a tuple with the DesiredFirmware field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDesiredFirmware

`func (o *V10ClusterNodeDriveFirmware) SetDesiredFirmware(v string)`

SetDesiredFirmware sets DesiredFirmware field to given value.

### HasDesiredFirmware

`func (o *V10ClusterNodeDriveFirmware) HasDesiredFirmware() bool`

HasDesiredFirmware returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


