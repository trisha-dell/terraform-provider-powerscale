# Createv10S3KeyResponseKeys

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccessId** | Pointer to **string** | S3 Access ID | [optional] 
**OldKeyExpiry** | Pointer to **int32** | Time that previous secret key will expire, in format YYYY-MM-DD HH:MM:SS | [optional] 
**OldKeyTimestamp** | Pointer to **int32** | Time that previous secret key was created, in format YYYY-MM-DD HH:MM:SS | [optional] 
**OldSecretKey** | Pointer to **string** | Previous secret key | [optional] 
**SecretKey** | Pointer to **string** | Secret key | [optional] 
**SecretKeyTimestamp** | Pointer to **int32** | Time that secret key was created, in format YYYY-MM-DD HH:MM:SS | [optional] 

## Methods

### NewCreatev10S3KeyResponseKeys

`func NewCreatev10S3KeyResponseKeys() *Createv10S3KeyResponseKeys`

NewCreatev10S3KeyResponseKeys instantiates a new Createv10S3KeyResponseKeys object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev10S3KeyResponseKeysWithDefaults

`func NewCreatev10S3KeyResponseKeysWithDefaults() *Createv10S3KeyResponseKeys`

NewCreatev10S3KeyResponseKeysWithDefaults instantiates a new Createv10S3KeyResponseKeys object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAccessId

`func (o *Createv10S3KeyResponseKeys) GetAccessId() string`

GetAccessId returns the AccessId field if non-nil, zero value otherwise.

### GetAccessIdOk

`func (o *Createv10S3KeyResponseKeys) GetAccessIdOk() (*string, bool)`

GetAccessIdOk returns a tuple with the AccessId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAccessId

`func (o *Createv10S3KeyResponseKeys) SetAccessId(v string)`

SetAccessId sets AccessId field to given value.

### HasAccessId

`func (o *Createv10S3KeyResponseKeys) HasAccessId() bool`

HasAccessId returns a boolean if a field has been set.

### GetOldKeyExpiry

`func (o *Createv10S3KeyResponseKeys) GetOldKeyExpiry() int32`

GetOldKeyExpiry returns the OldKeyExpiry field if non-nil, zero value otherwise.

### GetOldKeyExpiryOk

`func (o *Createv10S3KeyResponseKeys) GetOldKeyExpiryOk() (*int32, bool)`

GetOldKeyExpiryOk returns a tuple with the OldKeyExpiry field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOldKeyExpiry

`func (o *Createv10S3KeyResponseKeys) SetOldKeyExpiry(v int32)`

SetOldKeyExpiry sets OldKeyExpiry field to given value.

### HasOldKeyExpiry

`func (o *Createv10S3KeyResponseKeys) HasOldKeyExpiry() bool`

HasOldKeyExpiry returns a boolean if a field has been set.

### GetOldKeyTimestamp

`func (o *Createv10S3KeyResponseKeys) GetOldKeyTimestamp() int32`

GetOldKeyTimestamp returns the OldKeyTimestamp field if non-nil, zero value otherwise.

### GetOldKeyTimestampOk

`func (o *Createv10S3KeyResponseKeys) GetOldKeyTimestampOk() (*int32, bool)`

GetOldKeyTimestampOk returns a tuple with the OldKeyTimestamp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOldKeyTimestamp

`func (o *Createv10S3KeyResponseKeys) SetOldKeyTimestamp(v int32)`

SetOldKeyTimestamp sets OldKeyTimestamp field to given value.

### HasOldKeyTimestamp

`func (o *Createv10S3KeyResponseKeys) HasOldKeyTimestamp() bool`

HasOldKeyTimestamp returns a boolean if a field has been set.

### GetOldSecretKey

`func (o *Createv10S3KeyResponseKeys) GetOldSecretKey() string`

GetOldSecretKey returns the OldSecretKey field if non-nil, zero value otherwise.

### GetOldSecretKeyOk

`func (o *Createv10S3KeyResponseKeys) GetOldSecretKeyOk() (*string, bool)`

GetOldSecretKeyOk returns a tuple with the OldSecretKey field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOldSecretKey

`func (o *Createv10S3KeyResponseKeys) SetOldSecretKey(v string)`

SetOldSecretKey sets OldSecretKey field to given value.

### HasOldSecretKey

`func (o *Createv10S3KeyResponseKeys) HasOldSecretKey() bool`

HasOldSecretKey returns a boolean if a field has been set.

### GetSecretKey

`func (o *Createv10S3KeyResponseKeys) GetSecretKey() string`

GetSecretKey returns the SecretKey field if non-nil, zero value otherwise.

### GetSecretKeyOk

`func (o *Createv10S3KeyResponseKeys) GetSecretKeyOk() (*string, bool)`

GetSecretKeyOk returns a tuple with the SecretKey field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSecretKey

`func (o *Createv10S3KeyResponseKeys) SetSecretKey(v string)`

SetSecretKey sets SecretKey field to given value.

### HasSecretKey

`func (o *Createv10S3KeyResponseKeys) HasSecretKey() bool`

HasSecretKey returns a boolean if a field has been set.

### GetSecretKeyTimestamp

`func (o *Createv10S3KeyResponseKeys) GetSecretKeyTimestamp() int32`

GetSecretKeyTimestamp returns the SecretKeyTimestamp field if non-nil, zero value otherwise.

### GetSecretKeyTimestampOk

`func (o *Createv10S3KeyResponseKeys) GetSecretKeyTimestampOk() (*int32, bool)`

GetSecretKeyTimestampOk returns a tuple with the SecretKeyTimestamp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSecretKeyTimestamp

`func (o *Createv10S3KeyResponseKeys) SetSecretKeyTimestamp(v int32)`

SetSecretKeyTimestamp sets SecretKeyTimestamp field to given value.

### HasSecretKeyTimestamp

`func (o *Createv10S3KeyResponseKeys) HasSecretKeyTimestamp() bool`

HasSecretKeyTimestamp returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


