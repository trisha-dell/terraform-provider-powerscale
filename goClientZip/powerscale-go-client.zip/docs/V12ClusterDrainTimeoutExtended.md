# V12ClusterDrainTimeoutExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AlertTimeout** | Pointer to **int32** | The duration in seconds after drain begins that an alert will be raised. An alert timeout must be set to a smaller value than the drain timeout to be used. If not specified, an alert will not be raised (legacy behavior). | [optional] 
**DrainTimeout** | Pointer to **int32** | The duration in seconds that upgrade waits for all SMB clients to disconnect from a node before rebooting it. A value of 0 means wait indefinitely. If not specified, upgrade proceeds with reboots regardless of SMB client connections (legacy behavior). | [optional] 

## Methods

### NewV12ClusterDrainTimeoutExtended

`func NewV12ClusterDrainTimeoutExtended() *V12ClusterDrainTimeoutExtended`

NewV12ClusterDrainTimeoutExtended instantiates a new V12ClusterDrainTimeoutExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12ClusterDrainTimeoutExtendedWithDefaults

`func NewV12ClusterDrainTimeoutExtendedWithDefaults() *V12ClusterDrainTimeoutExtended`

NewV12ClusterDrainTimeoutExtendedWithDefaults instantiates a new V12ClusterDrainTimeoutExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAlertTimeout

`func (o *V12ClusterDrainTimeoutExtended) GetAlertTimeout() int32`

GetAlertTimeout returns the AlertTimeout field if non-nil, zero value otherwise.

### GetAlertTimeoutOk

`func (o *V12ClusterDrainTimeoutExtended) GetAlertTimeoutOk() (*int32, bool)`

GetAlertTimeoutOk returns a tuple with the AlertTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAlertTimeout

`func (o *V12ClusterDrainTimeoutExtended) SetAlertTimeout(v int32)`

SetAlertTimeout sets AlertTimeout field to given value.

### HasAlertTimeout

`func (o *V12ClusterDrainTimeoutExtended) HasAlertTimeout() bool`

HasAlertTimeout returns a boolean if a field has been set.

### GetDrainTimeout

`func (o *V12ClusterDrainTimeoutExtended) GetDrainTimeout() int32`

GetDrainTimeout returns the DrainTimeout field if non-nil, zero value otherwise.

### GetDrainTimeoutOk

`func (o *V12ClusterDrainTimeoutExtended) GetDrainTimeoutOk() (*int32, bool)`

GetDrainTimeoutOk returns a tuple with the DrainTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDrainTimeout

`func (o *V12ClusterDrainTimeoutExtended) SetDrainTimeout(v int32)`

SetDrainTimeout sets DrainTimeout field to given value.

### HasDrainTimeout

`func (o *V12ClusterDrainTimeoutExtended) HasDrainTimeout() bool`

HasDrainTimeout returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


