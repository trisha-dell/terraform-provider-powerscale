# V12QuotaQuotas

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Quotas** | Pointer to [**[]V12QuotaQuotaExtended**](V12QuotaQuotaExtended.md) |  | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 

## Methods

### NewV12QuotaQuotas

`func NewV12QuotaQuotas() *V12QuotaQuotas`

NewV12QuotaQuotas instantiates a new V12QuotaQuotas object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12QuotaQuotasWithDefaults

`func NewV12QuotaQuotasWithDefaults() *V12QuotaQuotas`

NewV12QuotaQuotasWithDefaults instantiates a new V12QuotaQuotas object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetQuotas

`func (o *V12QuotaQuotas) GetQuotas() []V12QuotaQuotaExtended`

GetQuotas returns the Quotas field if non-nil, zero value otherwise.

### GetQuotasOk

`func (o *V12QuotaQuotas) GetQuotasOk() (*[]V12QuotaQuotaExtended, bool)`

GetQuotasOk returns a tuple with the Quotas field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetQuotas

`func (o *V12QuotaQuotas) SetQuotas(v []V12QuotaQuotaExtended)`

SetQuotas sets Quotas field to given value.

### HasQuotas

`func (o *V12QuotaQuotas) HasQuotas() bool`

HasQuotas returns a boolean if a field has been set.

### GetResume

`func (o *V12QuotaQuotas) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V12QuotaQuotas) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V12QuotaQuotas) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V12QuotaQuotas) HasResume() bool`

HasResume returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


