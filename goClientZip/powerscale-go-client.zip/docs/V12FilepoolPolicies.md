# V12FilepoolPolicies

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Policies** | Pointer to [**[]V12FilepoolPolicyExtended**](V12FilepoolPolicyExtended.md) |  | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV12FilepoolPolicies

`func NewV12FilepoolPolicies() *V12FilepoolPolicies`

NewV12FilepoolPolicies instantiates a new V12FilepoolPolicies object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12FilepoolPoliciesWithDefaults

`func NewV12FilepoolPoliciesWithDefaults() *V12FilepoolPolicies`

NewV12FilepoolPoliciesWithDefaults instantiates a new V12FilepoolPolicies object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetPolicies

`func (o *V12FilepoolPolicies) GetPolicies() []V12FilepoolPolicyExtended`

GetPolicies returns the Policies field if non-nil, zero value otherwise.

### GetPoliciesOk

`func (o *V12FilepoolPolicies) GetPoliciesOk() (*[]V12FilepoolPolicyExtended, bool)`

GetPoliciesOk returns a tuple with the Policies field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPolicies

`func (o *V12FilepoolPolicies) SetPolicies(v []V12FilepoolPolicyExtended)`

SetPolicies sets Policies field to given value.

### HasPolicies

`func (o *V12FilepoolPolicies) HasPolicies() bool`

HasPolicies returns a boolean if a field has been set.

### GetTotal

`func (o *V12FilepoolPolicies) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V12FilepoolPolicies) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V12FilepoolPolicies) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V12FilepoolPolicies) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


