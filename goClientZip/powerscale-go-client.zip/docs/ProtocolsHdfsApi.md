# \ProtocolsHdfsApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateProtocolsHdfsv1ProxyusersNameMember**](ProtocolsHdfsApi.md#CreateProtocolsHdfsv1ProxyusersNameMember) | **Post** /platform/1/protocols/hdfs/proxyusers/{Name}/members | 
[**ListProtocolsHdfsv1ProxyusersNameMembers**](ProtocolsHdfsApi.md#ListProtocolsHdfsv1ProxyusersNameMembers) | **Get** /platform/1/protocols/hdfs/proxyusers/{Name}/members | 



## CreateProtocolsHdfsv1ProxyusersNameMember

> map[string]interface{} CreateProtocolsHdfsv1ProxyusersNameMember(ctx, name).V1ProxyusersNameMember(v1ProxyusersNameMember).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    name := "name_example" // string | 
    v1ProxyusersNameMember := *openapiclient.NewV1AuthAccessAccessItemFileGroup() // V1AuthAccessAccessItemFileGroup | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsHdfsApi.CreateProtocolsHdfsv1ProxyusersNameMember(context.Background(), name).V1ProxyusersNameMember(v1ProxyusersNameMember).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsHdfsApi.CreateProtocolsHdfsv1ProxyusersNameMember``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsHdfsv1ProxyusersNameMember`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsHdfsApi.CreateProtocolsHdfsv1ProxyusersNameMember`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**name** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsHdfsv1ProxyusersNameMemberRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1ProxyusersNameMember** | [**V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsHdfsv1ProxyusersNameMembers

> V1RoleMembers ListProtocolsHdfsv1ProxyusersNameMembers(ctx, name).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    name := "name_example" // string | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsHdfsApi.ListProtocolsHdfsv1ProxyusersNameMembers(context.Background(), name).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsHdfsApi.ListProtocolsHdfsv1ProxyusersNameMembers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsHdfsv1ProxyusersNameMembers`: V1RoleMembers
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsHdfsApi.ListProtocolsHdfsv1ProxyusersNameMembers`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**name** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsHdfsv1ProxyusersNameMembersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**V1RoleMembers**](V1RoleMembers.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

