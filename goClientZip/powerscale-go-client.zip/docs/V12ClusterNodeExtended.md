# V12ClusterNodeExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Domain** | Pointer to **int32** | Unique identifier for the failure domain that thisnode resides in. Within a given domain, nodes are rebooted 1 at a time. The actual value is meaningless, it is merely used to group nodes by failure domain. | [optional] 
**DownPeer** | Pointer to **bool** | Peer node is down. | [optional] 
**Error** | Pointer to [**V12ClusterNodeError**](V12ClusterNodeError.md) |  | [optional] 
**LastAction** | Pointer to **string** | The last action performed to completion/failure on this node.  Null if the node_state is &#39;committed&#39; or &#39;assessing.&#39; One of the following values: &#39;upgrade&#39;, &#39;rollback&#39;. | [optional] 
**LastActionResult** | Pointer to **string** | Did the node pass upgrade or rollback without failing? Null if the node_state is &#39;committed.&#39; One of the following values: &#39;pass&#39;, &#39;fail&#39;, null | [optional] 
**Lnn** | Pointer to **int32** | The lnn of the node. | [optional] 
**NodeState** | Pointer to **string** | \\e The state of the node during the upgrade, rollback, or assessment. One of the following values: &#39;committed&#39;, &#39;upgraded&#39;, &#39;upgrading&#39;, &#39;rolling back&#39;, &#39;assessing&#39;, &#39;error&#39; | [optional] 
**OnefsVersion** | Pointer to [**V12UpgradeClusterOnefsVersionCurrent**](V12UpgradeClusterOnefsVersionCurrent.md) |  | [optional] 
**Progress** | Pointer to **int32** | What step is the upgrade, assessment, or rollback in? To show via progress indicator. NOTE: the value is an integer between 0 and 100 (percent) | [optional] 

## Methods

### NewV12ClusterNodeExtended

`func NewV12ClusterNodeExtended() *V12ClusterNodeExtended`

NewV12ClusterNodeExtended instantiates a new V12ClusterNodeExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12ClusterNodeExtendedWithDefaults

`func NewV12ClusterNodeExtendedWithDefaults() *V12ClusterNodeExtended`

NewV12ClusterNodeExtendedWithDefaults instantiates a new V12ClusterNodeExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDomain

`func (o *V12ClusterNodeExtended) GetDomain() int32`

GetDomain returns the Domain field if non-nil, zero value otherwise.

### GetDomainOk

`func (o *V12ClusterNodeExtended) GetDomainOk() (*int32, bool)`

GetDomainOk returns a tuple with the Domain field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDomain

`func (o *V12ClusterNodeExtended) SetDomain(v int32)`

SetDomain sets Domain field to given value.

### HasDomain

`func (o *V12ClusterNodeExtended) HasDomain() bool`

HasDomain returns a boolean if a field has been set.

### GetDownPeer

`func (o *V12ClusterNodeExtended) GetDownPeer() bool`

GetDownPeer returns the DownPeer field if non-nil, zero value otherwise.

### GetDownPeerOk

`func (o *V12ClusterNodeExtended) GetDownPeerOk() (*bool, bool)`

GetDownPeerOk returns a tuple with the DownPeer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDownPeer

`func (o *V12ClusterNodeExtended) SetDownPeer(v bool)`

SetDownPeer sets DownPeer field to given value.

### HasDownPeer

`func (o *V12ClusterNodeExtended) HasDownPeer() bool`

HasDownPeer returns a boolean if a field has been set.

### GetError

`func (o *V12ClusterNodeExtended) GetError() V12ClusterNodeError`

GetError returns the Error field if non-nil, zero value otherwise.

### GetErrorOk

`func (o *V12ClusterNodeExtended) GetErrorOk() (*V12ClusterNodeError, bool)`

GetErrorOk returns a tuple with the Error field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetError

`func (o *V12ClusterNodeExtended) SetError(v V12ClusterNodeError)`

SetError sets Error field to given value.

### HasError

`func (o *V12ClusterNodeExtended) HasError() bool`

HasError returns a boolean if a field has been set.

### GetLastAction

`func (o *V12ClusterNodeExtended) GetLastAction() string`

GetLastAction returns the LastAction field if non-nil, zero value otherwise.

### GetLastActionOk

`func (o *V12ClusterNodeExtended) GetLastActionOk() (*string, bool)`

GetLastActionOk returns a tuple with the LastAction field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastAction

`func (o *V12ClusterNodeExtended) SetLastAction(v string)`

SetLastAction sets LastAction field to given value.

### HasLastAction

`func (o *V12ClusterNodeExtended) HasLastAction() bool`

HasLastAction returns a boolean if a field has been set.

### GetLastActionResult

`func (o *V12ClusterNodeExtended) GetLastActionResult() string`

GetLastActionResult returns the LastActionResult field if non-nil, zero value otherwise.

### GetLastActionResultOk

`func (o *V12ClusterNodeExtended) GetLastActionResultOk() (*string, bool)`

GetLastActionResultOk returns a tuple with the LastActionResult field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastActionResult

`func (o *V12ClusterNodeExtended) SetLastActionResult(v string)`

SetLastActionResult sets LastActionResult field to given value.

### HasLastActionResult

`func (o *V12ClusterNodeExtended) HasLastActionResult() bool`

HasLastActionResult returns a boolean if a field has been set.

### GetLnn

`func (o *V12ClusterNodeExtended) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V12ClusterNodeExtended) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V12ClusterNodeExtended) SetLnn(v int32)`

SetLnn sets Lnn field to given value.

### HasLnn

`func (o *V12ClusterNodeExtended) HasLnn() bool`

HasLnn returns a boolean if a field has been set.

### GetNodeState

`func (o *V12ClusterNodeExtended) GetNodeState() string`

GetNodeState returns the NodeState field if non-nil, zero value otherwise.

### GetNodeStateOk

`func (o *V12ClusterNodeExtended) GetNodeStateOk() (*string, bool)`

GetNodeStateOk returns a tuple with the NodeState field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodeState

`func (o *V12ClusterNodeExtended) SetNodeState(v string)`

SetNodeState sets NodeState field to given value.

### HasNodeState

`func (o *V12ClusterNodeExtended) HasNodeState() bool`

HasNodeState returns a boolean if a field has been set.

### GetOnefsVersion

`func (o *V12ClusterNodeExtended) GetOnefsVersion() V12UpgradeClusterOnefsVersionCurrent`

GetOnefsVersion returns the OnefsVersion field if non-nil, zero value otherwise.

### GetOnefsVersionOk

`func (o *V12ClusterNodeExtended) GetOnefsVersionOk() (*V12UpgradeClusterOnefsVersionCurrent, bool)`

GetOnefsVersionOk returns a tuple with the OnefsVersion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOnefsVersion

`func (o *V12ClusterNodeExtended) SetOnefsVersion(v V12UpgradeClusterOnefsVersionCurrent)`

SetOnefsVersion sets OnefsVersion field to given value.

### HasOnefsVersion

`func (o *V12ClusterNodeExtended) HasOnefsVersion() bool`

HasOnefsVersion returns a boolean if a field has been set.

### GetProgress

`func (o *V12ClusterNodeExtended) GetProgress() int32`

GetProgress returns the Progress field if non-nil, zero value otherwise.

### GetProgressOk

`func (o *V12ClusterNodeExtended) GetProgressOk() (*int32, bool)`

GetProgressOk returns a tuple with the Progress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProgress

`func (o *V12ClusterNodeExtended) SetProgress(v int32)`

SetProgress sets Progress field to given value.

### HasProgress

`func (o *V12ClusterNodeExtended) HasProgress() bool`

HasProgress returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


