# V12DatasetWorkloads

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 
**Workloads** | [**[]V12DatasetWorkloadExtended**](V12DatasetWorkloadExtended.md) |  | 

## Methods

### NewV12DatasetWorkloads

`func NewV12DatasetWorkloads(workloads []V12DatasetWorkloadExtended, ) *V12DatasetWorkloads`

NewV12DatasetWorkloads instantiates a new V12DatasetWorkloads object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12DatasetWorkloadsWithDefaults

`func NewV12DatasetWorkloadsWithDefaults() *V12DatasetWorkloads`

NewV12DatasetWorkloadsWithDefaults instantiates a new V12DatasetWorkloads object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetResume

`func (o *V12DatasetWorkloads) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V12DatasetWorkloads) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V12DatasetWorkloads) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V12DatasetWorkloads) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V12DatasetWorkloads) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V12DatasetWorkloads) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V12DatasetWorkloads) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V12DatasetWorkloads) HasTotal() bool`

HasTotal returns a boolean if a field has been set.

### GetWorkloads

`func (o *V12DatasetWorkloads) GetWorkloads() []V12DatasetWorkloadExtended`

GetWorkloads returns the Workloads field if non-nil, zero value otherwise.

### GetWorkloadsOk

`func (o *V12DatasetWorkloads) GetWorkloadsOk() (*[]V12DatasetWorkloadExtended, bool)`

GetWorkloadsOk returns a tuple with the Workloads field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWorkloads

`func (o *V12DatasetWorkloads) SetWorkloads(v []V12DatasetWorkloadExtended)`

SetWorkloads sets Workloads field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


