# V10ChangelistEntryCtime

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Nsec** | Pointer to **int32** | Nanoseconds component of timespec. | [optional] 
**Sec** | **int32** | Seconds component of timespec. | 

## Methods

### NewV10ChangelistEntryCtime

`func NewV10ChangelistEntryCtime(sec int32, ) *V10ChangelistEntryCtime`

NewV10ChangelistEntryCtime instantiates a new V10ChangelistEntryCtime object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ChangelistEntryCtimeWithDefaults

`func NewV10ChangelistEntryCtimeWithDefaults() *V10ChangelistEntryCtime`

NewV10ChangelistEntryCtimeWithDefaults instantiates a new V10ChangelistEntryCtime object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNsec

`func (o *V10ChangelistEntryCtime) GetNsec() int32`

GetNsec returns the Nsec field if non-nil, zero value otherwise.

### GetNsecOk

`func (o *V10ChangelistEntryCtime) GetNsecOk() (*int32, bool)`

GetNsecOk returns a tuple with the Nsec field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNsec

`func (o *V10ChangelistEntryCtime) SetNsec(v int32)`

SetNsec sets Nsec field to given value.

### HasNsec

`func (o *V10ChangelistEntryCtime) HasNsec() bool`

HasNsec returns a boolean if a field has been set.

### GetSec

`func (o *V10ChangelistEntryCtime) GetSec() int32`

GetSec returns the Sec field if non-nil, zero value otherwise.

### GetSecOk

`func (o *V10ChangelistEntryCtime) GetSecOk() (*int32, bool)`

GetSecOk returns a tuple with the Sec field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSec

`func (o *V10ChangelistEntryCtime) SetSec(v int32)`

SetSec sets Sec field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


