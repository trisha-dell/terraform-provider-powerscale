# V10ClusterNodePartitionStatfs

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FBavail** | Pointer to **int32** | Free blocks available to non-superuser on this partition. | [optional] 
**FBfree** | Pointer to **int32** | Free blocks on this partition. | [optional] 
**FBlocks** | Pointer to **int32** | Total data blocks on this partition. | [optional] 
**FBsize** | Pointer to **int32** | Filesystem fragment size; block size in OneFS. | [optional] 
**FFfree** | Pointer to **int32** | Free file nodes avail to non-superuser. | [optional] 
**FFiles** | Pointer to **int32** | Total file nodes in filesystem. | [optional] 
**FFlags** | Pointer to **int32** | Mount exported flags. | [optional] 
**FFstypename** | Pointer to **string** | File system type name. | [optional] 
**FIosize** | Pointer to **int32** | Optimal transfer block size. | [optional] 
**FMntfromname** | Pointer to **string** | Names of devices this partition is mounted from. | [optional] 
**FMntonname** | Pointer to **string** | Directory this partition is mounted to. | [optional] 
**FNamemax** | Pointer to **int32** | Maximum filename length. | [optional] 
**FOwner** | Pointer to **int32** | UID of user that mounted the filesystem. | [optional] 
**FType** | Pointer to **int32** | Type of filesystem. | [optional] 
**FVersion** | Pointer to **int32** | statfs() structure version number. | [optional] 

## Methods

### NewV10ClusterNodePartitionStatfs

`func NewV10ClusterNodePartitionStatfs() *V10ClusterNodePartitionStatfs`

NewV10ClusterNodePartitionStatfs instantiates a new V10ClusterNodePartitionStatfs object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodePartitionStatfsWithDefaults

`func NewV10ClusterNodePartitionStatfsWithDefaults() *V10ClusterNodePartitionStatfs`

NewV10ClusterNodePartitionStatfsWithDefaults instantiates a new V10ClusterNodePartitionStatfs object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFBavail

`func (o *V10ClusterNodePartitionStatfs) GetFBavail() int32`

GetFBavail returns the FBavail field if non-nil, zero value otherwise.

### GetFBavailOk

`func (o *V10ClusterNodePartitionStatfs) GetFBavailOk() (*int32, bool)`

GetFBavailOk returns a tuple with the FBavail field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFBavail

`func (o *V10ClusterNodePartitionStatfs) SetFBavail(v int32)`

SetFBavail sets FBavail field to given value.

### HasFBavail

`func (o *V10ClusterNodePartitionStatfs) HasFBavail() bool`

HasFBavail returns a boolean if a field has been set.

### GetFBfree

`func (o *V10ClusterNodePartitionStatfs) GetFBfree() int32`

GetFBfree returns the FBfree field if non-nil, zero value otherwise.

### GetFBfreeOk

`func (o *V10ClusterNodePartitionStatfs) GetFBfreeOk() (*int32, bool)`

GetFBfreeOk returns a tuple with the FBfree field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFBfree

`func (o *V10ClusterNodePartitionStatfs) SetFBfree(v int32)`

SetFBfree sets FBfree field to given value.

### HasFBfree

`func (o *V10ClusterNodePartitionStatfs) HasFBfree() bool`

HasFBfree returns a boolean if a field has been set.

### GetFBlocks

`func (o *V10ClusterNodePartitionStatfs) GetFBlocks() int32`

GetFBlocks returns the FBlocks field if non-nil, zero value otherwise.

### GetFBlocksOk

`func (o *V10ClusterNodePartitionStatfs) GetFBlocksOk() (*int32, bool)`

GetFBlocksOk returns a tuple with the FBlocks field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFBlocks

`func (o *V10ClusterNodePartitionStatfs) SetFBlocks(v int32)`

SetFBlocks sets FBlocks field to given value.

### HasFBlocks

`func (o *V10ClusterNodePartitionStatfs) HasFBlocks() bool`

HasFBlocks returns a boolean if a field has been set.

### GetFBsize

`func (o *V10ClusterNodePartitionStatfs) GetFBsize() int32`

GetFBsize returns the FBsize field if non-nil, zero value otherwise.

### GetFBsizeOk

`func (o *V10ClusterNodePartitionStatfs) GetFBsizeOk() (*int32, bool)`

GetFBsizeOk returns a tuple with the FBsize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFBsize

`func (o *V10ClusterNodePartitionStatfs) SetFBsize(v int32)`

SetFBsize sets FBsize field to given value.

### HasFBsize

`func (o *V10ClusterNodePartitionStatfs) HasFBsize() bool`

HasFBsize returns a boolean if a field has been set.

### GetFFfree

`func (o *V10ClusterNodePartitionStatfs) GetFFfree() int32`

GetFFfree returns the FFfree field if non-nil, zero value otherwise.

### GetFFfreeOk

`func (o *V10ClusterNodePartitionStatfs) GetFFfreeOk() (*int32, bool)`

GetFFfreeOk returns a tuple with the FFfree field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFFfree

`func (o *V10ClusterNodePartitionStatfs) SetFFfree(v int32)`

SetFFfree sets FFfree field to given value.

### HasFFfree

`func (o *V10ClusterNodePartitionStatfs) HasFFfree() bool`

HasFFfree returns a boolean if a field has been set.

### GetFFiles

`func (o *V10ClusterNodePartitionStatfs) GetFFiles() int32`

GetFFiles returns the FFiles field if non-nil, zero value otherwise.

### GetFFilesOk

`func (o *V10ClusterNodePartitionStatfs) GetFFilesOk() (*int32, bool)`

GetFFilesOk returns a tuple with the FFiles field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFFiles

`func (o *V10ClusterNodePartitionStatfs) SetFFiles(v int32)`

SetFFiles sets FFiles field to given value.

### HasFFiles

`func (o *V10ClusterNodePartitionStatfs) HasFFiles() bool`

HasFFiles returns a boolean if a field has been set.

### GetFFlags

`func (o *V10ClusterNodePartitionStatfs) GetFFlags() int32`

GetFFlags returns the FFlags field if non-nil, zero value otherwise.

### GetFFlagsOk

`func (o *V10ClusterNodePartitionStatfs) GetFFlagsOk() (*int32, bool)`

GetFFlagsOk returns a tuple with the FFlags field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFFlags

`func (o *V10ClusterNodePartitionStatfs) SetFFlags(v int32)`

SetFFlags sets FFlags field to given value.

### HasFFlags

`func (o *V10ClusterNodePartitionStatfs) HasFFlags() bool`

HasFFlags returns a boolean if a field has been set.

### GetFFstypename

`func (o *V10ClusterNodePartitionStatfs) GetFFstypename() string`

GetFFstypename returns the FFstypename field if non-nil, zero value otherwise.

### GetFFstypenameOk

`func (o *V10ClusterNodePartitionStatfs) GetFFstypenameOk() (*string, bool)`

GetFFstypenameOk returns a tuple with the FFstypename field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFFstypename

`func (o *V10ClusterNodePartitionStatfs) SetFFstypename(v string)`

SetFFstypename sets FFstypename field to given value.

### HasFFstypename

`func (o *V10ClusterNodePartitionStatfs) HasFFstypename() bool`

HasFFstypename returns a boolean if a field has been set.

### GetFIosize

`func (o *V10ClusterNodePartitionStatfs) GetFIosize() int32`

GetFIosize returns the FIosize field if non-nil, zero value otherwise.

### GetFIosizeOk

`func (o *V10ClusterNodePartitionStatfs) GetFIosizeOk() (*int32, bool)`

GetFIosizeOk returns a tuple with the FIosize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFIosize

`func (o *V10ClusterNodePartitionStatfs) SetFIosize(v int32)`

SetFIosize sets FIosize field to given value.

### HasFIosize

`func (o *V10ClusterNodePartitionStatfs) HasFIosize() bool`

HasFIosize returns a boolean if a field has been set.

### GetFMntfromname

`func (o *V10ClusterNodePartitionStatfs) GetFMntfromname() string`

GetFMntfromname returns the FMntfromname field if non-nil, zero value otherwise.

### GetFMntfromnameOk

`func (o *V10ClusterNodePartitionStatfs) GetFMntfromnameOk() (*string, bool)`

GetFMntfromnameOk returns a tuple with the FMntfromname field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFMntfromname

`func (o *V10ClusterNodePartitionStatfs) SetFMntfromname(v string)`

SetFMntfromname sets FMntfromname field to given value.

### HasFMntfromname

`func (o *V10ClusterNodePartitionStatfs) HasFMntfromname() bool`

HasFMntfromname returns a boolean if a field has been set.

### GetFMntonname

`func (o *V10ClusterNodePartitionStatfs) GetFMntonname() string`

GetFMntonname returns the FMntonname field if non-nil, zero value otherwise.

### GetFMntonnameOk

`func (o *V10ClusterNodePartitionStatfs) GetFMntonnameOk() (*string, bool)`

GetFMntonnameOk returns a tuple with the FMntonname field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFMntonname

`func (o *V10ClusterNodePartitionStatfs) SetFMntonname(v string)`

SetFMntonname sets FMntonname field to given value.

### HasFMntonname

`func (o *V10ClusterNodePartitionStatfs) HasFMntonname() bool`

HasFMntonname returns a boolean if a field has been set.

### GetFNamemax

`func (o *V10ClusterNodePartitionStatfs) GetFNamemax() int32`

GetFNamemax returns the FNamemax field if non-nil, zero value otherwise.

### GetFNamemaxOk

`func (o *V10ClusterNodePartitionStatfs) GetFNamemaxOk() (*int32, bool)`

GetFNamemaxOk returns a tuple with the FNamemax field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFNamemax

`func (o *V10ClusterNodePartitionStatfs) SetFNamemax(v int32)`

SetFNamemax sets FNamemax field to given value.

### HasFNamemax

`func (o *V10ClusterNodePartitionStatfs) HasFNamemax() bool`

HasFNamemax returns a boolean if a field has been set.

### GetFOwner

`func (o *V10ClusterNodePartitionStatfs) GetFOwner() int32`

GetFOwner returns the FOwner field if non-nil, zero value otherwise.

### GetFOwnerOk

`func (o *V10ClusterNodePartitionStatfs) GetFOwnerOk() (*int32, bool)`

GetFOwnerOk returns a tuple with the FOwner field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFOwner

`func (o *V10ClusterNodePartitionStatfs) SetFOwner(v int32)`

SetFOwner sets FOwner field to given value.

### HasFOwner

`func (o *V10ClusterNodePartitionStatfs) HasFOwner() bool`

HasFOwner returns a boolean if a field has been set.

### GetFType

`func (o *V10ClusterNodePartitionStatfs) GetFType() int32`

GetFType returns the FType field if non-nil, zero value otherwise.

### GetFTypeOk

`func (o *V10ClusterNodePartitionStatfs) GetFTypeOk() (*int32, bool)`

GetFTypeOk returns a tuple with the FType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFType

`func (o *V10ClusterNodePartitionStatfs) SetFType(v int32)`

SetFType sets FType field to given value.

### HasFType

`func (o *V10ClusterNodePartitionStatfs) HasFType() bool`

HasFType returns a boolean if a field has been set.

### GetFVersion

`func (o *V10ClusterNodePartitionStatfs) GetFVersion() int32`

GetFVersion returns the FVersion field if non-nil, zero value otherwise.

### GetFVersionOk

`func (o *V10ClusterNodePartitionStatfs) GetFVersionOk() (*int32, bool)`

GetFVersionOk returns a tuple with the FVersion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFVersion

`func (o *V10ClusterNodePartitionStatfs) SetFVersion(v int32)`

SetFVersion sets FVersion field to given value.

### HasFVersion

`func (o *V10ClusterNodePartitionStatfs) HasFVersion() bool`

HasFVersion returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


