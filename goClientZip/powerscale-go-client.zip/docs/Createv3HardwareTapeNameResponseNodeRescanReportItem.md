# Createv3HardwareTapeNameResponseNodeRescanReportItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Devicename** | Pointer to **string** | device name | [optional] 
**Path** | Pointer to **string** | device driver path | [optional] 
**Product** | Pointer to **string** | device product name | [optional] 
**Serial** | Pointer to **string** | device serial:L number | [optional] 
**StatusReport** | Pointer to **string** | device change status | [optional] 
**Wwnn** | Pointer to **string** | device node world wide name | [optional] 

## Methods

### NewCreatev3HardwareTapeNameResponseNodeRescanReportItem

`func NewCreatev3HardwareTapeNameResponseNodeRescanReportItem() *Createv3HardwareTapeNameResponseNodeRescanReportItem`

NewCreatev3HardwareTapeNameResponseNodeRescanReportItem instantiates a new Createv3HardwareTapeNameResponseNodeRescanReportItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev3HardwareTapeNameResponseNodeRescanReportItemWithDefaults

`func NewCreatev3HardwareTapeNameResponseNodeRescanReportItemWithDefaults() *Createv3HardwareTapeNameResponseNodeRescanReportItem`

NewCreatev3HardwareTapeNameResponseNodeRescanReportItemWithDefaults instantiates a new Createv3HardwareTapeNameResponseNodeRescanReportItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDevicename

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) GetDevicename() string`

GetDevicename returns the Devicename field if non-nil, zero value otherwise.

### GetDevicenameOk

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) GetDevicenameOk() (*string, bool)`

GetDevicenameOk returns a tuple with the Devicename field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDevicename

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) SetDevicename(v string)`

SetDevicename sets Devicename field to given value.

### HasDevicename

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) HasDevicename() bool`

HasDevicename returns a boolean if a field has been set.

### GetPath

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) GetPath() string`

GetPath returns the Path field if non-nil, zero value otherwise.

### GetPathOk

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) GetPathOk() (*string, bool)`

GetPathOk returns a tuple with the Path field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPath

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) SetPath(v string)`

SetPath sets Path field to given value.

### HasPath

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) HasPath() bool`

HasPath returns a boolean if a field has been set.

### GetProduct

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) GetProduct() string`

GetProduct returns the Product field if non-nil, zero value otherwise.

### GetProductOk

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) GetProductOk() (*string, bool)`

GetProductOk returns a tuple with the Product field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProduct

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) SetProduct(v string)`

SetProduct sets Product field to given value.

### HasProduct

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) HasProduct() bool`

HasProduct returns a boolean if a field has been set.

### GetSerial

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) GetSerial() string`

GetSerial returns the Serial field if non-nil, zero value otherwise.

### GetSerialOk

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) GetSerialOk() (*string, bool)`

GetSerialOk returns a tuple with the Serial field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSerial

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) SetSerial(v string)`

SetSerial sets Serial field to given value.

### HasSerial

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) HasSerial() bool`

HasSerial returns a boolean if a field has been set.

### GetStatusReport

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) GetStatusReport() string`

GetStatusReport returns the StatusReport field if non-nil, zero value otherwise.

### GetStatusReportOk

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) GetStatusReportOk() (*string, bool)`

GetStatusReportOk returns a tuple with the StatusReport field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatusReport

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) SetStatusReport(v string)`

SetStatusReport sets StatusReport field to given value.

### HasStatusReport

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) HasStatusReport() bool`

HasStatusReport returns a boolean if a field has been set.

### GetWwnn

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) GetWwnn() string`

GetWwnn returns the Wwnn field if non-nil, zero value otherwise.

### GetWwnnOk

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) GetWwnnOk() (*string, bool)`

GetWwnnOk returns a tuple with the Wwnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWwnn

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) SetWwnn(v string)`

SetWwnn sets Wwnn field to given value.

### HasWwnn

`func (o *Createv3HardwareTapeNameResponseNodeRescanReportItem) HasWwnn() bool`

HasWwnn returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


