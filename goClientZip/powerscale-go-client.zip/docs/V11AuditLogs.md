# V11AuditLogs

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Before** | Pointer to **string** | The date which the current purging process will delete logs before. | [optional] 
**Blocker** | Pointer to [**[]V11AuditLogsBlockerItem**](V11AuditLogsBlockerItem.md) | The status ot the consumers that blocked the deletion. | [optional] 
**Deletion** | Pointer to [**[]V11AuditLogsDeletionItem**](V11AuditLogsDeletionItem.md) | Deleted result on each node. | [optional] 
**Status** | Pointer to **string** | Status of current manual purging. | [optional] 

## Methods

### NewV11AuditLogs

`func NewV11AuditLogs() *V11AuditLogs`

NewV11AuditLogs instantiates a new V11AuditLogs object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11AuditLogsWithDefaults

`func NewV11AuditLogsWithDefaults() *V11AuditLogs`

NewV11AuditLogsWithDefaults instantiates a new V11AuditLogs object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBefore

`func (o *V11AuditLogs) GetBefore() string`

GetBefore returns the Before field if non-nil, zero value otherwise.

### GetBeforeOk

`func (o *V11AuditLogs) GetBeforeOk() (*string, bool)`

GetBeforeOk returns a tuple with the Before field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBefore

`func (o *V11AuditLogs) SetBefore(v string)`

SetBefore sets Before field to given value.

### HasBefore

`func (o *V11AuditLogs) HasBefore() bool`

HasBefore returns a boolean if a field has been set.

### GetBlocker

`func (o *V11AuditLogs) GetBlocker() []V11AuditLogsBlockerItem`

GetBlocker returns the Blocker field if non-nil, zero value otherwise.

### GetBlockerOk

`func (o *V11AuditLogs) GetBlockerOk() (*[]V11AuditLogsBlockerItem, bool)`

GetBlockerOk returns a tuple with the Blocker field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBlocker

`func (o *V11AuditLogs) SetBlocker(v []V11AuditLogsBlockerItem)`

SetBlocker sets Blocker field to given value.

### HasBlocker

`func (o *V11AuditLogs) HasBlocker() bool`

HasBlocker returns a boolean if a field has been set.

### GetDeletion

`func (o *V11AuditLogs) GetDeletion() []V11AuditLogsDeletionItem`

GetDeletion returns the Deletion field if non-nil, zero value otherwise.

### GetDeletionOk

`func (o *V11AuditLogs) GetDeletionOk() (*[]V11AuditLogsDeletionItem, bool)`

GetDeletionOk returns a tuple with the Deletion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDeletion

`func (o *V11AuditLogs) SetDeletion(v []V11AuditLogsDeletionItem)`

SetDeletion sets Deletion field to given value.

### HasDeletion

`func (o *V11AuditLogs) HasDeletion() bool`

HasDeletion returns a boolean if a field has been set.

### GetStatus

`func (o *V11AuditLogs) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V11AuditLogs) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V11AuditLogs) SetStatus(v string)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V11AuditLogs) HasStatus() bool`

HasStatus returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


