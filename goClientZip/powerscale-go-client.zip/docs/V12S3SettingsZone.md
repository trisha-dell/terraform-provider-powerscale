# V12S3SettingsZone

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Settings** | [**V12S3SettingsZoneSettings**](V12S3SettingsZoneSettings.md) |  | 

## Methods

### NewV12S3SettingsZone

`func NewV12S3SettingsZone(settings V12S3SettingsZoneSettings, ) *V12S3SettingsZone`

NewV12S3SettingsZone instantiates a new V12S3SettingsZone object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12S3SettingsZoneWithDefaults

`func NewV12S3SettingsZoneWithDefaults() *V12S3SettingsZone`

NewV12S3SettingsZoneWithDefaults instantiates a new V12S3SettingsZone object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSettings

`func (o *V12S3SettingsZone) GetSettings() V12S3SettingsZoneSettings`

GetSettings returns the Settings field if non-nil, zero value otherwise.

### GetSettingsOk

`func (o *V12S3SettingsZone) GetSettingsOk() (*V12S3SettingsZoneSettings, bool)`

GetSettingsOk returns a tuple with the Settings field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSettings

`func (o *V12S3SettingsZone) SetSettings(v V12S3SettingsZoneSettings)`

SetSettings sets Settings field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


