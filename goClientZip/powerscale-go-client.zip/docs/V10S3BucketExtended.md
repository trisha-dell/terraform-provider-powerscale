# V10S3BucketExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Acl** | Pointer to [**[]V10S3BucketAclItem**](V10S3BucketAclItem.md) | Specifies an ordered list of S3 permissions. | [optional] 
**Description** | **string** | Description for this S3 bucket. | 
**Id** | **string** | Bucket ID. | 
**Name** | **string** | Bucket name. | 
**ObjectAclPolicy** | **string** | Set behavior of modifying object acls | 
**Owner** | **string** | Specifies the name of the owner. | 
**Path** | **string** | Path of bucket within /ifs. | 
**Zone** | Pointer to **string** | Specifies which access zone to use. | [optional] 

## Methods

### NewV10S3BucketExtended

`func NewV10S3BucketExtended(description string, id string, name string, objectAclPolicy string, owner string, path string, ) *V10S3BucketExtended`

NewV10S3BucketExtended instantiates a new V10S3BucketExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10S3BucketExtendedWithDefaults

`func NewV10S3BucketExtendedWithDefaults() *V10S3BucketExtended`

NewV10S3BucketExtendedWithDefaults instantiates a new V10S3BucketExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAcl

`func (o *V10S3BucketExtended) GetAcl() []V10S3BucketAclItem`

GetAcl returns the Acl field if non-nil, zero value otherwise.

### GetAclOk

`func (o *V10S3BucketExtended) GetAclOk() (*[]V10S3BucketAclItem, bool)`

GetAclOk returns a tuple with the Acl field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAcl

`func (o *V10S3BucketExtended) SetAcl(v []V10S3BucketAclItem)`

SetAcl sets Acl field to given value.

### HasAcl

`func (o *V10S3BucketExtended) HasAcl() bool`

HasAcl returns a boolean if a field has been set.

### GetDescription

`func (o *V10S3BucketExtended) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V10S3BucketExtended) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V10S3BucketExtended) SetDescription(v string)`

SetDescription sets Description field to given value.


### GetId

`func (o *V10S3BucketExtended) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V10S3BucketExtended) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V10S3BucketExtended) SetId(v string)`

SetId sets Id field to given value.


### GetName

`func (o *V10S3BucketExtended) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V10S3BucketExtended) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V10S3BucketExtended) SetName(v string)`

SetName sets Name field to given value.


### GetObjectAclPolicy

`func (o *V10S3BucketExtended) GetObjectAclPolicy() string`

GetObjectAclPolicy returns the ObjectAclPolicy field if non-nil, zero value otherwise.

### GetObjectAclPolicyOk

`func (o *V10S3BucketExtended) GetObjectAclPolicyOk() (*string, bool)`

GetObjectAclPolicyOk returns a tuple with the ObjectAclPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetObjectAclPolicy

`func (o *V10S3BucketExtended) SetObjectAclPolicy(v string)`

SetObjectAclPolicy sets ObjectAclPolicy field to given value.


### GetOwner

`func (o *V10S3BucketExtended) GetOwner() string`

GetOwner returns the Owner field if non-nil, zero value otherwise.

### GetOwnerOk

`func (o *V10S3BucketExtended) GetOwnerOk() (*string, bool)`

GetOwnerOk returns a tuple with the Owner field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOwner

`func (o *V10S3BucketExtended) SetOwner(v string)`

SetOwner sets Owner field to given value.


### GetPath

`func (o *V10S3BucketExtended) GetPath() string`

GetPath returns the Path field if non-nil, zero value otherwise.

### GetPathOk

`func (o *V10S3BucketExtended) GetPathOk() (*string, bool)`

GetPathOk returns a tuple with the Path field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPath

`func (o *V10S3BucketExtended) SetPath(v string)`

SetPath sets Path field to given value.


### GetZone

`func (o *V10S3BucketExtended) GetZone() string`

GetZone returns the Zone field if non-nil, zero value otherwise.

### GetZoneOk

`func (o *V10S3BucketExtended) GetZoneOk() (*string, bool)`

GetZoneOk returns a tuple with the Zone field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetZone

`func (o *V10S3BucketExtended) SetZone(v string)`

SetZone sets Zone field to given value.

### HasZone

`func (o *V10S3BucketExtended) HasZone() bool`

HasZone returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


