# V12EventMaintenanceExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Maintenance** | Pointer to **bool** | Indicates if maintenance mode is enabled. | [optional] 
**Prune** | Pointer to **int32** | Removes all maintenance mode history that is greater than set number of days. | [optional] 

## Methods

### NewV12EventMaintenanceExtended

`func NewV12EventMaintenanceExtended() *V12EventMaintenanceExtended`

NewV12EventMaintenanceExtended instantiates a new V12EventMaintenanceExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12EventMaintenanceExtendedWithDefaults

`func NewV12EventMaintenanceExtendedWithDefaults() *V12EventMaintenanceExtended`

NewV12EventMaintenanceExtendedWithDefaults instantiates a new V12EventMaintenanceExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMaintenance

`func (o *V12EventMaintenanceExtended) GetMaintenance() bool`

GetMaintenance returns the Maintenance field if non-nil, zero value otherwise.

### GetMaintenanceOk

`func (o *V12EventMaintenanceExtended) GetMaintenanceOk() (*bool, bool)`

GetMaintenanceOk returns a tuple with the Maintenance field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaintenance

`func (o *V12EventMaintenanceExtended) SetMaintenance(v bool)`

SetMaintenance sets Maintenance field to given value.

### HasMaintenance

`func (o *V12EventMaintenanceExtended) HasMaintenance() bool`

HasMaintenance returns a boolean if a field has been set.

### GetPrune

`func (o *V12EventMaintenanceExtended) GetPrune() int32`

GetPrune returns the Prune field if non-nil, zero value otherwise.

### GetPruneOk

`func (o *V12EventMaintenanceExtended) GetPruneOk() (*int32, bool)`

GetPruneOk returns a tuple with the Prune field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrune

`func (o *V12EventMaintenanceExtended) SetPrune(v int32)`

SetPrune sets Prune field to given value.

### HasPrune

`func (o *V12EventMaintenanceExtended) HasPrune() bool`

HasPrune returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


