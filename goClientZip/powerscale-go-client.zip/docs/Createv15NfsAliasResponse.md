# Createv15NfsAliasResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Health** | **string** | Specifies whether the alias is usable. | 
**Id** | **string** | Specifies a string which represents the unique location of the alias. | 

## Methods

### NewCreatev15NfsAliasResponse

`func NewCreatev15NfsAliasResponse(health string, id string, ) *Createv15NfsAliasResponse`

NewCreatev15NfsAliasResponse instantiates a new Createv15NfsAliasResponse object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev15NfsAliasResponseWithDefaults

`func NewCreatev15NfsAliasResponseWithDefaults() *Createv15NfsAliasResponse`

NewCreatev15NfsAliasResponseWithDefaults instantiates a new Createv15NfsAliasResponse object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetHealth

`func (o *Createv15NfsAliasResponse) GetHealth() string`

GetHealth returns the Health field if non-nil, zero value otherwise.

### GetHealthOk

`func (o *Createv15NfsAliasResponse) GetHealthOk() (*string, bool)`

GetHealthOk returns a tuple with the Health field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHealth

`func (o *Createv15NfsAliasResponse) SetHealth(v string)`

SetHealth sets Health field to given value.


### GetId

`func (o *Createv15NfsAliasResponse) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *Createv15NfsAliasResponse) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *Createv15NfsAliasResponse) SetId(v string)`

SetId sets Id field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


