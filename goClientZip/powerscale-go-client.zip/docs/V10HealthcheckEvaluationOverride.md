# V10HealthcheckEvaluationOverride

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Freshness** | Pointer to **int32** | Optional freshness override | [optional] 
**Id** | Pointer to **string** | Id of Item to which override applies | [optional] 
**PassStatus** | Pointer to **string** | Optional pass status override | [optional] 
**Thresholds** | Pointer to [**V10HealthcheckChecklistItemThresholds**](V10HealthcheckChecklistItemThresholds.md) |  | [optional] 

## Methods

### NewV10HealthcheckEvaluationOverride

`func NewV10HealthcheckEvaluationOverride() *V10HealthcheckEvaluationOverride`

NewV10HealthcheckEvaluationOverride instantiates a new V10HealthcheckEvaluationOverride object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10HealthcheckEvaluationOverrideWithDefaults

`func NewV10HealthcheckEvaluationOverrideWithDefaults() *V10HealthcheckEvaluationOverride`

NewV10HealthcheckEvaluationOverrideWithDefaults instantiates a new V10HealthcheckEvaluationOverride object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFreshness

`func (o *V10HealthcheckEvaluationOverride) GetFreshness() int32`

GetFreshness returns the Freshness field if non-nil, zero value otherwise.

### GetFreshnessOk

`func (o *V10HealthcheckEvaluationOverride) GetFreshnessOk() (*int32, bool)`

GetFreshnessOk returns a tuple with the Freshness field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFreshness

`func (o *V10HealthcheckEvaluationOverride) SetFreshness(v int32)`

SetFreshness sets Freshness field to given value.

### HasFreshness

`func (o *V10HealthcheckEvaluationOverride) HasFreshness() bool`

HasFreshness returns a boolean if a field has been set.

### GetId

`func (o *V10HealthcheckEvaluationOverride) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V10HealthcheckEvaluationOverride) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V10HealthcheckEvaluationOverride) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V10HealthcheckEvaluationOverride) HasId() bool`

HasId returns a boolean if a field has been set.

### GetPassStatus

`func (o *V10HealthcheckEvaluationOverride) GetPassStatus() string`

GetPassStatus returns the PassStatus field if non-nil, zero value otherwise.

### GetPassStatusOk

`func (o *V10HealthcheckEvaluationOverride) GetPassStatusOk() (*string, bool)`

GetPassStatusOk returns a tuple with the PassStatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPassStatus

`func (o *V10HealthcheckEvaluationOverride) SetPassStatus(v string)`

SetPassStatus sets PassStatus field to given value.

### HasPassStatus

`func (o *V10HealthcheckEvaluationOverride) HasPassStatus() bool`

HasPassStatus returns a boolean if a field has been set.

### GetThresholds

`func (o *V10HealthcheckEvaluationOverride) GetThresholds() V10HealthcheckChecklistItemThresholds`

GetThresholds returns the Thresholds field if non-nil, zero value otherwise.

### GetThresholdsOk

`func (o *V10HealthcheckEvaluationOverride) GetThresholdsOk() (*V10HealthcheckChecklistItemThresholds, bool)`

GetThresholdsOk returns a tuple with the Thresholds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetThresholds

`func (o *V10HealthcheckEvaluationOverride) SetThresholds(v V10HealthcheckChecklistItemThresholds)`

SetThresholds sets Thresholds field to given value.

### HasThresholds

`func (o *V10HealthcheckEvaluationOverride) HasThresholds() bool`

HasThresholds returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


