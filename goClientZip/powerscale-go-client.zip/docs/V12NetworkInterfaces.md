# V12NetworkInterfaces

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Errors** | Pointer to [**[]V11NodeStatusError**](V11NodeStatusError.md) | A list of errors encountered by the individual nodes involved in this request, or null if there were no errors. | [optional] 
**Interfaces** | Pointer to [**[]V12NetworkInterface**](V12NetworkInterface.md) |  | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV12NetworkInterfaces

`func NewV12NetworkInterfaces() *V12NetworkInterfaces`

NewV12NetworkInterfaces instantiates a new V12NetworkInterfaces object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12NetworkInterfacesWithDefaults

`func NewV12NetworkInterfacesWithDefaults() *V12NetworkInterfaces`

NewV12NetworkInterfacesWithDefaults instantiates a new V12NetworkInterfaces object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetErrors

`func (o *V12NetworkInterfaces) GetErrors() []V11NodeStatusError`

GetErrors returns the Errors field if non-nil, zero value otherwise.

### GetErrorsOk

`func (o *V12NetworkInterfaces) GetErrorsOk() (*[]V11NodeStatusError, bool)`

GetErrorsOk returns a tuple with the Errors field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetErrors

`func (o *V12NetworkInterfaces) SetErrors(v []V11NodeStatusError)`

SetErrors sets Errors field to given value.

### HasErrors

`func (o *V12NetworkInterfaces) HasErrors() bool`

HasErrors returns a boolean if a field has been set.

### GetInterfaces

`func (o *V12NetworkInterfaces) GetInterfaces() []V12NetworkInterface`

GetInterfaces returns the Interfaces field if non-nil, zero value otherwise.

### GetInterfacesOk

`func (o *V12NetworkInterfaces) GetInterfacesOk() (*[]V12NetworkInterface, bool)`

GetInterfacesOk returns a tuple with the Interfaces field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInterfaces

`func (o *V12NetworkInterfaces) SetInterfaces(v []V12NetworkInterface)`

SetInterfaces sets Interfaces field to given value.

### HasInterfaces

`func (o *V12NetworkInterfaces) HasInterfaces() bool`

HasInterfaces returns a boolean if a field has been set.

### GetResume

`func (o *V12NetworkInterfaces) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V12NetworkInterfaces) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V12NetworkInterfaces) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V12NetworkInterfaces) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V12NetworkInterfaces) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V12NetworkInterfaces) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V12NetworkInterfaces) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V12NetworkInterfaces) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


