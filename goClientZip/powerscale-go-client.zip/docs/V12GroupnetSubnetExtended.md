# V12GroupnetSubnetExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AddrFamily** | Pointer to **string** | IP address format. | [optional] 
**BaseAddr** | Pointer to **string** | The base IP address. | [optional] 
**Description** | Pointer to **string** | A description of the subnet. | [optional] 
**DsrAddrs** | Pointer to **[]string** | List of Direct Server Return addresses. | [optional] 
**Gateway** | Pointer to **string** | Gateway IP address. | [optional] 
**GatewayPriority** | Pointer to **int32** | Gateway priority. | [optional] 
**Groupnet** | Pointer to **string** | Name of the groupnet this subnet belongs to. | [optional] 
**Id** | Pointer to **string** | Unique Subnet ID. | [optional] 
**Mtu** | Pointer to **int32** | MTU of the subnet. | [optional] 
**Name** | Pointer to **string** | The name of the subnet. | [optional] 
**Pools** | Pointer to **[]string** | Name of the pools in the subnet. | [optional] 
**Prefixlen** | Pointer to **int32** | Subnet Prefix Length. | [optional] 
**ScServiceAddrs** | Pointer to [**[]V12GroupnetSubnetScServiceAddr**](V12GroupnetSubnetScServiceAddr.md) | List of IP addresses that SmartConnect listens for DNS requests. | [optional] 
**ScServiceName** | Pointer to **string** | Domain Name corresponding to the SmartConnect Service Address. | [optional] 
**VlanEnabled** | Pointer to **bool** | VLAN tagging enabled or disabled. | [optional] 
**VlanId** | Pointer to **int32** | VLAN ID for all interfaces in the subnet. | [optional] 

## Methods

### NewV12GroupnetSubnetExtended

`func NewV12GroupnetSubnetExtended() *V12GroupnetSubnetExtended`

NewV12GroupnetSubnetExtended instantiates a new V12GroupnetSubnetExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12GroupnetSubnetExtendedWithDefaults

`func NewV12GroupnetSubnetExtendedWithDefaults() *V12GroupnetSubnetExtended`

NewV12GroupnetSubnetExtendedWithDefaults instantiates a new V12GroupnetSubnetExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAddrFamily

`func (o *V12GroupnetSubnetExtended) GetAddrFamily() string`

GetAddrFamily returns the AddrFamily field if non-nil, zero value otherwise.

### GetAddrFamilyOk

`func (o *V12GroupnetSubnetExtended) GetAddrFamilyOk() (*string, bool)`

GetAddrFamilyOk returns a tuple with the AddrFamily field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddrFamily

`func (o *V12GroupnetSubnetExtended) SetAddrFamily(v string)`

SetAddrFamily sets AddrFamily field to given value.

### HasAddrFamily

`func (o *V12GroupnetSubnetExtended) HasAddrFamily() bool`

HasAddrFamily returns a boolean if a field has been set.

### GetBaseAddr

`func (o *V12GroupnetSubnetExtended) GetBaseAddr() string`

GetBaseAddr returns the BaseAddr field if non-nil, zero value otherwise.

### GetBaseAddrOk

`func (o *V12GroupnetSubnetExtended) GetBaseAddrOk() (*string, bool)`

GetBaseAddrOk returns a tuple with the BaseAddr field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBaseAddr

`func (o *V12GroupnetSubnetExtended) SetBaseAddr(v string)`

SetBaseAddr sets BaseAddr field to given value.

### HasBaseAddr

`func (o *V12GroupnetSubnetExtended) HasBaseAddr() bool`

HasBaseAddr returns a boolean if a field has been set.

### GetDescription

`func (o *V12GroupnetSubnetExtended) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V12GroupnetSubnetExtended) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V12GroupnetSubnetExtended) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *V12GroupnetSubnetExtended) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetDsrAddrs

`func (o *V12GroupnetSubnetExtended) GetDsrAddrs() []string`

GetDsrAddrs returns the DsrAddrs field if non-nil, zero value otherwise.

### GetDsrAddrsOk

`func (o *V12GroupnetSubnetExtended) GetDsrAddrsOk() (*[]string, bool)`

GetDsrAddrsOk returns a tuple with the DsrAddrs field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDsrAddrs

`func (o *V12GroupnetSubnetExtended) SetDsrAddrs(v []string)`

SetDsrAddrs sets DsrAddrs field to given value.

### HasDsrAddrs

`func (o *V12GroupnetSubnetExtended) HasDsrAddrs() bool`

HasDsrAddrs returns a boolean if a field has been set.

### GetGateway

`func (o *V12GroupnetSubnetExtended) GetGateway() string`

GetGateway returns the Gateway field if non-nil, zero value otherwise.

### GetGatewayOk

`func (o *V12GroupnetSubnetExtended) GetGatewayOk() (*string, bool)`

GetGatewayOk returns a tuple with the Gateway field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGateway

`func (o *V12GroupnetSubnetExtended) SetGateway(v string)`

SetGateway sets Gateway field to given value.

### HasGateway

`func (o *V12GroupnetSubnetExtended) HasGateway() bool`

HasGateway returns a boolean if a field has been set.

### GetGatewayPriority

`func (o *V12GroupnetSubnetExtended) GetGatewayPriority() int32`

GetGatewayPriority returns the GatewayPriority field if non-nil, zero value otherwise.

### GetGatewayPriorityOk

`func (o *V12GroupnetSubnetExtended) GetGatewayPriorityOk() (*int32, bool)`

GetGatewayPriorityOk returns a tuple with the GatewayPriority field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGatewayPriority

`func (o *V12GroupnetSubnetExtended) SetGatewayPriority(v int32)`

SetGatewayPriority sets GatewayPriority field to given value.

### HasGatewayPriority

`func (o *V12GroupnetSubnetExtended) HasGatewayPriority() bool`

HasGatewayPriority returns a boolean if a field has been set.

### GetGroupnet

`func (o *V12GroupnetSubnetExtended) GetGroupnet() string`

GetGroupnet returns the Groupnet field if non-nil, zero value otherwise.

### GetGroupnetOk

`func (o *V12GroupnetSubnetExtended) GetGroupnetOk() (*string, bool)`

GetGroupnetOk returns a tuple with the Groupnet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupnet

`func (o *V12GroupnetSubnetExtended) SetGroupnet(v string)`

SetGroupnet sets Groupnet field to given value.

### HasGroupnet

`func (o *V12GroupnetSubnetExtended) HasGroupnet() bool`

HasGroupnet returns a boolean if a field has been set.

### GetId

`func (o *V12GroupnetSubnetExtended) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12GroupnetSubnetExtended) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12GroupnetSubnetExtended) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V12GroupnetSubnetExtended) HasId() bool`

HasId returns a boolean if a field has been set.

### GetMtu

`func (o *V12GroupnetSubnetExtended) GetMtu() int32`

GetMtu returns the Mtu field if non-nil, zero value otherwise.

### GetMtuOk

`func (o *V12GroupnetSubnetExtended) GetMtuOk() (*int32, bool)`

GetMtuOk returns a tuple with the Mtu field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMtu

`func (o *V12GroupnetSubnetExtended) SetMtu(v int32)`

SetMtu sets Mtu field to given value.

### HasMtu

`func (o *V12GroupnetSubnetExtended) HasMtu() bool`

HasMtu returns a boolean if a field has been set.

### GetName

`func (o *V12GroupnetSubnetExtended) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V12GroupnetSubnetExtended) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V12GroupnetSubnetExtended) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V12GroupnetSubnetExtended) HasName() bool`

HasName returns a boolean if a field has been set.

### GetPools

`func (o *V12GroupnetSubnetExtended) GetPools() []string`

GetPools returns the Pools field if non-nil, zero value otherwise.

### GetPoolsOk

`func (o *V12GroupnetSubnetExtended) GetPoolsOk() (*[]string, bool)`

GetPoolsOk returns a tuple with the Pools field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPools

`func (o *V12GroupnetSubnetExtended) SetPools(v []string)`

SetPools sets Pools field to given value.

### HasPools

`func (o *V12GroupnetSubnetExtended) HasPools() bool`

HasPools returns a boolean if a field has been set.

### GetPrefixlen

`func (o *V12GroupnetSubnetExtended) GetPrefixlen() int32`

GetPrefixlen returns the Prefixlen field if non-nil, zero value otherwise.

### GetPrefixlenOk

`func (o *V12GroupnetSubnetExtended) GetPrefixlenOk() (*int32, bool)`

GetPrefixlenOk returns a tuple with the Prefixlen field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrefixlen

`func (o *V12GroupnetSubnetExtended) SetPrefixlen(v int32)`

SetPrefixlen sets Prefixlen field to given value.

### HasPrefixlen

`func (o *V12GroupnetSubnetExtended) HasPrefixlen() bool`

HasPrefixlen returns a boolean if a field has been set.

### GetScServiceAddrs

`func (o *V12GroupnetSubnetExtended) GetScServiceAddrs() []V12GroupnetSubnetScServiceAddr`

GetScServiceAddrs returns the ScServiceAddrs field if non-nil, zero value otherwise.

### GetScServiceAddrsOk

`func (o *V12GroupnetSubnetExtended) GetScServiceAddrsOk() (*[]V12GroupnetSubnetScServiceAddr, bool)`

GetScServiceAddrsOk returns a tuple with the ScServiceAddrs field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScServiceAddrs

`func (o *V12GroupnetSubnetExtended) SetScServiceAddrs(v []V12GroupnetSubnetScServiceAddr)`

SetScServiceAddrs sets ScServiceAddrs field to given value.

### HasScServiceAddrs

`func (o *V12GroupnetSubnetExtended) HasScServiceAddrs() bool`

HasScServiceAddrs returns a boolean if a field has been set.

### GetScServiceName

`func (o *V12GroupnetSubnetExtended) GetScServiceName() string`

GetScServiceName returns the ScServiceName field if non-nil, zero value otherwise.

### GetScServiceNameOk

`func (o *V12GroupnetSubnetExtended) GetScServiceNameOk() (*string, bool)`

GetScServiceNameOk returns a tuple with the ScServiceName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScServiceName

`func (o *V12GroupnetSubnetExtended) SetScServiceName(v string)`

SetScServiceName sets ScServiceName field to given value.

### HasScServiceName

`func (o *V12GroupnetSubnetExtended) HasScServiceName() bool`

HasScServiceName returns a boolean if a field has been set.

### GetVlanEnabled

`func (o *V12GroupnetSubnetExtended) GetVlanEnabled() bool`

GetVlanEnabled returns the VlanEnabled field if non-nil, zero value otherwise.

### GetVlanEnabledOk

`func (o *V12GroupnetSubnetExtended) GetVlanEnabledOk() (*bool, bool)`

GetVlanEnabledOk returns a tuple with the VlanEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVlanEnabled

`func (o *V12GroupnetSubnetExtended) SetVlanEnabled(v bool)`

SetVlanEnabled sets VlanEnabled field to given value.

### HasVlanEnabled

`func (o *V12GroupnetSubnetExtended) HasVlanEnabled() bool`

HasVlanEnabled returns a boolean if a field has been set.

### GetVlanId

`func (o *V12GroupnetSubnetExtended) GetVlanId() int32`

GetVlanId returns the VlanId field if non-nil, zero value otherwise.

### GetVlanIdOk

`func (o *V12GroupnetSubnetExtended) GetVlanIdOk() (*int32, bool)`

GetVlanIdOk returns a tuple with the VlanId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVlanId

`func (o *V12GroupnetSubnetExtended) SetVlanId(v int32)`

SetVlanId sets VlanId field to given value.

### HasVlanId

`func (o *V12GroupnetSubnetExtended) HasVlanId() bool`

HasVlanId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


