# V12EventEventgroupOccurrences

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Eventgroups** | Pointer to [**[]V12EventEventgroupOccurrencesEventgroup**](V12EventEventgroupOccurrencesEventgroup.md) |  | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV12EventEventgroupOccurrences

`func NewV12EventEventgroupOccurrences() *V12EventEventgroupOccurrences`

NewV12EventEventgroupOccurrences instantiates a new V12EventEventgroupOccurrences object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12EventEventgroupOccurrencesWithDefaults

`func NewV12EventEventgroupOccurrencesWithDefaults() *V12EventEventgroupOccurrences`

NewV12EventEventgroupOccurrencesWithDefaults instantiates a new V12EventEventgroupOccurrences object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEventgroups

`func (o *V12EventEventgroupOccurrences) GetEventgroups() []V12EventEventgroupOccurrencesEventgroup`

GetEventgroups returns the Eventgroups field if non-nil, zero value otherwise.

### GetEventgroupsOk

`func (o *V12EventEventgroupOccurrences) GetEventgroupsOk() (*[]V12EventEventgroupOccurrencesEventgroup, bool)`

GetEventgroupsOk returns a tuple with the Eventgroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEventgroups

`func (o *V12EventEventgroupOccurrences) SetEventgroups(v []V12EventEventgroupOccurrencesEventgroup)`

SetEventgroups sets Eventgroups field to given value.

### HasEventgroups

`func (o *V12EventEventgroupOccurrences) HasEventgroups() bool`

HasEventgroups returns a boolean if a field has been set.

### GetResume

`func (o *V12EventEventgroupOccurrences) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V12EventEventgroupOccurrences) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V12EventEventgroupOccurrences) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V12EventEventgroupOccurrences) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V12EventEventgroupOccurrences) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V12EventEventgroupOccurrences) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V12EventEventgroupOccurrences) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V12EventEventgroupOccurrences) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


