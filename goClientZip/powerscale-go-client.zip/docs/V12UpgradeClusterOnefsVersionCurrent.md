# V12UpgradeClusterOnefsVersionCurrent

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Bugfix** | Pointer to **int32** |  | [optional] 
**Maintenance** | Pointer to **int32** |  | [optional] 
**Major** | Pointer to **int32** |  | [optional] 
**Minor** | Pointer to **int32** |  | [optional] 
**Version** | Pointer to **string** | Hex representation of the OneFS version integer. | [optional] 

## Methods

### NewV12UpgradeClusterOnefsVersionCurrent

`func NewV12UpgradeClusterOnefsVersionCurrent() *V12UpgradeClusterOnefsVersionCurrent`

NewV12UpgradeClusterOnefsVersionCurrent instantiates a new V12UpgradeClusterOnefsVersionCurrent object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12UpgradeClusterOnefsVersionCurrentWithDefaults

`func NewV12UpgradeClusterOnefsVersionCurrentWithDefaults() *V12UpgradeClusterOnefsVersionCurrent`

NewV12UpgradeClusterOnefsVersionCurrentWithDefaults instantiates a new V12UpgradeClusterOnefsVersionCurrent object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBugfix

`func (o *V12UpgradeClusterOnefsVersionCurrent) GetBugfix() int32`

GetBugfix returns the Bugfix field if non-nil, zero value otherwise.

### GetBugfixOk

`func (o *V12UpgradeClusterOnefsVersionCurrent) GetBugfixOk() (*int32, bool)`

GetBugfixOk returns a tuple with the Bugfix field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBugfix

`func (o *V12UpgradeClusterOnefsVersionCurrent) SetBugfix(v int32)`

SetBugfix sets Bugfix field to given value.

### HasBugfix

`func (o *V12UpgradeClusterOnefsVersionCurrent) HasBugfix() bool`

HasBugfix returns a boolean if a field has been set.

### GetMaintenance

`func (o *V12UpgradeClusterOnefsVersionCurrent) GetMaintenance() int32`

GetMaintenance returns the Maintenance field if non-nil, zero value otherwise.

### GetMaintenanceOk

`func (o *V12UpgradeClusterOnefsVersionCurrent) GetMaintenanceOk() (*int32, bool)`

GetMaintenanceOk returns a tuple with the Maintenance field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaintenance

`func (o *V12UpgradeClusterOnefsVersionCurrent) SetMaintenance(v int32)`

SetMaintenance sets Maintenance field to given value.

### HasMaintenance

`func (o *V12UpgradeClusterOnefsVersionCurrent) HasMaintenance() bool`

HasMaintenance returns a boolean if a field has been set.

### GetMajor

`func (o *V12UpgradeClusterOnefsVersionCurrent) GetMajor() int32`

GetMajor returns the Major field if non-nil, zero value otherwise.

### GetMajorOk

`func (o *V12UpgradeClusterOnefsVersionCurrent) GetMajorOk() (*int32, bool)`

GetMajorOk returns a tuple with the Major field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMajor

`func (o *V12UpgradeClusterOnefsVersionCurrent) SetMajor(v int32)`

SetMajor sets Major field to given value.

### HasMajor

`func (o *V12UpgradeClusterOnefsVersionCurrent) HasMajor() bool`

HasMajor returns a boolean if a field has been set.

### GetMinor

`func (o *V12UpgradeClusterOnefsVersionCurrent) GetMinor() int32`

GetMinor returns the Minor field if non-nil, zero value otherwise.

### GetMinorOk

`func (o *V12UpgradeClusterOnefsVersionCurrent) GetMinorOk() (*int32, bool)`

GetMinorOk returns a tuple with the Minor field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMinor

`func (o *V12UpgradeClusterOnefsVersionCurrent) SetMinor(v int32)`

SetMinor sets Minor field to given value.

### HasMinor

`func (o *V12UpgradeClusterOnefsVersionCurrent) HasMinor() bool`

HasMinor returns a boolean if a field has been set.

### GetVersion

`func (o *V12UpgradeClusterOnefsVersionCurrent) GetVersion() string`

GetVersion returns the Version field if non-nil, zero value otherwise.

### GetVersionOk

`func (o *V12UpgradeClusterOnefsVersionCurrent) GetVersionOk() (*string, bool)`

GetVersionOk returns a tuple with the Version field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVersion

`func (o *V12UpgradeClusterOnefsVersionCurrent) SetVersion(v string)`

SetVersion sets Version field to given value.

### HasVersion

`func (o *V12UpgradeClusterOnefsVersionCurrent) HasVersion() bool`

HasVersion returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


