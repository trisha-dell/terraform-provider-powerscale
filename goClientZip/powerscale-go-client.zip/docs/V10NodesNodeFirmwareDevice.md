# V10NodesNodeFirmwareDevice

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Devices** | Pointer to [**[]V10ClusterFirmwareDeviceNodeDevice**](V10ClusterFirmwareDeviceNodeDevice.md) | List of the firmware status for hardware components on the node. | [optional] 
**NodeUnavailable** | Pointer to **bool** | Node is unavailable. | [optional] 

## Methods

### NewV10NodesNodeFirmwareDevice

`func NewV10NodesNodeFirmwareDevice() *V10NodesNodeFirmwareDevice`

NewV10NodesNodeFirmwareDevice instantiates a new V10NodesNodeFirmwareDevice object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10NodesNodeFirmwareDeviceWithDefaults

`func NewV10NodesNodeFirmwareDeviceWithDefaults() *V10NodesNodeFirmwareDevice`

NewV10NodesNodeFirmwareDeviceWithDefaults instantiates a new V10NodesNodeFirmwareDevice object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDevices

`func (o *V10NodesNodeFirmwareDevice) GetDevices() []V10ClusterFirmwareDeviceNodeDevice`

GetDevices returns the Devices field if non-nil, zero value otherwise.

### GetDevicesOk

`func (o *V10NodesNodeFirmwareDevice) GetDevicesOk() (*[]V10ClusterFirmwareDeviceNodeDevice, bool)`

GetDevicesOk returns a tuple with the Devices field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDevices

`func (o *V10NodesNodeFirmwareDevice) SetDevices(v []V10ClusterFirmwareDeviceNodeDevice)`

SetDevices sets Devices field to given value.

### HasDevices

`func (o *V10NodesNodeFirmwareDevice) HasDevices() bool`

HasDevices returns a boolean if a field has been set.

### GetNodeUnavailable

`func (o *V10NodesNodeFirmwareDevice) GetNodeUnavailable() bool`

GetNodeUnavailable returns the NodeUnavailable field if non-nil, zero value otherwise.

### GetNodeUnavailableOk

`func (o *V10NodesNodeFirmwareDevice) GetNodeUnavailableOk() (*bool, bool)`

GetNodeUnavailableOk returns a tuple with the NodeUnavailable field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodeUnavailable

`func (o *V10NodesNodeFirmwareDevice) SetNodeUnavailable(v bool)`

SetNodeUnavailable sets NodeUnavailable field to given value.

### HasNodeUnavailable

`func (o *V10NodesNodeFirmwareDevice) HasNodeUnavailable() bool`

HasNodeUnavailable returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


