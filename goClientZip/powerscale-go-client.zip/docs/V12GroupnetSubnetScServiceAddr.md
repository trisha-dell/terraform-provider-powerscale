# V12GroupnetSubnetScServiceAddr

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**High** | **string** | High IP | 
**Low** | **string** | Low IP | 

## Methods

### NewV12GroupnetSubnetScServiceAddr

`func NewV12GroupnetSubnetScServiceAddr(high string, low string, ) *V12GroupnetSubnetScServiceAddr`

NewV12GroupnetSubnetScServiceAddr instantiates a new V12GroupnetSubnetScServiceAddr object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12GroupnetSubnetScServiceAddrWithDefaults

`func NewV12GroupnetSubnetScServiceAddrWithDefaults() *V12GroupnetSubnetScServiceAddr`

NewV12GroupnetSubnetScServiceAddrWithDefaults instantiates a new V12GroupnetSubnetScServiceAddr object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetHigh

`func (o *V12GroupnetSubnetScServiceAddr) GetHigh() string`

GetHigh returns the High field if non-nil, zero value otherwise.

### GetHighOk

`func (o *V12GroupnetSubnetScServiceAddr) GetHighOk() (*string, bool)`

GetHighOk returns a tuple with the High field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHigh

`func (o *V12GroupnetSubnetScServiceAddr) SetHigh(v string)`

SetHigh sets High field to given value.


### GetLow

`func (o *V12GroupnetSubnetScServiceAddr) GetLow() string`

GetLow returns the Low field if non-nil, zero value otherwise.

### GetLowOk

`func (o *V12GroupnetSubnetScServiceAddr) GetLowOk() (*string, bool)`

GetLowOk returns a tuple with the Low field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLow

`func (o *V12GroupnetSubnetScServiceAddr) SetLow(v string)`

SetLow sets Low field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


