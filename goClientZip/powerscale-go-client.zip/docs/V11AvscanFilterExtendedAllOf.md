# V11AvscanFilterExtendedAllOf

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FileExtensionAction** | Pointer to **string** | When a file matches an entry in the list of file extensions, do we include or exclude it?. | [optional] 
**FileExtensions** | Pointer to **[]string** | Array of file extensions to use in scanning decision. | [optional] 
**PathsToExclude** | Pointer to **[]string** | Array of relative paths under zone root not to scan. | [optional] 
**ScanIfNoExtension** | Pointer to **bool** | Scan files without extensions? | [optional] 

## Methods

### NewV11AvscanFilterExtendedAllOf

`func NewV11AvscanFilterExtendedAllOf() *V11AvscanFilterExtendedAllOf`

NewV11AvscanFilterExtendedAllOf instantiates a new V11AvscanFilterExtendedAllOf object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11AvscanFilterExtendedAllOfWithDefaults

`func NewV11AvscanFilterExtendedAllOfWithDefaults() *V11AvscanFilterExtendedAllOf`

NewV11AvscanFilterExtendedAllOfWithDefaults instantiates a new V11AvscanFilterExtendedAllOf object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFileExtensionAction

`func (o *V11AvscanFilterExtendedAllOf) GetFileExtensionAction() string`

GetFileExtensionAction returns the FileExtensionAction field if non-nil, zero value otherwise.

### GetFileExtensionActionOk

`func (o *V11AvscanFilterExtendedAllOf) GetFileExtensionActionOk() (*string, bool)`

GetFileExtensionActionOk returns a tuple with the FileExtensionAction field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFileExtensionAction

`func (o *V11AvscanFilterExtendedAllOf) SetFileExtensionAction(v string)`

SetFileExtensionAction sets FileExtensionAction field to given value.

### HasFileExtensionAction

`func (o *V11AvscanFilterExtendedAllOf) HasFileExtensionAction() bool`

HasFileExtensionAction returns a boolean if a field has been set.

### GetFileExtensions

`func (o *V11AvscanFilterExtendedAllOf) GetFileExtensions() []string`

GetFileExtensions returns the FileExtensions field if non-nil, zero value otherwise.

### GetFileExtensionsOk

`func (o *V11AvscanFilterExtendedAllOf) GetFileExtensionsOk() (*[]string, bool)`

GetFileExtensionsOk returns a tuple with the FileExtensions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFileExtensions

`func (o *V11AvscanFilterExtendedAllOf) SetFileExtensions(v []string)`

SetFileExtensions sets FileExtensions field to given value.

### HasFileExtensions

`func (o *V11AvscanFilterExtendedAllOf) HasFileExtensions() bool`

HasFileExtensions returns a boolean if a field has been set.

### GetPathsToExclude

`func (o *V11AvscanFilterExtendedAllOf) GetPathsToExclude() []string`

GetPathsToExclude returns the PathsToExclude field if non-nil, zero value otherwise.

### GetPathsToExcludeOk

`func (o *V11AvscanFilterExtendedAllOf) GetPathsToExcludeOk() (*[]string, bool)`

GetPathsToExcludeOk returns a tuple with the PathsToExclude field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPathsToExclude

`func (o *V11AvscanFilterExtendedAllOf) SetPathsToExclude(v []string)`

SetPathsToExclude sets PathsToExclude field to given value.

### HasPathsToExclude

`func (o *V11AvscanFilterExtendedAllOf) HasPathsToExclude() bool`

HasPathsToExclude returns a boolean if a field has been set.

### GetScanIfNoExtension

`func (o *V11AvscanFilterExtendedAllOf) GetScanIfNoExtension() bool`

GetScanIfNoExtension returns the ScanIfNoExtension field if non-nil, zero value otherwise.

### GetScanIfNoExtensionOk

`func (o *V11AvscanFilterExtendedAllOf) GetScanIfNoExtensionOk() (*bool, bool)`

GetScanIfNoExtensionOk returns a tuple with the ScanIfNoExtension field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanIfNoExtension

`func (o *V11AvscanFilterExtendedAllOf) SetScanIfNoExtension(v bool)`

SetScanIfNoExtension sets ScanIfNoExtension field to given value.

### HasScanIfNoExtension

`func (o *V11AvscanFilterExtendedAllOf) HasScanIfNoExtension() bool`

HasScanIfNoExtension returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


