# V12NetworkInterfaceVlan

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Flags** | Pointer to **[]string** | List of interface flags | [optional] 
**Id** | Pointer to **string** | Id is a concatenation of lnn and name in the format &#39;lnn:name&#39; e.g. 3:ext-2. | [optional] 
**IpAddrs** | Pointer to **[]string** | List of IP addresses | [optional] 
**Ipv4Gateway** | **string** | Address of the default IPv4 gateway | 
**Ipv6Gateway** | **string** | Address of the default IPv6 gateway | 
**Lnn** | Pointer to **int32** | Logical Node Number (LNN) of a node. | [optional] 
**Mtu** | Pointer to **int32** | The mtu the interface. | [optional] 
**Name** | Pointer to **string** | The name of the interface. | [optional] 
**NicName** | Pointer to **string** | NIC name | [optional] 
**Status** | Pointer to **string** | Status of the interface | [optional] 
**Type** | Pointer to **string** | The type of network interface | [optional] 
**VlanId** | Pointer to **int32** | The configured VLAN ID. | [optional] 

## Methods

### NewV12NetworkInterfaceVlan

`func NewV12NetworkInterfaceVlan(ipv4Gateway string, ipv6Gateway string, ) *V12NetworkInterfaceVlan`

NewV12NetworkInterfaceVlan instantiates a new V12NetworkInterfaceVlan object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12NetworkInterfaceVlanWithDefaults

`func NewV12NetworkInterfaceVlanWithDefaults() *V12NetworkInterfaceVlan`

NewV12NetworkInterfaceVlanWithDefaults instantiates a new V12NetworkInterfaceVlan object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFlags

`func (o *V12NetworkInterfaceVlan) GetFlags() []string`

GetFlags returns the Flags field if non-nil, zero value otherwise.

### GetFlagsOk

`func (o *V12NetworkInterfaceVlan) GetFlagsOk() (*[]string, bool)`

GetFlagsOk returns a tuple with the Flags field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlags

`func (o *V12NetworkInterfaceVlan) SetFlags(v []string)`

SetFlags sets Flags field to given value.

### HasFlags

`func (o *V12NetworkInterfaceVlan) HasFlags() bool`

HasFlags returns a boolean if a field has been set.

### GetId

`func (o *V12NetworkInterfaceVlan) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12NetworkInterfaceVlan) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12NetworkInterfaceVlan) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V12NetworkInterfaceVlan) HasId() bool`

HasId returns a boolean if a field has been set.

### GetIpAddrs

`func (o *V12NetworkInterfaceVlan) GetIpAddrs() []string`

GetIpAddrs returns the IpAddrs field if non-nil, zero value otherwise.

### GetIpAddrsOk

`func (o *V12NetworkInterfaceVlan) GetIpAddrsOk() (*[]string, bool)`

GetIpAddrsOk returns a tuple with the IpAddrs field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpAddrs

`func (o *V12NetworkInterfaceVlan) SetIpAddrs(v []string)`

SetIpAddrs sets IpAddrs field to given value.

### HasIpAddrs

`func (o *V12NetworkInterfaceVlan) HasIpAddrs() bool`

HasIpAddrs returns a boolean if a field has been set.

### GetIpv4Gateway

`func (o *V12NetworkInterfaceVlan) GetIpv4Gateway() string`

GetIpv4Gateway returns the Ipv4Gateway field if non-nil, zero value otherwise.

### GetIpv4GatewayOk

`func (o *V12NetworkInterfaceVlan) GetIpv4GatewayOk() (*string, bool)`

GetIpv4GatewayOk returns a tuple with the Ipv4Gateway field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpv4Gateway

`func (o *V12NetworkInterfaceVlan) SetIpv4Gateway(v string)`

SetIpv4Gateway sets Ipv4Gateway field to given value.


### GetIpv6Gateway

`func (o *V12NetworkInterfaceVlan) GetIpv6Gateway() string`

GetIpv6Gateway returns the Ipv6Gateway field if non-nil, zero value otherwise.

### GetIpv6GatewayOk

`func (o *V12NetworkInterfaceVlan) GetIpv6GatewayOk() (*string, bool)`

GetIpv6GatewayOk returns a tuple with the Ipv6Gateway field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpv6Gateway

`func (o *V12NetworkInterfaceVlan) SetIpv6Gateway(v string)`

SetIpv6Gateway sets Ipv6Gateway field to given value.


### GetLnn

`func (o *V12NetworkInterfaceVlan) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V12NetworkInterfaceVlan) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V12NetworkInterfaceVlan) SetLnn(v int32)`

SetLnn sets Lnn field to given value.

### HasLnn

`func (o *V12NetworkInterfaceVlan) HasLnn() bool`

HasLnn returns a boolean if a field has been set.

### GetMtu

`func (o *V12NetworkInterfaceVlan) GetMtu() int32`

GetMtu returns the Mtu field if non-nil, zero value otherwise.

### GetMtuOk

`func (o *V12NetworkInterfaceVlan) GetMtuOk() (*int32, bool)`

GetMtuOk returns a tuple with the Mtu field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMtu

`func (o *V12NetworkInterfaceVlan) SetMtu(v int32)`

SetMtu sets Mtu field to given value.

### HasMtu

`func (o *V12NetworkInterfaceVlan) HasMtu() bool`

HasMtu returns a boolean if a field has been set.

### GetName

`func (o *V12NetworkInterfaceVlan) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V12NetworkInterfaceVlan) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V12NetworkInterfaceVlan) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V12NetworkInterfaceVlan) HasName() bool`

HasName returns a boolean if a field has been set.

### GetNicName

`func (o *V12NetworkInterfaceVlan) GetNicName() string`

GetNicName returns the NicName field if non-nil, zero value otherwise.

### GetNicNameOk

`func (o *V12NetworkInterfaceVlan) GetNicNameOk() (*string, bool)`

GetNicNameOk returns a tuple with the NicName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNicName

`func (o *V12NetworkInterfaceVlan) SetNicName(v string)`

SetNicName sets NicName field to given value.

### HasNicName

`func (o *V12NetworkInterfaceVlan) HasNicName() bool`

HasNicName returns a boolean if a field has been set.

### GetStatus

`func (o *V12NetworkInterfaceVlan) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V12NetworkInterfaceVlan) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V12NetworkInterfaceVlan) SetStatus(v string)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V12NetworkInterfaceVlan) HasStatus() bool`

HasStatus returns a boolean if a field has been set.

### GetType

`func (o *V12NetworkInterfaceVlan) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *V12NetworkInterfaceVlan) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *V12NetworkInterfaceVlan) SetType(v string)`

SetType sets Type field to given value.

### HasType

`func (o *V12NetworkInterfaceVlan) HasType() bool`

HasType returns a boolean if a field has been set.

### GetVlanId

`func (o *V12NetworkInterfaceVlan) GetVlanId() int32`

GetVlanId returns the VlanId field if non-nil, zero value otherwise.

### GetVlanIdOk

`func (o *V12NetworkInterfaceVlan) GetVlanIdOk() (*int32, bool)`

GetVlanIdOk returns a tuple with the VlanId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVlanId

`func (o *V12NetworkInterfaceVlan) SetVlanId(v int32)`

SetVlanId sets VlanId field to given value.

### HasVlanId

`func (o *V12NetworkInterfaceVlan) HasVlanId() bool`

HasVlanId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


