# V10ClusterNodeDriveDConfig

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Alert** | Pointer to [**V10ClusterNodeDriveDConfigAlert**](V10ClusterNodeDriveDConfigAlert.md) |  | [optional] 
**Allow** | Pointer to [**V10ClusterNodeDriveDConfigAllow**](V10ClusterNodeDriveDConfigAllow.md) |  | [optional] 
**AutomaticReplacementRecognition** | Pointer to [**V10ClusterNodeDriveDConfigAutomaticReplacementRecognition**](V10ClusterNodeDriveDConfigAutomaticReplacementRecognition.md) |  | [optional] 
**InstantSecureErase** | Pointer to [**V10ClusterNodeDriveDConfigInstantSecureErase**](V10ClusterNodeDriveDConfigInstantSecureErase.md) |  | [optional] 
**Log** | Pointer to [**V10ClusterNodeDriveDConfigLog**](V10ClusterNodeDriveDConfigLog.md) |  | [optional] 
**Reboot** | Pointer to [**V10ClusterNodeDriveDConfigReboot**](V10ClusterNodeDriveDConfigReboot.md) |  | [optional] 
**SpinWait** | Pointer to [**V10ClusterNodeDriveDConfigSpinWait**](V10ClusterNodeDriveDConfigSpinWait.md) |  | [optional] 
**Stall** | Pointer to [**V10ClusterNodeDriveDConfigStall**](V10ClusterNodeDriveDConfigStall.md) |  | [optional] 

## Methods

### NewV10ClusterNodeDriveDConfig

`func NewV10ClusterNodeDriveDConfig() *V10ClusterNodeDriveDConfig`

NewV10ClusterNodeDriveDConfig instantiates a new V10ClusterNodeDriveDConfig object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeDriveDConfigWithDefaults

`func NewV10ClusterNodeDriveDConfigWithDefaults() *V10ClusterNodeDriveDConfig`

NewV10ClusterNodeDriveDConfigWithDefaults instantiates a new V10ClusterNodeDriveDConfig object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAlert

`func (o *V10ClusterNodeDriveDConfig) GetAlert() V10ClusterNodeDriveDConfigAlert`

GetAlert returns the Alert field if non-nil, zero value otherwise.

### GetAlertOk

`func (o *V10ClusterNodeDriveDConfig) GetAlertOk() (*V10ClusterNodeDriveDConfigAlert, bool)`

GetAlertOk returns a tuple with the Alert field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAlert

`func (o *V10ClusterNodeDriveDConfig) SetAlert(v V10ClusterNodeDriveDConfigAlert)`

SetAlert sets Alert field to given value.

### HasAlert

`func (o *V10ClusterNodeDriveDConfig) HasAlert() bool`

HasAlert returns a boolean if a field has been set.

### GetAllow

`func (o *V10ClusterNodeDriveDConfig) GetAllow() V10ClusterNodeDriveDConfigAllow`

GetAllow returns the Allow field if non-nil, zero value otherwise.

### GetAllowOk

`func (o *V10ClusterNodeDriveDConfig) GetAllowOk() (*V10ClusterNodeDriveDConfigAllow, bool)`

GetAllowOk returns a tuple with the Allow field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllow

`func (o *V10ClusterNodeDriveDConfig) SetAllow(v V10ClusterNodeDriveDConfigAllow)`

SetAllow sets Allow field to given value.

### HasAllow

`func (o *V10ClusterNodeDriveDConfig) HasAllow() bool`

HasAllow returns a boolean if a field has been set.

### GetAutomaticReplacementRecognition

`func (o *V10ClusterNodeDriveDConfig) GetAutomaticReplacementRecognition() V10ClusterNodeDriveDConfigAutomaticReplacementRecognition`

GetAutomaticReplacementRecognition returns the AutomaticReplacementRecognition field if non-nil, zero value otherwise.

### GetAutomaticReplacementRecognitionOk

`func (o *V10ClusterNodeDriveDConfig) GetAutomaticReplacementRecognitionOk() (*V10ClusterNodeDriveDConfigAutomaticReplacementRecognition, bool)`

GetAutomaticReplacementRecognitionOk returns a tuple with the AutomaticReplacementRecognition field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAutomaticReplacementRecognition

`func (o *V10ClusterNodeDriveDConfig) SetAutomaticReplacementRecognition(v V10ClusterNodeDriveDConfigAutomaticReplacementRecognition)`

SetAutomaticReplacementRecognition sets AutomaticReplacementRecognition field to given value.

### HasAutomaticReplacementRecognition

`func (o *V10ClusterNodeDriveDConfig) HasAutomaticReplacementRecognition() bool`

HasAutomaticReplacementRecognition returns a boolean if a field has been set.

### GetInstantSecureErase

`func (o *V10ClusterNodeDriveDConfig) GetInstantSecureErase() V10ClusterNodeDriveDConfigInstantSecureErase`

GetInstantSecureErase returns the InstantSecureErase field if non-nil, zero value otherwise.

### GetInstantSecureEraseOk

`func (o *V10ClusterNodeDriveDConfig) GetInstantSecureEraseOk() (*V10ClusterNodeDriveDConfigInstantSecureErase, bool)`

GetInstantSecureEraseOk returns a tuple with the InstantSecureErase field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInstantSecureErase

`func (o *V10ClusterNodeDriveDConfig) SetInstantSecureErase(v V10ClusterNodeDriveDConfigInstantSecureErase)`

SetInstantSecureErase sets InstantSecureErase field to given value.

### HasInstantSecureErase

`func (o *V10ClusterNodeDriveDConfig) HasInstantSecureErase() bool`

HasInstantSecureErase returns a boolean if a field has been set.

### GetLog

`func (o *V10ClusterNodeDriveDConfig) GetLog() V10ClusterNodeDriveDConfigLog`

GetLog returns the Log field if non-nil, zero value otherwise.

### GetLogOk

`func (o *V10ClusterNodeDriveDConfig) GetLogOk() (*V10ClusterNodeDriveDConfigLog, bool)`

GetLogOk returns a tuple with the Log field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLog

`func (o *V10ClusterNodeDriveDConfig) SetLog(v V10ClusterNodeDriveDConfigLog)`

SetLog sets Log field to given value.

### HasLog

`func (o *V10ClusterNodeDriveDConfig) HasLog() bool`

HasLog returns a boolean if a field has been set.

### GetReboot

`func (o *V10ClusterNodeDriveDConfig) GetReboot() V10ClusterNodeDriveDConfigReboot`

GetReboot returns the Reboot field if non-nil, zero value otherwise.

### GetRebootOk

`func (o *V10ClusterNodeDriveDConfig) GetRebootOk() (*V10ClusterNodeDriveDConfigReboot, bool)`

GetRebootOk returns a tuple with the Reboot field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReboot

`func (o *V10ClusterNodeDriveDConfig) SetReboot(v V10ClusterNodeDriveDConfigReboot)`

SetReboot sets Reboot field to given value.

### HasReboot

`func (o *V10ClusterNodeDriveDConfig) HasReboot() bool`

HasReboot returns a boolean if a field has been set.

### GetSpinWait

`func (o *V10ClusterNodeDriveDConfig) GetSpinWait() V10ClusterNodeDriveDConfigSpinWait`

GetSpinWait returns the SpinWait field if non-nil, zero value otherwise.

### GetSpinWaitOk

`func (o *V10ClusterNodeDriveDConfig) GetSpinWaitOk() (*V10ClusterNodeDriveDConfigSpinWait, bool)`

GetSpinWaitOk returns a tuple with the SpinWait field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSpinWait

`func (o *V10ClusterNodeDriveDConfig) SetSpinWait(v V10ClusterNodeDriveDConfigSpinWait)`

SetSpinWait sets SpinWait field to given value.

### HasSpinWait

`func (o *V10ClusterNodeDriveDConfig) HasSpinWait() bool`

HasSpinWait returns a boolean if a field has been set.

### GetStall

`func (o *V10ClusterNodeDriveDConfig) GetStall() V10ClusterNodeDriveDConfigStall`

GetStall returns the Stall field if non-nil, zero value otherwise.

### GetStallOk

`func (o *V10ClusterNodeDriveDConfig) GetStallOk() (*V10ClusterNodeDriveDConfigStall, bool)`

GetStallOk returns a tuple with the Stall field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStall

`func (o *V10ClusterNodeDriveDConfig) SetStall(v V10ClusterNodeDriveDConfigStall)`

SetStall sets Stall field to given value.

### HasStall

`func (o *V10ClusterNodeDriveDConfig) HasStall() bool`

HasStall returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


