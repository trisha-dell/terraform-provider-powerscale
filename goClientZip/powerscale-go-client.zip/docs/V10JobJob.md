# V10JobJob

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AllowDup** | Pointer to **bool** | Whether or not to queue the job if one of the same type is already running or queued. | [optional] 
**AvscanParams** | Pointer to [**V10JobJobAvscanParams**](V10JobJobAvscanParams.md) |  | [optional] 
**ChangelistcreateParams** | Pointer to [**V10JobJobChangelistcreateParams**](V10JobJobChangelistcreateParams.md) |  | [optional] 
**DomainmarkParams** | Pointer to [**V1JobJobDomainmarkParams**](V1JobJobDomainmarkParams.md) |  | [optional] 
**EsrsmftdownloadParams** | Pointer to [**V1JobJobEsrsmftdownloadParams**](V1JobJobEsrsmftdownloadParams.md) |  | [optional] 
**FilepolicyParams** | Pointer to [**V10JobJobFilepolicyParams**](V10JobJobFilepolicyParams.md) |  | [optional] 
**Paths** | Pointer to **[]string** | For jobs which take paths, the IFS paths to pass to the job. | [optional] 
**Policy** | Pointer to **string** | Impact policy of this job instance. | [optional] 
**PrepairParams** | Pointer to [**V1JobJobPrepairParams**](V1JobJobPrepairParams.md) |  | [optional] 
**Priority** | Pointer to **int32** | Priority of this job instance; lower numbers preempt higher numbers. | [optional] 
**SmartpoolstreeParams** | Pointer to [**V1JobJobSmartpoolstreeParams**](V1JobJobSmartpoolstreeParams.md) |  | [optional] 
**SnaprevertParams** | Pointer to [**V1JobJobSnaprevertParams**](V1JobJobSnaprevertParams.md) |  | [optional] 
**TreedeleteParams** | Pointer to [**V10JobJobTreedeleteParams**](V10JobJobTreedeleteParams.md) |  | [optional] 
**Type** | **string** | Job type to queue. | 

## Methods

### NewV10JobJob

`func NewV10JobJob(type_ string, ) *V10JobJob`

NewV10JobJob instantiates a new V10JobJob object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10JobJobWithDefaults

`func NewV10JobJobWithDefaults() *V10JobJob`

NewV10JobJobWithDefaults instantiates a new V10JobJob object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAllowDup

`func (o *V10JobJob) GetAllowDup() bool`

GetAllowDup returns the AllowDup field if non-nil, zero value otherwise.

### GetAllowDupOk

`func (o *V10JobJob) GetAllowDupOk() (*bool, bool)`

GetAllowDupOk returns a tuple with the AllowDup field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllowDup

`func (o *V10JobJob) SetAllowDup(v bool)`

SetAllowDup sets AllowDup field to given value.

### HasAllowDup

`func (o *V10JobJob) HasAllowDup() bool`

HasAllowDup returns a boolean if a field has been set.

### GetAvscanParams

`func (o *V10JobJob) GetAvscanParams() V10JobJobAvscanParams`

GetAvscanParams returns the AvscanParams field if non-nil, zero value otherwise.

### GetAvscanParamsOk

`func (o *V10JobJob) GetAvscanParamsOk() (*V10JobJobAvscanParams, bool)`

GetAvscanParamsOk returns a tuple with the AvscanParams field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAvscanParams

`func (o *V10JobJob) SetAvscanParams(v V10JobJobAvscanParams)`

SetAvscanParams sets AvscanParams field to given value.

### HasAvscanParams

`func (o *V10JobJob) HasAvscanParams() bool`

HasAvscanParams returns a boolean if a field has been set.

### GetChangelistcreateParams

`func (o *V10JobJob) GetChangelistcreateParams() V10JobJobChangelistcreateParams`

GetChangelistcreateParams returns the ChangelistcreateParams field if non-nil, zero value otherwise.

### GetChangelistcreateParamsOk

`func (o *V10JobJob) GetChangelistcreateParamsOk() (*V10JobJobChangelistcreateParams, bool)`

GetChangelistcreateParamsOk returns a tuple with the ChangelistcreateParams field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChangelistcreateParams

`func (o *V10JobJob) SetChangelistcreateParams(v V10JobJobChangelistcreateParams)`

SetChangelistcreateParams sets ChangelistcreateParams field to given value.

### HasChangelistcreateParams

`func (o *V10JobJob) HasChangelistcreateParams() bool`

HasChangelistcreateParams returns a boolean if a field has been set.

### GetDomainmarkParams

`func (o *V10JobJob) GetDomainmarkParams() V1JobJobDomainmarkParams`

GetDomainmarkParams returns the DomainmarkParams field if non-nil, zero value otherwise.

### GetDomainmarkParamsOk

`func (o *V10JobJob) GetDomainmarkParamsOk() (*V1JobJobDomainmarkParams, bool)`

GetDomainmarkParamsOk returns a tuple with the DomainmarkParams field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDomainmarkParams

`func (o *V10JobJob) SetDomainmarkParams(v V1JobJobDomainmarkParams)`

SetDomainmarkParams sets DomainmarkParams field to given value.

### HasDomainmarkParams

`func (o *V10JobJob) HasDomainmarkParams() bool`

HasDomainmarkParams returns a boolean if a field has been set.

### GetEsrsmftdownloadParams

`func (o *V10JobJob) GetEsrsmftdownloadParams() V1JobJobEsrsmftdownloadParams`

GetEsrsmftdownloadParams returns the EsrsmftdownloadParams field if non-nil, zero value otherwise.

### GetEsrsmftdownloadParamsOk

`func (o *V10JobJob) GetEsrsmftdownloadParamsOk() (*V1JobJobEsrsmftdownloadParams, bool)`

GetEsrsmftdownloadParamsOk returns a tuple with the EsrsmftdownloadParams field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEsrsmftdownloadParams

`func (o *V10JobJob) SetEsrsmftdownloadParams(v V1JobJobEsrsmftdownloadParams)`

SetEsrsmftdownloadParams sets EsrsmftdownloadParams field to given value.

### HasEsrsmftdownloadParams

`func (o *V10JobJob) HasEsrsmftdownloadParams() bool`

HasEsrsmftdownloadParams returns a boolean if a field has been set.

### GetFilepolicyParams

`func (o *V10JobJob) GetFilepolicyParams() V10JobJobFilepolicyParams`

GetFilepolicyParams returns the FilepolicyParams field if non-nil, zero value otherwise.

### GetFilepolicyParamsOk

`func (o *V10JobJob) GetFilepolicyParamsOk() (*V10JobJobFilepolicyParams, bool)`

GetFilepolicyParamsOk returns a tuple with the FilepolicyParams field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFilepolicyParams

`func (o *V10JobJob) SetFilepolicyParams(v V10JobJobFilepolicyParams)`

SetFilepolicyParams sets FilepolicyParams field to given value.

### HasFilepolicyParams

`func (o *V10JobJob) HasFilepolicyParams() bool`

HasFilepolicyParams returns a boolean if a field has been set.

### GetPaths

`func (o *V10JobJob) GetPaths() []string`

GetPaths returns the Paths field if non-nil, zero value otherwise.

### GetPathsOk

`func (o *V10JobJob) GetPathsOk() (*[]string, bool)`

GetPathsOk returns a tuple with the Paths field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPaths

`func (o *V10JobJob) SetPaths(v []string)`

SetPaths sets Paths field to given value.

### HasPaths

`func (o *V10JobJob) HasPaths() bool`

HasPaths returns a boolean if a field has been set.

### GetPolicy

`func (o *V10JobJob) GetPolicy() string`

GetPolicy returns the Policy field if non-nil, zero value otherwise.

### GetPolicyOk

`func (o *V10JobJob) GetPolicyOk() (*string, bool)`

GetPolicyOk returns a tuple with the Policy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPolicy

`func (o *V10JobJob) SetPolicy(v string)`

SetPolicy sets Policy field to given value.

### HasPolicy

`func (o *V10JobJob) HasPolicy() bool`

HasPolicy returns a boolean if a field has been set.

### GetPrepairParams

`func (o *V10JobJob) GetPrepairParams() V1JobJobPrepairParams`

GetPrepairParams returns the PrepairParams field if non-nil, zero value otherwise.

### GetPrepairParamsOk

`func (o *V10JobJob) GetPrepairParamsOk() (*V1JobJobPrepairParams, bool)`

GetPrepairParamsOk returns a tuple with the PrepairParams field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrepairParams

`func (o *V10JobJob) SetPrepairParams(v V1JobJobPrepairParams)`

SetPrepairParams sets PrepairParams field to given value.

### HasPrepairParams

`func (o *V10JobJob) HasPrepairParams() bool`

HasPrepairParams returns a boolean if a field has been set.

### GetPriority

`func (o *V10JobJob) GetPriority() int32`

GetPriority returns the Priority field if non-nil, zero value otherwise.

### GetPriorityOk

`func (o *V10JobJob) GetPriorityOk() (*int32, bool)`

GetPriorityOk returns a tuple with the Priority field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPriority

`func (o *V10JobJob) SetPriority(v int32)`

SetPriority sets Priority field to given value.

### HasPriority

`func (o *V10JobJob) HasPriority() bool`

HasPriority returns a boolean if a field has been set.

### GetSmartpoolstreeParams

`func (o *V10JobJob) GetSmartpoolstreeParams() V1JobJobSmartpoolstreeParams`

GetSmartpoolstreeParams returns the SmartpoolstreeParams field if non-nil, zero value otherwise.

### GetSmartpoolstreeParamsOk

`func (o *V10JobJob) GetSmartpoolstreeParamsOk() (*V1JobJobSmartpoolstreeParams, bool)`

GetSmartpoolstreeParamsOk returns a tuple with the SmartpoolstreeParams field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmartpoolstreeParams

`func (o *V10JobJob) SetSmartpoolstreeParams(v V1JobJobSmartpoolstreeParams)`

SetSmartpoolstreeParams sets SmartpoolstreeParams field to given value.

### HasSmartpoolstreeParams

`func (o *V10JobJob) HasSmartpoolstreeParams() bool`

HasSmartpoolstreeParams returns a boolean if a field has been set.

### GetSnaprevertParams

`func (o *V10JobJob) GetSnaprevertParams() V1JobJobSnaprevertParams`

GetSnaprevertParams returns the SnaprevertParams field if non-nil, zero value otherwise.

### GetSnaprevertParamsOk

`func (o *V10JobJob) GetSnaprevertParamsOk() (*V1JobJobSnaprevertParams, bool)`

GetSnaprevertParamsOk returns a tuple with the SnaprevertParams field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSnaprevertParams

`func (o *V10JobJob) SetSnaprevertParams(v V1JobJobSnaprevertParams)`

SetSnaprevertParams sets SnaprevertParams field to given value.

### HasSnaprevertParams

`func (o *V10JobJob) HasSnaprevertParams() bool`

HasSnaprevertParams returns a boolean if a field has been set.

### GetTreedeleteParams

`func (o *V10JobJob) GetTreedeleteParams() V10JobJobTreedeleteParams`

GetTreedeleteParams returns the TreedeleteParams field if non-nil, zero value otherwise.

### GetTreedeleteParamsOk

`func (o *V10JobJob) GetTreedeleteParamsOk() (*V10JobJobTreedeleteParams, bool)`

GetTreedeleteParamsOk returns a tuple with the TreedeleteParams field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTreedeleteParams

`func (o *V10JobJob) SetTreedeleteParams(v V10JobJobTreedeleteParams)`

SetTreedeleteParams sets TreedeleteParams field to given value.

### HasTreedeleteParams

`func (o *V10JobJob) HasTreedeleteParams() bool`

HasTreedeleteParams returns a boolean if a field has been set.

### GetType

`func (o *V10JobJob) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *V10JobJob) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *V10JobJob) SetType(v string)`

SetType sets Type field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


