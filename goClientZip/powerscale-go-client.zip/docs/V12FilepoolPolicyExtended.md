# V12FilepoolPolicyExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Actions** | [**[]V1FilepoolDefaultPolicyAction**](V1FilepoolDefaultPolicyAction.md) | A list of actions to be taken for matching files | 
**ApplyOrder** | Pointer to **int64** | The order in which this policy should be applied (relative to other policies) | [optional] 
**BirthClusterId** | Pointer to **string** | The guid assigned to the cluster on which the policy was created | [optional] 
**Description** | Pointer to **string** | A description for this policy | [optional] 
**FileMatchingPattern** | Pointer to [**V1FilepoolPolicyFileMatchingPattern**](V1FilepoolPolicyFileMatchingPattern.md) |  | [optional] 
**Id** | Pointer to **string** | A unique name for this policy | [optional] 
**Name** | Pointer to **string** | A unique name for this policy | [optional] 
**State** | Pointer to **string** | Indicates whether this policy is in a good state (\&quot;OK\&quot;) or disabled (\&quot;disabled\&quot;) | [optional] 
**StateDetails** | Pointer to **string** | Gives further information to describe the state of this policy | [optional] 

## Methods

### NewV12FilepoolPolicyExtended

`func NewV12FilepoolPolicyExtended(actions []V1FilepoolDefaultPolicyAction, ) *V12FilepoolPolicyExtended`

NewV12FilepoolPolicyExtended instantiates a new V12FilepoolPolicyExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12FilepoolPolicyExtendedWithDefaults

`func NewV12FilepoolPolicyExtendedWithDefaults() *V12FilepoolPolicyExtended`

NewV12FilepoolPolicyExtendedWithDefaults instantiates a new V12FilepoolPolicyExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetActions

`func (o *V12FilepoolPolicyExtended) GetActions() []V1FilepoolDefaultPolicyAction`

GetActions returns the Actions field if non-nil, zero value otherwise.

### GetActionsOk

`func (o *V12FilepoolPolicyExtended) GetActionsOk() (*[]V1FilepoolDefaultPolicyAction, bool)`

GetActionsOk returns a tuple with the Actions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetActions

`func (o *V12FilepoolPolicyExtended) SetActions(v []V1FilepoolDefaultPolicyAction)`

SetActions sets Actions field to given value.


### GetApplyOrder

`func (o *V12FilepoolPolicyExtended) GetApplyOrder() int64`

GetApplyOrder returns the ApplyOrder field if non-nil, zero value otherwise.

### GetApplyOrderOk

`func (o *V12FilepoolPolicyExtended) GetApplyOrderOk() (*int64, bool)`

GetApplyOrderOk returns a tuple with the ApplyOrder field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetApplyOrder

`func (o *V12FilepoolPolicyExtended) SetApplyOrder(v int64)`

SetApplyOrder sets ApplyOrder field to given value.

### HasApplyOrder

`func (o *V12FilepoolPolicyExtended) HasApplyOrder() bool`

HasApplyOrder returns a boolean if a field has been set.

### GetBirthClusterId

`func (o *V12FilepoolPolicyExtended) GetBirthClusterId() string`

GetBirthClusterId returns the BirthClusterId field if non-nil, zero value otherwise.

### GetBirthClusterIdOk

`func (o *V12FilepoolPolicyExtended) GetBirthClusterIdOk() (*string, bool)`

GetBirthClusterIdOk returns a tuple with the BirthClusterId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBirthClusterId

`func (o *V12FilepoolPolicyExtended) SetBirthClusterId(v string)`

SetBirthClusterId sets BirthClusterId field to given value.

### HasBirthClusterId

`func (o *V12FilepoolPolicyExtended) HasBirthClusterId() bool`

HasBirthClusterId returns a boolean if a field has been set.

### GetDescription

`func (o *V12FilepoolPolicyExtended) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V12FilepoolPolicyExtended) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V12FilepoolPolicyExtended) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *V12FilepoolPolicyExtended) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetFileMatchingPattern

`func (o *V12FilepoolPolicyExtended) GetFileMatchingPattern() V1FilepoolPolicyFileMatchingPattern`

GetFileMatchingPattern returns the FileMatchingPattern field if non-nil, zero value otherwise.

### GetFileMatchingPatternOk

`func (o *V12FilepoolPolicyExtended) GetFileMatchingPatternOk() (*V1FilepoolPolicyFileMatchingPattern, bool)`

GetFileMatchingPatternOk returns a tuple with the FileMatchingPattern field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFileMatchingPattern

`func (o *V12FilepoolPolicyExtended) SetFileMatchingPattern(v V1FilepoolPolicyFileMatchingPattern)`

SetFileMatchingPattern sets FileMatchingPattern field to given value.

### HasFileMatchingPattern

`func (o *V12FilepoolPolicyExtended) HasFileMatchingPattern() bool`

HasFileMatchingPattern returns a boolean if a field has been set.

### GetId

`func (o *V12FilepoolPolicyExtended) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12FilepoolPolicyExtended) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12FilepoolPolicyExtended) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V12FilepoolPolicyExtended) HasId() bool`

HasId returns a boolean if a field has been set.

### GetName

`func (o *V12FilepoolPolicyExtended) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V12FilepoolPolicyExtended) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V12FilepoolPolicyExtended) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V12FilepoolPolicyExtended) HasName() bool`

HasName returns a boolean if a field has been set.

### GetState

`func (o *V12FilepoolPolicyExtended) GetState() string`

GetState returns the State field if non-nil, zero value otherwise.

### GetStateOk

`func (o *V12FilepoolPolicyExtended) GetStateOk() (*string, bool)`

GetStateOk returns a tuple with the State field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetState

`func (o *V12FilepoolPolicyExtended) SetState(v string)`

SetState sets State field to given value.

### HasState

`func (o *V12FilepoolPolicyExtended) HasState() bool`

HasState returns a boolean if a field has been set.

### GetStateDetails

`func (o *V12FilepoolPolicyExtended) GetStateDetails() string`

GetStateDetails returns the StateDetails field if non-nil, zero value otherwise.

### GetStateDetailsOk

`func (o *V12FilepoolPolicyExtended) GetStateDetailsOk() (*string, bool)`

GetStateDetailsOk returns a tuple with the StateDetails field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStateDetails

`func (o *V12FilepoolPolicyExtended) SetStateDetails(v string)`

SetStateDetails sets StateDetails field to given value.

### HasStateDetails

`func (o *V12FilepoolPolicyExtended) HasStateDetails() bool`

HasStateDetails returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


