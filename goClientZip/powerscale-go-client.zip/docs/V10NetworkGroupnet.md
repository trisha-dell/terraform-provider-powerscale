# V10NetworkGroupnet

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AllowWildcardSubdomains** | Pointer to **bool** | If enabled, SmartConnect treats subdomains of known dns zones as the known dns zone. This is required for S3 Virtual Host domains. Defaults to True. | [optional] 
**Description** | Pointer to **string** | A description of the groupnet. | [optional] 
**DnsCacheEnabled** | Pointer to **bool** | DNS caching is enabled or disabled. | [optional] 
**DnsOptions** | Pointer to **[]string** | List of DNS resolver options. | [optional] 
**DnsSearch** | Pointer to **[]string** | List of DNS search suffixes. | [optional] 
**DnsServers** | Pointer to **[]string** | List of Domain Name Server IP addresses. | [optional] 
**Name** | **string** | The name of the groupnet. | 
**ServerSideDnsSearch** | Pointer to **bool** | Enable or disable appending nodes DNS search  list to client DNS inquiries directed at SmartConnect service IP. | [optional] 

## Methods

### NewV10NetworkGroupnet

`func NewV10NetworkGroupnet(name string, ) *V10NetworkGroupnet`

NewV10NetworkGroupnet instantiates a new V10NetworkGroupnet object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10NetworkGroupnetWithDefaults

`func NewV10NetworkGroupnetWithDefaults() *V10NetworkGroupnet`

NewV10NetworkGroupnetWithDefaults instantiates a new V10NetworkGroupnet object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAllowWildcardSubdomains

`func (o *V10NetworkGroupnet) GetAllowWildcardSubdomains() bool`

GetAllowWildcardSubdomains returns the AllowWildcardSubdomains field if non-nil, zero value otherwise.

### GetAllowWildcardSubdomainsOk

`func (o *V10NetworkGroupnet) GetAllowWildcardSubdomainsOk() (*bool, bool)`

GetAllowWildcardSubdomainsOk returns a tuple with the AllowWildcardSubdomains field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllowWildcardSubdomains

`func (o *V10NetworkGroupnet) SetAllowWildcardSubdomains(v bool)`

SetAllowWildcardSubdomains sets AllowWildcardSubdomains field to given value.

### HasAllowWildcardSubdomains

`func (o *V10NetworkGroupnet) HasAllowWildcardSubdomains() bool`

HasAllowWildcardSubdomains returns a boolean if a field has been set.

### GetDescription

`func (o *V10NetworkGroupnet) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V10NetworkGroupnet) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V10NetworkGroupnet) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *V10NetworkGroupnet) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetDnsCacheEnabled

`func (o *V10NetworkGroupnet) GetDnsCacheEnabled() bool`

GetDnsCacheEnabled returns the DnsCacheEnabled field if non-nil, zero value otherwise.

### GetDnsCacheEnabledOk

`func (o *V10NetworkGroupnet) GetDnsCacheEnabledOk() (*bool, bool)`

GetDnsCacheEnabledOk returns a tuple with the DnsCacheEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDnsCacheEnabled

`func (o *V10NetworkGroupnet) SetDnsCacheEnabled(v bool)`

SetDnsCacheEnabled sets DnsCacheEnabled field to given value.

### HasDnsCacheEnabled

`func (o *V10NetworkGroupnet) HasDnsCacheEnabled() bool`

HasDnsCacheEnabled returns a boolean if a field has been set.

### GetDnsOptions

`func (o *V10NetworkGroupnet) GetDnsOptions() []string`

GetDnsOptions returns the DnsOptions field if non-nil, zero value otherwise.

### GetDnsOptionsOk

`func (o *V10NetworkGroupnet) GetDnsOptionsOk() (*[]string, bool)`

GetDnsOptionsOk returns a tuple with the DnsOptions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDnsOptions

`func (o *V10NetworkGroupnet) SetDnsOptions(v []string)`

SetDnsOptions sets DnsOptions field to given value.

### HasDnsOptions

`func (o *V10NetworkGroupnet) HasDnsOptions() bool`

HasDnsOptions returns a boolean if a field has been set.

### GetDnsSearch

`func (o *V10NetworkGroupnet) GetDnsSearch() []string`

GetDnsSearch returns the DnsSearch field if non-nil, zero value otherwise.

### GetDnsSearchOk

`func (o *V10NetworkGroupnet) GetDnsSearchOk() (*[]string, bool)`

GetDnsSearchOk returns a tuple with the DnsSearch field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDnsSearch

`func (o *V10NetworkGroupnet) SetDnsSearch(v []string)`

SetDnsSearch sets DnsSearch field to given value.

### HasDnsSearch

`func (o *V10NetworkGroupnet) HasDnsSearch() bool`

HasDnsSearch returns a boolean if a field has been set.

### GetDnsServers

`func (o *V10NetworkGroupnet) GetDnsServers() []string`

GetDnsServers returns the DnsServers field if non-nil, zero value otherwise.

### GetDnsServersOk

`func (o *V10NetworkGroupnet) GetDnsServersOk() (*[]string, bool)`

GetDnsServersOk returns a tuple with the DnsServers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDnsServers

`func (o *V10NetworkGroupnet) SetDnsServers(v []string)`

SetDnsServers sets DnsServers field to given value.

### HasDnsServers

`func (o *V10NetworkGroupnet) HasDnsServers() bool`

HasDnsServers returns a boolean if a field has been set.

### GetName

`func (o *V10NetworkGroupnet) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V10NetworkGroupnet) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V10NetworkGroupnet) SetName(v string)`

SetName sets Name field to given value.


### GetServerSideDnsSearch

`func (o *V10NetworkGroupnet) GetServerSideDnsSearch() bool`

GetServerSideDnsSearch returns the ServerSideDnsSearch field if non-nil, zero value otherwise.

### GetServerSideDnsSearchOk

`func (o *V10NetworkGroupnet) GetServerSideDnsSearchOk() (*bool, bool)`

GetServerSideDnsSearchOk returns a tuple with the ServerSideDnsSearch field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServerSideDnsSearch

`func (o *V10NetworkGroupnet) SetServerSideDnsSearch(v bool)`

SetServerSideDnsSearch sets ServerSideDnsSearch field to given value.

### HasServerSideDnsSearch

`func (o *V10NetworkGroupnet) HasServerSideDnsSearch() bool`

HasServerSideDnsSearch returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


