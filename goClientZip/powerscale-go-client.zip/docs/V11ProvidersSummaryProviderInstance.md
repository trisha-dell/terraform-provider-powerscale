# V11ProvidersSummaryProviderInstance

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ActiveServer** | Pointer to **string** | Specifies the server through which the provider serves authentication requests. Null if no server is set or is not applicable for that provider. | [optional] 
**ClientSite** | Pointer to **string** | The Nodes Site. | [optional] 
**Connections** | Pointer to [**[]V1ProvidersSummaryProviderInstanceConnection**](V1ProvidersSummaryProviderInstanceConnection.md) |  | [optional] 
**DcSite** | Pointer to **string** | The DC Site. | [optional] 
**Forest** | Pointer to **string** | Specifies the Active Directory forest. Null if not applicable. | [optional] 
**Groupnet** | Pointer to **string** | The groupnet the provider is in. | [optional] 
**Id** | Pointer to **string** | Specifies the ID of the provider. | [optional] 
**Name** | Pointer to **string** | Specifies the name of the provider. | [optional] 
**Status** | Pointer to **string** | Indicates the status of the provider. | [optional] 
**Type** | Pointer to **string** | Specifies the type of provider. | [optional] 
**ZoneName** | Pointer to **string** | Specifies the name of the access zone in which this provider was created. | [optional] 

## Methods

### NewV11ProvidersSummaryProviderInstance

`func NewV11ProvidersSummaryProviderInstance() *V11ProvidersSummaryProviderInstance`

NewV11ProvidersSummaryProviderInstance instantiates a new V11ProvidersSummaryProviderInstance object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11ProvidersSummaryProviderInstanceWithDefaults

`func NewV11ProvidersSummaryProviderInstanceWithDefaults() *V11ProvidersSummaryProviderInstance`

NewV11ProvidersSummaryProviderInstanceWithDefaults instantiates a new V11ProvidersSummaryProviderInstance object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetActiveServer

`func (o *V11ProvidersSummaryProviderInstance) GetActiveServer() string`

GetActiveServer returns the ActiveServer field if non-nil, zero value otherwise.

### GetActiveServerOk

`func (o *V11ProvidersSummaryProviderInstance) GetActiveServerOk() (*string, bool)`

GetActiveServerOk returns a tuple with the ActiveServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetActiveServer

`func (o *V11ProvidersSummaryProviderInstance) SetActiveServer(v string)`

SetActiveServer sets ActiveServer field to given value.

### HasActiveServer

`func (o *V11ProvidersSummaryProviderInstance) HasActiveServer() bool`

HasActiveServer returns a boolean if a field has been set.

### GetClientSite

`func (o *V11ProvidersSummaryProviderInstance) GetClientSite() string`

GetClientSite returns the ClientSite field if non-nil, zero value otherwise.

### GetClientSiteOk

`func (o *V11ProvidersSummaryProviderInstance) GetClientSiteOk() (*string, bool)`

GetClientSiteOk returns a tuple with the ClientSite field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClientSite

`func (o *V11ProvidersSummaryProviderInstance) SetClientSite(v string)`

SetClientSite sets ClientSite field to given value.

### HasClientSite

`func (o *V11ProvidersSummaryProviderInstance) HasClientSite() bool`

HasClientSite returns a boolean if a field has been set.

### GetConnections

`func (o *V11ProvidersSummaryProviderInstance) GetConnections() []V1ProvidersSummaryProviderInstanceConnection`

GetConnections returns the Connections field if non-nil, zero value otherwise.

### GetConnectionsOk

`func (o *V11ProvidersSummaryProviderInstance) GetConnectionsOk() (*[]V1ProvidersSummaryProviderInstanceConnection, bool)`

GetConnectionsOk returns a tuple with the Connections field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetConnections

`func (o *V11ProvidersSummaryProviderInstance) SetConnections(v []V1ProvidersSummaryProviderInstanceConnection)`

SetConnections sets Connections field to given value.

### HasConnections

`func (o *V11ProvidersSummaryProviderInstance) HasConnections() bool`

HasConnections returns a boolean if a field has been set.

### GetDcSite

`func (o *V11ProvidersSummaryProviderInstance) GetDcSite() string`

GetDcSite returns the DcSite field if non-nil, zero value otherwise.

### GetDcSiteOk

`func (o *V11ProvidersSummaryProviderInstance) GetDcSiteOk() (*string, bool)`

GetDcSiteOk returns a tuple with the DcSite field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDcSite

`func (o *V11ProvidersSummaryProviderInstance) SetDcSite(v string)`

SetDcSite sets DcSite field to given value.

### HasDcSite

`func (o *V11ProvidersSummaryProviderInstance) HasDcSite() bool`

HasDcSite returns a boolean if a field has been set.

### GetForest

`func (o *V11ProvidersSummaryProviderInstance) GetForest() string`

GetForest returns the Forest field if non-nil, zero value otherwise.

### GetForestOk

`func (o *V11ProvidersSummaryProviderInstance) GetForestOk() (*string, bool)`

GetForestOk returns a tuple with the Forest field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetForest

`func (o *V11ProvidersSummaryProviderInstance) SetForest(v string)`

SetForest sets Forest field to given value.

### HasForest

`func (o *V11ProvidersSummaryProviderInstance) HasForest() bool`

HasForest returns a boolean if a field has been set.

### GetGroupnet

`func (o *V11ProvidersSummaryProviderInstance) GetGroupnet() string`

GetGroupnet returns the Groupnet field if non-nil, zero value otherwise.

### GetGroupnetOk

`func (o *V11ProvidersSummaryProviderInstance) GetGroupnetOk() (*string, bool)`

GetGroupnetOk returns a tuple with the Groupnet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupnet

`func (o *V11ProvidersSummaryProviderInstance) SetGroupnet(v string)`

SetGroupnet sets Groupnet field to given value.

### HasGroupnet

`func (o *V11ProvidersSummaryProviderInstance) HasGroupnet() bool`

HasGroupnet returns a boolean if a field has been set.

### GetId

`func (o *V11ProvidersSummaryProviderInstance) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V11ProvidersSummaryProviderInstance) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V11ProvidersSummaryProviderInstance) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V11ProvidersSummaryProviderInstance) HasId() bool`

HasId returns a boolean if a field has been set.

### GetName

`func (o *V11ProvidersSummaryProviderInstance) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V11ProvidersSummaryProviderInstance) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V11ProvidersSummaryProviderInstance) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V11ProvidersSummaryProviderInstance) HasName() bool`

HasName returns a boolean if a field has been set.

### GetStatus

`func (o *V11ProvidersSummaryProviderInstance) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V11ProvidersSummaryProviderInstance) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V11ProvidersSummaryProviderInstance) SetStatus(v string)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V11ProvidersSummaryProviderInstance) HasStatus() bool`

HasStatus returns a boolean if a field has been set.

### GetType

`func (o *V11ProvidersSummaryProviderInstance) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *V11ProvidersSummaryProviderInstance) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *V11ProvidersSummaryProviderInstance) SetType(v string)`

SetType sets Type field to given value.

### HasType

`func (o *V11ProvidersSummaryProviderInstance) HasType() bool`

HasType returns a boolean if a field has been set.

### GetZoneName

`func (o *V11ProvidersSummaryProviderInstance) GetZoneName() string`

GetZoneName returns the ZoneName field if non-nil, zero value otherwise.

### GetZoneNameOk

`func (o *V11ProvidersSummaryProviderInstance) GetZoneNameOk() (*string, bool)`

GetZoneNameOk returns a tuple with the ZoneName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetZoneName

`func (o *V11ProvidersSummaryProviderInstance) SetZoneName(v string)`

SetZoneName sets ZoneName field to given value.

### HasZoneName

`func (o *V11ProvidersSummaryProviderInstance) HasZoneName() bool`

HasZoneName returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


