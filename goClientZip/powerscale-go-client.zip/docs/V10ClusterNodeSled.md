# V10ClusterNodeSled

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IsRemoveable** | **bool** | Boolean to indicate whether or not the sled is safe to remove. | 
**SledLetter** | **string** | The sled letter which OneFS uses to refer to this sled in the node. | 
**SledState** | **string** | The state of physical presence of a sled. | 

## Methods

### NewV10ClusterNodeSled

`func NewV10ClusterNodeSled(isRemoveable bool, sledLetter string, sledState string, ) *V10ClusterNodeSled`

NewV10ClusterNodeSled instantiates a new V10ClusterNodeSled object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeSledWithDefaults

`func NewV10ClusterNodeSledWithDefaults() *V10ClusterNodeSled`

NewV10ClusterNodeSledWithDefaults instantiates a new V10ClusterNodeSled object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetIsRemoveable

`func (o *V10ClusterNodeSled) GetIsRemoveable() bool`

GetIsRemoveable returns the IsRemoveable field if non-nil, zero value otherwise.

### GetIsRemoveableOk

`func (o *V10ClusterNodeSled) GetIsRemoveableOk() (*bool, bool)`

GetIsRemoveableOk returns a tuple with the IsRemoveable field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIsRemoveable

`func (o *V10ClusterNodeSled) SetIsRemoveable(v bool)`

SetIsRemoveable sets IsRemoveable field to given value.


### GetSledLetter

`func (o *V10ClusterNodeSled) GetSledLetter() string`

GetSledLetter returns the SledLetter field if non-nil, zero value otherwise.

### GetSledLetterOk

`func (o *V10ClusterNodeSled) GetSledLetterOk() (*string, bool)`

GetSledLetterOk returns a tuple with the SledLetter field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSledLetter

`func (o *V10ClusterNodeSled) SetSledLetter(v string)`

SetSledLetter sets SledLetter field to given value.


### GetSledState

`func (o *V10ClusterNodeSled) GetSledState() string`

GetSledState returns the SledState field if non-nil, zero value otherwise.

### GetSledStateOk

`func (o *V10ClusterNodeSled) GetSledStateOk() (*string, bool)`

GetSledStateOk returns a tuple with the SledState field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSledState

`func (o *V10ClusterNodeSled) SetSledState(v string)`

SetSledState sets SledState field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


