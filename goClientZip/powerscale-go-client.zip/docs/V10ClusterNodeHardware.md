# V10ClusterNodeHardware

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Chassis** | Pointer to **string** | Name of this node&#39;s chassis. | [optional] 
**ChassisCode** | Pointer to **string** | Chassis code of this node (1U, 2U, etc.). | [optional] 
**ChassisCount** | Pointer to **string** | Number of chassis making up this node. | [optional] 
**ChassisDepth** | Pointer to **string** | Chassis depth for this node if applicable (e.g., Normal, Deep, Unknown). If not supported or error: Unknown.  | [optional] 
**Class** | Pointer to **string** | Class of this node (storage, accelerator, etc.). | [optional] 
**CodeName** | Pointer to **string** | Code name of this node if applicable If not supported or error: Unknown. | [optional] 
**ComputeType** | Pointer to **string** | Type of compute node if applicable (e.g., Low, Medium, High, Turbo, Ultra, Unknown). If not supported or error: Unknown.  | [optional] 
**ConfigurationId** | Pointer to **string** | Node configuration ID. | [optional] 
**Cpu** | Pointer to **string** | Manufacturer and model of this node&#39;s CPU. | [optional] 
**DiskController** | Pointer to **string** | Manufacturer and model of this node&#39;s disk controller. | [optional] 
**DiskExpander** | Pointer to **string** | Manufacturer and model of this node&#39;s disk expander. | [optional] 
**FamilyCode** | Pointer to **string** | Family code of this node (X, S, NL, etc.). | [optional] 
**FlashDrive** | Pointer to **string** | Manufacturer, model, and device id of this node&#39;s flash drive. | [optional] 
**GenerationCode** | Pointer to **string** | Generation code of this node. | [optional] 
**Hwgen** | Pointer to **string** | PowerScale hardware generation name. | [optional] 
**ImbVersion** | Pointer to **string** | Version of this node&#39;s PowerScale Management Board. | [optional] 
**Infiniband** | Pointer to **string** | Infiniband card type. | [optional] 
**LcdVersion** | Pointer to **string** | Version of the LCD panel. | [optional] 
**Model** | Pointer to **string** | PowerScale node model identifier string (S200, X410, Infinity-H500, etc.). | [optional] 
**ModelCode** | Pointer to **string** | PowerScale node model code string (S200, X410, H500, etc.). | [optional] 
**Motherboard** | Pointer to **string** | Manufacturer and model of this node&#39;s motherboard. | [optional] 
**NetInterfaces** | Pointer to **string** | Description of all this node&#39;s network interfaces. | [optional] 
**NodeSlotId** | Pointer to **int32** | Position of node within chassis. -1 for error or not supported. | [optional] 
**Nvram** | Pointer to **string** | Manufacturer and model of this node&#39;s NVRAM board. | [optional] 
**PeerSerialNumber** | **string** | Serial number of this node&#39;s peer/buddy node.(Infinity Only) | 
**PerformanceCode** | Pointer to **string** | Performance code of this node, if applicable (2, 4, 5, etc.). | [optional] 
**Powersupplies** | Pointer to **[]string** | Description strings for each power supply on this node. | [optional] 
**Processor** | Pointer to **string** | Number of processors and cores on this node. | [optional] 
**Product** | Pointer to **string** | PowerScale product name. | [optional] 
**Ram** | Pointer to **int32** | Size of RAM in bytes. | [optional] 
**SerialNumber** | Pointer to **string** | Serial number of this node. | [optional] 
**Series** | Pointer to **string** | Series of this node (X, I, NL, etc.). | [optional] 
**SledDriveCount** | Pointer to **int32** | Size of drive sleds in node, if applicable. Expected values: 3, 4, 6. 0 if unable to determine sled size. -1 for error or not supported. If PSI_Get fails: -1. PSI_Get can fail if PSI not initialized, or key does not exist. | [optional] 
**StorageClass** | Pointer to **string** | Storage class of this node (storage or diskless). | [optional] 
**Tier** | Pointer to **int32** | Platform tier level of this node if applicable(positive for a defined tier, 0 for unknown or not supported, -1 for error). | [optional] 
**TopLevelAssemblySerialNumber** | **string** | Serial number of the top level assembly of this node.(Infinity Only) | 

## Methods

### NewV10ClusterNodeHardware

`func NewV10ClusterNodeHardware(peerSerialNumber string, topLevelAssemblySerialNumber string, ) *V10ClusterNodeHardware`

NewV10ClusterNodeHardware instantiates a new V10ClusterNodeHardware object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeHardwareWithDefaults

`func NewV10ClusterNodeHardwareWithDefaults() *V10ClusterNodeHardware`

NewV10ClusterNodeHardwareWithDefaults instantiates a new V10ClusterNodeHardware object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetChassis

`func (o *V10ClusterNodeHardware) GetChassis() string`

GetChassis returns the Chassis field if non-nil, zero value otherwise.

### GetChassisOk

`func (o *V10ClusterNodeHardware) GetChassisOk() (*string, bool)`

GetChassisOk returns a tuple with the Chassis field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChassis

`func (o *V10ClusterNodeHardware) SetChassis(v string)`

SetChassis sets Chassis field to given value.

### HasChassis

`func (o *V10ClusterNodeHardware) HasChassis() bool`

HasChassis returns a boolean if a field has been set.

### GetChassisCode

`func (o *V10ClusterNodeHardware) GetChassisCode() string`

GetChassisCode returns the ChassisCode field if non-nil, zero value otherwise.

### GetChassisCodeOk

`func (o *V10ClusterNodeHardware) GetChassisCodeOk() (*string, bool)`

GetChassisCodeOk returns a tuple with the ChassisCode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChassisCode

`func (o *V10ClusterNodeHardware) SetChassisCode(v string)`

SetChassisCode sets ChassisCode field to given value.

### HasChassisCode

`func (o *V10ClusterNodeHardware) HasChassisCode() bool`

HasChassisCode returns a boolean if a field has been set.

### GetChassisCount

`func (o *V10ClusterNodeHardware) GetChassisCount() string`

GetChassisCount returns the ChassisCount field if non-nil, zero value otherwise.

### GetChassisCountOk

`func (o *V10ClusterNodeHardware) GetChassisCountOk() (*string, bool)`

GetChassisCountOk returns a tuple with the ChassisCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChassisCount

`func (o *V10ClusterNodeHardware) SetChassisCount(v string)`

SetChassisCount sets ChassisCount field to given value.

### HasChassisCount

`func (o *V10ClusterNodeHardware) HasChassisCount() bool`

HasChassisCount returns a boolean if a field has been set.

### GetChassisDepth

`func (o *V10ClusterNodeHardware) GetChassisDepth() string`

GetChassisDepth returns the ChassisDepth field if non-nil, zero value otherwise.

### GetChassisDepthOk

`func (o *V10ClusterNodeHardware) GetChassisDepthOk() (*string, bool)`

GetChassisDepthOk returns a tuple with the ChassisDepth field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChassisDepth

`func (o *V10ClusterNodeHardware) SetChassisDepth(v string)`

SetChassisDepth sets ChassisDepth field to given value.

### HasChassisDepth

`func (o *V10ClusterNodeHardware) HasChassisDepth() bool`

HasChassisDepth returns a boolean if a field has been set.

### GetClass

`func (o *V10ClusterNodeHardware) GetClass() string`

GetClass returns the Class field if non-nil, zero value otherwise.

### GetClassOk

`func (o *V10ClusterNodeHardware) GetClassOk() (*string, bool)`

GetClassOk returns a tuple with the Class field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClass

`func (o *V10ClusterNodeHardware) SetClass(v string)`

SetClass sets Class field to given value.

### HasClass

`func (o *V10ClusterNodeHardware) HasClass() bool`

HasClass returns a boolean if a field has been set.

### GetCodeName

`func (o *V10ClusterNodeHardware) GetCodeName() string`

GetCodeName returns the CodeName field if non-nil, zero value otherwise.

### GetCodeNameOk

`func (o *V10ClusterNodeHardware) GetCodeNameOk() (*string, bool)`

GetCodeNameOk returns a tuple with the CodeName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCodeName

`func (o *V10ClusterNodeHardware) SetCodeName(v string)`

SetCodeName sets CodeName field to given value.

### HasCodeName

`func (o *V10ClusterNodeHardware) HasCodeName() bool`

HasCodeName returns a boolean if a field has been set.

### GetComputeType

`func (o *V10ClusterNodeHardware) GetComputeType() string`

GetComputeType returns the ComputeType field if non-nil, zero value otherwise.

### GetComputeTypeOk

`func (o *V10ClusterNodeHardware) GetComputeTypeOk() (*string, bool)`

GetComputeTypeOk returns a tuple with the ComputeType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetComputeType

`func (o *V10ClusterNodeHardware) SetComputeType(v string)`

SetComputeType sets ComputeType field to given value.

### HasComputeType

`func (o *V10ClusterNodeHardware) HasComputeType() bool`

HasComputeType returns a boolean if a field has been set.

### GetConfigurationId

`func (o *V10ClusterNodeHardware) GetConfigurationId() string`

GetConfigurationId returns the ConfigurationId field if non-nil, zero value otherwise.

### GetConfigurationIdOk

`func (o *V10ClusterNodeHardware) GetConfigurationIdOk() (*string, bool)`

GetConfigurationIdOk returns a tuple with the ConfigurationId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetConfigurationId

`func (o *V10ClusterNodeHardware) SetConfigurationId(v string)`

SetConfigurationId sets ConfigurationId field to given value.

### HasConfigurationId

`func (o *V10ClusterNodeHardware) HasConfigurationId() bool`

HasConfigurationId returns a boolean if a field has been set.

### GetCpu

`func (o *V10ClusterNodeHardware) GetCpu() string`

GetCpu returns the Cpu field if non-nil, zero value otherwise.

### GetCpuOk

`func (o *V10ClusterNodeHardware) GetCpuOk() (*string, bool)`

GetCpuOk returns a tuple with the Cpu field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCpu

`func (o *V10ClusterNodeHardware) SetCpu(v string)`

SetCpu sets Cpu field to given value.

### HasCpu

`func (o *V10ClusterNodeHardware) HasCpu() bool`

HasCpu returns a boolean if a field has been set.

### GetDiskController

`func (o *V10ClusterNodeHardware) GetDiskController() string`

GetDiskController returns the DiskController field if non-nil, zero value otherwise.

### GetDiskControllerOk

`func (o *V10ClusterNodeHardware) GetDiskControllerOk() (*string, bool)`

GetDiskControllerOk returns a tuple with the DiskController field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDiskController

`func (o *V10ClusterNodeHardware) SetDiskController(v string)`

SetDiskController sets DiskController field to given value.

### HasDiskController

`func (o *V10ClusterNodeHardware) HasDiskController() bool`

HasDiskController returns a boolean if a field has been set.

### GetDiskExpander

`func (o *V10ClusterNodeHardware) GetDiskExpander() string`

GetDiskExpander returns the DiskExpander field if non-nil, zero value otherwise.

### GetDiskExpanderOk

`func (o *V10ClusterNodeHardware) GetDiskExpanderOk() (*string, bool)`

GetDiskExpanderOk returns a tuple with the DiskExpander field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDiskExpander

`func (o *V10ClusterNodeHardware) SetDiskExpander(v string)`

SetDiskExpander sets DiskExpander field to given value.

### HasDiskExpander

`func (o *V10ClusterNodeHardware) HasDiskExpander() bool`

HasDiskExpander returns a boolean if a field has been set.

### GetFamilyCode

`func (o *V10ClusterNodeHardware) GetFamilyCode() string`

GetFamilyCode returns the FamilyCode field if non-nil, zero value otherwise.

### GetFamilyCodeOk

`func (o *V10ClusterNodeHardware) GetFamilyCodeOk() (*string, bool)`

GetFamilyCodeOk returns a tuple with the FamilyCode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFamilyCode

`func (o *V10ClusterNodeHardware) SetFamilyCode(v string)`

SetFamilyCode sets FamilyCode field to given value.

### HasFamilyCode

`func (o *V10ClusterNodeHardware) HasFamilyCode() bool`

HasFamilyCode returns a boolean if a field has been set.

### GetFlashDrive

`func (o *V10ClusterNodeHardware) GetFlashDrive() string`

GetFlashDrive returns the FlashDrive field if non-nil, zero value otherwise.

### GetFlashDriveOk

`func (o *V10ClusterNodeHardware) GetFlashDriveOk() (*string, bool)`

GetFlashDriveOk returns a tuple with the FlashDrive field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlashDrive

`func (o *V10ClusterNodeHardware) SetFlashDrive(v string)`

SetFlashDrive sets FlashDrive field to given value.

### HasFlashDrive

`func (o *V10ClusterNodeHardware) HasFlashDrive() bool`

HasFlashDrive returns a boolean if a field has been set.

### GetGenerationCode

`func (o *V10ClusterNodeHardware) GetGenerationCode() string`

GetGenerationCode returns the GenerationCode field if non-nil, zero value otherwise.

### GetGenerationCodeOk

`func (o *V10ClusterNodeHardware) GetGenerationCodeOk() (*string, bool)`

GetGenerationCodeOk returns a tuple with the GenerationCode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGenerationCode

`func (o *V10ClusterNodeHardware) SetGenerationCode(v string)`

SetGenerationCode sets GenerationCode field to given value.

### HasGenerationCode

`func (o *V10ClusterNodeHardware) HasGenerationCode() bool`

HasGenerationCode returns a boolean if a field has been set.

### GetHwgen

`func (o *V10ClusterNodeHardware) GetHwgen() string`

GetHwgen returns the Hwgen field if non-nil, zero value otherwise.

### GetHwgenOk

`func (o *V10ClusterNodeHardware) GetHwgenOk() (*string, bool)`

GetHwgenOk returns a tuple with the Hwgen field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHwgen

`func (o *V10ClusterNodeHardware) SetHwgen(v string)`

SetHwgen sets Hwgen field to given value.

### HasHwgen

`func (o *V10ClusterNodeHardware) HasHwgen() bool`

HasHwgen returns a boolean if a field has been set.

### GetImbVersion

`func (o *V10ClusterNodeHardware) GetImbVersion() string`

GetImbVersion returns the ImbVersion field if non-nil, zero value otherwise.

### GetImbVersionOk

`func (o *V10ClusterNodeHardware) GetImbVersionOk() (*string, bool)`

GetImbVersionOk returns a tuple with the ImbVersion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetImbVersion

`func (o *V10ClusterNodeHardware) SetImbVersion(v string)`

SetImbVersion sets ImbVersion field to given value.

### HasImbVersion

`func (o *V10ClusterNodeHardware) HasImbVersion() bool`

HasImbVersion returns a boolean if a field has been set.

### GetInfiniband

`func (o *V10ClusterNodeHardware) GetInfiniband() string`

GetInfiniband returns the Infiniband field if non-nil, zero value otherwise.

### GetInfinibandOk

`func (o *V10ClusterNodeHardware) GetInfinibandOk() (*string, bool)`

GetInfinibandOk returns a tuple with the Infiniband field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInfiniband

`func (o *V10ClusterNodeHardware) SetInfiniband(v string)`

SetInfiniband sets Infiniband field to given value.

### HasInfiniband

`func (o *V10ClusterNodeHardware) HasInfiniband() bool`

HasInfiniband returns a boolean if a field has been set.

### GetLcdVersion

`func (o *V10ClusterNodeHardware) GetLcdVersion() string`

GetLcdVersion returns the LcdVersion field if non-nil, zero value otherwise.

### GetLcdVersionOk

`func (o *V10ClusterNodeHardware) GetLcdVersionOk() (*string, bool)`

GetLcdVersionOk returns a tuple with the LcdVersion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLcdVersion

`func (o *V10ClusterNodeHardware) SetLcdVersion(v string)`

SetLcdVersion sets LcdVersion field to given value.

### HasLcdVersion

`func (o *V10ClusterNodeHardware) HasLcdVersion() bool`

HasLcdVersion returns a boolean if a field has been set.

### GetModel

`func (o *V10ClusterNodeHardware) GetModel() string`

GetModel returns the Model field if non-nil, zero value otherwise.

### GetModelOk

`func (o *V10ClusterNodeHardware) GetModelOk() (*string, bool)`

GetModelOk returns a tuple with the Model field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetModel

`func (o *V10ClusterNodeHardware) SetModel(v string)`

SetModel sets Model field to given value.

### HasModel

`func (o *V10ClusterNodeHardware) HasModel() bool`

HasModel returns a boolean if a field has been set.

### GetModelCode

`func (o *V10ClusterNodeHardware) GetModelCode() string`

GetModelCode returns the ModelCode field if non-nil, zero value otherwise.

### GetModelCodeOk

`func (o *V10ClusterNodeHardware) GetModelCodeOk() (*string, bool)`

GetModelCodeOk returns a tuple with the ModelCode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetModelCode

`func (o *V10ClusterNodeHardware) SetModelCode(v string)`

SetModelCode sets ModelCode field to given value.

### HasModelCode

`func (o *V10ClusterNodeHardware) HasModelCode() bool`

HasModelCode returns a boolean if a field has been set.

### GetMotherboard

`func (o *V10ClusterNodeHardware) GetMotherboard() string`

GetMotherboard returns the Motherboard field if non-nil, zero value otherwise.

### GetMotherboardOk

`func (o *V10ClusterNodeHardware) GetMotherboardOk() (*string, bool)`

GetMotherboardOk returns a tuple with the Motherboard field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMotherboard

`func (o *V10ClusterNodeHardware) SetMotherboard(v string)`

SetMotherboard sets Motherboard field to given value.

### HasMotherboard

`func (o *V10ClusterNodeHardware) HasMotherboard() bool`

HasMotherboard returns a boolean if a field has been set.

### GetNetInterfaces

`func (o *V10ClusterNodeHardware) GetNetInterfaces() string`

GetNetInterfaces returns the NetInterfaces field if non-nil, zero value otherwise.

### GetNetInterfacesOk

`func (o *V10ClusterNodeHardware) GetNetInterfacesOk() (*string, bool)`

GetNetInterfacesOk returns a tuple with the NetInterfaces field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetInterfaces

`func (o *V10ClusterNodeHardware) SetNetInterfaces(v string)`

SetNetInterfaces sets NetInterfaces field to given value.

### HasNetInterfaces

`func (o *V10ClusterNodeHardware) HasNetInterfaces() bool`

HasNetInterfaces returns a boolean if a field has been set.

### GetNodeSlotId

`func (o *V10ClusterNodeHardware) GetNodeSlotId() int32`

GetNodeSlotId returns the NodeSlotId field if non-nil, zero value otherwise.

### GetNodeSlotIdOk

`func (o *V10ClusterNodeHardware) GetNodeSlotIdOk() (*int32, bool)`

GetNodeSlotIdOk returns a tuple with the NodeSlotId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodeSlotId

`func (o *V10ClusterNodeHardware) SetNodeSlotId(v int32)`

SetNodeSlotId sets NodeSlotId field to given value.

### HasNodeSlotId

`func (o *V10ClusterNodeHardware) HasNodeSlotId() bool`

HasNodeSlotId returns a boolean if a field has been set.

### GetNvram

`func (o *V10ClusterNodeHardware) GetNvram() string`

GetNvram returns the Nvram field if non-nil, zero value otherwise.

### GetNvramOk

`func (o *V10ClusterNodeHardware) GetNvramOk() (*string, bool)`

GetNvramOk returns a tuple with the Nvram field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNvram

`func (o *V10ClusterNodeHardware) SetNvram(v string)`

SetNvram sets Nvram field to given value.

### HasNvram

`func (o *V10ClusterNodeHardware) HasNvram() bool`

HasNvram returns a boolean if a field has been set.

### GetPeerSerialNumber

`func (o *V10ClusterNodeHardware) GetPeerSerialNumber() string`

GetPeerSerialNumber returns the PeerSerialNumber field if non-nil, zero value otherwise.

### GetPeerSerialNumberOk

`func (o *V10ClusterNodeHardware) GetPeerSerialNumberOk() (*string, bool)`

GetPeerSerialNumberOk returns a tuple with the PeerSerialNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPeerSerialNumber

`func (o *V10ClusterNodeHardware) SetPeerSerialNumber(v string)`

SetPeerSerialNumber sets PeerSerialNumber field to given value.


### GetPerformanceCode

`func (o *V10ClusterNodeHardware) GetPerformanceCode() string`

GetPerformanceCode returns the PerformanceCode field if non-nil, zero value otherwise.

### GetPerformanceCodeOk

`func (o *V10ClusterNodeHardware) GetPerformanceCodeOk() (*string, bool)`

GetPerformanceCodeOk returns a tuple with the PerformanceCode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPerformanceCode

`func (o *V10ClusterNodeHardware) SetPerformanceCode(v string)`

SetPerformanceCode sets PerformanceCode field to given value.

### HasPerformanceCode

`func (o *V10ClusterNodeHardware) HasPerformanceCode() bool`

HasPerformanceCode returns a boolean if a field has been set.

### GetPowersupplies

`func (o *V10ClusterNodeHardware) GetPowersupplies() []string`

GetPowersupplies returns the Powersupplies field if non-nil, zero value otherwise.

### GetPowersuppliesOk

`func (o *V10ClusterNodeHardware) GetPowersuppliesOk() (*[]string, bool)`

GetPowersuppliesOk returns a tuple with the Powersupplies field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPowersupplies

`func (o *V10ClusterNodeHardware) SetPowersupplies(v []string)`

SetPowersupplies sets Powersupplies field to given value.

### HasPowersupplies

`func (o *V10ClusterNodeHardware) HasPowersupplies() bool`

HasPowersupplies returns a boolean if a field has been set.

### GetProcessor

`func (o *V10ClusterNodeHardware) GetProcessor() string`

GetProcessor returns the Processor field if non-nil, zero value otherwise.

### GetProcessorOk

`func (o *V10ClusterNodeHardware) GetProcessorOk() (*string, bool)`

GetProcessorOk returns a tuple with the Processor field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProcessor

`func (o *V10ClusterNodeHardware) SetProcessor(v string)`

SetProcessor sets Processor field to given value.

### HasProcessor

`func (o *V10ClusterNodeHardware) HasProcessor() bool`

HasProcessor returns a boolean if a field has been set.

### GetProduct

`func (o *V10ClusterNodeHardware) GetProduct() string`

GetProduct returns the Product field if non-nil, zero value otherwise.

### GetProductOk

`func (o *V10ClusterNodeHardware) GetProductOk() (*string, bool)`

GetProductOk returns a tuple with the Product field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProduct

`func (o *V10ClusterNodeHardware) SetProduct(v string)`

SetProduct sets Product field to given value.

### HasProduct

`func (o *V10ClusterNodeHardware) HasProduct() bool`

HasProduct returns a boolean if a field has been set.

### GetRam

`func (o *V10ClusterNodeHardware) GetRam() int32`

GetRam returns the Ram field if non-nil, zero value otherwise.

### GetRamOk

`func (o *V10ClusterNodeHardware) GetRamOk() (*int32, bool)`

GetRamOk returns a tuple with the Ram field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRam

`func (o *V10ClusterNodeHardware) SetRam(v int32)`

SetRam sets Ram field to given value.

### HasRam

`func (o *V10ClusterNodeHardware) HasRam() bool`

HasRam returns a boolean if a field has been set.

### GetSerialNumber

`func (o *V10ClusterNodeHardware) GetSerialNumber() string`

GetSerialNumber returns the SerialNumber field if non-nil, zero value otherwise.

### GetSerialNumberOk

`func (o *V10ClusterNodeHardware) GetSerialNumberOk() (*string, bool)`

GetSerialNumberOk returns a tuple with the SerialNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSerialNumber

`func (o *V10ClusterNodeHardware) SetSerialNumber(v string)`

SetSerialNumber sets SerialNumber field to given value.

### HasSerialNumber

`func (o *V10ClusterNodeHardware) HasSerialNumber() bool`

HasSerialNumber returns a boolean if a field has been set.

### GetSeries

`func (o *V10ClusterNodeHardware) GetSeries() string`

GetSeries returns the Series field if non-nil, zero value otherwise.

### GetSeriesOk

`func (o *V10ClusterNodeHardware) GetSeriesOk() (*string, bool)`

GetSeriesOk returns a tuple with the Series field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSeries

`func (o *V10ClusterNodeHardware) SetSeries(v string)`

SetSeries sets Series field to given value.

### HasSeries

`func (o *V10ClusterNodeHardware) HasSeries() bool`

HasSeries returns a boolean if a field has been set.

### GetSledDriveCount

`func (o *V10ClusterNodeHardware) GetSledDriveCount() int32`

GetSledDriveCount returns the SledDriveCount field if non-nil, zero value otherwise.

### GetSledDriveCountOk

`func (o *V10ClusterNodeHardware) GetSledDriveCountOk() (*int32, bool)`

GetSledDriveCountOk returns a tuple with the SledDriveCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSledDriveCount

`func (o *V10ClusterNodeHardware) SetSledDriveCount(v int32)`

SetSledDriveCount sets SledDriveCount field to given value.

### HasSledDriveCount

`func (o *V10ClusterNodeHardware) HasSledDriveCount() bool`

HasSledDriveCount returns a boolean if a field has been set.

### GetStorageClass

`func (o *V10ClusterNodeHardware) GetStorageClass() string`

GetStorageClass returns the StorageClass field if non-nil, zero value otherwise.

### GetStorageClassOk

`func (o *V10ClusterNodeHardware) GetStorageClassOk() (*string, bool)`

GetStorageClassOk returns a tuple with the StorageClass field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageClass

`func (o *V10ClusterNodeHardware) SetStorageClass(v string)`

SetStorageClass sets StorageClass field to given value.

### HasStorageClass

`func (o *V10ClusterNodeHardware) HasStorageClass() bool`

HasStorageClass returns a boolean if a field has been set.

### GetTier

`func (o *V10ClusterNodeHardware) GetTier() int32`

GetTier returns the Tier field if non-nil, zero value otherwise.

### GetTierOk

`func (o *V10ClusterNodeHardware) GetTierOk() (*int32, bool)`

GetTierOk returns a tuple with the Tier field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTier

`func (o *V10ClusterNodeHardware) SetTier(v int32)`

SetTier sets Tier field to given value.

### HasTier

`func (o *V10ClusterNodeHardware) HasTier() bool`

HasTier returns a boolean if a field has been set.

### GetTopLevelAssemblySerialNumber

`func (o *V10ClusterNodeHardware) GetTopLevelAssemblySerialNumber() string`

GetTopLevelAssemblySerialNumber returns the TopLevelAssemblySerialNumber field if non-nil, zero value otherwise.

### GetTopLevelAssemblySerialNumberOk

`func (o *V10ClusterNodeHardware) GetTopLevelAssemblySerialNumberOk() (*string, bool)`

GetTopLevelAssemblySerialNumberOk returns a tuple with the TopLevelAssemblySerialNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTopLevelAssemblySerialNumber

`func (o *V10ClusterNodeHardware) SetTopLevelAssemblySerialNumber(v string)`

SetTopLevelAssemblySerialNumber sets TopLevelAssemblySerialNumber field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


