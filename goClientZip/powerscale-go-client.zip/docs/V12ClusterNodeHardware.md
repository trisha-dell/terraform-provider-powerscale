# V12ClusterNodeHardware

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Chassis** | Pointer to **string** | Name of this node&#39;s chassis. | [optional] 
**ChassisCode** | Pointer to **string** | Chassis code of this node (1U, 2U, etc.). | [optional] 
**ChassisDepth** | Pointer to **string** | Chassis depth for this node if applicable (e.g., Normal, Deep, Unknown). If not supported or error: Unknown.  | [optional] 
**Class** | Pointer to **string** | Class of this node (storage, accelerator, etc.). | [optional] 
**ComputeType** | Pointer to **string** | Type of compute node if applicable (e.g., Low, Medium, High, Turbo, Ultra, Unknown). If not supported or error: Unknown.  | [optional] 
**ConfigurationId** | Pointer to **string** | Node configuration ID. | [optional] 
**Cpu** | Pointer to **string** | Manufacturer and model of this node&#39;s CPU. | [optional] 
**DiskController** | Pointer to **string** | Manufacturer and model of this node&#39;s disk controller. | [optional] 
**DiskExpander** | Pointer to **string** | Manufacturer and model of this node&#39;s disk expander. | [optional] 
**FamilyCode** | Pointer to **string** | Family code of this node (X, S, NL, etc.). | [optional] 
**GenerationCode** | Pointer to **string** | Generation code of this node. | [optional] 
**Hwgen** | Pointer to **string** | PowerScale hardware generation name. | [optional] 
**Infiniband** | Pointer to **string** | Infiniband card type. | [optional] 
**LcdVersion** | Pointer to **string** | Version of the LCD panel. | [optional] 
**Model** | Pointer to **string** | PowerScale node model identifier string (S200, X410, Infinity-H500, etc.). | [optional] 
**ModelCode** | Pointer to **string** | PowerScale node model code string (S200, X410, H500, etc.). | [optional] 
**Motherboard** | Pointer to **string** | Manufacturer and model of this node&#39;s motherboard. | [optional] 
**NetInterfaces** | Pointer to **string** | Description of all this node&#39;s network interfaces. | [optional] 
**NodeSlotId** | Pointer to **int32** | Position of node within chassis. -1 for error or not supported. | [optional] 
**Nvram** | Pointer to **string** | Manufacturer and model of this node&#39;s NVRAM board. | [optional] 
**PeerSerialNumber** | **string** | Serial number of this node&#39;s peer/buddy node.(Infinity Only) | 
**PerformanceCode** | Pointer to **string** | Performance code of this node, if applicable (2, 4, 5, etc.). | [optional] 
**Powersupplies** | Pointer to **[]string** | Description strings for each power supply on this node. | [optional] 
**Processor** | Pointer to **string** | Number of processors and cores on this node. | [optional] 
**Product** | Pointer to **string** | PowerScale product name. | [optional] 
**Ram** | Pointer to **int32** | Size of RAM in bytes. | [optional] 
**SerialNumber** | Pointer to **string** | Serial number of this node. | [optional] 
**Series** | Pointer to **string** | Series of this node (X, I, NL, etc.). | [optional] 
**SledDriveCount** | Pointer to **int32** | Size of drive sleds in node, if applicable. Expected values: 3, 4, 6. 0 if unable to determine sled size. -1 for error or not supported. If PSI_Get fails: -1. PSI_Get can fail if PSI not initialized, or key does not exist. | [optional] 
**StorageClass** | Pointer to **string** | Storage class of this node (storage or diskless). | [optional] 
**Tier** | Pointer to **int32** | Platform tier level of this node if applicable(positive for a defined tier, 0 for unknown or not supported, -1 for error). | [optional] 
**TopLevelAssemblySerialNumber** | **string** | Serial number of the top level assembly of this node.(Infinity Only) | 

## Methods

### NewV12ClusterNodeHardware

`func NewV12ClusterNodeHardware(peerSerialNumber string, topLevelAssemblySerialNumber string, ) *V12ClusterNodeHardware`

NewV12ClusterNodeHardware instantiates a new V12ClusterNodeHardware object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12ClusterNodeHardwareWithDefaults

`func NewV12ClusterNodeHardwareWithDefaults() *V12ClusterNodeHardware`

NewV12ClusterNodeHardwareWithDefaults instantiates a new V12ClusterNodeHardware object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetChassis

`func (o *V12ClusterNodeHardware) GetChassis() string`

GetChassis returns the Chassis field if non-nil, zero value otherwise.

### GetChassisOk

`func (o *V12ClusterNodeHardware) GetChassisOk() (*string, bool)`

GetChassisOk returns a tuple with the Chassis field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChassis

`func (o *V12ClusterNodeHardware) SetChassis(v string)`

SetChassis sets Chassis field to given value.

### HasChassis

`func (o *V12ClusterNodeHardware) HasChassis() bool`

HasChassis returns a boolean if a field has been set.

### GetChassisCode

`func (o *V12ClusterNodeHardware) GetChassisCode() string`

GetChassisCode returns the ChassisCode field if non-nil, zero value otherwise.

### GetChassisCodeOk

`func (o *V12ClusterNodeHardware) GetChassisCodeOk() (*string, bool)`

GetChassisCodeOk returns a tuple with the ChassisCode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChassisCode

`func (o *V12ClusterNodeHardware) SetChassisCode(v string)`

SetChassisCode sets ChassisCode field to given value.

### HasChassisCode

`func (o *V12ClusterNodeHardware) HasChassisCode() bool`

HasChassisCode returns a boolean if a field has been set.

### GetChassisDepth

`func (o *V12ClusterNodeHardware) GetChassisDepth() string`

GetChassisDepth returns the ChassisDepth field if non-nil, zero value otherwise.

### GetChassisDepthOk

`func (o *V12ClusterNodeHardware) GetChassisDepthOk() (*string, bool)`

GetChassisDepthOk returns a tuple with the ChassisDepth field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChassisDepth

`func (o *V12ClusterNodeHardware) SetChassisDepth(v string)`

SetChassisDepth sets ChassisDepth field to given value.

### HasChassisDepth

`func (o *V12ClusterNodeHardware) HasChassisDepth() bool`

HasChassisDepth returns a boolean if a field has been set.

### GetClass

`func (o *V12ClusterNodeHardware) GetClass() string`

GetClass returns the Class field if non-nil, zero value otherwise.

### GetClassOk

`func (o *V12ClusterNodeHardware) GetClassOk() (*string, bool)`

GetClassOk returns a tuple with the Class field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClass

`func (o *V12ClusterNodeHardware) SetClass(v string)`

SetClass sets Class field to given value.

### HasClass

`func (o *V12ClusterNodeHardware) HasClass() bool`

HasClass returns a boolean if a field has been set.

### GetComputeType

`func (o *V12ClusterNodeHardware) GetComputeType() string`

GetComputeType returns the ComputeType field if non-nil, zero value otherwise.

### GetComputeTypeOk

`func (o *V12ClusterNodeHardware) GetComputeTypeOk() (*string, bool)`

GetComputeTypeOk returns a tuple with the ComputeType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetComputeType

`func (o *V12ClusterNodeHardware) SetComputeType(v string)`

SetComputeType sets ComputeType field to given value.

### HasComputeType

`func (o *V12ClusterNodeHardware) HasComputeType() bool`

HasComputeType returns a boolean if a field has been set.

### GetConfigurationId

`func (o *V12ClusterNodeHardware) GetConfigurationId() string`

GetConfigurationId returns the ConfigurationId field if non-nil, zero value otherwise.

### GetConfigurationIdOk

`func (o *V12ClusterNodeHardware) GetConfigurationIdOk() (*string, bool)`

GetConfigurationIdOk returns a tuple with the ConfigurationId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetConfigurationId

`func (o *V12ClusterNodeHardware) SetConfigurationId(v string)`

SetConfigurationId sets ConfigurationId field to given value.

### HasConfigurationId

`func (o *V12ClusterNodeHardware) HasConfigurationId() bool`

HasConfigurationId returns a boolean if a field has been set.

### GetCpu

`func (o *V12ClusterNodeHardware) GetCpu() string`

GetCpu returns the Cpu field if non-nil, zero value otherwise.

### GetCpuOk

`func (o *V12ClusterNodeHardware) GetCpuOk() (*string, bool)`

GetCpuOk returns a tuple with the Cpu field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCpu

`func (o *V12ClusterNodeHardware) SetCpu(v string)`

SetCpu sets Cpu field to given value.

### HasCpu

`func (o *V12ClusterNodeHardware) HasCpu() bool`

HasCpu returns a boolean if a field has been set.

### GetDiskController

`func (o *V12ClusterNodeHardware) GetDiskController() string`

GetDiskController returns the DiskController field if non-nil, zero value otherwise.

### GetDiskControllerOk

`func (o *V12ClusterNodeHardware) GetDiskControllerOk() (*string, bool)`

GetDiskControllerOk returns a tuple with the DiskController field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDiskController

`func (o *V12ClusterNodeHardware) SetDiskController(v string)`

SetDiskController sets DiskController field to given value.

### HasDiskController

`func (o *V12ClusterNodeHardware) HasDiskController() bool`

HasDiskController returns a boolean if a field has been set.

### GetDiskExpander

`func (o *V12ClusterNodeHardware) GetDiskExpander() string`

GetDiskExpander returns the DiskExpander field if non-nil, zero value otherwise.

### GetDiskExpanderOk

`func (o *V12ClusterNodeHardware) GetDiskExpanderOk() (*string, bool)`

GetDiskExpanderOk returns a tuple with the DiskExpander field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDiskExpander

`func (o *V12ClusterNodeHardware) SetDiskExpander(v string)`

SetDiskExpander sets DiskExpander field to given value.

### HasDiskExpander

`func (o *V12ClusterNodeHardware) HasDiskExpander() bool`

HasDiskExpander returns a boolean if a field has been set.

### GetFamilyCode

`func (o *V12ClusterNodeHardware) GetFamilyCode() string`

GetFamilyCode returns the FamilyCode field if non-nil, zero value otherwise.

### GetFamilyCodeOk

`func (o *V12ClusterNodeHardware) GetFamilyCodeOk() (*string, bool)`

GetFamilyCodeOk returns a tuple with the FamilyCode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFamilyCode

`func (o *V12ClusterNodeHardware) SetFamilyCode(v string)`

SetFamilyCode sets FamilyCode field to given value.

### HasFamilyCode

`func (o *V12ClusterNodeHardware) HasFamilyCode() bool`

HasFamilyCode returns a boolean if a field has been set.

### GetGenerationCode

`func (o *V12ClusterNodeHardware) GetGenerationCode() string`

GetGenerationCode returns the GenerationCode field if non-nil, zero value otherwise.

### GetGenerationCodeOk

`func (o *V12ClusterNodeHardware) GetGenerationCodeOk() (*string, bool)`

GetGenerationCodeOk returns a tuple with the GenerationCode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGenerationCode

`func (o *V12ClusterNodeHardware) SetGenerationCode(v string)`

SetGenerationCode sets GenerationCode field to given value.

### HasGenerationCode

`func (o *V12ClusterNodeHardware) HasGenerationCode() bool`

HasGenerationCode returns a boolean if a field has been set.

### GetHwgen

`func (o *V12ClusterNodeHardware) GetHwgen() string`

GetHwgen returns the Hwgen field if non-nil, zero value otherwise.

### GetHwgenOk

`func (o *V12ClusterNodeHardware) GetHwgenOk() (*string, bool)`

GetHwgenOk returns a tuple with the Hwgen field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHwgen

`func (o *V12ClusterNodeHardware) SetHwgen(v string)`

SetHwgen sets Hwgen field to given value.

### HasHwgen

`func (o *V12ClusterNodeHardware) HasHwgen() bool`

HasHwgen returns a boolean if a field has been set.

### GetInfiniband

`func (o *V12ClusterNodeHardware) GetInfiniband() string`

GetInfiniband returns the Infiniband field if non-nil, zero value otherwise.

### GetInfinibandOk

`func (o *V12ClusterNodeHardware) GetInfinibandOk() (*string, bool)`

GetInfinibandOk returns a tuple with the Infiniband field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInfiniband

`func (o *V12ClusterNodeHardware) SetInfiniband(v string)`

SetInfiniband sets Infiniband field to given value.

### HasInfiniband

`func (o *V12ClusterNodeHardware) HasInfiniband() bool`

HasInfiniband returns a boolean if a field has been set.

### GetLcdVersion

`func (o *V12ClusterNodeHardware) GetLcdVersion() string`

GetLcdVersion returns the LcdVersion field if non-nil, zero value otherwise.

### GetLcdVersionOk

`func (o *V12ClusterNodeHardware) GetLcdVersionOk() (*string, bool)`

GetLcdVersionOk returns a tuple with the LcdVersion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLcdVersion

`func (o *V12ClusterNodeHardware) SetLcdVersion(v string)`

SetLcdVersion sets LcdVersion field to given value.

### HasLcdVersion

`func (o *V12ClusterNodeHardware) HasLcdVersion() bool`

HasLcdVersion returns a boolean if a field has been set.

### GetModel

`func (o *V12ClusterNodeHardware) GetModel() string`

GetModel returns the Model field if non-nil, zero value otherwise.

### GetModelOk

`func (o *V12ClusterNodeHardware) GetModelOk() (*string, bool)`

GetModelOk returns a tuple with the Model field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetModel

`func (o *V12ClusterNodeHardware) SetModel(v string)`

SetModel sets Model field to given value.

### HasModel

`func (o *V12ClusterNodeHardware) HasModel() bool`

HasModel returns a boolean if a field has been set.

### GetModelCode

`func (o *V12ClusterNodeHardware) GetModelCode() string`

GetModelCode returns the ModelCode field if non-nil, zero value otherwise.

### GetModelCodeOk

`func (o *V12ClusterNodeHardware) GetModelCodeOk() (*string, bool)`

GetModelCodeOk returns a tuple with the ModelCode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetModelCode

`func (o *V12ClusterNodeHardware) SetModelCode(v string)`

SetModelCode sets ModelCode field to given value.

### HasModelCode

`func (o *V12ClusterNodeHardware) HasModelCode() bool`

HasModelCode returns a boolean if a field has been set.

### GetMotherboard

`func (o *V12ClusterNodeHardware) GetMotherboard() string`

GetMotherboard returns the Motherboard field if non-nil, zero value otherwise.

### GetMotherboardOk

`func (o *V12ClusterNodeHardware) GetMotherboardOk() (*string, bool)`

GetMotherboardOk returns a tuple with the Motherboard field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMotherboard

`func (o *V12ClusterNodeHardware) SetMotherboard(v string)`

SetMotherboard sets Motherboard field to given value.

### HasMotherboard

`func (o *V12ClusterNodeHardware) HasMotherboard() bool`

HasMotherboard returns a boolean if a field has been set.

### GetNetInterfaces

`func (o *V12ClusterNodeHardware) GetNetInterfaces() string`

GetNetInterfaces returns the NetInterfaces field if non-nil, zero value otherwise.

### GetNetInterfacesOk

`func (o *V12ClusterNodeHardware) GetNetInterfacesOk() (*string, bool)`

GetNetInterfacesOk returns a tuple with the NetInterfaces field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetInterfaces

`func (o *V12ClusterNodeHardware) SetNetInterfaces(v string)`

SetNetInterfaces sets NetInterfaces field to given value.

### HasNetInterfaces

`func (o *V12ClusterNodeHardware) HasNetInterfaces() bool`

HasNetInterfaces returns a boolean if a field has been set.

### GetNodeSlotId

`func (o *V12ClusterNodeHardware) GetNodeSlotId() int32`

GetNodeSlotId returns the NodeSlotId field if non-nil, zero value otherwise.

### GetNodeSlotIdOk

`func (o *V12ClusterNodeHardware) GetNodeSlotIdOk() (*int32, bool)`

GetNodeSlotIdOk returns a tuple with the NodeSlotId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodeSlotId

`func (o *V12ClusterNodeHardware) SetNodeSlotId(v int32)`

SetNodeSlotId sets NodeSlotId field to given value.

### HasNodeSlotId

`func (o *V12ClusterNodeHardware) HasNodeSlotId() bool`

HasNodeSlotId returns a boolean if a field has been set.

### GetNvram

`func (o *V12ClusterNodeHardware) GetNvram() string`

GetNvram returns the Nvram field if non-nil, zero value otherwise.

### GetNvramOk

`func (o *V12ClusterNodeHardware) GetNvramOk() (*string, bool)`

GetNvramOk returns a tuple with the Nvram field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNvram

`func (o *V12ClusterNodeHardware) SetNvram(v string)`

SetNvram sets Nvram field to given value.

### HasNvram

`func (o *V12ClusterNodeHardware) HasNvram() bool`

HasNvram returns a boolean if a field has been set.

### GetPeerSerialNumber

`func (o *V12ClusterNodeHardware) GetPeerSerialNumber() string`

GetPeerSerialNumber returns the PeerSerialNumber field if non-nil, zero value otherwise.

### GetPeerSerialNumberOk

`func (o *V12ClusterNodeHardware) GetPeerSerialNumberOk() (*string, bool)`

GetPeerSerialNumberOk returns a tuple with the PeerSerialNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPeerSerialNumber

`func (o *V12ClusterNodeHardware) SetPeerSerialNumber(v string)`

SetPeerSerialNumber sets PeerSerialNumber field to given value.


### GetPerformanceCode

`func (o *V12ClusterNodeHardware) GetPerformanceCode() string`

GetPerformanceCode returns the PerformanceCode field if non-nil, zero value otherwise.

### GetPerformanceCodeOk

`func (o *V12ClusterNodeHardware) GetPerformanceCodeOk() (*string, bool)`

GetPerformanceCodeOk returns a tuple with the PerformanceCode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPerformanceCode

`func (o *V12ClusterNodeHardware) SetPerformanceCode(v string)`

SetPerformanceCode sets PerformanceCode field to given value.

### HasPerformanceCode

`func (o *V12ClusterNodeHardware) HasPerformanceCode() bool`

HasPerformanceCode returns a boolean if a field has been set.

### GetPowersupplies

`func (o *V12ClusterNodeHardware) GetPowersupplies() []string`

GetPowersupplies returns the Powersupplies field if non-nil, zero value otherwise.

### GetPowersuppliesOk

`func (o *V12ClusterNodeHardware) GetPowersuppliesOk() (*[]string, bool)`

GetPowersuppliesOk returns a tuple with the Powersupplies field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPowersupplies

`func (o *V12ClusterNodeHardware) SetPowersupplies(v []string)`

SetPowersupplies sets Powersupplies field to given value.

### HasPowersupplies

`func (o *V12ClusterNodeHardware) HasPowersupplies() bool`

HasPowersupplies returns a boolean if a field has been set.

### GetProcessor

`func (o *V12ClusterNodeHardware) GetProcessor() string`

GetProcessor returns the Processor field if non-nil, zero value otherwise.

### GetProcessorOk

`func (o *V12ClusterNodeHardware) GetProcessorOk() (*string, bool)`

GetProcessorOk returns a tuple with the Processor field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProcessor

`func (o *V12ClusterNodeHardware) SetProcessor(v string)`

SetProcessor sets Processor field to given value.

### HasProcessor

`func (o *V12ClusterNodeHardware) HasProcessor() bool`

HasProcessor returns a boolean if a field has been set.

### GetProduct

`func (o *V12ClusterNodeHardware) GetProduct() string`

GetProduct returns the Product field if non-nil, zero value otherwise.

### GetProductOk

`func (o *V12ClusterNodeHardware) GetProductOk() (*string, bool)`

GetProductOk returns a tuple with the Product field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProduct

`func (o *V12ClusterNodeHardware) SetProduct(v string)`

SetProduct sets Product field to given value.

### HasProduct

`func (o *V12ClusterNodeHardware) HasProduct() bool`

HasProduct returns a boolean if a field has been set.

### GetRam

`func (o *V12ClusterNodeHardware) GetRam() int32`

GetRam returns the Ram field if non-nil, zero value otherwise.

### GetRamOk

`func (o *V12ClusterNodeHardware) GetRamOk() (*int32, bool)`

GetRamOk returns a tuple with the Ram field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRam

`func (o *V12ClusterNodeHardware) SetRam(v int32)`

SetRam sets Ram field to given value.

### HasRam

`func (o *V12ClusterNodeHardware) HasRam() bool`

HasRam returns a boolean if a field has been set.

### GetSerialNumber

`func (o *V12ClusterNodeHardware) GetSerialNumber() string`

GetSerialNumber returns the SerialNumber field if non-nil, zero value otherwise.

### GetSerialNumberOk

`func (o *V12ClusterNodeHardware) GetSerialNumberOk() (*string, bool)`

GetSerialNumberOk returns a tuple with the SerialNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSerialNumber

`func (o *V12ClusterNodeHardware) SetSerialNumber(v string)`

SetSerialNumber sets SerialNumber field to given value.

### HasSerialNumber

`func (o *V12ClusterNodeHardware) HasSerialNumber() bool`

HasSerialNumber returns a boolean if a field has been set.

### GetSeries

`func (o *V12ClusterNodeHardware) GetSeries() string`

GetSeries returns the Series field if non-nil, zero value otherwise.

### GetSeriesOk

`func (o *V12ClusterNodeHardware) GetSeriesOk() (*string, bool)`

GetSeriesOk returns a tuple with the Series field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSeries

`func (o *V12ClusterNodeHardware) SetSeries(v string)`

SetSeries sets Series field to given value.

### HasSeries

`func (o *V12ClusterNodeHardware) HasSeries() bool`

HasSeries returns a boolean if a field has been set.

### GetSledDriveCount

`func (o *V12ClusterNodeHardware) GetSledDriveCount() int32`

GetSledDriveCount returns the SledDriveCount field if non-nil, zero value otherwise.

### GetSledDriveCountOk

`func (o *V12ClusterNodeHardware) GetSledDriveCountOk() (*int32, bool)`

GetSledDriveCountOk returns a tuple with the SledDriveCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSledDriveCount

`func (o *V12ClusterNodeHardware) SetSledDriveCount(v int32)`

SetSledDriveCount sets SledDriveCount field to given value.

### HasSledDriveCount

`func (o *V12ClusterNodeHardware) HasSledDriveCount() bool`

HasSledDriveCount returns a boolean if a field has been set.

### GetStorageClass

`func (o *V12ClusterNodeHardware) GetStorageClass() string`

GetStorageClass returns the StorageClass field if non-nil, zero value otherwise.

### GetStorageClassOk

`func (o *V12ClusterNodeHardware) GetStorageClassOk() (*string, bool)`

GetStorageClassOk returns a tuple with the StorageClass field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageClass

`func (o *V12ClusterNodeHardware) SetStorageClass(v string)`

SetStorageClass sets StorageClass field to given value.

### HasStorageClass

`func (o *V12ClusterNodeHardware) HasStorageClass() bool`

HasStorageClass returns a boolean if a field has been set.

### GetTier

`func (o *V12ClusterNodeHardware) GetTier() int32`

GetTier returns the Tier field if non-nil, zero value otherwise.

### GetTierOk

`func (o *V12ClusterNodeHardware) GetTierOk() (*int32, bool)`

GetTierOk returns a tuple with the Tier field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTier

`func (o *V12ClusterNodeHardware) SetTier(v int32)`

SetTier sets Tier field to given value.

### HasTier

`func (o *V12ClusterNodeHardware) HasTier() bool`

HasTier returns a boolean if a field has been set.

### GetTopLevelAssemblySerialNumber

`func (o *V12ClusterNodeHardware) GetTopLevelAssemblySerialNumber() string`

GetTopLevelAssemblySerialNumber returns the TopLevelAssemblySerialNumber field if non-nil, zero value otherwise.

### GetTopLevelAssemblySerialNumberOk

`func (o *V12ClusterNodeHardware) GetTopLevelAssemblySerialNumberOk() (*string, bool)`

GetTopLevelAssemblySerialNumberOk returns a tuple with the TopLevelAssemblySerialNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTopLevelAssemblySerialNumber

`func (o *V12ClusterNodeHardware) SetTopLevelAssemblySerialNumber(v string)`

SetTopLevelAssemblySerialNumber sets TopLevelAssemblySerialNumber field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


