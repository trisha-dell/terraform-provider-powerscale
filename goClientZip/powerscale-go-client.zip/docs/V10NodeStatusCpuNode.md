# V10NodeStatusCpuNode

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Error** | Pointer to **string** | Error message, if the HTTP status returned from this node was not 200. | [optional] 
**Id** | Pointer to **int32** | Node ID (Device Number) of a node. | [optional] 
**Lnn** | Pointer to **int32** | Logical Node Number (LNN) of a node. | [optional] 
**Model** | Pointer to **string** | Manufacturer model description of this CPU. | [optional] 
**Overtemp** | Pointer to **string** | CPU overtemp state. | [optional] 
**Proc** | Pointer to **string** | Type of processor and core of this CPU. | [optional] 
**SpeedLimit** | Pointer to **string** | CPU throttling (expressed as a percentage). | [optional] 
**Status** | Pointer to **int32** | Status of the HTTP response from this node if not 200.  If 200, this field does not appear. | [optional] 

## Methods

### NewV10NodeStatusCpuNode

`func NewV10NodeStatusCpuNode() *V10NodeStatusCpuNode`

NewV10NodeStatusCpuNode instantiates a new V10NodeStatusCpuNode object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10NodeStatusCpuNodeWithDefaults

`func NewV10NodeStatusCpuNodeWithDefaults() *V10NodeStatusCpuNode`

NewV10NodeStatusCpuNodeWithDefaults instantiates a new V10NodeStatusCpuNode object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetError

`func (o *V10NodeStatusCpuNode) GetError() string`

GetError returns the Error field if non-nil, zero value otherwise.

### GetErrorOk

`func (o *V10NodeStatusCpuNode) GetErrorOk() (*string, bool)`

GetErrorOk returns a tuple with the Error field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetError

`func (o *V10NodeStatusCpuNode) SetError(v string)`

SetError sets Error field to given value.

### HasError

`func (o *V10NodeStatusCpuNode) HasError() bool`

HasError returns a boolean if a field has been set.

### GetId

`func (o *V10NodeStatusCpuNode) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V10NodeStatusCpuNode) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V10NodeStatusCpuNode) SetId(v int32)`

SetId sets Id field to given value.

### HasId

`func (o *V10NodeStatusCpuNode) HasId() bool`

HasId returns a boolean if a field has been set.

### GetLnn

`func (o *V10NodeStatusCpuNode) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V10NodeStatusCpuNode) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V10NodeStatusCpuNode) SetLnn(v int32)`

SetLnn sets Lnn field to given value.

### HasLnn

`func (o *V10NodeStatusCpuNode) HasLnn() bool`

HasLnn returns a boolean if a field has been set.

### GetModel

`func (o *V10NodeStatusCpuNode) GetModel() string`

GetModel returns the Model field if non-nil, zero value otherwise.

### GetModelOk

`func (o *V10NodeStatusCpuNode) GetModelOk() (*string, bool)`

GetModelOk returns a tuple with the Model field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetModel

`func (o *V10NodeStatusCpuNode) SetModel(v string)`

SetModel sets Model field to given value.

### HasModel

`func (o *V10NodeStatusCpuNode) HasModel() bool`

HasModel returns a boolean if a field has been set.

### GetOvertemp

`func (o *V10NodeStatusCpuNode) GetOvertemp() string`

GetOvertemp returns the Overtemp field if non-nil, zero value otherwise.

### GetOvertempOk

`func (o *V10NodeStatusCpuNode) GetOvertempOk() (*string, bool)`

GetOvertempOk returns a tuple with the Overtemp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOvertemp

`func (o *V10NodeStatusCpuNode) SetOvertemp(v string)`

SetOvertemp sets Overtemp field to given value.

### HasOvertemp

`func (o *V10NodeStatusCpuNode) HasOvertemp() bool`

HasOvertemp returns a boolean if a field has been set.

### GetProc

`func (o *V10NodeStatusCpuNode) GetProc() string`

GetProc returns the Proc field if non-nil, zero value otherwise.

### GetProcOk

`func (o *V10NodeStatusCpuNode) GetProcOk() (*string, bool)`

GetProcOk returns a tuple with the Proc field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProc

`func (o *V10NodeStatusCpuNode) SetProc(v string)`

SetProc sets Proc field to given value.

### HasProc

`func (o *V10NodeStatusCpuNode) HasProc() bool`

HasProc returns a boolean if a field has been set.

### GetSpeedLimit

`func (o *V10NodeStatusCpuNode) GetSpeedLimit() string`

GetSpeedLimit returns the SpeedLimit field if non-nil, zero value otherwise.

### GetSpeedLimitOk

`func (o *V10NodeStatusCpuNode) GetSpeedLimitOk() (*string, bool)`

GetSpeedLimitOk returns a tuple with the SpeedLimit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSpeedLimit

`func (o *V10NodeStatusCpuNode) SetSpeedLimit(v string)`

SetSpeedLimit sets SpeedLimit field to given value.

### HasSpeedLimit

`func (o *V10NodeStatusCpuNode) HasSpeedLimit() bool`

HasSpeedLimit returns a boolean if a field has been set.

### GetStatus

`func (o *V10NodeStatusCpuNode) GetStatus() int32`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V10NodeStatusCpuNode) GetStatusOk() (*int32, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V10NodeStatusCpuNode) SetStatus(v int32)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V10NodeStatusCpuNode) HasStatus() bool`

HasStatus returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


