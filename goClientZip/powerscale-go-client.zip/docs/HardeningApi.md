# \HardeningApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateHardeningv16HardeningApplyItem**](HardeningApi.md#CreateHardeningv16HardeningApplyItem) | **Post** /platform/16/hardening/apply | 
[**CreateHardeningv16HardeningDisableItem**](HardeningApi.md#CreateHardeningv16HardeningDisableItem) | **Post** /platform/16/hardening/disable | 
[**CreateHardeningv16HardeningReport**](HardeningApi.md#CreateHardeningv16HardeningReport) | **Post** /platform/16/hardening/reports | 
[**GetHardeningv16HardeningList**](HardeningApi.md#GetHardeningv16HardeningList) | **Get** /platform/16/hardening/list | 
[**GetHardeningv16HardeningState**](HardeningApi.md#GetHardeningv16HardeningState) | **Get** /platform/16/hardening/state | 
[**ListHardeningv16HardeningReports**](HardeningApi.md#ListHardeningv16HardeningReports) | **Get** /platform/16/hardening/reports | 



## CreateHardeningv16HardeningApplyItem

> Createv16HardeningApplyItemResponse CreateHardeningv16HardeningApplyItem(ctx).V16HardeningApplyItem(v16HardeningApplyItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16HardeningApplyItem := *openapiclient.NewV16HardeningApplyItem() // V16HardeningApplyItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HardeningApi.CreateHardeningv16HardeningApplyItem(context.Background()).V16HardeningApplyItem(v16HardeningApplyItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HardeningApi.CreateHardeningv16HardeningApplyItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateHardeningv16HardeningApplyItem`: Createv16HardeningApplyItemResponse
    fmt.Fprintf(os.Stdout, "Response from `HardeningApi.CreateHardeningv16HardeningApplyItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateHardeningv16HardeningApplyItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16HardeningApplyItem** | [**V16HardeningApplyItem**](V16HardeningApplyItem.md) |  | 

### Return type

[**Createv16HardeningApplyItemResponse**](Createv16HardeningApplyItemResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateHardeningv16HardeningDisableItem

> Createv16HardeningApplyItemResponse CreateHardeningv16HardeningDisableItem(ctx).V16HardeningDisableItem(v16HardeningDisableItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16HardeningDisableItem := *openapiclient.NewV16HardeningApplyItem() // V16HardeningApplyItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HardeningApi.CreateHardeningv16HardeningDisableItem(context.Background()).V16HardeningDisableItem(v16HardeningDisableItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HardeningApi.CreateHardeningv16HardeningDisableItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateHardeningv16HardeningDisableItem`: Createv16HardeningApplyItemResponse
    fmt.Fprintf(os.Stdout, "Response from `HardeningApi.CreateHardeningv16HardeningDisableItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateHardeningv16HardeningDisableItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16HardeningDisableItem** | [**V16HardeningApplyItem**](V16HardeningApplyItem.md) |  | 

### Return type

[**Createv16HardeningApplyItemResponse**](Createv16HardeningApplyItemResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateHardeningv16HardeningReport

> Createv16HardeningApplyItemResponse CreateHardeningv16HardeningReport(ctx).V16HardeningReport(v16HardeningReport).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16HardeningReport := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HardeningApi.CreateHardeningv16HardeningReport(context.Background()).V16HardeningReport(v16HardeningReport).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HardeningApi.CreateHardeningv16HardeningReport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateHardeningv16HardeningReport`: Createv16HardeningApplyItemResponse
    fmt.Fprintf(os.Stdout, "Response from `HardeningApi.CreateHardeningv16HardeningReport`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateHardeningv16HardeningReportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16HardeningReport** | **map[string]interface{}** |  | 

### Return type

[**Createv16HardeningApplyItemResponse**](Createv16HardeningApplyItemResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetHardeningv16HardeningList

> V16HardeningList GetHardeningv16HardeningList(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HardeningApi.GetHardeningv16HardeningList(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HardeningApi.GetHardeningv16HardeningList``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetHardeningv16HardeningList`: V16HardeningList
    fmt.Fprintf(os.Stdout, "Response from `HardeningApi.GetHardeningv16HardeningList`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetHardeningv16HardeningListRequest struct via the builder pattern


### Return type

[**V16HardeningList**](V16HardeningList.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetHardeningv16HardeningState

> V16HardeningState GetHardeningv16HardeningState(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HardeningApi.GetHardeningv16HardeningState(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HardeningApi.GetHardeningv16HardeningState``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetHardeningv16HardeningState`: V16HardeningState
    fmt.Fprintf(os.Stdout, "Response from `HardeningApi.GetHardeningv16HardeningState`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetHardeningv16HardeningStateRequest struct via the builder pattern


### Return type

[**V16HardeningState**](V16HardeningState.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListHardeningv16HardeningReports

> V16HardeningReports ListHardeningv16HardeningReports(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HardeningApi.ListHardeningv16HardeningReports(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HardeningApi.ListHardeningv16HardeningReports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListHardeningv16HardeningReports`: V16HardeningReports
    fmt.Fprintf(os.Stdout, "Response from `HardeningApi.ListHardeningv16HardeningReports`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListHardeningv16HardeningReportsRequest struct via the builder pattern


### Return type

[**V16HardeningReports**](V16HardeningReports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

