# \SyncApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateSyncv14SyncPolicy**](SyncApi.md#CreateSyncv14SyncPolicy) | **Post** /platform/14/sync/policies | 
[**CreateSyncv15SyncJob**](SyncApi.md#CreateSyncv15SyncJob) | **Post** /platform/15/sync/jobs | 
[**CreateSyncv1SyncJob**](SyncApi.md#CreateSyncv1SyncJob) | **Post** /platform/1/sync/jobs | 
[**CreateSyncv1SyncPolicy**](SyncApi.md#CreateSyncv1SyncPolicy) | **Post** /platform/1/sync/policies | 
[**CreateSyncv1SyncReportsRotateItem**](SyncApi.md#CreateSyncv1SyncReportsRotateItem) | **Post** /platform/1/sync/reports-rotate | 
[**CreateSyncv1SyncRule**](SyncApi.md#CreateSyncv1SyncRule) | **Post** /platform/1/sync/rules | 
[**CreateSyncv3SyncJob**](SyncApi.md#CreateSyncv3SyncJob) | **Post** /platform/3/sync/jobs | 
[**CreateSyncv3SyncPolicy**](SyncApi.md#CreateSyncv3SyncPolicy) | **Post** /platform/3/sync/policies | 
[**CreateSyncv3SyncRule**](SyncApi.md#CreateSyncv3SyncRule) | **Post** /platform/3/sync/rules | 
[**CreateSyncv7CertificatesPeerItem**](SyncApi.md#CreateSyncv7CertificatesPeerItem) | **Post** /platform/7/sync/certificates/peer | 
[**CreateSyncv7CertificatesServerItem**](SyncApi.md#CreateSyncv7CertificatesServerItem) | **Post** /platform/7/sync/certificates/server | 
[**CreateSyncv7ServicePolicy**](SyncApi.md#CreateSyncv7ServicePolicy) | **Post** /platform/7/sync/service/policies | 
[**CreateSyncv7SyncJob**](SyncApi.md#CreateSyncv7SyncJob) | **Post** /platform/7/sync/jobs | 
[**CreateSyncv7SyncPolicy**](SyncApi.md#CreateSyncv7SyncPolicy) | **Post** /platform/7/sync/policies | 
[**DeleteSyncv14SyncPolicies**](SyncApi.md#DeleteSyncv14SyncPolicies) | **Delete** /platform/14/sync/policies | 
[**DeleteSyncv14SyncPolicy**](SyncApi.md#DeleteSyncv14SyncPolicy) | **Delete** /platform/14/sync/policies/{v14SyncPolicyId} | 
[**DeleteSyncv15SyncJobs**](SyncApi.md#DeleteSyncv15SyncJobs) | **Delete** /platform/15/sync/jobs | 
[**DeleteSyncv1SyncJobs**](SyncApi.md#DeleteSyncv1SyncJobs) | **Delete** /platform/1/sync/jobs | 
[**DeleteSyncv1SyncPolicies**](SyncApi.md#DeleteSyncv1SyncPolicies) | **Delete** /platform/1/sync/policies | 
[**DeleteSyncv1SyncPolicy**](SyncApi.md#DeleteSyncv1SyncPolicy) | **Delete** /platform/1/sync/policies/{v1SyncPolicyId} | 
[**DeleteSyncv1SyncRule**](SyncApi.md#DeleteSyncv1SyncRule) | **Delete** /platform/1/sync/rules/{v1SyncRuleId} | 
[**DeleteSyncv1SyncRules**](SyncApi.md#DeleteSyncv1SyncRules) | **Delete** /platform/1/sync/rules | 
[**DeleteSyncv1TargetPolicy**](SyncApi.md#DeleteSyncv1TargetPolicy) | **Delete** /platform/1/sync/target/policies/{v1TargetPolicyId} | 
[**DeleteSyncv3SyncJobs**](SyncApi.md#DeleteSyncv3SyncJobs) | **Delete** /platform/3/sync/jobs | 
[**DeleteSyncv3SyncPolicies**](SyncApi.md#DeleteSyncv3SyncPolicies) | **Delete** /platform/3/sync/policies | 
[**DeleteSyncv3SyncPolicy**](SyncApi.md#DeleteSyncv3SyncPolicy) | **Delete** /platform/3/sync/policies/{v3SyncPolicyId} | 
[**DeleteSyncv3SyncRule**](SyncApi.md#DeleteSyncv3SyncRule) | **Delete** /platform/3/sync/rules/{v3SyncRuleId} | 
[**DeleteSyncv3SyncRules**](SyncApi.md#DeleteSyncv3SyncRules) | **Delete** /platform/3/sync/rules | 
[**DeleteSyncv7CertificatesPeerById**](SyncApi.md#DeleteSyncv7CertificatesPeerById) | **Delete** /platform/7/sync/certificates/peer/{v7CertificatesPeerId} | 
[**DeleteSyncv7CertificatesServerById**](SyncApi.md#DeleteSyncv7CertificatesServerById) | **Delete** /platform/7/sync/certificates/server/{v7CertificatesServerId} | 
[**DeleteSyncv7ServicePolicies**](SyncApi.md#DeleteSyncv7ServicePolicies) | **Delete** /platform/7/sync/service/policies | 
[**DeleteSyncv7ServicePolicy**](SyncApi.md#DeleteSyncv7ServicePolicy) | **Delete** /platform/7/sync/service/policies/{v7ServicePolicyId} | 
[**DeleteSyncv7ServiceTargetPolicy**](SyncApi.md#DeleteSyncv7ServiceTargetPolicy) | **Delete** /platform/7/sync/service/target/policies/{v7ServiceTargetPolicyId} | 
[**DeleteSyncv7SyncJobs**](SyncApi.md#DeleteSyncv7SyncJobs) | **Delete** /platform/7/sync/jobs | 
[**DeleteSyncv7SyncPolicies**](SyncApi.md#DeleteSyncv7SyncPolicies) | **Delete** /platform/7/sync/policies | 
[**DeleteSyncv7SyncPolicy**](SyncApi.md#DeleteSyncv7SyncPolicy) | **Delete** /platform/7/sync/policies/{v7SyncPolicyId} | 
[**GetSyncv14SyncPolicy**](SyncApi.md#GetSyncv14SyncPolicy) | **Get** /platform/14/sync/policies/{v14SyncPolicyId} | 
[**GetSyncv14SyncSettings**](SyncApi.md#GetSyncv14SyncSettings) | **Get** /platform/14/sync/settings | 
[**GetSyncv15ReportsRidSubreport**](SyncApi.md#GetSyncv15ReportsRidSubreport) | **Get** /platform/15/sync/reports/{Rid}/subreports/{v15ReportsRidSubreportId} | 
[**GetSyncv15SyncJob**](SyncApi.md#GetSyncv15SyncJob) | **Get** /platform/15/sync/jobs/{v15SyncJobId} | 
[**GetSyncv15SyncReport**](SyncApi.md#GetSyncv15SyncReport) | **Get** /platform/15/sync/reports/{v15SyncReportId} | 
[**GetSyncv15SyncReports**](SyncApi.md#GetSyncv15SyncReports) | **Get** /platform/15/sync/reports | 
[**GetSyncv15TargetReport**](SyncApi.md#GetSyncv15TargetReport) | **Get** /platform/15/sync/target/reports/{v15TargetReportId} | 
[**GetSyncv15TargetReports**](SyncApi.md#GetSyncv15TargetReports) | **Get** /platform/15/sync/target/reports | 
[**GetSyncv15TargetReportsRidSubreport**](SyncApi.md#GetSyncv15TargetReportsRidSubreport) | **Get** /platform/15/sync/target/reports/{Rid}/subreports/{v15TargetReportsRidSubreportId} | 
[**GetSyncv16SyncSettings**](SyncApi.md#GetSyncv16SyncSettings) | **Get** /platform/16/sync/settings | 
[**GetSyncv1HistoryFile**](SyncApi.md#GetSyncv1HistoryFile) | **Get** /platform/1/sync/history/file | 
[**GetSyncv1HistoryNetwork**](SyncApi.md#GetSyncv1HistoryNetwork) | **Get** /platform/1/sync/history/network | 
[**GetSyncv1ReportsRidSubreport**](SyncApi.md#GetSyncv1ReportsRidSubreport) | **Get** /platform/1/sync/reports/{Rid}/subreports/{v1ReportsRidSubreportId} | 
[**GetSyncv1SyncJob**](SyncApi.md#GetSyncv1SyncJob) | **Get** /platform/1/sync/jobs/{v1SyncJobId} | 
[**GetSyncv1SyncLicense**](SyncApi.md#GetSyncv1SyncLicense) | **Get** /platform/1/sync/license | 
[**GetSyncv1SyncPolicy**](SyncApi.md#GetSyncv1SyncPolicy) | **Get** /platform/1/sync/policies/{v1SyncPolicyId} | 
[**GetSyncv1SyncReport**](SyncApi.md#GetSyncv1SyncReport) | **Get** /platform/1/sync/reports/{v1SyncReportId} | 
[**GetSyncv1SyncReports**](SyncApi.md#GetSyncv1SyncReports) | **Get** /platform/1/sync/reports | 
[**GetSyncv1SyncRule**](SyncApi.md#GetSyncv1SyncRule) | **Get** /platform/1/sync/rules/{v1SyncRuleId} | 
[**GetSyncv1SyncSettings**](SyncApi.md#GetSyncv1SyncSettings) | **Get** /platform/1/sync/settings | 
[**GetSyncv1TargetPolicies**](SyncApi.md#GetSyncv1TargetPolicies) | **Get** /platform/1/sync/target/policies | 
[**GetSyncv1TargetPolicy**](SyncApi.md#GetSyncv1TargetPolicy) | **Get** /platform/1/sync/target/policies/{v1TargetPolicyId} | 
[**GetSyncv1TargetReport**](SyncApi.md#GetSyncv1TargetReport) | **Get** /platform/1/sync/target/reports/{v1TargetReportId} | 
[**GetSyncv1TargetReports**](SyncApi.md#GetSyncv1TargetReports) | **Get** /platform/1/sync/target/reports | 
[**GetSyncv1TargetReportsRidSubreport**](SyncApi.md#GetSyncv1TargetReportsRidSubreport) | **Get** /platform/1/sync/target/reports/{Rid}/subreports/{v1TargetReportsRidSubreportId} | 
[**GetSyncv3HistoryCpu**](SyncApi.md#GetSyncv3HistoryCpu) | **Get** /platform/3/sync/history/cpu | 
[**GetSyncv3HistoryWorker**](SyncApi.md#GetSyncv3HistoryWorker) | **Get** /platform/3/sync/history/worker | 
[**GetSyncv3SyncJob**](SyncApi.md#GetSyncv3SyncJob) | **Get** /platform/3/sync/jobs/{v3SyncJobId} | 
[**GetSyncv3SyncPolicy**](SyncApi.md#GetSyncv3SyncPolicy) | **Get** /platform/3/sync/policies/{v3SyncPolicyId} | 
[**GetSyncv3SyncRule**](SyncApi.md#GetSyncv3SyncRule) | **Get** /platform/3/sync/rules/{v3SyncRuleId} | 
[**GetSyncv3SyncSettings**](SyncApi.md#GetSyncv3SyncSettings) | **Get** /platform/3/sync/settings | 
[**GetSyncv4ReportsRidSubreport**](SyncApi.md#GetSyncv4ReportsRidSubreport) | **Get** /platform/4/sync/reports/{Rid}/subreports/{v4ReportsRidSubreportId} | 
[**GetSyncv4SyncReport**](SyncApi.md#GetSyncv4SyncReport) | **Get** /platform/4/sync/reports/{v4SyncReportId} | 
[**GetSyncv4SyncReports**](SyncApi.md#GetSyncv4SyncReports) | **Get** /platform/4/sync/reports | 
[**GetSyncv4TargetReport**](SyncApi.md#GetSyncv4TargetReport) | **Get** /platform/4/sync/target/reports/{v4TargetReportId} | 
[**GetSyncv4TargetReports**](SyncApi.md#GetSyncv4TargetReports) | **Get** /platform/4/sync/target/reports | 
[**GetSyncv4TargetReportsRidSubreport**](SyncApi.md#GetSyncv4TargetReportsRidSubreport) | **Get** /platform/4/sync/target/reports/{Rid}/subreports/{v4TargetReportsRidSubreportId} | 
[**GetSyncv5SyncLicense**](SyncApi.md#GetSyncv5SyncLicense) | **Get** /platform/5/sync/license | 
[**GetSyncv7CertificatesPeerById**](SyncApi.md#GetSyncv7CertificatesPeerById) | **Get** /platform/7/sync/certificates/peer/{v7CertificatesPeerId} | 
[**GetSyncv7CertificatesServerById**](SyncApi.md#GetSyncv7CertificatesServerById) | **Get** /platform/7/sync/certificates/server/{v7CertificatesServerId} | 
[**GetSyncv7HistoryNetwork**](SyncApi.md#GetSyncv7HistoryNetwork) | **Get** /platform/7/sync/history/network | 
[**GetSyncv7ReportsRidSubreport**](SyncApi.md#GetSyncv7ReportsRidSubreport) | **Get** /platform/7/sync/reports/{Rid}/subreports/{v7ReportsRidSubreportId} | 
[**GetSyncv7ServicePolicy**](SyncApi.md#GetSyncv7ServicePolicy) | **Get** /platform/7/sync/service/policies/{v7ServicePolicyId} | 
[**GetSyncv7ServiceTargetPolicies**](SyncApi.md#GetSyncv7ServiceTargetPolicies) | **Get** /platform/7/sync/service/target/policies | 
[**GetSyncv7ServiceTargetPolicy**](SyncApi.md#GetSyncv7ServiceTargetPolicy) | **Get** /platform/7/sync/service/target/policies/{v7ServiceTargetPolicyId} | 
[**GetSyncv7SyncJob**](SyncApi.md#GetSyncv7SyncJob) | **Get** /platform/7/sync/jobs/{v7SyncJobId} | 
[**GetSyncv7SyncPolicy**](SyncApi.md#GetSyncv7SyncPolicy) | **Get** /platform/7/sync/policies/{v7SyncPolicyId} | 
[**GetSyncv7SyncReport**](SyncApi.md#GetSyncv7SyncReport) | **Get** /platform/7/sync/reports/{v7SyncReportId} | 
[**GetSyncv7SyncReports**](SyncApi.md#GetSyncv7SyncReports) | **Get** /platform/7/sync/reports | 
[**GetSyncv7SyncSettings**](SyncApi.md#GetSyncv7SyncSettings) | **Get** /platform/7/sync/settings | 
[**GetSyncv7TargetReport**](SyncApi.md#GetSyncv7TargetReport) | **Get** /platform/7/sync/target/reports/{v7TargetReportId} | 
[**GetSyncv7TargetReports**](SyncApi.md#GetSyncv7TargetReports) | **Get** /platform/7/sync/target/reports | 
[**GetSyncv7TargetReportsRidSubreport**](SyncApi.md#GetSyncv7TargetReportsRidSubreport) | **Get** /platform/7/sync/target/reports/{Rid}/subreports/{v7TargetReportsRidSubreportId} | 
[**ListSyncv14SyncPolicies**](SyncApi.md#ListSyncv14SyncPolicies) | **Get** /platform/14/sync/policies | 
[**ListSyncv15SyncJobs**](SyncApi.md#ListSyncv15SyncJobs) | **Get** /platform/15/sync/jobs | 
[**ListSyncv1SyncJobs**](SyncApi.md#ListSyncv1SyncJobs) | **Get** /platform/1/sync/jobs | 
[**ListSyncv1SyncPolicies**](SyncApi.md#ListSyncv1SyncPolicies) | **Get** /platform/1/sync/policies | 
[**ListSyncv1SyncReportsRotate**](SyncApi.md#ListSyncv1SyncReportsRotate) | **Get** /platform/1/sync/reports-rotate | 
[**ListSyncv1SyncRules**](SyncApi.md#ListSyncv1SyncRules) | **Get** /platform/1/sync/rules | 
[**ListSyncv3SyncJobs**](SyncApi.md#ListSyncv3SyncJobs) | **Get** /platform/3/sync/jobs | 
[**ListSyncv3SyncPolicies**](SyncApi.md#ListSyncv3SyncPolicies) | **Get** /platform/3/sync/policies | 
[**ListSyncv3SyncRules**](SyncApi.md#ListSyncv3SyncRules) | **Get** /platform/3/sync/rules | 
[**ListSyncv7CertificatesPeer**](SyncApi.md#ListSyncv7CertificatesPeer) | **Get** /platform/7/sync/certificates/peer | 
[**ListSyncv7CertificatesServer**](SyncApi.md#ListSyncv7CertificatesServer) | **Get** /platform/7/sync/certificates/server | 
[**ListSyncv7ServicePolicies**](SyncApi.md#ListSyncv7ServicePolicies) | **Get** /platform/7/sync/service/policies | 
[**ListSyncv7SyncJobs**](SyncApi.md#ListSyncv7SyncJobs) | **Get** /platform/7/sync/jobs | 
[**ListSyncv7SyncPolicies**](SyncApi.md#ListSyncv7SyncPolicies) | **Get** /platform/7/sync/policies | 
[**UpdateSyncv14SyncPolicy**](SyncApi.md#UpdateSyncv14SyncPolicy) | **Put** /platform/14/sync/policies/{v14SyncPolicyId} | 
[**UpdateSyncv14SyncSettings**](SyncApi.md#UpdateSyncv14SyncSettings) | **Put** /platform/14/sync/settings | 
[**UpdateSyncv15SyncJob**](SyncApi.md#UpdateSyncv15SyncJob) | **Put** /platform/15/sync/jobs/{v15SyncJobId} | 
[**UpdateSyncv16SyncSettings**](SyncApi.md#UpdateSyncv16SyncSettings) | **Put** /platform/16/sync/settings | 
[**UpdateSyncv1SyncJob**](SyncApi.md#UpdateSyncv1SyncJob) | **Put** /platform/1/sync/jobs/{v1SyncJobId} | 
[**UpdateSyncv1SyncPolicy**](SyncApi.md#UpdateSyncv1SyncPolicy) | **Put** /platform/1/sync/policies/{v1SyncPolicyId} | 
[**UpdateSyncv1SyncRule**](SyncApi.md#UpdateSyncv1SyncRule) | **Put** /platform/1/sync/rules/{v1SyncRuleId} | 
[**UpdateSyncv1SyncSettings**](SyncApi.md#UpdateSyncv1SyncSettings) | **Put** /platform/1/sync/settings | 
[**UpdateSyncv3SyncJob**](SyncApi.md#UpdateSyncv3SyncJob) | **Put** /platform/3/sync/jobs/{v3SyncJobId} | 
[**UpdateSyncv3SyncPolicy**](SyncApi.md#UpdateSyncv3SyncPolicy) | **Put** /platform/3/sync/policies/{v3SyncPolicyId} | 
[**UpdateSyncv3SyncRule**](SyncApi.md#UpdateSyncv3SyncRule) | **Put** /platform/3/sync/rules/{v3SyncRuleId} | 
[**UpdateSyncv3SyncSettings**](SyncApi.md#UpdateSyncv3SyncSettings) | **Put** /platform/3/sync/settings | 
[**UpdateSyncv7CertificatesPeerById**](SyncApi.md#UpdateSyncv7CertificatesPeerById) | **Put** /platform/7/sync/certificates/peer/{v7CertificatesPeerId} | 
[**UpdateSyncv7CertificatesServerById**](SyncApi.md#UpdateSyncv7CertificatesServerById) | **Put** /platform/7/sync/certificates/server/{v7CertificatesServerId} | 
[**UpdateSyncv7ServicePolicy**](SyncApi.md#UpdateSyncv7ServicePolicy) | **Put** /platform/7/sync/service/policies/{v7ServicePolicyId} | 
[**UpdateSyncv7SyncJob**](SyncApi.md#UpdateSyncv7SyncJob) | **Put** /platform/7/sync/jobs/{v7SyncJobId} | 
[**UpdateSyncv7SyncPolicy**](SyncApi.md#UpdateSyncv7SyncPolicy) | **Put** /platform/7/sync/policies/{v7SyncPolicyId} | 
[**UpdateSyncv7SyncSettings**](SyncApi.md#UpdateSyncv7SyncSettings) | **Put** /platform/7/sync/settings | 



## CreateSyncv14SyncPolicy

> CreateResponse CreateSyncv14SyncPolicy(ctx).V14SyncPolicy(v14SyncPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14SyncPolicy := *openapiclient.NewV14SyncPolicy("Action_example", "Name_example", "SourceRootPath_example", "TargetHost_example", "TargetPath_example") // V14SyncPolicy | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.CreateSyncv14SyncPolicy(context.Background()).V14SyncPolicy(v14SyncPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.CreateSyncv14SyncPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSyncv14SyncPolicy`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.CreateSyncv14SyncPolicy`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSyncv14SyncPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v14SyncPolicy** | [**V14SyncPolicy**](V14SyncPolicy.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSyncv15SyncJob

> CreateResponse CreateSyncv15SyncJob(ctx).V15SyncJob(v15SyncJob).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15SyncJob := *openapiclient.NewV15SyncJob("Id_example") // V15SyncJob | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.CreateSyncv15SyncJob(context.Background()).V15SyncJob(v15SyncJob).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.CreateSyncv15SyncJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSyncv15SyncJob`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.CreateSyncv15SyncJob`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSyncv15SyncJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v15SyncJob** | [**V15SyncJob**](V15SyncJob.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSyncv1SyncJob

> CreateResponse CreateSyncv1SyncJob(ctx).V1SyncJob(v1SyncJob).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SyncJob := *openapiclient.NewV1SyncJob("Id_example") // V1SyncJob | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.CreateSyncv1SyncJob(context.Background()).V1SyncJob(v1SyncJob).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.CreateSyncv1SyncJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSyncv1SyncJob`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.CreateSyncv1SyncJob`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSyncv1SyncJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SyncJob** | [**V1SyncJob**](V1SyncJob.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSyncv1SyncPolicy

> CreateResponse CreateSyncv1SyncPolicy(ctx).V1SyncPolicy(v1SyncPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SyncPolicy := *openapiclient.NewV1SyncPolicy("Action_example", "Name_example", "SourceRootPath_example", "TargetHost_example", "TargetPath_example") // V1SyncPolicy | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.CreateSyncv1SyncPolicy(context.Background()).V1SyncPolicy(v1SyncPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.CreateSyncv1SyncPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSyncv1SyncPolicy`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.CreateSyncv1SyncPolicy`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSyncv1SyncPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SyncPolicy** | [**V1SyncPolicy**](V1SyncPolicy.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSyncv1SyncReportsRotateItem

> Createv1SyncReportsRotateItemResponse CreateSyncv1SyncReportsRotateItem(ctx).V1SyncReportsRotateItem(v1SyncReportsRotateItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SyncReportsRotateItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.CreateSyncv1SyncReportsRotateItem(context.Background()).V1SyncReportsRotateItem(v1SyncReportsRotateItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.CreateSyncv1SyncReportsRotateItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSyncv1SyncReportsRotateItem`: Createv1SyncReportsRotateItemResponse
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.CreateSyncv1SyncReportsRotateItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSyncv1SyncReportsRotateItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SyncReportsRotateItem** | **map[string]interface{}** |  | 

### Return type

[**Createv1SyncReportsRotateItemResponse**](Createv1SyncReportsRotateItemResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSyncv1SyncRule

> CreateResponse CreateSyncv1SyncRule(ctx).V1SyncRule(v1SyncRule).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SyncRule := *openapiclient.NewV1SyncRule(int32(123), "Type_example") // V1SyncRule | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.CreateSyncv1SyncRule(context.Background()).V1SyncRule(v1SyncRule).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.CreateSyncv1SyncRule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSyncv1SyncRule`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.CreateSyncv1SyncRule`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSyncv1SyncRuleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SyncRule** | [**V1SyncRule**](V1SyncRule.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSyncv3SyncJob

> CreateResponse CreateSyncv3SyncJob(ctx).V3SyncJob(v3SyncJob).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SyncJob := *openapiclient.NewV1SyncJob("Id_example") // V1SyncJob | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.CreateSyncv3SyncJob(context.Background()).V3SyncJob(v3SyncJob).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.CreateSyncv3SyncJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSyncv3SyncJob`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.CreateSyncv3SyncJob`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSyncv3SyncJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3SyncJob** | [**V1SyncJob**](V1SyncJob.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSyncv3SyncPolicy

> CreateResponse CreateSyncv3SyncPolicy(ctx).V3SyncPolicy(v3SyncPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SyncPolicy := *openapiclient.NewV3SyncPolicy("Action_example", "Name_example", "SourceRootPath_example", "TargetHost_example", "TargetPath_example") // V3SyncPolicy | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.CreateSyncv3SyncPolicy(context.Background()).V3SyncPolicy(v3SyncPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.CreateSyncv3SyncPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSyncv3SyncPolicy`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.CreateSyncv3SyncPolicy`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSyncv3SyncPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3SyncPolicy** | [**V3SyncPolicy**](V3SyncPolicy.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSyncv3SyncRule

> CreateResponse CreateSyncv3SyncRule(ctx).V3SyncRule(v3SyncRule).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SyncRule := *openapiclient.NewV3SyncRule(int32(123), "Type_example") // V3SyncRule | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.CreateSyncv3SyncRule(context.Background()).V3SyncRule(v3SyncRule).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.CreateSyncv3SyncRule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSyncv3SyncRule`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.CreateSyncv3SyncRule`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSyncv3SyncRuleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3SyncRule** | [**V3SyncRule**](V3SyncRule.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSyncv7CertificatesPeerItem

> CreateResponse CreateSyncv7CertificatesPeerItem(ctx).V7CertificatesPeerItem(v7CertificatesPeerItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CertificatesPeerItem := *openapiclient.NewV7CertificateAuthorityItem("CertificatePath_example") // V7CertificateAuthorityItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.CreateSyncv7CertificatesPeerItem(context.Background()).V7CertificatesPeerItem(v7CertificatesPeerItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.CreateSyncv7CertificatesPeerItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSyncv7CertificatesPeerItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.CreateSyncv7CertificatesPeerItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSyncv7CertificatesPeerItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7CertificatesPeerItem** | [**V7CertificateAuthorityItem**](V7CertificateAuthorityItem.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSyncv7CertificatesServerItem

> CreateResponse CreateSyncv7CertificatesServerItem(ctx).V7CertificatesServerItem(v7CertificatesServerItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CertificatesServerItem := *openapiclient.NewV16CertificatesSyslogItem("CertificateKeyPath_example", "CertificatePath_example") // V16CertificatesSyslogItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.CreateSyncv7CertificatesServerItem(context.Background()).V7CertificatesServerItem(v7CertificatesServerItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.CreateSyncv7CertificatesServerItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSyncv7CertificatesServerItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.CreateSyncv7CertificatesServerItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSyncv7CertificatesServerItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7CertificatesServerItem** | [**V16CertificatesSyslogItem**](V16CertificatesSyslogItem.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSyncv7ServicePolicy

> CreateResponse CreateSyncv7ServicePolicy(ctx).V7ServicePolicy(v7ServicePolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ServicePolicy := *openapiclient.NewV7ServicePolicy("Name_example", "TargetHost_example") // V7ServicePolicy | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.CreateSyncv7ServicePolicy(context.Background()).V7ServicePolicy(v7ServicePolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.CreateSyncv7ServicePolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSyncv7ServicePolicy`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.CreateSyncv7ServicePolicy`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSyncv7ServicePolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7ServicePolicy** | [**V7ServicePolicy**](V7ServicePolicy.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSyncv7SyncJob

> CreateResponse CreateSyncv7SyncJob(ctx).V7SyncJob(v7SyncJob).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SyncJob := *openapiclient.NewV15SyncJob("Id_example") // V15SyncJob | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.CreateSyncv7SyncJob(context.Background()).V7SyncJob(v7SyncJob).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.CreateSyncv7SyncJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSyncv7SyncJob`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.CreateSyncv7SyncJob`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSyncv7SyncJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7SyncJob** | [**V15SyncJob**](V15SyncJob.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSyncv7SyncPolicy

> CreateResponse CreateSyncv7SyncPolicy(ctx).V7SyncPolicy(v7SyncPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SyncPolicy := *openapiclient.NewV7SyncPolicy("Action_example", "Name_example", "SourceRootPath_example", "TargetHost_example", "TargetPath_example") // V7SyncPolicy | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.CreateSyncv7SyncPolicy(context.Background()).V7SyncPolicy(v7SyncPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.CreateSyncv7SyncPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSyncv7SyncPolicy`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.CreateSyncv7SyncPolicy`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSyncv7SyncPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7SyncPolicy** | [**V7SyncPolicy**](V7SyncPolicy.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv14SyncPolicies

> DeleteSyncv14SyncPolicies(ctx).LocalOnly(localOnly).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    localOnly := true // bool | Skip deleting the policy association on the target. (optional)
    force := true // bool | Ignore any running jobs when preparing to delete a policy. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv14SyncPolicies(context.Background()).LocalOnly(localOnly).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv14SyncPolicies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv14SyncPoliciesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **localOnly** | **bool** | Skip deleting the policy association on the target. | 
 **force** | **bool** | Ignore any running jobs when preparing to delete a policy. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv14SyncPolicy

> DeleteSyncv14SyncPolicy(ctx, v14SyncPolicyId).LocalOnly(localOnly).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14SyncPolicyId := "v14SyncPolicyId_example" // string | Delete a single SyncIQ policy.
    localOnly := true // bool | Skip deleting the policy association on the target. (optional)
    force := true // bool | Ignore any running jobs when preparing to delete a policy. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv14SyncPolicy(context.Background(), v14SyncPolicyId).LocalOnly(localOnly).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv14SyncPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v14SyncPolicyId** | **string** | Delete a single SyncIQ policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv14SyncPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **localOnly** | **bool** | Skip deleting the policy association on the target. | 
 **force** | **bool** | Ignore any running jobs when preparing to delete a policy. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv15SyncJobs

> DeleteSyncv15SyncJobs(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv15SyncJobs(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv15SyncJobs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv15SyncJobsRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv1SyncJobs

> DeleteSyncv1SyncJobs(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv1SyncJobs(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv1SyncJobs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv1SyncJobsRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv1SyncPolicies

> DeleteSyncv1SyncPolicies(ctx).LocalOnly(localOnly).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    localOnly := true // bool | Skip deleting the policy association on the target. (optional)
    force := true // bool | Ignore any running jobs when preparing to delete a policy. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv1SyncPolicies(context.Background()).LocalOnly(localOnly).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv1SyncPolicies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv1SyncPoliciesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **localOnly** | **bool** | Skip deleting the policy association on the target. | 
 **force** | **bool** | Ignore any running jobs when preparing to delete a policy. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv1SyncPolicy

> DeleteSyncv1SyncPolicy(ctx, v1SyncPolicyId).LocalOnly(localOnly).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SyncPolicyId := "v1SyncPolicyId_example" // string | Delete a single SyncIQ policy.
    localOnly := true // bool | Skip deleting the policy association on the target. (optional)
    force := true // bool | Ignore any running jobs when preparing to delete a policy. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv1SyncPolicy(context.Background(), v1SyncPolicyId).LocalOnly(localOnly).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv1SyncPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SyncPolicyId** | **string** | Delete a single SyncIQ policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv1SyncPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **localOnly** | **bool** | Skip deleting the policy association on the target. | 
 **force** | **bool** | Ignore any running jobs when preparing to delete a policy. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv1SyncRule

> DeleteSyncv1SyncRule(ctx, v1SyncRuleId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SyncRuleId := "v1SyncRuleId_example" // string | Delete a single SyncIQ performance rule.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv1SyncRule(context.Background(), v1SyncRuleId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv1SyncRule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SyncRuleId** | **string** | Delete a single SyncIQ performance rule. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv1SyncRuleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv1SyncRules

> DeleteSyncv1SyncRules(ctx).Type_(type_).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    type_ := "type__example" // string | Delete all rules of the specified rule type only. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv1SyncRules(context.Background()).Type_(type_).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv1SyncRules``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv1SyncRulesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **type_** | **string** | Delete all rules of the specified rule type only. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv1TargetPolicy

> DeleteSyncv1TargetPolicy(ctx, v1TargetPolicyId).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1TargetPolicyId := "v1TargetPolicyId_example" // string | Break the target association with this cluster for this policy.
    force := true // bool | Ignore any running jobs when preparing to delete the policy target association. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv1TargetPolicy(context.Background(), v1TargetPolicyId).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv1TargetPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1TargetPolicyId** | **string** | Break the target association with this cluster for this policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv1TargetPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **force** | **bool** | Ignore any running jobs when preparing to delete the policy target association. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv3SyncJobs

> DeleteSyncv3SyncJobs(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv3SyncJobs(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv3SyncJobs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv3SyncJobsRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv3SyncPolicies

> DeleteSyncv3SyncPolicies(ctx).LocalOnly(localOnly).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    localOnly := true // bool | Skip deleting the policy association on the target. (optional)
    force := true // bool | Ignore any running jobs when preparing to delete a policy. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv3SyncPolicies(context.Background()).LocalOnly(localOnly).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv3SyncPolicies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv3SyncPoliciesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **localOnly** | **bool** | Skip deleting the policy association on the target. | 
 **force** | **bool** | Ignore any running jobs when preparing to delete a policy. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv3SyncPolicy

> DeleteSyncv3SyncPolicy(ctx, v3SyncPolicyId).LocalOnly(localOnly).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SyncPolicyId := "v3SyncPolicyId_example" // string | Delete a single SyncIQ policy.
    localOnly := true // bool | Skip deleting the policy association on the target. (optional)
    force := true // bool | Ignore any running jobs when preparing to delete a policy. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv3SyncPolicy(context.Background(), v3SyncPolicyId).LocalOnly(localOnly).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv3SyncPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3SyncPolicyId** | **string** | Delete a single SyncIQ policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv3SyncPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **localOnly** | **bool** | Skip deleting the policy association on the target. | 
 **force** | **bool** | Ignore any running jobs when preparing to delete a policy. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv3SyncRule

> DeleteSyncv3SyncRule(ctx, v3SyncRuleId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SyncRuleId := "v3SyncRuleId_example" // string | Delete a single SyncIQ performance rule.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv3SyncRule(context.Background(), v3SyncRuleId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv3SyncRule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3SyncRuleId** | **string** | Delete a single SyncIQ performance rule. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv3SyncRuleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv3SyncRules

> DeleteSyncv3SyncRules(ctx).Type_(type_).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    type_ := "type__example" // string | Delete all rules of the specified rule type only. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv3SyncRules(context.Background()).Type_(type_).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv3SyncRules``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv3SyncRulesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **type_** | **string** | Delete all rules of the specified rule type only. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv7CertificatesPeerById

> DeleteSyncv7CertificatesPeerById(ctx, v7CertificatesPeerId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CertificatesPeerId := "v7CertificatesPeerId_example" // string | Delete a trusted SyncIQ TLS certificate.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv7CertificatesPeerById(context.Background(), v7CertificatesPeerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv7CertificatesPeerById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7CertificatesPeerId** | **string** | Delete a trusted SyncIQ TLS certificate. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv7CertificatesPeerByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv7CertificatesServerById

> DeleteSyncv7CertificatesServerById(ctx, v7CertificatesServerId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CertificatesServerId := "v7CertificatesServerId_example" // string | Delete a SyncIQ TLS server certificate.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv7CertificatesServerById(context.Background(), v7CertificatesServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv7CertificatesServerById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7CertificatesServerId** | **string** | Delete a SyncIQ TLS server certificate. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv7CertificatesServerByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv7ServicePolicies

> DeleteSyncv7ServicePolicies(ctx).LocalOnly(localOnly).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    localOnly := true // bool | Skip deleting the policy association on the target. (optional)
    force := true // bool | Ignore any running jobs when preparing to delete a policy. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv7ServicePolicies(context.Background()).LocalOnly(localOnly).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv7ServicePolicies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv7ServicePoliciesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **localOnly** | **bool** | Skip deleting the policy association on the target. | 
 **force** | **bool** | Ignore any running jobs when preparing to delete a policy. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv7ServicePolicy

> DeleteSyncv7ServicePolicy(ctx, v7ServicePolicyId).LocalOnly(localOnly).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ServicePolicyId := "v7ServicePolicyId_example" // string | Delete a single SyncIQ service replication policy.
    localOnly := true // bool | Skip deleting the policy association on the target. (optional)
    force := true // bool | Ignore any running jobs when preparing to delete a policy. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv7ServicePolicy(context.Background(), v7ServicePolicyId).LocalOnly(localOnly).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv7ServicePolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ServicePolicyId** | **string** | Delete a single SyncIQ service replication policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv7ServicePolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **localOnly** | **bool** | Skip deleting the policy association on the target. | 
 **force** | **bool** | Ignore any running jobs when preparing to delete a policy. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv7ServiceTargetPolicy

> DeleteSyncv7ServiceTargetPolicy(ctx, v7ServiceTargetPolicyId).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ServiceTargetPolicyId := "v7ServiceTargetPolicyId_example" // string | Break the target association with this cluster for this policy.
    force := true // bool | Ignore any running jobs when preparing to delete the policy target association. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv7ServiceTargetPolicy(context.Background(), v7ServiceTargetPolicyId).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv7ServiceTargetPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ServiceTargetPolicyId** | **string** | Break the target association with this cluster for this policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv7ServiceTargetPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **force** | **bool** | Ignore any running jobs when preparing to delete the policy target association. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv7SyncJobs

> DeleteSyncv7SyncJobs(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv7SyncJobs(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv7SyncJobs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv7SyncJobsRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv7SyncPolicies

> DeleteSyncv7SyncPolicies(ctx).LocalOnly(localOnly).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    localOnly := true // bool | Skip deleting the policy association on the target. (optional)
    force := true // bool | Ignore any running jobs when preparing to delete a policy. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv7SyncPolicies(context.Background()).LocalOnly(localOnly).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv7SyncPolicies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv7SyncPoliciesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **localOnly** | **bool** | Skip deleting the policy association on the target. | 
 **force** | **bool** | Ignore any running jobs when preparing to delete a policy. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSyncv7SyncPolicy

> DeleteSyncv7SyncPolicy(ctx, v7SyncPolicyId).LocalOnly(localOnly).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SyncPolicyId := "v7SyncPolicyId_example" // string | Delete a single SyncIQ policy.
    localOnly := true // bool | Skip deleting the policy association on the target. (optional)
    force := true // bool | Ignore any running jobs when preparing to delete a policy. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.DeleteSyncv7SyncPolicy(context.Background(), v7SyncPolicyId).LocalOnly(localOnly).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.DeleteSyncv7SyncPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7SyncPolicyId** | **string** | Delete a single SyncIQ policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSyncv7SyncPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **localOnly** | **bool** | Skip deleting the policy association on the target. | 
 **force** | **bool** | Ignore any running jobs when preparing to delete a policy. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv14SyncPolicy

> V14SyncPoliciesExtended GetSyncv14SyncPolicy(ctx, v14SyncPolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14SyncPolicyId := "v14SyncPolicyId_example" // string | View a single SyncIQ policy.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv14SyncPolicy(context.Background(), v14SyncPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv14SyncPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv14SyncPolicy`: V14SyncPoliciesExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv14SyncPolicy`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v14SyncPolicyId** | **string** | View a single SyncIQ policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv14SyncPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V14SyncPoliciesExtended**](V14SyncPoliciesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv14SyncSettings

> V14SyncSettings GetSyncv14SyncSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv14SyncSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv14SyncSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv14SyncSettings`: V14SyncSettings
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv14SyncSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv14SyncSettingsRequest struct via the builder pattern


### Return type

[**V14SyncSettings**](V14SyncSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv15ReportsRidSubreport

> V15ReportsRidSubreports GetSyncv15ReportsRidSubreport(ctx, v15ReportsRidSubreportId, rid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15ReportsRidSubreportId := "v15ReportsRidSubreportId_example" // string | View a single SyncIQ subreport.
    rid := "rid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv15ReportsRidSubreport(context.Background(), v15ReportsRidSubreportId, rid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv15ReportsRidSubreport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv15ReportsRidSubreport`: V15ReportsRidSubreports
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv15ReportsRidSubreport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15ReportsRidSubreportId** | **string** | View a single SyncIQ subreport. | 
**rid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv15ReportsRidSubreportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V15ReportsRidSubreports**](V15ReportsRidSubreports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv15SyncJob

> V15SyncJobsExtended GetSyncv15SyncJob(ctx, v15SyncJobId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15SyncJobId := "v15SyncJobId_example" // string | View a single SyncIQ job.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv15SyncJob(context.Background(), v15SyncJobId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv15SyncJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv15SyncJob`: V15SyncJobsExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv15SyncJob`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15SyncJobId** | **string** | View a single SyncIQ job. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv15SyncJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V15SyncJobsExtended**](V15SyncJobsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv15SyncReport

> V15SyncReportsExtended GetSyncv15SyncReport(ctx, v15SyncReportId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15SyncReportId := "v15SyncReportId_example" // string | View a single SyncIQ report.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv15SyncReport(context.Background(), v15SyncReportId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv15SyncReport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv15SyncReport`: V15SyncReportsExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv15SyncReport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15SyncReportId** | **string** | View a single SyncIQ report. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv15SyncReportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V15SyncReportsExtended**](V15SyncReportsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv15SyncReports

> V15SyncReports GetSyncv15SyncReports(ctx).Sort(sort).Resume(resume).NewerThan(newerThan).PolicyName(policyName).State(state).Limit(limit).ReportsPerPolicy(reportsPerPolicy).Summary(summary).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    newerThan := int32(56) // int32 | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. (optional)
    policyName := "policyName_example" // string | Filter the returned reports to include only those with this policy name. (optional)
    state := "state_example" // string | Filter the returned reports to include only those whose jobs are in this state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    reportsPerPolicy := int32(56) // int32 | If specified, only the N most recent reports will be returned per policy.  If no other query args are present this argument defaults to 1.  (optional)
    summary := true // bool | Return a summary rather than entire objects (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv15SyncReports(context.Background()).Sort(sort).Resume(resume).NewerThan(newerThan).PolicyName(policyName).State(state).Limit(limit).ReportsPerPolicy(reportsPerPolicy).Summary(summary).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv15SyncReports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv15SyncReports`: V15SyncReports
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv15SyncReports`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv15SyncReportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **newerThan** | **int32** | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. | 
 **policyName** | **string** | Filter the returned reports to include only those with this policy name. | 
 **state** | **string** | Filter the returned reports to include only those whose jobs are in this state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **reportsPerPolicy** | **int32** | If specified, only the N most recent reports will be returned per policy.  If no other query args are present this argument defaults to 1.  | 
 **summary** | **bool** | Return a summary rather than entire objects | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V15SyncReports**](V15SyncReports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv15TargetReport

> V15TargetReportsExtended GetSyncv15TargetReport(ctx, v15TargetReportId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15TargetReportId := "v15TargetReportId_example" // string | View a single SyncIQ target report.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv15TargetReport(context.Background(), v15TargetReportId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv15TargetReport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv15TargetReport`: V15TargetReportsExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv15TargetReport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15TargetReportId** | **string** | View a single SyncIQ target report. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv15TargetReportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V15TargetReportsExtended**](V15TargetReportsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv15TargetReports

> V15TargetReports GetSyncv15TargetReports(ctx).Sort(sort).Resume(resume).NewerThan(newerThan).PolicyName(policyName).State(state).Limit(limit).ReportsPerPolicy(reportsPerPolicy).Summary(summary).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    newerThan := int32(56) // int32 | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. (optional)
    policyName := "policyName_example" // string | Filter the returned reports to include only those with this policy name. (optional)
    state := "state_example" // string | Filter the returned reports to include only those whose jobs are in this state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    reportsPerPolicy := int32(56) // int32 | If specified, only the N most recent reports will be returned per policy.  If no other query args are present this argument defaults to 1.  (optional)
    summary := true // bool | Return a summary rather than entire objects. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv15TargetReports(context.Background()).Sort(sort).Resume(resume).NewerThan(newerThan).PolicyName(policyName).State(state).Limit(limit).ReportsPerPolicy(reportsPerPolicy).Summary(summary).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv15TargetReports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv15TargetReports`: V15TargetReports
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv15TargetReports`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv15TargetReportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **newerThan** | **int32** | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. | 
 **policyName** | **string** | Filter the returned reports to include only those with this policy name. | 
 **state** | **string** | Filter the returned reports to include only those whose jobs are in this state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **reportsPerPolicy** | **int32** | If specified, only the N most recent reports will be returned per policy.  If no other query args are present this argument defaults to 1.  | 
 **summary** | **bool** | Return a summary rather than entire objects. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V15TargetReports**](V15TargetReports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv15TargetReportsRidSubreport

> V15TargetReportsRidSubreports GetSyncv15TargetReportsRidSubreport(ctx, v15TargetReportsRidSubreportId, rid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15TargetReportsRidSubreportId := "v15TargetReportsRidSubreportId_example" // string | View a single SyncIQ target subreport.
    rid := "rid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv15TargetReportsRidSubreport(context.Background(), v15TargetReportsRidSubreportId, rid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv15TargetReportsRidSubreport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv15TargetReportsRidSubreport`: V15TargetReportsRidSubreports
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv15TargetReportsRidSubreport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15TargetReportsRidSubreportId** | **string** | View a single SyncIQ target subreport. | 
**rid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv15TargetReportsRidSubreportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V15TargetReportsRidSubreports**](V15TargetReportsRidSubreports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv16SyncSettings

> V16SyncSettings GetSyncv16SyncSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv16SyncSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv16SyncSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv16SyncSettings`: V16SyncSettings
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv16SyncSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv16SyncSettingsRequest struct via the builder pattern


### Return type

[**V16SyncSettings**](V16SyncSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv1HistoryFile

> V1HistoryFile GetSyncv1HistoryFile(ctx).Begin(begin).End(end).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    begin := int32(56) // int32 | Begin timestamp for time-series report. (optional)
    end := int32(56) // int32 | End timestamp for time-series report. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv1HistoryFile(context.Background()).Begin(begin).End(end).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv1HistoryFile``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv1HistoryFile`: V1HistoryFile
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv1HistoryFile`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv1HistoryFileRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **begin** | **int32** | Begin timestamp for time-series report. | 
 **end** | **int32** | End timestamp for time-series report. | 

### Return type

[**V1HistoryFile**](V1HistoryFile.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv1HistoryNetwork

> V1HistoryNetwork GetSyncv1HistoryNetwork(ctx).Begin(begin).End(end).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    begin := int32(56) // int32 | Begin timestamp for time-series report. (optional)
    end := int32(56) // int32 | End timestamp for time-series report. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv1HistoryNetwork(context.Background()).Begin(begin).End(end).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv1HistoryNetwork``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv1HistoryNetwork`: V1HistoryNetwork
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv1HistoryNetwork`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv1HistoryNetworkRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **begin** | **int32** | Begin timestamp for time-series report. | 
 **end** | **int32** | End timestamp for time-series report. | 

### Return type

[**V1HistoryNetwork**](V1HistoryNetwork.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv1ReportsRidSubreport

> V1ReportsRidSubreports GetSyncv1ReportsRidSubreport(ctx, v1ReportsRidSubreportId, rid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ReportsRidSubreportId := "v1ReportsRidSubreportId_example" // string | View a single SyncIQ subreport.
    rid := "rid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv1ReportsRidSubreport(context.Background(), v1ReportsRidSubreportId, rid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv1ReportsRidSubreport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv1ReportsRidSubreport`: V1ReportsRidSubreports
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv1ReportsRidSubreport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1ReportsRidSubreportId** | **string** | View a single SyncIQ subreport. | 
**rid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv1ReportsRidSubreportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V1ReportsRidSubreports**](V1ReportsRidSubreports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv1SyncJob

> V1SyncJobsExtended GetSyncv1SyncJob(ctx, v1SyncJobId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SyncJobId := "v1SyncJobId_example" // string | View a single SyncIQ job.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv1SyncJob(context.Background(), v1SyncJobId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv1SyncJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv1SyncJob`: V1SyncJobsExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv1SyncJob`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SyncJobId** | **string** | View a single SyncIQ job. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv1SyncJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1SyncJobsExtended**](V1SyncJobsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv1SyncLicense

> V1LicenseLicenseExtended GetSyncv1SyncLicense(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv1SyncLicense(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv1SyncLicense``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv1SyncLicense`: V1LicenseLicenseExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv1SyncLicense`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv1SyncLicenseRequest struct via the builder pattern


### Return type

[**V1LicenseLicenseExtended**](V1LicenseLicenseExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv1SyncPolicy

> V1SyncPoliciesExtended GetSyncv1SyncPolicy(ctx, v1SyncPolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SyncPolicyId := "v1SyncPolicyId_example" // string | View a single SyncIQ policy.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv1SyncPolicy(context.Background(), v1SyncPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv1SyncPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv1SyncPolicy`: V1SyncPoliciesExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv1SyncPolicy`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SyncPolicyId** | **string** | View a single SyncIQ policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv1SyncPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1SyncPoliciesExtended**](V1SyncPoliciesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv1SyncReport

> V1SyncReportsExtended GetSyncv1SyncReport(ctx, v1SyncReportId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SyncReportId := "v1SyncReportId_example" // string | View a single SyncIQ report.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv1SyncReport(context.Background(), v1SyncReportId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv1SyncReport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv1SyncReport`: V1SyncReportsExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv1SyncReport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SyncReportId** | **string** | View a single SyncIQ report. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv1SyncReportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1SyncReportsExtended**](V1SyncReportsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv1SyncReports

> V1SyncReports GetSyncv1SyncReports(ctx).Sort(sort).Resume(resume).NewerThan(newerThan).PolicyName(policyName).State(state).Limit(limit).ReportsPerPolicy(reportsPerPolicy).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    newerThan := int32(56) // int32 | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. (optional)
    policyName := "policyName_example" // string | Filter the returned reports to include only those with this policy name. (optional)
    state := "state_example" // string | Filter the returned reports to include only those whose jobs are in this state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    reportsPerPolicy := int32(56) // int32 | If specified, only the N most recent reports will be returned per policy.  If no other query args are present this argument defaults to 1.  (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv1SyncReports(context.Background()).Sort(sort).Resume(resume).NewerThan(newerThan).PolicyName(policyName).State(state).Limit(limit).ReportsPerPolicy(reportsPerPolicy).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv1SyncReports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv1SyncReports`: V1SyncReports
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv1SyncReports`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv1SyncReportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **newerThan** | **int32** | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. | 
 **policyName** | **string** | Filter the returned reports to include only those with this policy name. | 
 **state** | **string** | Filter the returned reports to include only those whose jobs are in this state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **reportsPerPolicy** | **int32** | If specified, only the N most recent reports will be returned per policy.  If no other query args are present this argument defaults to 1.  | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V1SyncReports**](V1SyncReports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv1SyncRule

> V1SyncRulesExtended GetSyncv1SyncRule(ctx, v1SyncRuleId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SyncRuleId := "v1SyncRuleId_example" // string | View a single SyncIQ performance rule.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv1SyncRule(context.Background(), v1SyncRuleId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv1SyncRule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv1SyncRule`: V1SyncRulesExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv1SyncRule`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SyncRuleId** | **string** | View a single SyncIQ performance rule. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv1SyncRuleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1SyncRulesExtended**](V1SyncRulesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv1SyncSettings

> V1SyncSettings GetSyncv1SyncSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv1SyncSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv1SyncSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv1SyncSettings`: V1SyncSettings
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv1SyncSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv1SyncSettingsRequest struct via the builder pattern


### Return type

[**V1SyncSettings**](V1SyncSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv1TargetPolicies

> V1TargetPolicies GetSyncv1TargetPolicies(ctx).Sort(sort).TargetPath(targetPath).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    targetPath := "targetPath_example" // string | Filter the returned policies to include only those with this target path. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv1TargetPolicies(context.Background()).Sort(sort).TargetPath(targetPath).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv1TargetPolicies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv1TargetPolicies`: V1TargetPolicies
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv1TargetPolicies`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv1TargetPoliciesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **targetPath** | **string** | Filter the returned policies to include only those with this target path. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1TargetPolicies**](V1TargetPolicies.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv1TargetPolicy

> V7ServiceTargetPoliciesExtended GetSyncv1TargetPolicy(ctx, v1TargetPolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1TargetPolicyId := "v1TargetPolicyId_example" // string | View a single SyncIQ target policy.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv1TargetPolicy(context.Background(), v1TargetPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv1TargetPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv1TargetPolicy`: V7ServiceTargetPoliciesExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv1TargetPolicy`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1TargetPolicyId** | **string** | View a single SyncIQ target policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv1TargetPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7ServiceTargetPoliciesExtended**](V7ServiceTargetPoliciesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv1TargetReport

> V1TargetReportsExtended GetSyncv1TargetReport(ctx, v1TargetReportId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1TargetReportId := "v1TargetReportId_example" // string | View a single SyncIQ target report.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv1TargetReport(context.Background(), v1TargetReportId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv1TargetReport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv1TargetReport`: V1TargetReportsExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv1TargetReport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1TargetReportId** | **string** | View a single SyncIQ target report. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv1TargetReportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1TargetReportsExtended**](V1TargetReportsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv1TargetReports

> V1TargetReports GetSyncv1TargetReports(ctx).Sort(sort).Resume(resume).NewerThan(newerThan).PolicyName(policyName).State(state).Limit(limit).ReportsPerPolicy(reportsPerPolicy).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    newerThan := int32(56) // int32 | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. (optional)
    policyName := "policyName_example" // string | Filter the returned reports to include only those with this policy name. (optional)
    state := "state_example" // string | Filter the returned reports to include only those whose jobs are in this state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    reportsPerPolicy := int32(56) // int32 | If specified, only the N most recent reports will be returned per policy.  If no other query args are present this argument defaults to 1.  (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv1TargetReports(context.Background()).Sort(sort).Resume(resume).NewerThan(newerThan).PolicyName(policyName).State(state).Limit(limit).ReportsPerPolicy(reportsPerPolicy).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv1TargetReports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv1TargetReports`: V1TargetReports
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv1TargetReports`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv1TargetReportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **newerThan** | **int32** | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. | 
 **policyName** | **string** | Filter the returned reports to include only those with this policy name. | 
 **state** | **string** | Filter the returned reports to include only those whose jobs are in this state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **reportsPerPolicy** | **int32** | If specified, only the N most recent reports will be returned per policy.  If no other query args are present this argument defaults to 1.  | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V1TargetReports**](V1TargetReports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv1TargetReportsRidSubreport

> V1TargetReportsRidSubreports GetSyncv1TargetReportsRidSubreport(ctx, v1TargetReportsRidSubreportId, rid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1TargetReportsRidSubreportId := "v1TargetReportsRidSubreportId_example" // string | View a single SyncIQ target subreport.
    rid := "rid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv1TargetReportsRidSubreport(context.Background(), v1TargetReportsRidSubreportId, rid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv1TargetReportsRidSubreport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv1TargetReportsRidSubreport`: V1TargetReportsRidSubreports
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv1TargetReportsRidSubreport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1TargetReportsRidSubreportId** | **string** | View a single SyncIQ target subreport. | 
**rid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv1TargetReportsRidSubreportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V1TargetReportsRidSubreports**](V1TargetReportsRidSubreports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv3HistoryCpu

> V3HistoryCpu GetSyncv3HistoryCpu(ctx).Begin(begin).End(end).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    begin := int32(56) // int32 | Begin timestamp for time-series report. (optional)
    end := int32(56) // int32 | End timestamp for time-series report. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv3HistoryCpu(context.Background()).Begin(begin).End(end).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv3HistoryCpu``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv3HistoryCpu`: V3HistoryCpu
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv3HistoryCpu`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv3HistoryCpuRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **begin** | **int32** | Begin timestamp for time-series report. | 
 **end** | **int32** | End timestamp for time-series report. | 

### Return type

[**V3HistoryCpu**](V3HistoryCpu.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv3HistoryWorker

> V3HistoryWorker GetSyncv3HistoryWorker(ctx).Begin(begin).End(end).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    begin := int32(56) // int32 | Begin timestamp for time-series report. (optional)
    end := int32(56) // int32 | End timestamp for time-series report. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv3HistoryWorker(context.Background()).Begin(begin).End(end).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv3HistoryWorker``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv3HistoryWorker`: V3HistoryWorker
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv3HistoryWorker`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv3HistoryWorkerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **begin** | **int32** | Begin timestamp for time-series report. | 
 **end** | **int32** | End timestamp for time-series report. | 

### Return type

[**V3HistoryWorker**](V3HistoryWorker.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv3SyncJob

> V3SyncJobsExtended GetSyncv3SyncJob(ctx, v3SyncJobId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SyncJobId := "v3SyncJobId_example" // string | View a single SyncIQ job.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv3SyncJob(context.Background(), v3SyncJobId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv3SyncJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv3SyncJob`: V3SyncJobsExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv3SyncJob`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3SyncJobId** | **string** | View a single SyncIQ job. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv3SyncJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3SyncJobsExtended**](V3SyncJobsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv3SyncPolicy

> V3SyncPoliciesExtended GetSyncv3SyncPolicy(ctx, v3SyncPolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SyncPolicyId := "v3SyncPolicyId_example" // string | View a single SyncIQ policy.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv3SyncPolicy(context.Background(), v3SyncPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv3SyncPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv3SyncPolicy`: V3SyncPoliciesExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv3SyncPolicy`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3SyncPolicyId** | **string** | View a single SyncIQ policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv3SyncPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3SyncPoliciesExtended**](V3SyncPoliciesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv3SyncRule

> V3SyncRulesExtended GetSyncv3SyncRule(ctx, v3SyncRuleId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SyncRuleId := "v3SyncRuleId_example" // string | View a single SyncIQ performance rule.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv3SyncRule(context.Background(), v3SyncRuleId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv3SyncRule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv3SyncRule`: V3SyncRulesExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv3SyncRule`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3SyncRuleId** | **string** | View a single SyncIQ performance rule. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv3SyncRuleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3SyncRulesExtended**](V3SyncRulesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv3SyncSettings

> V3SyncSettings GetSyncv3SyncSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv3SyncSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv3SyncSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv3SyncSettings`: V3SyncSettings
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv3SyncSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv3SyncSettingsRequest struct via the builder pattern


### Return type

[**V3SyncSettings**](V3SyncSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv4ReportsRidSubreport

> V4ReportsRidSubreports GetSyncv4ReportsRidSubreport(ctx, v4ReportsRidSubreportId, rid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4ReportsRidSubreportId := "v4ReportsRidSubreportId_example" // string | View a single SyncIQ subreport.
    rid := "rid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv4ReportsRidSubreport(context.Background(), v4ReportsRidSubreportId, rid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv4ReportsRidSubreport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv4ReportsRidSubreport`: V4ReportsRidSubreports
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv4ReportsRidSubreport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4ReportsRidSubreportId** | **string** | View a single SyncIQ subreport. | 
**rid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv4ReportsRidSubreportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V4ReportsRidSubreports**](V4ReportsRidSubreports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv4SyncReport

> V4SyncReportsExtended GetSyncv4SyncReport(ctx, v4SyncReportId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4SyncReportId := "v4SyncReportId_example" // string | View a single SyncIQ report.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv4SyncReport(context.Background(), v4SyncReportId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv4SyncReport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv4SyncReport`: V4SyncReportsExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv4SyncReport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4SyncReportId** | **string** | View a single SyncIQ report. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv4SyncReportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V4SyncReportsExtended**](V4SyncReportsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv4SyncReports

> V4SyncReports GetSyncv4SyncReports(ctx).Sort(sort).Resume(resume).NewerThan(newerThan).PolicyName(policyName).State(state).Limit(limit).ReportsPerPolicy(reportsPerPolicy).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    newerThan := int32(56) // int32 | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. (optional)
    policyName := "policyName_example" // string | Filter the returned reports to include only those with this policy name. (optional)
    state := "state_example" // string | Filter the returned reports to include only those whose jobs are in this state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    reportsPerPolicy := int32(56) // int32 | If specified, only the N most recent reports will be returned per policy.  If no other query args are present this argument defaults to 1.  (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv4SyncReports(context.Background()).Sort(sort).Resume(resume).NewerThan(newerThan).PolicyName(policyName).State(state).Limit(limit).ReportsPerPolicy(reportsPerPolicy).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv4SyncReports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv4SyncReports`: V4SyncReports
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv4SyncReports`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv4SyncReportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **newerThan** | **int32** | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. | 
 **policyName** | **string** | Filter the returned reports to include only those with this policy name. | 
 **state** | **string** | Filter the returned reports to include only those whose jobs are in this state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **reportsPerPolicy** | **int32** | If specified, only the N most recent reports will be returned per policy.  If no other query args are present this argument defaults to 1.  | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V4SyncReports**](V4SyncReports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv4TargetReport

> V4TargetReportsExtended GetSyncv4TargetReport(ctx, v4TargetReportId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4TargetReportId := "v4TargetReportId_example" // string | View a single SyncIQ target report.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv4TargetReport(context.Background(), v4TargetReportId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv4TargetReport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv4TargetReport`: V4TargetReportsExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv4TargetReport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4TargetReportId** | **string** | View a single SyncIQ target report. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv4TargetReportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V4TargetReportsExtended**](V4TargetReportsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv4TargetReports

> V4TargetReports GetSyncv4TargetReports(ctx).Sort(sort).Resume(resume).NewerThan(newerThan).PolicyName(policyName).State(state).Limit(limit).ReportsPerPolicy(reportsPerPolicy).Summary(summary).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    newerThan := int32(56) // int32 | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. (optional)
    policyName := "policyName_example" // string | Filter the returned reports to include only those with this policy name. (optional)
    state := "state_example" // string | Filter the returned reports to include only those whose jobs are in this state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    reportsPerPolicy := int32(56) // int32 | If specified, only the N most recent reports will be returned per policy.  If no other query args are present this argument defaults to 1.  (optional)
    summary := true // bool | Return a summary rather than entire objects. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv4TargetReports(context.Background()).Sort(sort).Resume(resume).NewerThan(newerThan).PolicyName(policyName).State(state).Limit(limit).ReportsPerPolicy(reportsPerPolicy).Summary(summary).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv4TargetReports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv4TargetReports`: V4TargetReports
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv4TargetReports`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv4TargetReportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **newerThan** | **int32** | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. | 
 **policyName** | **string** | Filter the returned reports to include only those with this policy name. | 
 **state** | **string** | Filter the returned reports to include only those whose jobs are in this state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **reportsPerPolicy** | **int32** | If specified, only the N most recent reports will be returned per policy.  If no other query args are present this argument defaults to 1.  | 
 **summary** | **bool** | Return a summary rather than entire objects. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V4TargetReports**](V4TargetReports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv4TargetReportsRidSubreport

> V4TargetReportsRidSubreports GetSyncv4TargetReportsRidSubreport(ctx, v4TargetReportsRidSubreportId, rid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4TargetReportsRidSubreportId := "v4TargetReportsRidSubreportId_example" // string | View a single SyncIQ target subreport.
    rid := "rid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv4TargetReportsRidSubreport(context.Background(), v4TargetReportsRidSubreportId, rid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv4TargetReportsRidSubreport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv4TargetReportsRidSubreport`: V4TargetReportsRidSubreports
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv4TargetReportsRidSubreport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4TargetReportsRidSubreportId** | **string** | View a single SyncIQ target subreport. | 
**rid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv4TargetReportsRidSubreportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V4TargetReportsRidSubreports**](V4TargetReportsRidSubreports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv5SyncLicense

> V5LicenseLicenseExtended GetSyncv5SyncLicense(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv5SyncLicense(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv5SyncLicense``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv5SyncLicense`: V5LicenseLicenseExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv5SyncLicense`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv5SyncLicenseRequest struct via the builder pattern


### Return type

[**V5LicenseLicenseExtended**](V5LicenseLicenseExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv7CertificatesPeerById

> V16CertificatesSyslogExtended GetSyncv7CertificatesPeerById(ctx, v7CertificatesPeerId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CertificatesPeerId := "v7CertificatesPeerId_example" // string | Retrieve a single trusted SyncIQ TLS certificate.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv7CertificatesPeerById(context.Background(), v7CertificatesPeerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv7CertificatesPeerById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv7CertificatesPeerById`: V16CertificatesSyslogExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv7CertificatesPeerById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7CertificatesPeerId** | **string** | Retrieve a single trusted SyncIQ TLS certificate. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv7CertificatesPeerByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V16CertificatesSyslogExtended**](V16CertificatesSyslogExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv7CertificatesServerById

> V4CertificateServerExtended GetSyncv7CertificatesServerById(ctx, v7CertificatesServerId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CertificatesServerId := "v7CertificatesServerId_example" // string | Retrieve a SyncIQ TLS server certificate.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv7CertificatesServerById(context.Background(), v7CertificatesServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv7CertificatesServerById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv7CertificatesServerById`: V4CertificateServerExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv7CertificatesServerById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7CertificatesServerId** | **string** | Retrieve a SyncIQ TLS server certificate. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv7CertificatesServerByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V4CertificateServerExtended**](V4CertificateServerExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv7HistoryNetwork

> V7HistoryNetwork GetSyncv7HistoryNetwork(ctx).RunningJobs(runningJobs).End(end).Start(start).PolicyId(policyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    runningJobs := true // bool | Receive network history for all currently running SyncIQ jobs. (optional)
    end := int32(56) // int32 | End timestamp for time-series report. (optional)
    start := int32(56) // int32 | Begin timestamp for time-series report. (optional)
    policyId := "policyId_example" // string | Receive network history for only the given policy. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv7HistoryNetwork(context.Background()).RunningJobs(runningJobs).End(end).Start(start).PolicyId(policyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv7HistoryNetwork``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv7HistoryNetwork`: V7HistoryNetwork
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv7HistoryNetwork`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv7HistoryNetworkRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **runningJobs** | **bool** | Receive network history for all currently running SyncIQ jobs. | 
 **end** | **int32** | End timestamp for time-series report. | 
 **start** | **int32** | Begin timestamp for time-series report. | 
 **policyId** | **string** | Receive network history for only the given policy. | 

### Return type

[**V7HistoryNetwork**](V7HistoryNetwork.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv7ReportsRidSubreport

> V7ReportsRidSubreports GetSyncv7ReportsRidSubreport(ctx, v7ReportsRidSubreportId, rid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ReportsRidSubreportId := "v7ReportsRidSubreportId_example" // string | View a single SyncIQ subreport.
    rid := "rid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv7ReportsRidSubreport(context.Background(), v7ReportsRidSubreportId, rid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv7ReportsRidSubreport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv7ReportsRidSubreport`: V7ReportsRidSubreports
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv7ReportsRidSubreport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ReportsRidSubreportId** | **string** | View a single SyncIQ subreport. | 
**rid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv7ReportsRidSubreportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V7ReportsRidSubreports**](V7ReportsRidSubreports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv7ServicePolicy

> V7ServicePoliciesExtended GetSyncv7ServicePolicy(ctx, v7ServicePolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ServicePolicyId := "v7ServicePolicyId_example" // string | View a single SyncIQ service replication policy.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv7ServicePolicy(context.Background(), v7ServicePolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv7ServicePolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv7ServicePolicy`: V7ServicePoliciesExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv7ServicePolicy`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ServicePolicyId** | **string** | View a single SyncIQ service replication policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv7ServicePolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7ServicePoliciesExtended**](V7ServicePoliciesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv7ServiceTargetPolicies

> V7ServiceTargetPolicies GetSyncv7ServiceTargetPolicies(ctx).Sort(sort).TargetPath(targetPath).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    targetPath := "targetPath_example" // string | Filter the returned policies to include only those with this target path. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv7ServiceTargetPolicies(context.Background()).Sort(sort).TargetPath(targetPath).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv7ServiceTargetPolicies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv7ServiceTargetPolicies`: V7ServiceTargetPolicies
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv7ServiceTargetPolicies`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv7ServiceTargetPoliciesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **targetPath** | **string** | Filter the returned policies to include only those with this target path. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V7ServiceTargetPolicies**](V7ServiceTargetPolicies.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv7ServiceTargetPolicy

> V7ServiceTargetPoliciesExtended GetSyncv7ServiceTargetPolicy(ctx, v7ServiceTargetPolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ServiceTargetPolicyId := "v7ServiceTargetPolicyId_example" // string | View a single SyncIQ target service replication policy.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv7ServiceTargetPolicy(context.Background(), v7ServiceTargetPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv7ServiceTargetPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv7ServiceTargetPolicy`: V7ServiceTargetPoliciesExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv7ServiceTargetPolicy`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ServiceTargetPolicyId** | **string** | View a single SyncIQ target service replication policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv7ServiceTargetPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7ServiceTargetPoliciesExtended**](V7ServiceTargetPoliciesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv7SyncJob

> V7SyncJobsExtended GetSyncv7SyncJob(ctx, v7SyncJobId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SyncJobId := "v7SyncJobId_example" // string | View a single SyncIQ job.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv7SyncJob(context.Background(), v7SyncJobId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv7SyncJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv7SyncJob`: V7SyncJobsExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv7SyncJob`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7SyncJobId** | **string** | View a single SyncIQ job. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv7SyncJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7SyncJobsExtended**](V7SyncJobsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv7SyncPolicy

> V7SyncPoliciesExtended GetSyncv7SyncPolicy(ctx, v7SyncPolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SyncPolicyId := "v7SyncPolicyId_example" // string | View a single SyncIQ policy.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv7SyncPolicy(context.Background(), v7SyncPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv7SyncPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv7SyncPolicy`: V7SyncPoliciesExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv7SyncPolicy`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7SyncPolicyId** | **string** | View a single SyncIQ policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv7SyncPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7SyncPoliciesExtended**](V7SyncPoliciesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv7SyncReport

> V7SyncReportsExtended GetSyncv7SyncReport(ctx, v7SyncReportId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SyncReportId := "v7SyncReportId_example" // string | View a single SyncIQ report.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv7SyncReport(context.Background(), v7SyncReportId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv7SyncReport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv7SyncReport`: V7SyncReportsExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv7SyncReport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7SyncReportId** | **string** | View a single SyncIQ report. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv7SyncReportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7SyncReportsExtended**](V7SyncReportsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv7SyncReports

> V7SyncReports GetSyncv7SyncReports(ctx).Sort(sort).Resume(resume).NewerThan(newerThan).PolicyName(policyName).State(state).Limit(limit).ReportsPerPolicy(reportsPerPolicy).Summary(summary).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    newerThan := int32(56) // int32 | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. (optional)
    policyName := "policyName_example" // string | Filter the returned reports to include only those with this policy name. (optional)
    state := "state_example" // string | Filter the returned reports to include only those whose jobs are in this state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    reportsPerPolicy := int32(56) // int32 | If specified, only the N most recent reports will be returned per policy.  If no other query args are present this argument defaults to 1.  (optional)
    summary := true // bool | Return a summary rather than entire objects (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv7SyncReports(context.Background()).Sort(sort).Resume(resume).NewerThan(newerThan).PolicyName(policyName).State(state).Limit(limit).ReportsPerPolicy(reportsPerPolicy).Summary(summary).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv7SyncReports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv7SyncReports`: V7SyncReports
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv7SyncReports`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv7SyncReportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **newerThan** | **int32** | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. | 
 **policyName** | **string** | Filter the returned reports to include only those with this policy name. | 
 **state** | **string** | Filter the returned reports to include only those whose jobs are in this state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **reportsPerPolicy** | **int32** | If specified, only the N most recent reports will be returned per policy.  If no other query args are present this argument defaults to 1.  | 
 **summary** | **bool** | Return a summary rather than entire objects | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V7SyncReports**](V7SyncReports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv7SyncSettings

> V7SyncSettings GetSyncv7SyncSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv7SyncSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv7SyncSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv7SyncSettings`: V7SyncSettings
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv7SyncSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv7SyncSettingsRequest struct via the builder pattern


### Return type

[**V7SyncSettings**](V7SyncSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv7TargetReport

> V7TargetReportsExtended GetSyncv7TargetReport(ctx, v7TargetReportId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7TargetReportId := "v7TargetReportId_example" // string | View a single SyncIQ target report.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv7TargetReport(context.Background(), v7TargetReportId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv7TargetReport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv7TargetReport`: V7TargetReportsExtended
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv7TargetReport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7TargetReportId** | **string** | View a single SyncIQ target report. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv7TargetReportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7TargetReportsExtended**](V7TargetReportsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv7TargetReports

> V7TargetReports GetSyncv7TargetReports(ctx).Sort(sort).Resume(resume).NewerThan(newerThan).PolicyName(policyName).State(state).Limit(limit).ReportsPerPolicy(reportsPerPolicy).Summary(summary).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    newerThan := int32(56) // int32 | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. (optional)
    policyName := "policyName_example" // string | Filter the returned reports to include only those with this policy name. (optional)
    state := "state_example" // string | Filter the returned reports to include only those whose jobs are in this state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    reportsPerPolicy := int32(56) // int32 | If specified, only the N most recent reports will be returned per policy.  If no other query args are present this argument defaults to 1.  (optional)
    summary := true // bool | Return a summary rather than entire objects. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv7TargetReports(context.Background()).Sort(sort).Resume(resume).NewerThan(newerThan).PolicyName(policyName).State(state).Limit(limit).ReportsPerPolicy(reportsPerPolicy).Summary(summary).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv7TargetReports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv7TargetReports`: V7TargetReports
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv7TargetReports`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv7TargetReportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **newerThan** | **int32** | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. | 
 **policyName** | **string** | Filter the returned reports to include only those with this policy name. | 
 **state** | **string** | Filter the returned reports to include only those whose jobs are in this state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **reportsPerPolicy** | **int32** | If specified, only the N most recent reports will be returned per policy.  If no other query args are present this argument defaults to 1.  | 
 **summary** | **bool** | Return a summary rather than entire objects. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V7TargetReports**](V7TargetReports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncv7TargetReportsRidSubreport

> V7TargetReportsRidSubreports GetSyncv7TargetReportsRidSubreport(ctx, v7TargetReportsRidSubreportId, rid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7TargetReportsRidSubreportId := "v7TargetReportsRidSubreportId_example" // string | View a single SyncIQ target subreport.
    rid := "rid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.GetSyncv7TargetReportsRidSubreport(context.Background(), v7TargetReportsRidSubreportId, rid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.GetSyncv7TargetReportsRidSubreport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncv7TargetReportsRidSubreport`: V7TargetReportsRidSubreports
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.GetSyncv7TargetReportsRidSubreport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7TargetReportsRidSubreportId** | **string** | View a single SyncIQ target subreport. | 
**rid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncv7TargetReportsRidSubreportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V7TargetReportsRidSubreports**](V7TargetReportsRidSubreports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSyncv14SyncPolicies

> V14SyncPolicies ListSyncv14SyncPolicies(ctx).Sort(sort).Resume(resume).Summary(summary).Limit(limit).Scope(scope).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    summary := true // bool | Return a summary rather than entire objects. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.ListSyncv14SyncPolicies(context.Background()).Sort(sort).Resume(resume).Summary(summary).Limit(limit).Scope(scope).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.ListSyncv14SyncPolicies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSyncv14SyncPolicies`: V14SyncPolicies
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.ListSyncv14SyncPolicies`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListSyncv14SyncPoliciesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **summary** | **bool** | Return a summary rather than entire objects. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V14SyncPolicies**](V14SyncPolicies.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSyncv15SyncJobs

> V15SyncJobs ListSyncv15SyncJobs(ctx).Sort(sort).State(state).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    state := "state_example" // string | The state of the job. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.ListSyncv15SyncJobs(context.Background()).Sort(sort).State(state).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.ListSyncv15SyncJobs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSyncv15SyncJobs`: V15SyncJobs
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.ListSyncv15SyncJobs`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListSyncv15SyncJobsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **state** | **string** | The state of the job. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V15SyncJobs**](V15SyncJobs.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSyncv1SyncJobs

> V1SyncJobs ListSyncv1SyncJobs(ctx).Sort(sort).State(state).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    state := "state_example" // string | The state of the job. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.ListSyncv1SyncJobs(context.Background()).Sort(sort).State(state).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.ListSyncv1SyncJobs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSyncv1SyncJobs`: V1SyncJobs
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.ListSyncv1SyncJobs`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListSyncv1SyncJobsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **state** | **string** | The state of the job. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1SyncJobs**](V1SyncJobs.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSyncv1SyncPolicies

> V1SyncPolicies ListSyncv1SyncPolicies(ctx).Sort(sort).Resume(resume).Summary(summary).Limit(limit).Scope(scope).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    summary := true // bool | Show only summary properties (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.ListSyncv1SyncPolicies(context.Background()).Sort(sort).Resume(resume).Summary(summary).Limit(limit).Scope(scope).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.ListSyncv1SyncPolicies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSyncv1SyncPolicies`: V1SyncPolicies
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.ListSyncv1SyncPolicies`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListSyncv1SyncPoliciesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **summary** | **bool** | Show only summary properties | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V1SyncPolicies**](V1SyncPolicies.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSyncv1SyncReportsRotate

> V1SyncReportsRotate ListSyncv1SyncReportsRotate(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.ListSyncv1SyncReportsRotate(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.ListSyncv1SyncReportsRotate``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSyncv1SyncReportsRotate`: V1SyncReportsRotate
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.ListSyncv1SyncReportsRotate`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListSyncv1SyncReportsRotateRequest struct via the builder pattern


### Return type

[**V1SyncReportsRotate**](V1SyncReportsRotate.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSyncv1SyncRules

> V1SyncRules ListSyncv1SyncRules(ctx).Sort(sort).Type_(type_).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    type_ := "type__example" // string | Filter the returned rules to include only those with this rule type. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.ListSyncv1SyncRules(context.Background()).Sort(sort).Type_(type_).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.ListSyncv1SyncRules``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSyncv1SyncRules`: V1SyncRules
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.ListSyncv1SyncRules`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListSyncv1SyncRulesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **type_** | **string** | Filter the returned rules to include only those with this rule type. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1SyncRules**](V1SyncRules.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSyncv3SyncJobs

> V3SyncJobs ListSyncv3SyncJobs(ctx).Sort(sort).State(state).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    state := "state_example" // string | The state of the job. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.ListSyncv3SyncJobs(context.Background()).Sort(sort).State(state).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.ListSyncv3SyncJobs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSyncv3SyncJobs`: V3SyncJobs
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.ListSyncv3SyncJobs`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListSyncv3SyncJobsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **state** | **string** | The state of the job. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3SyncJobs**](V3SyncJobs.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSyncv3SyncPolicies

> V3SyncPolicies ListSyncv3SyncPolicies(ctx).Sort(sort).Resume(resume).Summary(summary).Limit(limit).Scope(scope).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    summary := true // bool | Show only summary properties (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.ListSyncv3SyncPolicies(context.Background()).Sort(sort).Resume(resume).Summary(summary).Limit(limit).Scope(scope).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.ListSyncv3SyncPolicies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSyncv3SyncPolicies`: V3SyncPolicies
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.ListSyncv3SyncPolicies`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListSyncv3SyncPoliciesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **summary** | **bool** | Show only summary properties | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V3SyncPolicies**](V3SyncPolicies.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSyncv3SyncRules

> V3SyncRules ListSyncv3SyncRules(ctx).Sort(sort).Type_(type_).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    type_ := "type__example" // string | Filter the returned rules to include only those with this rule type. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.ListSyncv3SyncRules(context.Background()).Sort(sort).Type_(type_).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.ListSyncv3SyncRules``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSyncv3SyncRules`: V3SyncRules
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.ListSyncv3SyncRules`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListSyncv3SyncRulesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **type_** | **string** | Filter the returned rules to include only those with this rule type. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3SyncRules**](V3SyncRules.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSyncv7CertificatesPeer

> V7CertificatesPeer ListSyncv7CertificatesPeer(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.ListSyncv7CertificatesPeer(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.ListSyncv7CertificatesPeer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSyncv7CertificatesPeer`: V7CertificatesPeer
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.ListSyncv7CertificatesPeer`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListSyncv7CertificatesPeerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V7CertificatesPeer**](V7CertificatesPeer.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSyncv7CertificatesServer

> V7CertificatesServer ListSyncv7CertificatesServer(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.ListSyncv7CertificatesServer(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.ListSyncv7CertificatesServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSyncv7CertificatesServer`: V7CertificatesServer
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.ListSyncv7CertificatesServer`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListSyncv7CertificatesServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V7CertificatesServer**](V7CertificatesServer.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSyncv7ServicePolicies

> V7ServicePolicies ListSyncv7ServicePolicies(ctx).Sort(sort).Resume(resume).Summary(summary).Limit(limit).Scope(scope).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    summary := true // bool | Return a summary rather than entire objects. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.ListSyncv7ServicePolicies(context.Background()).Sort(sort).Resume(resume).Summary(summary).Limit(limit).Scope(scope).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.ListSyncv7ServicePolicies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSyncv7ServicePolicies`: V7ServicePolicies
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.ListSyncv7ServicePolicies`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListSyncv7ServicePoliciesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **summary** | **bool** | Return a summary rather than entire objects. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V7ServicePolicies**](V7ServicePolicies.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSyncv7SyncJobs

> V7SyncJobs ListSyncv7SyncJobs(ctx).Sort(sort).State(state).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    state := "state_example" // string | The state of the job. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.ListSyncv7SyncJobs(context.Background()).Sort(sort).State(state).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.ListSyncv7SyncJobs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSyncv7SyncJobs`: V7SyncJobs
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.ListSyncv7SyncJobs`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListSyncv7SyncJobsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **state** | **string** | The state of the job. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V7SyncJobs**](V7SyncJobs.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSyncv7SyncPolicies

> V7SyncPolicies ListSyncv7SyncPolicies(ctx).Sort(sort).Resume(resume).Summary(summary).Limit(limit).Scope(scope).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    summary := true // bool | Return a summary rather than entire objects. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncApi.ListSyncv7SyncPolicies(context.Background()).Sort(sort).Resume(resume).Summary(summary).Limit(limit).Scope(scope).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.ListSyncv7SyncPolicies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSyncv7SyncPolicies`: V7SyncPolicies
    fmt.Fprintf(os.Stdout, "Response from `SyncApi.ListSyncv7SyncPolicies`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListSyncv7SyncPoliciesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **summary** | **bool** | Return a summary rather than entire objects. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V7SyncPolicies**](V7SyncPolicies.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSyncv14SyncPolicy

> UpdateSyncv14SyncPolicy(ctx, v14SyncPolicyId).V14SyncPolicy(v14SyncPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14SyncPolicyId := "v14SyncPolicyId_example" // string | Modify a single SyncIQ policy.
    v14SyncPolicy := *openapiclient.NewV14SyncPolicyExtendedExtended() // V14SyncPolicyExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.UpdateSyncv14SyncPolicy(context.Background(), v14SyncPolicyId).V14SyncPolicy(v14SyncPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.UpdateSyncv14SyncPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v14SyncPolicyId** | **string** | Modify a single SyncIQ policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSyncv14SyncPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v14SyncPolicy** | [**V14SyncPolicyExtendedExtended**](V14SyncPolicyExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSyncv14SyncSettings

> UpdateSyncv14SyncSettings(ctx).V14SyncSettings(v14SyncSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14SyncSettings := *openapiclient.NewV14SyncSettingsExtended() // V14SyncSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.UpdateSyncv14SyncSettings(context.Background()).V14SyncSettings(v14SyncSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.UpdateSyncv14SyncSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSyncv14SyncSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v14SyncSettings** | [**V14SyncSettingsExtended**](V14SyncSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSyncv15SyncJob

> UpdateSyncv15SyncJob(ctx, v15SyncJobId).V15SyncJob(v15SyncJob).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15SyncJobId := "v15SyncJobId_example" // string | Perform an action (pause, cancel, etc...) on a single job.
    v15SyncJob := *openapiclient.NewV1SyncJobExtendedExtended("State_example") // V1SyncJobExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.UpdateSyncv15SyncJob(context.Background(), v15SyncJobId).V15SyncJob(v15SyncJob).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.UpdateSyncv15SyncJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15SyncJobId** | **string** | Perform an action (pause, cancel, etc...) on a single job. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSyncv15SyncJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v15SyncJob** | [**V1SyncJobExtendedExtended**](V1SyncJobExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSyncv16SyncSettings

> UpdateSyncv16SyncSettings(ctx).V16SyncSettings(v16SyncSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16SyncSettings := *openapiclient.NewV16SyncSettingsExtended() // V16SyncSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.UpdateSyncv16SyncSettings(context.Background()).V16SyncSettings(v16SyncSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.UpdateSyncv16SyncSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSyncv16SyncSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16SyncSettings** | [**V16SyncSettingsExtended**](V16SyncSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSyncv1SyncJob

> UpdateSyncv1SyncJob(ctx, v1SyncJobId).V1SyncJob(v1SyncJob).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SyncJobId := "v1SyncJobId_example" // string | Perform an action (pause, cancel, etc...) on a single job.
    v1SyncJob := *openapiclient.NewV1SyncJobExtendedExtended("State_example") // V1SyncJobExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.UpdateSyncv1SyncJob(context.Background(), v1SyncJobId).V1SyncJob(v1SyncJob).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.UpdateSyncv1SyncJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SyncJobId** | **string** | Perform an action (pause, cancel, etc...) on a single job. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSyncv1SyncJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1SyncJob** | [**V1SyncJobExtendedExtended**](V1SyncJobExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSyncv1SyncPolicy

> UpdateSyncv1SyncPolicy(ctx, v1SyncPolicyId).V1SyncPolicy(v1SyncPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SyncPolicyId := "v1SyncPolicyId_example" // string | Modify a single SyncIQ policy.
    v1SyncPolicy := *openapiclient.NewV1SyncPolicyExtendedExtended() // V1SyncPolicyExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.UpdateSyncv1SyncPolicy(context.Background(), v1SyncPolicyId).V1SyncPolicy(v1SyncPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.UpdateSyncv1SyncPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SyncPolicyId** | **string** | Modify a single SyncIQ policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSyncv1SyncPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1SyncPolicy** | [**V1SyncPolicyExtendedExtended**](V1SyncPolicyExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSyncv1SyncRule

> UpdateSyncv1SyncRule(ctx, v1SyncRuleId).V1SyncRule(v1SyncRule).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SyncRuleId := "v1SyncRuleId_example" // string | Modify a single SyncIQ performance rule.
    v1SyncRule := *openapiclient.NewV1SyncRuleExtendedExtended() // V1SyncRuleExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.UpdateSyncv1SyncRule(context.Background(), v1SyncRuleId).V1SyncRule(v1SyncRule).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.UpdateSyncv1SyncRule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SyncRuleId** | **string** | Modify a single SyncIQ performance rule. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSyncv1SyncRuleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1SyncRule** | [**V1SyncRuleExtendedExtended**](V1SyncRuleExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSyncv1SyncSettings

> UpdateSyncv1SyncSettings(ctx).V1SyncSettings(v1SyncSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SyncSettings := *openapiclient.NewV1SyncSettingsExtended() // V1SyncSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.UpdateSyncv1SyncSettings(context.Background()).V1SyncSettings(v1SyncSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.UpdateSyncv1SyncSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSyncv1SyncSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SyncSettings** | [**V1SyncSettingsExtended**](V1SyncSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSyncv3SyncJob

> UpdateSyncv3SyncJob(ctx, v3SyncJobId).V3SyncJob(v3SyncJob).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SyncJobId := "v3SyncJobId_example" // string | Perform an action (pause, cancel, etc...) on a single job.
    v3SyncJob := *openapiclient.NewV1SyncJobExtendedExtended("State_example") // V1SyncJobExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.UpdateSyncv3SyncJob(context.Background(), v3SyncJobId).V3SyncJob(v3SyncJob).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.UpdateSyncv3SyncJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3SyncJobId** | **string** | Perform an action (pause, cancel, etc...) on a single job. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSyncv3SyncJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3SyncJob** | [**V1SyncJobExtendedExtended**](V1SyncJobExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSyncv3SyncPolicy

> UpdateSyncv3SyncPolicy(ctx, v3SyncPolicyId).V3SyncPolicy(v3SyncPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SyncPolicyId := "v3SyncPolicyId_example" // string | Modify a single SyncIQ policy.
    v3SyncPolicy := *openapiclient.NewV3SyncPolicyExtendedExtended() // V3SyncPolicyExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.UpdateSyncv3SyncPolicy(context.Background(), v3SyncPolicyId).V3SyncPolicy(v3SyncPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.UpdateSyncv3SyncPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3SyncPolicyId** | **string** | Modify a single SyncIQ policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSyncv3SyncPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3SyncPolicy** | [**V3SyncPolicyExtendedExtended**](V3SyncPolicyExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSyncv3SyncRule

> UpdateSyncv3SyncRule(ctx, v3SyncRuleId).V3SyncRule(v3SyncRule).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SyncRuleId := "v3SyncRuleId_example" // string | Modify a single SyncIQ performance rule.
    v3SyncRule := *openapiclient.NewV3SyncRuleExtendedExtended() // V3SyncRuleExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.UpdateSyncv3SyncRule(context.Background(), v3SyncRuleId).V3SyncRule(v3SyncRule).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.UpdateSyncv3SyncRule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3SyncRuleId** | **string** | Modify a single SyncIQ performance rule. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSyncv3SyncRuleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3SyncRule** | [**V3SyncRuleExtendedExtended**](V3SyncRuleExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSyncv3SyncSettings

> UpdateSyncv3SyncSettings(ctx).V3SyncSettings(v3SyncSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SyncSettings := *openapiclient.NewV3SyncSettingsExtended() // V3SyncSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.UpdateSyncv3SyncSettings(context.Background()).V3SyncSettings(v3SyncSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.UpdateSyncv3SyncSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSyncv3SyncSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3SyncSettings** | [**V3SyncSettingsExtended**](V3SyncSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSyncv7CertificatesPeerById

> UpdateSyncv7CertificatesPeerById(ctx, v7CertificatesPeerId).V7CertificatesPeerIdParams(v7CertificatesPeerIdParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CertificatesPeerId := "v7CertificatesPeerId_example" // string | Modify a trusted SyncIQ TLS certificate.
    v7CertificatesPeerIdParams := *openapiclient.NewV16CertificatesSyslogIdParams() // V16CertificatesSyslogIdParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.UpdateSyncv7CertificatesPeerById(context.Background(), v7CertificatesPeerId).V7CertificatesPeerIdParams(v7CertificatesPeerIdParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.UpdateSyncv7CertificatesPeerById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7CertificatesPeerId** | **string** | Modify a trusted SyncIQ TLS certificate. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSyncv7CertificatesPeerByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7CertificatesPeerIdParams** | [**V16CertificatesSyslogIdParams**](V16CertificatesSyslogIdParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSyncv7CertificatesServerById

> UpdateSyncv7CertificatesServerById(ctx, v7CertificatesServerId).V7CertificatesServerIdParams(v7CertificatesServerIdParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CertificatesServerId := "v7CertificatesServerId_example" // string | Modify a SyncIQ TLS server certificate.
    v7CertificatesServerIdParams := *openapiclient.NewV16CertificatesSyslogIdParams() // V16CertificatesSyslogIdParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.UpdateSyncv7CertificatesServerById(context.Background(), v7CertificatesServerId).V7CertificatesServerIdParams(v7CertificatesServerIdParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.UpdateSyncv7CertificatesServerById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7CertificatesServerId** | **string** | Modify a SyncIQ TLS server certificate. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSyncv7CertificatesServerByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7CertificatesServerIdParams** | [**V16CertificatesSyslogIdParams**](V16CertificatesSyslogIdParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSyncv7ServicePolicy

> UpdateSyncv7ServicePolicy(ctx, v7ServicePolicyId).V7ServicePolicy(v7ServicePolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ServicePolicyId := "v7ServicePolicyId_example" // string | Modify a single SyncIQ service replication policy.
    v7ServicePolicy := *openapiclient.NewV7ServicePolicyExtendedExtended() // V7ServicePolicyExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.UpdateSyncv7ServicePolicy(context.Background(), v7ServicePolicyId).V7ServicePolicy(v7ServicePolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.UpdateSyncv7ServicePolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ServicePolicyId** | **string** | Modify a single SyncIQ service replication policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSyncv7ServicePolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7ServicePolicy** | [**V7ServicePolicyExtendedExtended**](V7ServicePolicyExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSyncv7SyncJob

> UpdateSyncv7SyncJob(ctx, v7SyncJobId).V7SyncJob(v7SyncJob).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SyncJobId := "v7SyncJobId_example" // string | Perform an action (pause, cancel, etc...) on a single job.
    v7SyncJob := *openapiclient.NewV1SyncJobExtendedExtended("State_example") // V1SyncJobExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.UpdateSyncv7SyncJob(context.Background(), v7SyncJobId).V7SyncJob(v7SyncJob).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.UpdateSyncv7SyncJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7SyncJobId** | **string** | Perform an action (pause, cancel, etc...) on a single job. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSyncv7SyncJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7SyncJob** | [**V1SyncJobExtendedExtended**](V1SyncJobExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSyncv7SyncPolicy

> UpdateSyncv7SyncPolicy(ctx, v7SyncPolicyId).V7SyncPolicy(v7SyncPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SyncPolicyId := "v7SyncPolicyId_example" // string | Modify a single SyncIQ policy.
    v7SyncPolicy := *openapiclient.NewV7SyncPolicyExtendedExtended() // V7SyncPolicyExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.UpdateSyncv7SyncPolicy(context.Background(), v7SyncPolicyId).V7SyncPolicy(v7SyncPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.UpdateSyncv7SyncPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7SyncPolicyId** | **string** | Modify a single SyncIQ policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSyncv7SyncPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7SyncPolicy** | [**V7SyncPolicyExtendedExtended**](V7SyncPolicyExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSyncv7SyncSettings

> UpdateSyncv7SyncSettings(ctx).V7SyncSettings(v7SyncSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SyncSettings := *openapiclient.NewV7SyncSettingsExtended() // V7SyncSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SyncApi.UpdateSyncv7SyncSettings(context.Background()).V7SyncSettings(v7SyncSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncApi.UpdateSyncv7SyncSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSyncv7SyncSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7SyncSettings** | [**V7SyncSettingsExtended**](V7SyncSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

