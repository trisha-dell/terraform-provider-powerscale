# V12ClusterDrainList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Lnns** | Pointer to **[]int32** | List of nodes in the delay or skip list. | [optional] 

## Methods

### NewV12ClusterDrainList

`func NewV12ClusterDrainList() *V12ClusterDrainList`

NewV12ClusterDrainList instantiates a new V12ClusterDrainList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12ClusterDrainListWithDefaults

`func NewV12ClusterDrainListWithDefaults() *V12ClusterDrainList`

NewV12ClusterDrainListWithDefaults instantiates a new V12ClusterDrainList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetLnns

`func (o *V12ClusterDrainList) GetLnns() []int32`

GetLnns returns the Lnns field if non-nil, zero value otherwise.

### GetLnnsOk

`func (o *V12ClusterDrainList) GetLnnsOk() (*[]int32, bool)`

GetLnnsOk returns a tuple with the Lnns field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnns

`func (o *V12ClusterDrainList) SetLnns(v []int32)`

SetLnns sets Lnns field to given value.

### HasLnns

`func (o *V12ClusterDrainList) HasLnns() bool`

HasLnns returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


