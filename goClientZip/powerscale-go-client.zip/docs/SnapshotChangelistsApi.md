# \SnapshotChangelistsApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetSnapshotChangelistsv10ChangelistEntries**](SnapshotChangelistsApi.md#GetSnapshotChangelistsv10ChangelistEntries) | **Get** /platform/10/snapshot/changelists/{Changelist}/entries | 
[**GetSnapshotChangelistsv1ChangelistLins**](SnapshotChangelistsApi.md#GetSnapshotChangelistsv1ChangelistLins) | **Get** /platform/1/snapshot/changelists/{Changelist}/lins | 
[**GetSnapshotChangelistsv8ChangelistEntries**](SnapshotChangelistsApi.md#GetSnapshotChangelistsv8ChangelistEntries) | **Get** /platform/8/snapshot/changelists/{Changelist}/entries | 



## GetSnapshotChangelistsv10ChangelistEntries

> V10ChangelistEntries GetSnapshotChangelistsv10ChangelistEntries(ctx, changelist).DiffRegions(diffRegions).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    changelist := "changelist_example" // string | 
    diffRegions := true // bool | Include snapshot diff regions in entry output. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotChangelistsApi.GetSnapshotChangelistsv10ChangelistEntries(context.Background(), changelist).DiffRegions(diffRegions).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotChangelistsApi.GetSnapshotChangelistsv10ChangelistEntries``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotChangelistsv10ChangelistEntries`: V10ChangelistEntries
    fmt.Fprintf(os.Stdout, "Response from `SnapshotChangelistsApi.GetSnapshotChangelistsv10ChangelistEntries`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**changelist** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotChangelistsv10ChangelistEntriesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **diffRegions** | **bool** | Include snapshot diff regions in entry output. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V10ChangelistEntries**](V10ChangelistEntries.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshotChangelistsv1ChangelistLins

> V1ChangelistLins GetSnapshotChangelistsv1ChangelistLins(ctx, changelist).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    changelist := "changelist_example" // string | 
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotChangelistsApi.GetSnapshotChangelistsv1ChangelistLins(context.Background(), changelist).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotChangelistsApi.GetSnapshotChangelistsv1ChangelistLins``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotChangelistsv1ChangelistLins`: V1ChangelistLins
    fmt.Fprintf(os.Stdout, "Response from `SnapshotChangelistsApi.GetSnapshotChangelistsv1ChangelistLins`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**changelist** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotChangelistsv1ChangelistLinsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1ChangelistLins**](V1ChangelistLins.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshotChangelistsv8ChangelistEntries

> V8ChangelistEntries GetSnapshotChangelistsv8ChangelistEntries(ctx, changelist).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    changelist := "changelist_example" // string | 
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotChangelistsApi.GetSnapshotChangelistsv8ChangelistEntries(context.Background(), changelist).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotChangelistsApi.GetSnapshotChangelistsv8ChangelistEntries``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotChangelistsv8ChangelistEntries`: V8ChangelistEntries
    fmt.Fprintf(os.Stdout, "Response from `SnapshotChangelistsApi.GetSnapshotChangelistsv8ChangelistEntries`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**changelist** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotChangelistsv8ChangelistEntriesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V8ChangelistEntries**](V8ChangelistEntries.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

