# \LicenseApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateLicensev11LicenseActivationItem**](LicenseApi.md#CreateLicensev11LicenseActivationItem) | **Post** /platform/11/license/activation | 
[**CreateLicensev1LicenseLicense**](LicenseApi.md#CreateLicensev1LicenseLicense) | **Post** /platform/1/license/licenses | 
[**CreateLicensev5LicenseLicense**](LicenseApi.md#CreateLicensev5LicenseLicense) | **Post** /platform/5/license/licenses | 
[**GetLicensev1LicenseLicense**](LicenseApi.md#GetLicensev1LicenseLicense) | **Get** /platform/1/license/licenses/{v1LicenseLicenseId} | 
[**GetLicensev5LicenseGenerate**](LicenseApi.md#GetLicensev5LicenseGenerate) | **Get** /platform/5/license/generate | 
[**GetLicensev5LicenseLicense**](LicenseApi.md#GetLicensev5LicenseLicense) | **Get** /platform/5/license/licenses/{v5LicenseLicenseId} | 
[**ListLicensev11LicenseActivation**](LicenseApi.md#ListLicensev11LicenseActivation) | **Get** /platform/11/license/activation | 
[**ListLicensev1LicenseLicenses**](LicenseApi.md#ListLicensev1LicenseLicenses) | **Get** /platform/1/license/licenses | 
[**ListLicensev5LicenseLicenses**](LicenseApi.md#ListLicensev5LicenseLicenses) | **Get** /platform/5/license/licenses | 



## CreateLicensev11LicenseActivationItem

> CreateLicensev11LicenseActivationItem(ctx).V11LicenseActivationItem(v11LicenseActivationItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11LicenseActivationItem := *openapiclient.NewV11LicenseActivationItem() // V11LicenseActivationItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.LicenseApi.CreateLicensev11LicenseActivationItem(context.Background()).V11LicenseActivationItem(v11LicenseActivationItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `LicenseApi.CreateLicensev11LicenseActivationItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateLicensev11LicenseActivationItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v11LicenseActivationItem** | [**V11LicenseActivationItem**](V11LicenseActivationItem.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateLicensev1LicenseLicense

> CreateLicensev1LicenseLicense(ctx).V1LicenseLicense(v1LicenseLicense).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1LicenseLicense := *openapiclient.NewV1LicenseLicense("Key_example") // V1LicenseLicense | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.LicenseApi.CreateLicensev1LicenseLicense(context.Background()).V1LicenseLicense(v1LicenseLicense).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `LicenseApi.CreateLicensev1LicenseLicense``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateLicensev1LicenseLicenseRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1LicenseLicense** | [**V1LicenseLicense**](V1LicenseLicense.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateLicensev5LicenseLicense

> map[string]interface{} CreateLicensev5LicenseLicense(ctx).V5LicenseLicense(v5LicenseLicense).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v5LicenseLicense := *openapiclient.NewV5LicenseLicense() // V5LicenseLicense | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.LicenseApi.CreateLicensev5LicenseLicense(context.Background()).V5LicenseLicense(v5LicenseLicense).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `LicenseApi.CreateLicensev5LicenseLicense``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateLicensev5LicenseLicense`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `LicenseApi.CreateLicensev5LicenseLicense`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateLicensev5LicenseLicenseRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v5LicenseLicense** | [**V5LicenseLicense**](V5LicenseLicense.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetLicensev1LicenseLicense

> V1LicenseLicenses GetLicensev1LicenseLicense(ctx, v1LicenseLicenseId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1LicenseLicenseId := "v1LicenseLicenseId_example" // string | Retrieve license information for the feature.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.LicenseApi.GetLicensev1LicenseLicense(context.Background(), v1LicenseLicenseId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `LicenseApi.GetLicensev1LicenseLicense``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetLicensev1LicenseLicense`: V1LicenseLicenses
    fmt.Fprintf(os.Stdout, "Response from `LicenseApi.GetLicensev1LicenseLicense`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1LicenseLicenseId** | **string** | Retrieve license information for the feature. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetLicensev1LicenseLicenseRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1LicenseLicenses**](V1LicenseLicenses.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetLicensev5LicenseGenerate

> V5LicenseGenerate GetLicensev5LicenseGenerate(ctx).Action(action).LicensesToInclude(licensesToInclude).LicensesToExclude(licensesToExclude).OnlyTheseLicenses(onlyTheseLicenses).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    action := "action_example" // string | enum: license_list_only (default), generate_activation, download_activation. Generate an activation file or return a list of activated licenses. If generating an activation file and no licenses are specified, the default configuration is to generate an activation file with the current set of licensed features. download_activation returns HTTP headers and the same XML content as seen in the response activation. (optional) (default to "license_list_only")
    licensesToInclude := "licensesToInclude_example" // string | Licenses to include in activation file. (optional)
    licensesToExclude := "licensesToExclude_example" // string | Licenses to omit from activation file. (optional)
    onlyTheseLicenses := "onlyTheseLicenses_example" // string | Activate only the defined licenses. This setting overrides all other license activation settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.LicenseApi.GetLicensev5LicenseGenerate(context.Background()).Action(action).LicensesToInclude(licensesToInclude).LicensesToExclude(licensesToExclude).OnlyTheseLicenses(onlyTheseLicenses).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `LicenseApi.GetLicensev5LicenseGenerate``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetLicensev5LicenseGenerate`: V5LicenseGenerate
    fmt.Fprintf(os.Stdout, "Response from `LicenseApi.GetLicensev5LicenseGenerate`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetLicensev5LicenseGenerateRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **action** | **string** | enum: license_list_only (default), generate_activation, download_activation. Generate an activation file or return a list of activated licenses. If generating an activation file and no licenses are specified, the default configuration is to generate an activation file with the current set of licensed features. download_activation returns HTTP headers and the same XML content as seen in the response activation. | [default to &quot;license_list_only&quot;]
 **licensesToInclude** | **string** | Licenses to include in activation file. | 
 **licensesToExclude** | **string** | Licenses to omit from activation file. | 
 **onlyTheseLicenses** | **string** | Activate only the defined licenses. This setting overrides all other license activation settings. | 

### Return type

[**V5LicenseGenerate**](V5LicenseGenerate.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetLicensev5LicenseLicense

> V5LicenseLicensesExtended GetLicensev5LicenseLicense(ctx, v5LicenseLicenseId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v5LicenseLicenseId := "v5LicenseLicenseId_example" // string | Retrieve license information for the feature.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.LicenseApi.GetLicensev5LicenseLicense(context.Background(), v5LicenseLicenseId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `LicenseApi.GetLicensev5LicenseLicense``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetLicensev5LicenseLicense`: V5LicenseLicensesExtended
    fmt.Fprintf(os.Stdout, "Response from `LicenseApi.GetLicensev5LicenseLicense`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v5LicenseLicenseId** | **string** | Retrieve license information for the feature. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetLicensev5LicenseLicenseRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V5LicenseLicensesExtended**](V5LicenseLicensesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListLicensev11LicenseActivation

> V11LicenseActivation ListLicensev11LicenseActivation(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.LicenseApi.ListLicensev11LicenseActivation(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `LicenseApi.ListLicensev11LicenseActivation``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListLicensev11LicenseActivation`: V11LicenseActivation
    fmt.Fprintf(os.Stdout, "Response from `LicenseApi.ListLicensev11LicenseActivation`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListLicensev11LicenseActivationRequest struct via the builder pattern


### Return type

[**V11LicenseActivation**](V11LicenseActivation.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListLicensev1LicenseLicenses

> V1LicenseLicenses ListLicensev1LicenseLicenses(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.LicenseApi.ListLicensev1LicenseLicenses(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `LicenseApi.ListLicensev1LicenseLicenses``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListLicensev1LicenseLicenses`: V1LicenseLicenses
    fmt.Fprintf(os.Stdout, "Response from `LicenseApi.ListLicensev1LicenseLicenses`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListLicensev1LicenseLicensesRequest struct via the builder pattern


### Return type

[**V1LicenseLicenses**](V1LicenseLicenses.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListLicensev5LicenseLicenses

> V5LicenseLicenses ListLicensev5LicenseLicenses(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.LicenseApi.ListLicensev5LicenseLicenses(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `LicenseApi.ListLicensev5LicenseLicenses``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListLicensev5LicenseLicenses`: V5LicenseLicenses
    fmt.Fprintf(os.Stdout, "Response from `LicenseApi.ListLicensev5LicenseLicenses`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListLicensev5LicenseLicensesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V5LicenseLicenses**](V5LicenseLicenses.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

