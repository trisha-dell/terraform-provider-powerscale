# V10PerformanceMetrics

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Metrics** | Pointer to [**[]V10PerformanceMetric**](V10PerformanceMetric.md) |  | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV10PerformanceMetrics

`func NewV10PerformanceMetrics() *V10PerformanceMetrics`

NewV10PerformanceMetrics instantiates a new V10PerformanceMetrics object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10PerformanceMetricsWithDefaults

`func NewV10PerformanceMetricsWithDefaults() *V10PerformanceMetrics`

NewV10PerformanceMetricsWithDefaults instantiates a new V10PerformanceMetrics object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMetrics

`func (o *V10PerformanceMetrics) GetMetrics() []V10PerformanceMetric`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *V10PerformanceMetrics) GetMetricsOk() (*[]V10PerformanceMetric, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *V10PerformanceMetrics) SetMetrics(v []V10PerformanceMetric)`

SetMetrics sets Metrics field to given value.

### HasMetrics

`func (o *V10PerformanceMetrics) HasMetrics() bool`

HasMetrics returns a boolean if a field has been set.

### GetTotal

`func (o *V10PerformanceMetrics) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V10PerformanceMetrics) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V10PerformanceMetrics) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V10PerformanceMetrics) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


