# V10ConfigNetwork

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Network** | Pointer to [**V10ConfigNetworkNetwork**](V10ConfigNetworkNetwork.md) |  | [optional] 

## Methods

### NewV10ConfigNetwork

`func NewV10ConfigNetwork() *V10ConfigNetwork`

NewV10ConfigNetwork instantiates a new V10ConfigNetwork object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ConfigNetworkWithDefaults

`func NewV10ConfigNetworkWithDefaults() *V10ConfigNetwork`

NewV10ConfigNetworkWithDefaults instantiates a new V10ConfigNetwork object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNetwork

`func (o *V10ConfigNetwork) GetNetwork() V10ConfigNetworkNetwork`

GetNetwork returns the Network field if non-nil, zero value otherwise.

### GetNetworkOk

`func (o *V10ConfigNetwork) GetNetworkOk() (*V10ConfigNetworkNetwork, bool)`

GetNetworkOk returns a tuple with the Network field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetwork

`func (o *V10ConfigNetwork) SetNetwork(v V10ConfigNetworkNetwork)`

SetNetwork sets Network field to given value.

### HasNetwork

`func (o *V10ConfigNetwork) HasNetwork() bool`

HasNetwork returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


