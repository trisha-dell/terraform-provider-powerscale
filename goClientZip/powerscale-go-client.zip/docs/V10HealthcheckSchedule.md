# V10HealthcheckSchedule

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Checklist** | **[]string** | Checklists or Items for scheduling. | 
**Id** | Pointer to **string** | The ID of the newly created schedule. | [optional] 
**Name** | **string** | The schedule name. | 
**Schedule** | **string** | The isi-schedule compatible natural language description of the schedule. | 

## Methods

### NewV10HealthcheckSchedule

`func NewV10HealthcheckSchedule(checklist []string, name string, schedule string, ) *V10HealthcheckSchedule`

NewV10HealthcheckSchedule instantiates a new V10HealthcheckSchedule object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10HealthcheckScheduleWithDefaults

`func NewV10HealthcheckScheduleWithDefaults() *V10HealthcheckSchedule`

NewV10HealthcheckScheduleWithDefaults instantiates a new V10HealthcheckSchedule object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetChecklist

`func (o *V10HealthcheckSchedule) GetChecklist() []string`

GetChecklist returns the Checklist field if non-nil, zero value otherwise.

### GetChecklistOk

`func (o *V10HealthcheckSchedule) GetChecklistOk() (*[]string, bool)`

GetChecklistOk returns a tuple with the Checklist field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChecklist

`func (o *V10HealthcheckSchedule) SetChecklist(v []string)`

SetChecklist sets Checklist field to given value.


### GetId

`func (o *V10HealthcheckSchedule) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V10HealthcheckSchedule) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V10HealthcheckSchedule) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V10HealthcheckSchedule) HasId() bool`

HasId returns a boolean if a field has been set.

### GetName

`func (o *V10HealthcheckSchedule) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V10HealthcheckSchedule) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V10HealthcheckSchedule) SetName(v string)`

SetName sets Name field to given value.


### GetSchedule

`func (o *V10HealthcheckSchedule) GetSchedule() string`

GetSchedule returns the Schedule field if non-nil, zero value otherwise.

### GetScheduleOk

`func (o *V10HealthcheckSchedule) GetScheduleOk() (*string, bool)`

GetScheduleOk returns a tuple with the Schedule field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSchedule

`func (o *V10HealthcheckSchedule) SetSchedule(v string)`

SetSchedule sets Schedule field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


