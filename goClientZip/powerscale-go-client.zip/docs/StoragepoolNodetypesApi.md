# \StoragepoolNodetypesApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetStoragepoolNodetypesv10NodetypeAssess**](StoragepoolNodetypesApi.md#GetStoragepoolNodetypesv10NodetypeAssess) | **Get** /platform/10/storagepool/nodetypes/{Nid}/assess | 
[**GetStoragepoolNodetypesv12NodetypeAssess**](StoragepoolNodetypesApi.md#GetStoragepoolNodetypesv12NodetypeAssess) | **Get** /platform/12/storagepool/nodetypes/{Nid}/assess | 



## GetStoragepoolNodetypesv10NodetypeAssess

> V10NodetypeAssess GetStoragepoolNodetypesv10NodetypeAssess(ctx, nid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    nid := "nid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolNodetypesApi.GetStoragepoolNodetypesv10NodetypeAssess(context.Background(), nid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolNodetypesApi.GetStoragepoolNodetypesv10NodetypeAssess``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStoragepoolNodetypesv10NodetypeAssess`: V10NodetypeAssess
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolNodetypesApi.GetStoragepoolNodetypesv10NodetypeAssess`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**nid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetStoragepoolNodetypesv10NodetypeAssessRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V10NodetypeAssess**](V10NodetypeAssess.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStoragepoolNodetypesv12NodetypeAssess

> V12NodetypeAssess GetStoragepoolNodetypesv12NodetypeAssess(ctx, nid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    nid := "nid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolNodetypesApi.GetStoragepoolNodetypesv12NodetypeAssess(context.Background(), nid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolNodetypesApi.GetStoragepoolNodetypesv12NodetypeAssess``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStoragepoolNodetypesv12NodetypeAssess`: V12NodetypeAssess
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolNodetypesApi.GetStoragepoolNodetypesv12NodetypeAssess`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**nid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetStoragepoolNodetypesv12NodetypeAssessRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V12NodetypeAssess**](V12NodetypeAssess.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

