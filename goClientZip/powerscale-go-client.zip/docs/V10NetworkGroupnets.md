# V10NetworkGroupnets

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Groupnets** | Pointer to [**[]V10NetworkGroupnetExtended**](V10NetworkGroupnetExtended.md) |  | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV10NetworkGroupnets

`func NewV10NetworkGroupnets() *V10NetworkGroupnets`

NewV10NetworkGroupnets instantiates a new V10NetworkGroupnets object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10NetworkGroupnetsWithDefaults

`func NewV10NetworkGroupnetsWithDefaults() *V10NetworkGroupnets`

NewV10NetworkGroupnetsWithDefaults instantiates a new V10NetworkGroupnets object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetGroupnets

`func (o *V10NetworkGroupnets) GetGroupnets() []V10NetworkGroupnetExtended`

GetGroupnets returns the Groupnets field if non-nil, zero value otherwise.

### GetGroupnetsOk

`func (o *V10NetworkGroupnets) GetGroupnetsOk() (*[]V10NetworkGroupnetExtended, bool)`

GetGroupnetsOk returns a tuple with the Groupnets field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupnets

`func (o *V10NetworkGroupnets) SetGroupnets(v []V10NetworkGroupnetExtended)`

SetGroupnets sets Groupnets field to given value.

### HasGroupnets

`func (o *V10NetworkGroupnets) HasGroupnets() bool`

HasGroupnets returns a boolean if a field has been set.

### GetResume

`func (o *V10NetworkGroupnets) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V10NetworkGroupnets) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V10NetworkGroupnets) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V10NetworkGroupnets) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V10NetworkGroupnets) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V10NetworkGroupnets) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V10NetworkGroupnets) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V10NetworkGroupnets) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


