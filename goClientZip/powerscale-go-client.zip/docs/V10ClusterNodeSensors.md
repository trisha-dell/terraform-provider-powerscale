# V10ClusterNodeSensors

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Sensors** | Pointer to [**[]V10ClusterNodeSensor**](V10ClusterNodeSensor.md) | This node&#39;s sensor information. | [optional] 

## Methods

### NewV10ClusterNodeSensors

`func NewV10ClusterNodeSensors() *V10ClusterNodeSensors`

NewV10ClusterNodeSensors instantiates a new V10ClusterNodeSensors object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeSensorsWithDefaults

`func NewV10ClusterNodeSensorsWithDefaults() *V10ClusterNodeSensors`

NewV10ClusterNodeSensorsWithDefaults instantiates a new V10ClusterNodeSensors object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSensors

`func (o *V10ClusterNodeSensors) GetSensors() []V10ClusterNodeSensor`

GetSensors returns the Sensors field if non-nil, zero value otherwise.

### GetSensorsOk

`func (o *V10ClusterNodeSensors) GetSensorsOk() (*[]V10ClusterNodeSensor, bool)`

GetSensorsOk returns a tuple with the Sensors field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSensors

`func (o *V10ClusterNodeSensors) SetSensors(v []V10ClusterNodeSensor)`

SetSensors sets Sensors field to given value.

### HasSensors

`func (o *V10ClusterNodeSensors) HasSensors() bool`

HasSensors returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


