# \SyncServiceTargetApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateSyncServiceTargetv7PoliciesPolicyCancelItem**](SyncServiceTargetApi.md#CreateSyncServiceTargetv7PoliciesPolicyCancelItem) | **Post** /platform/7/sync/service/target/policies/{Policy}/cancel | 



## CreateSyncServiceTargetv7PoliciesPolicyCancelItem

> CreateResponse CreateSyncServiceTargetv7PoliciesPolicyCancelItem(ctx, policy).V7PoliciesPolicyCancelItem(v7PoliciesPolicyCancelItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    policy := "policy_example" // string | 
    v7PoliciesPolicyCancelItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncServiceTargetApi.CreateSyncServiceTargetv7PoliciesPolicyCancelItem(context.Background(), policy).V7PoliciesPolicyCancelItem(v7PoliciesPolicyCancelItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncServiceTargetApi.CreateSyncServiceTargetv7PoliciesPolicyCancelItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSyncServiceTargetv7PoliciesPolicyCancelItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `SyncServiceTargetApi.CreateSyncServiceTargetv7PoliciesPolicyCancelItem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**policy** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateSyncServiceTargetv7PoliciesPolicyCancelItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7PoliciesPolicyCancelItem** | **map[string]interface{}** |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

