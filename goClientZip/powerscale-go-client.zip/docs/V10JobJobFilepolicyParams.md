# V10JobJobFilepolicyParams

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DirectoryOnly** | Pointer to **bool** | Skip processing of regular files. | [optional] 
**Nop** | Pointer to **bool** | Calculate what would be done (dry run). | [optional] 
**PolicyOnly** | Pointer to **bool** | Apply policies but skip restriping. | [optional] 

## Methods

### NewV10JobJobFilepolicyParams

`func NewV10JobJobFilepolicyParams() *V10JobJobFilepolicyParams`

NewV10JobJobFilepolicyParams instantiates a new V10JobJobFilepolicyParams object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10JobJobFilepolicyParamsWithDefaults

`func NewV10JobJobFilepolicyParamsWithDefaults() *V10JobJobFilepolicyParams`

NewV10JobJobFilepolicyParamsWithDefaults instantiates a new V10JobJobFilepolicyParams object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDirectoryOnly

`func (o *V10JobJobFilepolicyParams) GetDirectoryOnly() bool`

GetDirectoryOnly returns the DirectoryOnly field if non-nil, zero value otherwise.

### GetDirectoryOnlyOk

`func (o *V10JobJobFilepolicyParams) GetDirectoryOnlyOk() (*bool, bool)`

GetDirectoryOnlyOk returns a tuple with the DirectoryOnly field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDirectoryOnly

`func (o *V10JobJobFilepolicyParams) SetDirectoryOnly(v bool)`

SetDirectoryOnly sets DirectoryOnly field to given value.

### HasDirectoryOnly

`func (o *V10JobJobFilepolicyParams) HasDirectoryOnly() bool`

HasDirectoryOnly returns a boolean if a field has been set.

### GetNop

`func (o *V10JobJobFilepolicyParams) GetNop() bool`

GetNop returns the Nop field if non-nil, zero value otherwise.

### GetNopOk

`func (o *V10JobJobFilepolicyParams) GetNopOk() (*bool, bool)`

GetNopOk returns a tuple with the Nop field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNop

`func (o *V10JobJobFilepolicyParams) SetNop(v bool)`

SetNop sets Nop field to given value.

### HasNop

`func (o *V10JobJobFilepolicyParams) HasNop() bool`

HasNop returns a boolean if a field has been set.

### GetPolicyOnly

`func (o *V10JobJobFilepolicyParams) GetPolicyOnly() bool`

GetPolicyOnly returns the PolicyOnly field if non-nil, zero value otherwise.

### GetPolicyOnlyOk

`func (o *V10JobJobFilepolicyParams) GetPolicyOnlyOk() (*bool, bool)`

GetPolicyOnlyOk returns a tuple with the PolicyOnly field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPolicyOnly

`func (o *V10JobJobFilepolicyParams) SetPolicyOnly(v bool)`

SetPolicyOnly sets PolicyOnly field to given value.

### HasPolicyOnly

`func (o *V10JobJobFilepolicyParams) HasPolicyOnly() bool`

HasPolicyOnly returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


