# V12ConfigExportExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Done** | Pointer to **string** | All finished components. | [optional] 
**Failed** | Pointer to **string** | All failed components. | [optional] 
**Id** | Pointer to **string** | The export ID given to the task. | [optional] 
**Message** | Pointer to **string** | Message of job. | [optional] 
**Path** | Pointer to **string** | The path where export job&#39;s result is stored. | [optional] 
**Pending** | Pointer to **string** | All components to be exported. | [optional] 
**Status** | Pointer to **string** | The status of the job. | [optional] 

## Methods

### NewV12ConfigExportExtended

`func NewV12ConfigExportExtended() *V12ConfigExportExtended`

NewV12ConfigExportExtended instantiates a new V12ConfigExportExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12ConfigExportExtendedWithDefaults

`func NewV12ConfigExportExtendedWithDefaults() *V12ConfigExportExtended`

NewV12ConfigExportExtendedWithDefaults instantiates a new V12ConfigExportExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDone

`func (o *V12ConfigExportExtended) GetDone() string`

GetDone returns the Done field if non-nil, zero value otherwise.

### GetDoneOk

`func (o *V12ConfigExportExtended) GetDoneOk() (*string, bool)`

GetDoneOk returns a tuple with the Done field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDone

`func (o *V12ConfigExportExtended) SetDone(v string)`

SetDone sets Done field to given value.

### HasDone

`func (o *V12ConfigExportExtended) HasDone() bool`

HasDone returns a boolean if a field has been set.

### GetFailed

`func (o *V12ConfigExportExtended) GetFailed() string`

GetFailed returns the Failed field if non-nil, zero value otherwise.

### GetFailedOk

`func (o *V12ConfigExportExtended) GetFailedOk() (*string, bool)`

GetFailedOk returns a tuple with the Failed field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFailed

`func (o *V12ConfigExportExtended) SetFailed(v string)`

SetFailed sets Failed field to given value.

### HasFailed

`func (o *V12ConfigExportExtended) HasFailed() bool`

HasFailed returns a boolean if a field has been set.

### GetId

`func (o *V12ConfigExportExtended) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12ConfigExportExtended) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12ConfigExportExtended) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V12ConfigExportExtended) HasId() bool`

HasId returns a boolean if a field has been set.

### GetMessage

`func (o *V12ConfigExportExtended) GetMessage() string`

GetMessage returns the Message field if non-nil, zero value otherwise.

### GetMessageOk

`func (o *V12ConfigExportExtended) GetMessageOk() (*string, bool)`

GetMessageOk returns a tuple with the Message field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMessage

`func (o *V12ConfigExportExtended) SetMessage(v string)`

SetMessage sets Message field to given value.

### HasMessage

`func (o *V12ConfigExportExtended) HasMessage() bool`

HasMessage returns a boolean if a field has been set.

### GetPath

`func (o *V12ConfigExportExtended) GetPath() string`

GetPath returns the Path field if non-nil, zero value otherwise.

### GetPathOk

`func (o *V12ConfigExportExtended) GetPathOk() (*string, bool)`

GetPathOk returns a tuple with the Path field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPath

`func (o *V12ConfigExportExtended) SetPath(v string)`

SetPath sets Path field to given value.

### HasPath

`func (o *V12ConfigExportExtended) HasPath() bool`

HasPath returns a boolean if a field has been set.

### GetPending

`func (o *V12ConfigExportExtended) GetPending() string`

GetPending returns the Pending field if non-nil, zero value otherwise.

### GetPendingOk

`func (o *V12ConfigExportExtended) GetPendingOk() (*string, bool)`

GetPendingOk returns a tuple with the Pending field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPending

`func (o *V12ConfigExportExtended) SetPending(v string)`

SetPending sets Pending field to given value.

### HasPending

`func (o *V12ConfigExportExtended) HasPending() bool`

HasPending returns a boolean if a field has been set.

### GetStatus

`func (o *V12ConfigExportExtended) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V12ConfigExportExtended) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V12ConfigExportExtended) SetStatus(v string)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V12ConfigExportExtended) HasStatus() bool`

HasStatus returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


