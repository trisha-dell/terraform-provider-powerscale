# V12EventSuppress

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Suppressions** | Pointer to [**[]V12EventSuppressSuppression**](V12EventSuppressSuppression.md) |  | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV12EventSuppress

`func NewV12EventSuppress() *V12EventSuppress`

NewV12EventSuppress instantiates a new V12EventSuppress object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12EventSuppressWithDefaults

`func NewV12EventSuppressWithDefaults() *V12EventSuppress`

NewV12EventSuppressWithDefaults instantiates a new V12EventSuppress object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetResume

`func (o *V12EventSuppress) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V12EventSuppress) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V12EventSuppress) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V12EventSuppress) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetSuppressions

`func (o *V12EventSuppress) GetSuppressions() []V12EventSuppressSuppression`

GetSuppressions returns the Suppressions field if non-nil, zero value otherwise.

### GetSuppressionsOk

`func (o *V12EventSuppress) GetSuppressionsOk() (*[]V12EventSuppressSuppression, bool)`

GetSuppressionsOk returns a tuple with the Suppressions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSuppressions

`func (o *V12EventSuppress) SetSuppressions(v []V12EventSuppressSuppression)`

SetSuppressions sets Suppressions field to given value.

### HasSuppressions

`func (o *V12EventSuppress) HasSuppressions() bool`

HasSuppressions returns a boolean if a field has been set.

### GetTotal

`func (o *V12EventSuppress) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V12EventSuppress) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V12EventSuppress) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V12EventSuppress) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


