# Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Fingerprints** | Pointer to [**[]V16CertificatesSyslogCertificateFingerprint**](V16CertificatesSyslogCertificateFingerprint.md) | A list of zero or more certificate fingerprints which can be used for certificate identification. | [optional] 
**Issuer** | Pointer to **string** | Certificate issuer field extracted from the certificate. | [optional] 
**NotAfter** | Pointer to **int32** | Certificate notAfter field extracted from the certificate encoded as a UNIX epoch timestamp.  The certificate is not valid after this timestamp. | [optional] 
**NotBefore** | Pointer to **int32** | Certificate notBefore field extracted from the certificate encoded as a UNIX epoch timestamp.  The certificate is not valid before this timestamp. | [optional] 
**Status** | Pointer to **string** | Certificate validity status | [optional] 
**Subject** | Pointer to **string** | Certificate subject field extracted from the certificate. | [optional] 
**Value** | Pointer to [**V16ProvidersSamlServicesCertExtractSettingsCertificateInfoValue**](V16ProvidersSamlServicesCertExtractSettingsCertificateInfoValue.md) |  | [optional] 

## Methods

### NewCreatev16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate

`func NewCreatev16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate() *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate`

NewCreatev16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate instantiates a new Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificateWithDefaults

`func NewCreatev16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificateWithDefaults() *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate`

NewCreatev16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificateWithDefaults instantiates a new Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFingerprints

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) GetFingerprints() []V16CertificatesSyslogCertificateFingerprint`

GetFingerprints returns the Fingerprints field if non-nil, zero value otherwise.

### GetFingerprintsOk

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) GetFingerprintsOk() (*[]V16CertificatesSyslogCertificateFingerprint, bool)`

GetFingerprintsOk returns a tuple with the Fingerprints field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFingerprints

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) SetFingerprints(v []V16CertificatesSyslogCertificateFingerprint)`

SetFingerprints sets Fingerprints field to given value.

### HasFingerprints

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) HasFingerprints() bool`

HasFingerprints returns a boolean if a field has been set.

### GetIssuer

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) GetIssuer() string`

GetIssuer returns the Issuer field if non-nil, zero value otherwise.

### GetIssuerOk

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) GetIssuerOk() (*string, bool)`

GetIssuerOk returns a tuple with the Issuer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIssuer

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) SetIssuer(v string)`

SetIssuer sets Issuer field to given value.

### HasIssuer

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) HasIssuer() bool`

HasIssuer returns a boolean if a field has been set.

### GetNotAfter

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) GetNotAfter() int32`

GetNotAfter returns the NotAfter field if non-nil, zero value otherwise.

### GetNotAfterOk

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) GetNotAfterOk() (*int32, bool)`

GetNotAfterOk returns a tuple with the NotAfter field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNotAfter

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) SetNotAfter(v int32)`

SetNotAfter sets NotAfter field to given value.

### HasNotAfter

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) HasNotAfter() bool`

HasNotAfter returns a boolean if a field has been set.

### GetNotBefore

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) GetNotBefore() int32`

GetNotBefore returns the NotBefore field if non-nil, zero value otherwise.

### GetNotBeforeOk

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) GetNotBeforeOk() (*int32, bool)`

GetNotBeforeOk returns a tuple with the NotBefore field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNotBefore

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) SetNotBefore(v int32)`

SetNotBefore sets NotBefore field to given value.

### HasNotBefore

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) HasNotBefore() bool`

HasNotBefore returns a boolean if a field has been set.

### GetStatus

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) SetStatus(v string)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) HasStatus() bool`

HasStatus returns a boolean if a field has been set.

### GetSubject

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) GetSubject() string`

GetSubject returns the Subject field if non-nil, zero value otherwise.

### GetSubjectOk

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) GetSubjectOk() (*string, bool)`

GetSubjectOk returns a tuple with the Subject field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSubject

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) SetSubject(v string)`

SetSubject sets Subject field to given value.

### HasSubject

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) HasSubject() bool`

HasSubject returns a boolean if a field has been set.

### GetValue

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) GetValue() V16ProvidersSamlServicesCertExtractSettingsCertificateInfoValue`

GetValue returns the Value field if non-nil, zero value otherwise.

### GetValueOk

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) GetValueOk() (*V16ProvidersSamlServicesCertExtractSettingsCertificateInfoValue, bool)`

GetValueOk returns a tuple with the Value field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetValue

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) SetValue(v V16ProvidersSamlServicesCertExtractSettingsCertificateInfoValue)`

SetValue sets Value field to given value.

### HasValue

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate) HasValue() bool`

HasValue returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


