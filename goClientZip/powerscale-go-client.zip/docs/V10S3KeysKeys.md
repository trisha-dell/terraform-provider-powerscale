# V10S3KeysKeys

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccessId** | Pointer to **string** | S3 Access ID | [optional] 
**OldKeyExpiry** | Pointer to **int32** | Time that previous secret key will expire, in format YYYY-MM-DD HH:MM:SS | [optional] 
**OldKeyTimestamp** | Pointer to **int32** | Time that previous secret key was created, in format YYYY-MM-DD HH:MM:SS | [optional] 
**SecretKeyTimestamp** | Pointer to **int32** | Time that secret key was created, in format YYYY-MM-DD HH:MM:SS | [optional] 

## Methods

### NewV10S3KeysKeys

`func NewV10S3KeysKeys() *V10S3KeysKeys`

NewV10S3KeysKeys instantiates a new V10S3KeysKeys object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10S3KeysKeysWithDefaults

`func NewV10S3KeysKeysWithDefaults() *V10S3KeysKeys`

NewV10S3KeysKeysWithDefaults instantiates a new V10S3KeysKeys object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAccessId

`func (o *V10S3KeysKeys) GetAccessId() string`

GetAccessId returns the AccessId field if non-nil, zero value otherwise.

### GetAccessIdOk

`func (o *V10S3KeysKeys) GetAccessIdOk() (*string, bool)`

GetAccessIdOk returns a tuple with the AccessId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAccessId

`func (o *V10S3KeysKeys) SetAccessId(v string)`

SetAccessId sets AccessId field to given value.

### HasAccessId

`func (o *V10S3KeysKeys) HasAccessId() bool`

HasAccessId returns a boolean if a field has been set.

### GetOldKeyExpiry

`func (o *V10S3KeysKeys) GetOldKeyExpiry() int32`

GetOldKeyExpiry returns the OldKeyExpiry field if non-nil, zero value otherwise.

### GetOldKeyExpiryOk

`func (o *V10S3KeysKeys) GetOldKeyExpiryOk() (*int32, bool)`

GetOldKeyExpiryOk returns a tuple with the OldKeyExpiry field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOldKeyExpiry

`func (o *V10S3KeysKeys) SetOldKeyExpiry(v int32)`

SetOldKeyExpiry sets OldKeyExpiry field to given value.

### HasOldKeyExpiry

`func (o *V10S3KeysKeys) HasOldKeyExpiry() bool`

HasOldKeyExpiry returns a boolean if a field has been set.

### GetOldKeyTimestamp

`func (o *V10S3KeysKeys) GetOldKeyTimestamp() int32`

GetOldKeyTimestamp returns the OldKeyTimestamp field if non-nil, zero value otherwise.

### GetOldKeyTimestampOk

`func (o *V10S3KeysKeys) GetOldKeyTimestampOk() (*int32, bool)`

GetOldKeyTimestampOk returns a tuple with the OldKeyTimestamp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOldKeyTimestamp

`func (o *V10S3KeysKeys) SetOldKeyTimestamp(v int32)`

SetOldKeyTimestamp sets OldKeyTimestamp field to given value.

### HasOldKeyTimestamp

`func (o *V10S3KeysKeys) HasOldKeyTimestamp() bool`

HasOldKeyTimestamp returns a boolean if a field has been set.

### GetSecretKeyTimestamp

`func (o *V10S3KeysKeys) GetSecretKeyTimestamp() int32`

GetSecretKeyTimestamp returns the SecretKeyTimestamp field if non-nil, zero value otherwise.

### GetSecretKeyTimestampOk

`func (o *V10S3KeysKeys) GetSecretKeyTimestampOk() (*int32, bool)`

GetSecretKeyTimestampOk returns a tuple with the SecretKeyTimestamp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSecretKeyTimestamp

`func (o *V10S3KeysKeys) SetSecretKeyTimestamp(v int32)`

SetSecretKeyTimestamp sets SecretKeyTimestamp field to given value.

### HasSecretKeyTimestamp

`func (o *V10S3KeysKeys) HasSecretKeyTimestamp() bool`

HasSecretKeyTimestamp returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


