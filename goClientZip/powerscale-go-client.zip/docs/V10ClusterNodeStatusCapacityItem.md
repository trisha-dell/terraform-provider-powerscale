# V10ClusterNodeStatusCapacityItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Bytes** | Pointer to **int64** | Total device storage bytes. | [optional] 
**Count** | Pointer to **int64** | Total device count. | [optional] 
**Type** | Pointer to **string** | Device type. | [optional] 

## Methods

### NewV10ClusterNodeStatusCapacityItem

`func NewV10ClusterNodeStatusCapacityItem() *V10ClusterNodeStatusCapacityItem`

NewV10ClusterNodeStatusCapacityItem instantiates a new V10ClusterNodeStatusCapacityItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeStatusCapacityItemWithDefaults

`func NewV10ClusterNodeStatusCapacityItemWithDefaults() *V10ClusterNodeStatusCapacityItem`

NewV10ClusterNodeStatusCapacityItemWithDefaults instantiates a new V10ClusterNodeStatusCapacityItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBytes

`func (o *V10ClusterNodeStatusCapacityItem) GetBytes() int64`

GetBytes returns the Bytes field if non-nil, zero value otherwise.

### GetBytesOk

`func (o *V10ClusterNodeStatusCapacityItem) GetBytesOk() (*int64, bool)`

GetBytesOk returns a tuple with the Bytes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBytes

`func (o *V10ClusterNodeStatusCapacityItem) SetBytes(v int64)`

SetBytes sets Bytes field to given value.

### HasBytes

`func (o *V10ClusterNodeStatusCapacityItem) HasBytes() bool`

HasBytes returns a boolean if a field has been set.

### GetCount

`func (o *V10ClusterNodeStatusCapacityItem) GetCount() int64`

GetCount returns the Count field if non-nil, zero value otherwise.

### GetCountOk

`func (o *V10ClusterNodeStatusCapacityItem) GetCountOk() (*int64, bool)`

GetCountOk returns a tuple with the Count field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCount

`func (o *V10ClusterNodeStatusCapacityItem) SetCount(v int64)`

SetCount sets Count field to given value.

### HasCount

`func (o *V10ClusterNodeStatusCapacityItem) HasCount() bool`

HasCount returns a boolean if a field has been set.

### GetType

`func (o *V10ClusterNodeStatusCapacityItem) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *V10ClusterNodeStatusCapacityItem) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *V10ClusterNodeStatusCapacityItem) SetType(v string)`

SetType sets Type field to given value.

### HasType

`func (o *V10ClusterNodeStatusCapacityItem) HasType() bool`

HasType returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


