# \GroupnetsSummaryApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetGroupnetsSummaryv5GroupnetsSummary**](GroupnetsSummaryApi.md#GetGroupnetsSummaryv5GroupnetsSummary) | **Get** /platform/5/groupnets-summary | 



## GetGroupnetsSummaryv5GroupnetsSummary

> V5GroupnetsSummary GetGroupnetsSummaryv5GroupnetsSummary(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.GroupnetsSummaryApi.GetGroupnetsSummaryv5GroupnetsSummary(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `GroupnetsSummaryApi.GetGroupnetsSummaryv5GroupnetsSummary``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetGroupnetsSummaryv5GroupnetsSummary`: V5GroupnetsSummary
    fmt.Fprintf(os.Stdout, "Response from `GroupnetsSummaryApi.GetGroupnetsSummaryv5GroupnetsSummary`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetGroupnetsSummaryv5GroupnetsSummaryRequest struct via the builder pattern


### Return type

[**V5GroupnetsSummary**](V5GroupnetsSummary.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

