# V10NetworkGroupnetExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AllowWildcardSubdomains** | Pointer to **bool** | If enabled, SmartConnect treats subdomains of known dns zones as the known dns zone. This is required for S3 Virtual Host domains. Defaults to True. | [optional] 
**Description** | Pointer to **string** | A description of the groupnet. | [optional] 
**DnsCacheEnabled** | Pointer to **bool** | DNS caching is enabled or disabled. | [optional] 
**DnsOptions** | Pointer to **[]string** | List of DNS resolver options. | [optional] 
**DnsSearch** | Pointer to **[]string** | List of DNS search suffixes. | [optional] 
**DnsServers** | Pointer to **[]string** | List of Domain Name Server IP addresses. | [optional] 
**Id** | Pointer to **string** | Unique Interface ID. | [optional] 
**Name** | Pointer to **string** | The name of the groupnet. | [optional] 
**ServerSideDnsSearch** | Pointer to **bool** | Enable or disable appending nodes DNS search  list to client DNS inquiries directed at SmartConnect service IP. | [optional] 
**Subnets** | Pointer to **[]string** | Name of the subnets in the groupnet. | [optional] 

## Methods

### NewV10NetworkGroupnetExtended

`func NewV10NetworkGroupnetExtended() *V10NetworkGroupnetExtended`

NewV10NetworkGroupnetExtended instantiates a new V10NetworkGroupnetExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10NetworkGroupnetExtendedWithDefaults

`func NewV10NetworkGroupnetExtendedWithDefaults() *V10NetworkGroupnetExtended`

NewV10NetworkGroupnetExtendedWithDefaults instantiates a new V10NetworkGroupnetExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAllowWildcardSubdomains

`func (o *V10NetworkGroupnetExtended) GetAllowWildcardSubdomains() bool`

GetAllowWildcardSubdomains returns the AllowWildcardSubdomains field if non-nil, zero value otherwise.

### GetAllowWildcardSubdomainsOk

`func (o *V10NetworkGroupnetExtended) GetAllowWildcardSubdomainsOk() (*bool, bool)`

GetAllowWildcardSubdomainsOk returns a tuple with the AllowWildcardSubdomains field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllowWildcardSubdomains

`func (o *V10NetworkGroupnetExtended) SetAllowWildcardSubdomains(v bool)`

SetAllowWildcardSubdomains sets AllowWildcardSubdomains field to given value.

### HasAllowWildcardSubdomains

`func (o *V10NetworkGroupnetExtended) HasAllowWildcardSubdomains() bool`

HasAllowWildcardSubdomains returns a boolean if a field has been set.

### GetDescription

`func (o *V10NetworkGroupnetExtended) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V10NetworkGroupnetExtended) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V10NetworkGroupnetExtended) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *V10NetworkGroupnetExtended) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetDnsCacheEnabled

`func (o *V10NetworkGroupnetExtended) GetDnsCacheEnabled() bool`

GetDnsCacheEnabled returns the DnsCacheEnabled field if non-nil, zero value otherwise.

### GetDnsCacheEnabledOk

`func (o *V10NetworkGroupnetExtended) GetDnsCacheEnabledOk() (*bool, bool)`

GetDnsCacheEnabledOk returns a tuple with the DnsCacheEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDnsCacheEnabled

`func (o *V10NetworkGroupnetExtended) SetDnsCacheEnabled(v bool)`

SetDnsCacheEnabled sets DnsCacheEnabled field to given value.

### HasDnsCacheEnabled

`func (o *V10NetworkGroupnetExtended) HasDnsCacheEnabled() bool`

HasDnsCacheEnabled returns a boolean if a field has been set.

### GetDnsOptions

`func (o *V10NetworkGroupnetExtended) GetDnsOptions() []string`

GetDnsOptions returns the DnsOptions field if non-nil, zero value otherwise.

### GetDnsOptionsOk

`func (o *V10NetworkGroupnetExtended) GetDnsOptionsOk() (*[]string, bool)`

GetDnsOptionsOk returns a tuple with the DnsOptions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDnsOptions

`func (o *V10NetworkGroupnetExtended) SetDnsOptions(v []string)`

SetDnsOptions sets DnsOptions field to given value.

### HasDnsOptions

`func (o *V10NetworkGroupnetExtended) HasDnsOptions() bool`

HasDnsOptions returns a boolean if a field has been set.

### GetDnsSearch

`func (o *V10NetworkGroupnetExtended) GetDnsSearch() []string`

GetDnsSearch returns the DnsSearch field if non-nil, zero value otherwise.

### GetDnsSearchOk

`func (o *V10NetworkGroupnetExtended) GetDnsSearchOk() (*[]string, bool)`

GetDnsSearchOk returns a tuple with the DnsSearch field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDnsSearch

`func (o *V10NetworkGroupnetExtended) SetDnsSearch(v []string)`

SetDnsSearch sets DnsSearch field to given value.

### HasDnsSearch

`func (o *V10NetworkGroupnetExtended) HasDnsSearch() bool`

HasDnsSearch returns a boolean if a field has been set.

### GetDnsServers

`func (o *V10NetworkGroupnetExtended) GetDnsServers() []string`

GetDnsServers returns the DnsServers field if non-nil, zero value otherwise.

### GetDnsServersOk

`func (o *V10NetworkGroupnetExtended) GetDnsServersOk() (*[]string, bool)`

GetDnsServersOk returns a tuple with the DnsServers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDnsServers

`func (o *V10NetworkGroupnetExtended) SetDnsServers(v []string)`

SetDnsServers sets DnsServers field to given value.

### HasDnsServers

`func (o *V10NetworkGroupnetExtended) HasDnsServers() bool`

HasDnsServers returns a boolean if a field has been set.

### GetId

`func (o *V10NetworkGroupnetExtended) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V10NetworkGroupnetExtended) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V10NetworkGroupnetExtended) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V10NetworkGroupnetExtended) HasId() bool`

HasId returns a boolean if a field has been set.

### GetName

`func (o *V10NetworkGroupnetExtended) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V10NetworkGroupnetExtended) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V10NetworkGroupnetExtended) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V10NetworkGroupnetExtended) HasName() bool`

HasName returns a boolean if a field has been set.

### GetServerSideDnsSearch

`func (o *V10NetworkGroupnetExtended) GetServerSideDnsSearch() bool`

GetServerSideDnsSearch returns the ServerSideDnsSearch field if non-nil, zero value otherwise.

### GetServerSideDnsSearchOk

`func (o *V10NetworkGroupnetExtended) GetServerSideDnsSearchOk() (*bool, bool)`

GetServerSideDnsSearchOk returns a tuple with the ServerSideDnsSearch field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServerSideDnsSearch

`func (o *V10NetworkGroupnetExtended) SetServerSideDnsSearch(v bool)`

SetServerSideDnsSearch sets ServerSideDnsSearch field to given value.

### HasServerSideDnsSearch

`func (o *V10NetworkGroupnetExtended) HasServerSideDnsSearch() bool`

HasServerSideDnsSearch returns a boolean if a field has been set.

### GetSubnets

`func (o *V10NetworkGroupnetExtended) GetSubnets() []string`

GetSubnets returns the Subnets field if non-nil, zero value otherwise.

### GetSubnetsOk

`func (o *V10NetworkGroupnetExtended) GetSubnetsOk() (*[]string, bool)`

GetSubnetsOk returns a tuple with the Subnets field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSubnets

`func (o *V10NetworkGroupnetExtended) SetSubnets(v []string)`

SetSubnets sets Subnets field to given value.

### HasSubnets

`func (o *V10NetworkGroupnetExtended) HasSubnets() bool`

HasSubnets returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


