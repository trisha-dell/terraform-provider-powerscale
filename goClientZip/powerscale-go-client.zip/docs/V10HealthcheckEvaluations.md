# V10HealthcheckEvaluations

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Evaluations** | Pointer to [**[]V10HealthcheckEvaluationExtended**](V10HealthcheckEvaluationExtended.md) |  | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV10HealthcheckEvaluations

`func NewV10HealthcheckEvaluations() *V10HealthcheckEvaluations`

NewV10HealthcheckEvaluations instantiates a new V10HealthcheckEvaluations object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10HealthcheckEvaluationsWithDefaults

`func NewV10HealthcheckEvaluationsWithDefaults() *V10HealthcheckEvaluations`

NewV10HealthcheckEvaluationsWithDefaults instantiates a new V10HealthcheckEvaluations object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEvaluations

`func (o *V10HealthcheckEvaluations) GetEvaluations() []V10HealthcheckEvaluationExtended`

GetEvaluations returns the Evaluations field if non-nil, zero value otherwise.

### GetEvaluationsOk

`func (o *V10HealthcheckEvaluations) GetEvaluationsOk() (*[]V10HealthcheckEvaluationExtended, bool)`

GetEvaluationsOk returns a tuple with the Evaluations field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEvaluations

`func (o *V10HealthcheckEvaluations) SetEvaluations(v []V10HealthcheckEvaluationExtended)`

SetEvaluations sets Evaluations field to given value.

### HasEvaluations

`func (o *V10HealthcheckEvaluations) HasEvaluations() bool`

HasEvaluations returns a boolean if a field has been set.

### GetResume

`func (o *V10HealthcheckEvaluations) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V10HealthcheckEvaluations) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V10HealthcheckEvaluations) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V10HealthcheckEvaluations) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V10HealthcheckEvaluations) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V10HealthcheckEvaluations) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V10HealthcheckEvaluations) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V10HealthcheckEvaluations) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


