# \FileFilterApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetFileFilterv3FileFilterSettings**](FileFilterApi.md#GetFileFilterv3FileFilterSettings) | **Get** /platform/3/file-filter/settings | 
[**UpdateFileFilterv3FileFilterSettings**](FileFilterApi.md#UpdateFileFilterv3FileFilterSettings) | **Put** /platform/3/file-filter/settings | 



## GetFileFilterv3FileFilterSettings

> V3FileFilterSettings GetFileFilterv3FileFilterSettings(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Specifies the access zones in which these settings apply. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FileFilterApi.GetFileFilterv3FileFilterSettings(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileFilterApi.GetFileFilterv3FileFilterSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFileFilterv3FileFilterSettings`: V3FileFilterSettings
    fmt.Fprintf(os.Stdout, "Response from `FileFilterApi.GetFileFilterv3FileFilterSettings`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetFileFilterv3FileFilterSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Specifies the access zones in which these settings apply. | 

### Return type

[**V3FileFilterSettings**](V3FileFilterSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateFileFilterv3FileFilterSettings

> UpdateFileFilterv3FileFilterSettings(ctx).V3FileFilterSettings(v3FileFilterSettings).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3FileFilterSettings := *openapiclient.NewV3FileFilterSettingsSettings() // V3FileFilterSettingsSettings | 
    zone := "zone_example" // string | Specifies the access zones in which these settings apply. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FileFilterApi.UpdateFileFilterv3FileFilterSettings(context.Background()).V3FileFilterSettings(v3FileFilterSettings).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FileFilterApi.UpdateFileFilterv3FileFilterSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateFileFilterv3FileFilterSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3FileFilterSettings** | [**V3FileFilterSettingsSettings**](V3FileFilterSettingsSettings.md) |  | 
 **zone** | **string** | Specifies the access zones in which these settings apply. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

