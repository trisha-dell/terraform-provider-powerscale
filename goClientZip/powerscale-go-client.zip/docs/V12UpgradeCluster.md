# V12UpgradeCluster

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ClusterOverview** | Pointer to [**V12UpgradeClusterClusterOverview**](V12UpgradeClusterClusterOverview.md) |  | [optional] 
**ClusterState** | Pointer to **string** | The different states of an upgrade, rollback, or assessment. One of the following values: &#39;committed&#39;, &#39;upgraded&#39;, &#39;partially upgraded&#39;, &#39;upgrading&#39;, &#39;rolling back&#39;, &#39;assessing&#39;, &#39;error&#39; | [optional] 
**CommittedFeatures** | Pointer to [**V12UpgradeClusterCommittedFeatures**](V12UpgradeClusterCommittedFeatures.md) |  | [optional] 
**CurrentProcess** | Pointer to **string** | The current upgrade activity. | [optional] 
**FinishTime** | Pointer to **string** | The time when a rollback, assessment or upgrade has finished completely. Use ISO 8601 standard. Null if the cluster_state is not &#39;upgraded&#39;. | [optional] 
**FwPkg** | Pointer to **string** | The location (path) of the firmware package which must be within /ifs. | [optional] 
**FwPkgId** | Pointer to **string** | The ID of the signed artifact stored in the catalog. | [optional] 
**InstallImagePath** | Pointer to **string** | The location (path) of the upgrade image which must be within /ifs. Null if the cluster_state is &#39;committed&#39; or &#39;upgraded.&#39; | [optional] 
**NodeMedianTime** | Pointer to **int32** | The median time (seconds) to complete each node so far during this upgrade. Before the first node in an upgrade has completed this key will have an associated null value. | [optional] 
**OnefsVersionCurrent** | Pointer to [**V12UpgradeClusterOnefsVersionCurrent**](V12UpgradeClusterOnefsVersionCurrent.md) |  | [optional] 
**OnefsVersionUpgrade** | Pointer to [**V12UpgradeClusterOnefsVersionCurrent**](V12UpgradeClusterOnefsVersionCurrent.md) |  | [optional] 
**PatchAction** | Pointer to **string** | The most recent patch action performed. | [optional] 
**PatchName** | Pointer to **string** | The patch with the most recent patch action. | [optional] 
**StartTime** | Pointer to **string** | The time when an upgrade, rollback, or assessment was started. Use ISO 8601 standard. Null if the cluster_state is &#39;committed&#39; or &#39;partially upgraded.&#39; | [optional] 
**UpgradeIsCommitted** | Pointer to **bool** | True if upgrade is committed. | [optional] 
**UpgradeProcessState** | Pointer to **string** | The different states of upgrade process. One of the following values: &#39;Not started&#39;, &#39;Running&#39;, &#39;Pausing&#39;, &#39;Paused&#39;.  | [optional] 
**UpgradeSettings** | Pointer to [**V12UpgradeClusterUpgradeSettings**](V12UpgradeClusterUpgradeSettings.md) |  | [optional] 
**UpgradeTriggeredTime** | Pointer to **string** | Time at which upgrade was originally requested. | [optional] 

## Methods

### NewV12UpgradeCluster

`func NewV12UpgradeCluster() *V12UpgradeCluster`

NewV12UpgradeCluster instantiates a new V12UpgradeCluster object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12UpgradeClusterWithDefaults

`func NewV12UpgradeClusterWithDefaults() *V12UpgradeCluster`

NewV12UpgradeClusterWithDefaults instantiates a new V12UpgradeCluster object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetClusterOverview

`func (o *V12UpgradeCluster) GetClusterOverview() V12UpgradeClusterClusterOverview`

GetClusterOverview returns the ClusterOverview field if non-nil, zero value otherwise.

### GetClusterOverviewOk

`func (o *V12UpgradeCluster) GetClusterOverviewOk() (*V12UpgradeClusterClusterOverview, bool)`

GetClusterOverviewOk returns a tuple with the ClusterOverview field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClusterOverview

`func (o *V12UpgradeCluster) SetClusterOverview(v V12UpgradeClusterClusterOverview)`

SetClusterOverview sets ClusterOverview field to given value.

### HasClusterOverview

`func (o *V12UpgradeCluster) HasClusterOverview() bool`

HasClusterOverview returns a boolean if a field has been set.

### GetClusterState

`func (o *V12UpgradeCluster) GetClusterState() string`

GetClusterState returns the ClusterState field if non-nil, zero value otherwise.

### GetClusterStateOk

`func (o *V12UpgradeCluster) GetClusterStateOk() (*string, bool)`

GetClusterStateOk returns a tuple with the ClusterState field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClusterState

`func (o *V12UpgradeCluster) SetClusterState(v string)`

SetClusterState sets ClusterState field to given value.

### HasClusterState

`func (o *V12UpgradeCluster) HasClusterState() bool`

HasClusterState returns a boolean if a field has been set.

### GetCommittedFeatures

`func (o *V12UpgradeCluster) GetCommittedFeatures() V12UpgradeClusterCommittedFeatures`

GetCommittedFeatures returns the CommittedFeatures field if non-nil, zero value otherwise.

### GetCommittedFeaturesOk

`func (o *V12UpgradeCluster) GetCommittedFeaturesOk() (*V12UpgradeClusterCommittedFeatures, bool)`

GetCommittedFeaturesOk returns a tuple with the CommittedFeatures field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCommittedFeatures

`func (o *V12UpgradeCluster) SetCommittedFeatures(v V12UpgradeClusterCommittedFeatures)`

SetCommittedFeatures sets CommittedFeatures field to given value.

### HasCommittedFeatures

`func (o *V12UpgradeCluster) HasCommittedFeatures() bool`

HasCommittedFeatures returns a boolean if a field has been set.

### GetCurrentProcess

`func (o *V12UpgradeCluster) GetCurrentProcess() string`

GetCurrentProcess returns the CurrentProcess field if non-nil, zero value otherwise.

### GetCurrentProcessOk

`func (o *V12UpgradeCluster) GetCurrentProcessOk() (*string, bool)`

GetCurrentProcessOk returns a tuple with the CurrentProcess field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCurrentProcess

`func (o *V12UpgradeCluster) SetCurrentProcess(v string)`

SetCurrentProcess sets CurrentProcess field to given value.

### HasCurrentProcess

`func (o *V12UpgradeCluster) HasCurrentProcess() bool`

HasCurrentProcess returns a boolean if a field has been set.

### GetFinishTime

`func (o *V12UpgradeCluster) GetFinishTime() string`

GetFinishTime returns the FinishTime field if non-nil, zero value otherwise.

### GetFinishTimeOk

`func (o *V12UpgradeCluster) GetFinishTimeOk() (*string, bool)`

GetFinishTimeOk returns a tuple with the FinishTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFinishTime

`func (o *V12UpgradeCluster) SetFinishTime(v string)`

SetFinishTime sets FinishTime field to given value.

### HasFinishTime

`func (o *V12UpgradeCluster) HasFinishTime() bool`

HasFinishTime returns a boolean if a field has been set.

### GetFwPkg

`func (o *V12UpgradeCluster) GetFwPkg() string`

GetFwPkg returns the FwPkg field if non-nil, zero value otherwise.

### GetFwPkgOk

`func (o *V12UpgradeCluster) GetFwPkgOk() (*string, bool)`

GetFwPkgOk returns a tuple with the FwPkg field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFwPkg

`func (o *V12UpgradeCluster) SetFwPkg(v string)`

SetFwPkg sets FwPkg field to given value.

### HasFwPkg

`func (o *V12UpgradeCluster) HasFwPkg() bool`

HasFwPkg returns a boolean if a field has been set.

### GetFwPkgId

`func (o *V12UpgradeCluster) GetFwPkgId() string`

GetFwPkgId returns the FwPkgId field if non-nil, zero value otherwise.

### GetFwPkgIdOk

`func (o *V12UpgradeCluster) GetFwPkgIdOk() (*string, bool)`

GetFwPkgIdOk returns a tuple with the FwPkgId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFwPkgId

`func (o *V12UpgradeCluster) SetFwPkgId(v string)`

SetFwPkgId sets FwPkgId field to given value.

### HasFwPkgId

`func (o *V12UpgradeCluster) HasFwPkgId() bool`

HasFwPkgId returns a boolean if a field has been set.

### GetInstallImagePath

`func (o *V12UpgradeCluster) GetInstallImagePath() string`

GetInstallImagePath returns the InstallImagePath field if non-nil, zero value otherwise.

### GetInstallImagePathOk

`func (o *V12UpgradeCluster) GetInstallImagePathOk() (*string, bool)`

GetInstallImagePathOk returns a tuple with the InstallImagePath field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInstallImagePath

`func (o *V12UpgradeCluster) SetInstallImagePath(v string)`

SetInstallImagePath sets InstallImagePath field to given value.

### HasInstallImagePath

`func (o *V12UpgradeCluster) HasInstallImagePath() bool`

HasInstallImagePath returns a boolean if a field has been set.

### GetNodeMedianTime

`func (o *V12UpgradeCluster) GetNodeMedianTime() int32`

GetNodeMedianTime returns the NodeMedianTime field if non-nil, zero value otherwise.

### GetNodeMedianTimeOk

`func (o *V12UpgradeCluster) GetNodeMedianTimeOk() (*int32, bool)`

GetNodeMedianTimeOk returns a tuple with the NodeMedianTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodeMedianTime

`func (o *V12UpgradeCluster) SetNodeMedianTime(v int32)`

SetNodeMedianTime sets NodeMedianTime field to given value.

### HasNodeMedianTime

`func (o *V12UpgradeCluster) HasNodeMedianTime() bool`

HasNodeMedianTime returns a boolean if a field has been set.

### GetOnefsVersionCurrent

`func (o *V12UpgradeCluster) GetOnefsVersionCurrent() V12UpgradeClusterOnefsVersionCurrent`

GetOnefsVersionCurrent returns the OnefsVersionCurrent field if non-nil, zero value otherwise.

### GetOnefsVersionCurrentOk

`func (o *V12UpgradeCluster) GetOnefsVersionCurrentOk() (*V12UpgradeClusterOnefsVersionCurrent, bool)`

GetOnefsVersionCurrentOk returns a tuple with the OnefsVersionCurrent field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOnefsVersionCurrent

`func (o *V12UpgradeCluster) SetOnefsVersionCurrent(v V12UpgradeClusterOnefsVersionCurrent)`

SetOnefsVersionCurrent sets OnefsVersionCurrent field to given value.

### HasOnefsVersionCurrent

`func (o *V12UpgradeCluster) HasOnefsVersionCurrent() bool`

HasOnefsVersionCurrent returns a boolean if a field has been set.

### GetOnefsVersionUpgrade

`func (o *V12UpgradeCluster) GetOnefsVersionUpgrade() V12UpgradeClusterOnefsVersionCurrent`

GetOnefsVersionUpgrade returns the OnefsVersionUpgrade field if non-nil, zero value otherwise.

### GetOnefsVersionUpgradeOk

`func (o *V12UpgradeCluster) GetOnefsVersionUpgradeOk() (*V12UpgradeClusterOnefsVersionCurrent, bool)`

GetOnefsVersionUpgradeOk returns a tuple with the OnefsVersionUpgrade field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOnefsVersionUpgrade

`func (o *V12UpgradeCluster) SetOnefsVersionUpgrade(v V12UpgradeClusterOnefsVersionCurrent)`

SetOnefsVersionUpgrade sets OnefsVersionUpgrade field to given value.

### HasOnefsVersionUpgrade

`func (o *V12UpgradeCluster) HasOnefsVersionUpgrade() bool`

HasOnefsVersionUpgrade returns a boolean if a field has been set.

### GetPatchAction

`func (o *V12UpgradeCluster) GetPatchAction() string`

GetPatchAction returns the PatchAction field if non-nil, zero value otherwise.

### GetPatchActionOk

`func (o *V12UpgradeCluster) GetPatchActionOk() (*string, bool)`

GetPatchActionOk returns a tuple with the PatchAction field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPatchAction

`func (o *V12UpgradeCluster) SetPatchAction(v string)`

SetPatchAction sets PatchAction field to given value.

### HasPatchAction

`func (o *V12UpgradeCluster) HasPatchAction() bool`

HasPatchAction returns a boolean if a field has been set.

### GetPatchName

`func (o *V12UpgradeCluster) GetPatchName() string`

GetPatchName returns the PatchName field if non-nil, zero value otherwise.

### GetPatchNameOk

`func (o *V12UpgradeCluster) GetPatchNameOk() (*string, bool)`

GetPatchNameOk returns a tuple with the PatchName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPatchName

`func (o *V12UpgradeCluster) SetPatchName(v string)`

SetPatchName sets PatchName field to given value.

### HasPatchName

`func (o *V12UpgradeCluster) HasPatchName() bool`

HasPatchName returns a boolean if a field has been set.

### GetStartTime

`func (o *V12UpgradeCluster) GetStartTime() string`

GetStartTime returns the StartTime field if non-nil, zero value otherwise.

### GetStartTimeOk

`func (o *V12UpgradeCluster) GetStartTimeOk() (*string, bool)`

GetStartTimeOk returns a tuple with the StartTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartTime

`func (o *V12UpgradeCluster) SetStartTime(v string)`

SetStartTime sets StartTime field to given value.

### HasStartTime

`func (o *V12UpgradeCluster) HasStartTime() bool`

HasStartTime returns a boolean if a field has been set.

### GetUpgradeIsCommitted

`func (o *V12UpgradeCluster) GetUpgradeIsCommitted() bool`

GetUpgradeIsCommitted returns the UpgradeIsCommitted field if non-nil, zero value otherwise.

### GetUpgradeIsCommittedOk

`func (o *V12UpgradeCluster) GetUpgradeIsCommittedOk() (*bool, bool)`

GetUpgradeIsCommittedOk returns a tuple with the UpgradeIsCommitted field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUpgradeIsCommitted

`func (o *V12UpgradeCluster) SetUpgradeIsCommitted(v bool)`

SetUpgradeIsCommitted sets UpgradeIsCommitted field to given value.

### HasUpgradeIsCommitted

`func (o *V12UpgradeCluster) HasUpgradeIsCommitted() bool`

HasUpgradeIsCommitted returns a boolean if a field has been set.

### GetUpgradeProcessState

`func (o *V12UpgradeCluster) GetUpgradeProcessState() string`

GetUpgradeProcessState returns the UpgradeProcessState field if non-nil, zero value otherwise.

### GetUpgradeProcessStateOk

`func (o *V12UpgradeCluster) GetUpgradeProcessStateOk() (*string, bool)`

GetUpgradeProcessStateOk returns a tuple with the UpgradeProcessState field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUpgradeProcessState

`func (o *V12UpgradeCluster) SetUpgradeProcessState(v string)`

SetUpgradeProcessState sets UpgradeProcessState field to given value.

### HasUpgradeProcessState

`func (o *V12UpgradeCluster) HasUpgradeProcessState() bool`

HasUpgradeProcessState returns a boolean if a field has been set.

### GetUpgradeSettings

`func (o *V12UpgradeCluster) GetUpgradeSettings() V12UpgradeClusterUpgradeSettings`

GetUpgradeSettings returns the UpgradeSettings field if non-nil, zero value otherwise.

### GetUpgradeSettingsOk

`func (o *V12UpgradeCluster) GetUpgradeSettingsOk() (*V12UpgradeClusterUpgradeSettings, bool)`

GetUpgradeSettingsOk returns a tuple with the UpgradeSettings field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUpgradeSettings

`func (o *V12UpgradeCluster) SetUpgradeSettings(v V12UpgradeClusterUpgradeSettings)`

SetUpgradeSettings sets UpgradeSettings field to given value.

### HasUpgradeSettings

`func (o *V12UpgradeCluster) HasUpgradeSettings() bool`

HasUpgradeSettings returns a boolean if a field has been set.

### GetUpgradeTriggeredTime

`func (o *V12UpgradeCluster) GetUpgradeTriggeredTime() string`

GetUpgradeTriggeredTime returns the UpgradeTriggeredTime field if non-nil, zero value otherwise.

### GetUpgradeTriggeredTimeOk

`func (o *V12UpgradeCluster) GetUpgradeTriggeredTimeOk() (*string, bool)`

GetUpgradeTriggeredTimeOk returns a tuple with the UpgradeTriggeredTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUpgradeTriggeredTime

`func (o *V12UpgradeCluster) SetUpgradeTriggeredTime(v string)`

SetUpgradeTriggeredTime sets UpgradeTriggeredTime field to given value.

### HasUpgradeTriggeredTime

`func (o *V12UpgradeCluster) HasUpgradeTriggeredTime() bool`

HasUpgradeTriggeredTime returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


