# V11ProvidersLdapLdapItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AlternateSecurityIdentitiesAttribute** | Pointer to **string** | Specifies the attribute name used when searching for alternate security identities. | [optional] 
**Authentication** | Pointer to **bool** | If true, enables authentication and identity management through the authentication provider. | [optional] 
**BalanceServers** | Pointer to **bool** | If true, connects the provider to a random server. | [optional] 
**BaseDn** | Pointer to **string** | Specifies the root of the tree in which to search identities. | [optional] 
**BindDn** | Pointer to **string** | Specifies the distinguished name for binding to the LDAP server. | [optional] 
**BindMechanism** | Pointer to **string** | Specifies which bind mechanism to use when connecting to an LDAP server. The only supported option is the &#39;simple&#39; value. | [optional] 
**BindTimeout** | Pointer to **int64** | Specifies the timeout in seconds when binding to an LDAP server. | [optional] 
**CertificateAuthorityFile** | Pointer to **string** | Specifies the path to the root certificates file. | [optional] 
**CheckOnlineInterval** | Pointer to **int64** | Specifies the time in seconds between provider online checks. | [optional] 
**CnAttribute** | Pointer to **string** | Specifies the canonical name. | [optional] 
**CreateHomeDirectory** | Pointer to **bool** | Automatically create the home directory on the first login. | [optional] 
**CryptPasswordAttribute** | Pointer to **string** | Specifies the hashed password value. | [optional] 
**EmailAttribute** | Pointer to **string** | Specifies the LDAP Email attribute. | [optional] 
**Enabled** | Pointer to **bool** | If true, enables the LDAP provider. | [optional] 
**EnumerateGroups** | Pointer to **bool** | If true, allows the provider to enumerate groups. | [optional] 
**EnumerateUsers** | Pointer to **bool** | If true, allows the provider to enumerate users. | [optional] 
**FindableGroups** | Pointer to **[]string** | Specifies the list of groups that can be resolved. | [optional] 
**FindableUsers** | Pointer to **[]string** | Specifies the list of users that can be resolved. | [optional] 
**GecosAttribute** | Pointer to **string** | Specifies the LDAP GECOS attribute. | [optional] 
**GidAttribute** | Pointer to **string** | Specifies the LDAP GID attribute. | [optional] 
**GroupBaseDn** | Pointer to **string** | Specifies the distinguished name of the entry where LDAP searches for groups are started. | [optional] 
**GroupDomain** | Pointer to **string** | Specifies the domain for this provider through which groups are qualified. | [optional] 
**GroupFilter** | Pointer to **string** | Specifies the LDAP filter for group objects. | [optional] 
**GroupMembersAttribute** | Pointer to **string** | Specifies the LDAP Group Members attribute. | [optional] 
**GroupSearchScope** | Pointer to **string** | Specifies the depth from the base DN to perform LDAP searches. | [optional] 
**Groupnet** | Pointer to **string** | Groupnet identifier. | [optional] 
**HomeDirectoryTemplate** | Pointer to **string** | Specifies the path to the home directory template. | [optional] 
**HomedirAttribute** | Pointer to **string** | Specifies the LDAP Homedir attribute. | [optional] 
**Id** | Pointer to **string** | Specifies the ID of the LDAP provider. | [optional] 
**IgnoreTlsErrors** | Pointer to **bool** | If true, continues over secure connections even if identity checks fail. | [optional] 
**ListableGroups** | Pointer to **[]string** | Specifies the groups that can be viewed in the provider. | [optional] 
**ListableUsers** | Pointer to **[]string** | Specifies the users that can be viewed in the provider. | [optional] 
**LoginShell** | Pointer to **string** | Specifies the login shell path. | [optional] 
**MemberLookupMethod** | Pointer to **string** | Sets the method by which group member lookups are performed. Use caution when changing this option directly. | [optional] 
**MemberOfAttribute** | Pointer to **string** | Specifies the LDAP Query Member Of attribute, which performs reverse membership queries. | [optional] 
**Name** | Pointer to **string** | Specifies the name of the LDAP provider. | [optional] 
**NameAttribute** | Pointer to **string** | Specifies the LDAP UID attribute, which is used as the login name. | [optional] 
**NetgroupBaseDn** | Pointer to **string** | Specifies the distinguished name of the entry where LDAP searches for netgroups are started. | [optional] 
**NetgroupFilter** | Pointer to **string** | Specifies the LDAP filter for netgroup objects. | [optional] 
**NetgroupMembersAttribute** | Pointer to **string** | Specifies the LDAP Netgroup Members attribute. | [optional] 
**NetgroupSearchScope** | Pointer to **string** | Specifies the depth from the base DN to perform LDAP searches. | [optional] 
**NetgroupTripleAttribute** | Pointer to **string** | Specifies the LDAP Netgroup Triple attribute. | [optional] 
**NormalizeGroups** | Pointer to **bool** | Normalizes group names to lowercase before look up. | [optional] 
**NormalizeUsers** | Pointer to **bool** | Normalizes user names to lowercase before look up. | [optional] 
**NtPasswordAttribute** | Pointer to **string** | Specifies the LDAP NT Password attribute. | [optional] 
**NtlmSupport** | Pointer to **string** | Specifies which NTLM versions to support for users with NTLM-compatible credentials. | [optional] 
**ProviderDomain** | Pointer to **string** | Specifies the provider domain. | [optional] 
**RequireSecureConnection** | Pointer to **bool** | Determines whether to continue over a non-TLS connection. | [optional] 
**RestrictFindable** | Pointer to **bool** | If true, checks the provider for filtered lists of findable and unfindable users and groups. | [optional] 
**RestrictListable** | Pointer to **bool** | If true, checks the provider for filtered lists of listable and unlistable users and groups. | [optional] 
**SearchScope** | Pointer to **string** | Specifies the default depth from the base DN to perform LDAP searches. | [optional] 
**SearchTimeout** | Pointer to **int64** | Specifies the search timeout period in seconds. | [optional] 
**ServerUris** | Pointer to **[]string** | Specifies the server URIs. | [optional] 
**ShadowExpireAttribute** | Pointer to **string** | Sets the attribute name that indicates the absolute date to expire the account. | [optional] 
**ShadowFlagAttribute** | Pointer to **string** | Sets the attribute name that indicates the section of the shadow map that is used to store the flag value. | [optional] 
**ShadowInactiveAttribute** | Pointer to **string** | Sets the attribute name that indicates the number of days of inactivity that is allowed for the user. | [optional] 
**ShadowLastChangeAttribute** | Pointer to **string** | Sets the attribute name that indicates the last change of the shadow information. | [optional] 
**ShadowMaxAttribute** | Pointer to **string** | Sets the attribute name that indicates the maximum number of days a password can be valid. | [optional] 
**ShadowMinAttribute** | Pointer to **string** | Sets the attribute name that indicates the minimum number of days between shadow changes. | [optional] 
**ShadowUserFilter** | Pointer to **string** | Sets LDAP filter for shadow user objects. | [optional] 
**ShadowWarningAttribute** | Pointer to **string** | Sets the attribute name that indicates the number of days before the password expires to warn the user. | [optional] 
**ShellAttribute** | Pointer to **string** | Specifies the LDAP Shell attribute. | [optional] 
**SshPublicKeyAttribute** | Pointer to **string** | Sets the attribute name that indicates the SSH Public Key for the user. | [optional] 
**Status** | Pointer to **string** | Specifies the status of the provider. | [optional] 
**System** | Pointer to **bool** | If true, indicates that this provider instance was created by OneFS and cannot be removed. | [optional] 
**TlsProtocolMin** | Pointer to **string** | Specifies the minimum TLS protocol version. | [optional] 
**UidAttribute** | Pointer to **string** | Specifies the LDAP UID Number attribute. | [optional] 
**UnfindableGroups** | Pointer to **[]string** | Specifies the groups that cannot be resolved by the provider. | [optional] 
**UnfindableUsers** | Pointer to **[]string** | Specifies users that cannot be resolved by the provider. | [optional] 
**UniqueGroupMembersAttribute** | Pointer to **string** | Sets the LDAP Unique Group Members attribute. | [optional] 
**UnlistableGroups** | Pointer to **[]string** | Specifies a group that cannot be listed by the provider. | [optional] 
**UnlistableUsers** | Pointer to **[]string** | Specifies a user that cannot be listed by the provider. | [optional] 
**UserBaseDn** | Pointer to **string** | Specifies the distinguished name of the entry at which to start LDAP searches for users. | [optional] 
**UserDomain** | Pointer to **string** | Specifies the domain for this provider through which users are qualified. | [optional] 
**UserFilter** | Pointer to **string** | Specifies the LDAP filter for user objects. | [optional] 
**UserSearchScope** | Pointer to **string** | Specifies the depth from the base DN to perform LDAP searches. | [optional] 
**ZoneName** | Pointer to **string** | Specifies the name of the access zone in which this provider was created. | [optional] 

## Methods

### NewV11ProvidersLdapLdapItem

`func NewV11ProvidersLdapLdapItem() *V11ProvidersLdapLdapItem`

NewV11ProvidersLdapLdapItem instantiates a new V11ProvidersLdapLdapItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11ProvidersLdapLdapItemWithDefaults

`func NewV11ProvidersLdapLdapItemWithDefaults() *V11ProvidersLdapLdapItem`

NewV11ProvidersLdapLdapItemWithDefaults instantiates a new V11ProvidersLdapLdapItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAlternateSecurityIdentitiesAttribute

`func (o *V11ProvidersLdapLdapItem) GetAlternateSecurityIdentitiesAttribute() string`

GetAlternateSecurityIdentitiesAttribute returns the AlternateSecurityIdentitiesAttribute field if non-nil, zero value otherwise.

### GetAlternateSecurityIdentitiesAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetAlternateSecurityIdentitiesAttributeOk() (*string, bool)`

GetAlternateSecurityIdentitiesAttributeOk returns a tuple with the AlternateSecurityIdentitiesAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAlternateSecurityIdentitiesAttribute

`func (o *V11ProvidersLdapLdapItem) SetAlternateSecurityIdentitiesAttribute(v string)`

SetAlternateSecurityIdentitiesAttribute sets AlternateSecurityIdentitiesAttribute field to given value.

### HasAlternateSecurityIdentitiesAttribute

`func (o *V11ProvidersLdapLdapItem) HasAlternateSecurityIdentitiesAttribute() bool`

HasAlternateSecurityIdentitiesAttribute returns a boolean if a field has been set.

### GetAuthentication

`func (o *V11ProvidersLdapLdapItem) GetAuthentication() bool`

GetAuthentication returns the Authentication field if non-nil, zero value otherwise.

### GetAuthenticationOk

`func (o *V11ProvidersLdapLdapItem) GetAuthenticationOk() (*bool, bool)`

GetAuthenticationOk returns a tuple with the Authentication field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAuthentication

`func (o *V11ProvidersLdapLdapItem) SetAuthentication(v bool)`

SetAuthentication sets Authentication field to given value.

### HasAuthentication

`func (o *V11ProvidersLdapLdapItem) HasAuthentication() bool`

HasAuthentication returns a boolean if a field has been set.

### GetBalanceServers

`func (o *V11ProvidersLdapLdapItem) GetBalanceServers() bool`

GetBalanceServers returns the BalanceServers field if non-nil, zero value otherwise.

### GetBalanceServersOk

`func (o *V11ProvidersLdapLdapItem) GetBalanceServersOk() (*bool, bool)`

GetBalanceServersOk returns a tuple with the BalanceServers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBalanceServers

`func (o *V11ProvidersLdapLdapItem) SetBalanceServers(v bool)`

SetBalanceServers sets BalanceServers field to given value.

### HasBalanceServers

`func (o *V11ProvidersLdapLdapItem) HasBalanceServers() bool`

HasBalanceServers returns a boolean if a field has been set.

### GetBaseDn

`func (o *V11ProvidersLdapLdapItem) GetBaseDn() string`

GetBaseDn returns the BaseDn field if non-nil, zero value otherwise.

### GetBaseDnOk

`func (o *V11ProvidersLdapLdapItem) GetBaseDnOk() (*string, bool)`

GetBaseDnOk returns a tuple with the BaseDn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBaseDn

`func (o *V11ProvidersLdapLdapItem) SetBaseDn(v string)`

SetBaseDn sets BaseDn field to given value.

### HasBaseDn

`func (o *V11ProvidersLdapLdapItem) HasBaseDn() bool`

HasBaseDn returns a boolean if a field has been set.

### GetBindDn

`func (o *V11ProvidersLdapLdapItem) GetBindDn() string`

GetBindDn returns the BindDn field if non-nil, zero value otherwise.

### GetBindDnOk

`func (o *V11ProvidersLdapLdapItem) GetBindDnOk() (*string, bool)`

GetBindDnOk returns a tuple with the BindDn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBindDn

`func (o *V11ProvidersLdapLdapItem) SetBindDn(v string)`

SetBindDn sets BindDn field to given value.

### HasBindDn

`func (o *V11ProvidersLdapLdapItem) HasBindDn() bool`

HasBindDn returns a boolean if a field has been set.

### GetBindMechanism

`func (o *V11ProvidersLdapLdapItem) GetBindMechanism() string`

GetBindMechanism returns the BindMechanism field if non-nil, zero value otherwise.

### GetBindMechanismOk

`func (o *V11ProvidersLdapLdapItem) GetBindMechanismOk() (*string, bool)`

GetBindMechanismOk returns a tuple with the BindMechanism field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBindMechanism

`func (o *V11ProvidersLdapLdapItem) SetBindMechanism(v string)`

SetBindMechanism sets BindMechanism field to given value.

### HasBindMechanism

`func (o *V11ProvidersLdapLdapItem) HasBindMechanism() bool`

HasBindMechanism returns a boolean if a field has been set.

### GetBindTimeout

`func (o *V11ProvidersLdapLdapItem) GetBindTimeout() int64`

GetBindTimeout returns the BindTimeout field if non-nil, zero value otherwise.

### GetBindTimeoutOk

`func (o *V11ProvidersLdapLdapItem) GetBindTimeoutOk() (*int64, bool)`

GetBindTimeoutOk returns a tuple with the BindTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBindTimeout

`func (o *V11ProvidersLdapLdapItem) SetBindTimeout(v int64)`

SetBindTimeout sets BindTimeout field to given value.

### HasBindTimeout

`func (o *V11ProvidersLdapLdapItem) HasBindTimeout() bool`

HasBindTimeout returns a boolean if a field has been set.

### GetCertificateAuthorityFile

`func (o *V11ProvidersLdapLdapItem) GetCertificateAuthorityFile() string`

GetCertificateAuthorityFile returns the CertificateAuthorityFile field if non-nil, zero value otherwise.

### GetCertificateAuthorityFileOk

`func (o *V11ProvidersLdapLdapItem) GetCertificateAuthorityFileOk() (*string, bool)`

GetCertificateAuthorityFileOk returns a tuple with the CertificateAuthorityFile field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCertificateAuthorityFile

`func (o *V11ProvidersLdapLdapItem) SetCertificateAuthorityFile(v string)`

SetCertificateAuthorityFile sets CertificateAuthorityFile field to given value.

### HasCertificateAuthorityFile

`func (o *V11ProvidersLdapLdapItem) HasCertificateAuthorityFile() bool`

HasCertificateAuthorityFile returns a boolean if a field has been set.

### GetCheckOnlineInterval

`func (o *V11ProvidersLdapLdapItem) GetCheckOnlineInterval() int64`

GetCheckOnlineInterval returns the CheckOnlineInterval field if non-nil, zero value otherwise.

### GetCheckOnlineIntervalOk

`func (o *V11ProvidersLdapLdapItem) GetCheckOnlineIntervalOk() (*int64, bool)`

GetCheckOnlineIntervalOk returns a tuple with the CheckOnlineInterval field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCheckOnlineInterval

`func (o *V11ProvidersLdapLdapItem) SetCheckOnlineInterval(v int64)`

SetCheckOnlineInterval sets CheckOnlineInterval field to given value.

### HasCheckOnlineInterval

`func (o *V11ProvidersLdapLdapItem) HasCheckOnlineInterval() bool`

HasCheckOnlineInterval returns a boolean if a field has been set.

### GetCnAttribute

`func (o *V11ProvidersLdapLdapItem) GetCnAttribute() string`

GetCnAttribute returns the CnAttribute field if non-nil, zero value otherwise.

### GetCnAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetCnAttributeOk() (*string, bool)`

GetCnAttributeOk returns a tuple with the CnAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCnAttribute

`func (o *V11ProvidersLdapLdapItem) SetCnAttribute(v string)`

SetCnAttribute sets CnAttribute field to given value.

### HasCnAttribute

`func (o *V11ProvidersLdapLdapItem) HasCnAttribute() bool`

HasCnAttribute returns a boolean if a field has been set.

### GetCreateHomeDirectory

`func (o *V11ProvidersLdapLdapItem) GetCreateHomeDirectory() bool`

GetCreateHomeDirectory returns the CreateHomeDirectory field if non-nil, zero value otherwise.

### GetCreateHomeDirectoryOk

`func (o *V11ProvidersLdapLdapItem) GetCreateHomeDirectoryOk() (*bool, bool)`

GetCreateHomeDirectoryOk returns a tuple with the CreateHomeDirectory field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreateHomeDirectory

`func (o *V11ProvidersLdapLdapItem) SetCreateHomeDirectory(v bool)`

SetCreateHomeDirectory sets CreateHomeDirectory field to given value.

### HasCreateHomeDirectory

`func (o *V11ProvidersLdapLdapItem) HasCreateHomeDirectory() bool`

HasCreateHomeDirectory returns a boolean if a field has been set.

### GetCryptPasswordAttribute

`func (o *V11ProvidersLdapLdapItem) GetCryptPasswordAttribute() string`

GetCryptPasswordAttribute returns the CryptPasswordAttribute field if non-nil, zero value otherwise.

### GetCryptPasswordAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetCryptPasswordAttributeOk() (*string, bool)`

GetCryptPasswordAttributeOk returns a tuple with the CryptPasswordAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCryptPasswordAttribute

`func (o *V11ProvidersLdapLdapItem) SetCryptPasswordAttribute(v string)`

SetCryptPasswordAttribute sets CryptPasswordAttribute field to given value.

### HasCryptPasswordAttribute

`func (o *V11ProvidersLdapLdapItem) HasCryptPasswordAttribute() bool`

HasCryptPasswordAttribute returns a boolean if a field has been set.

### GetEmailAttribute

`func (o *V11ProvidersLdapLdapItem) GetEmailAttribute() string`

GetEmailAttribute returns the EmailAttribute field if non-nil, zero value otherwise.

### GetEmailAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetEmailAttributeOk() (*string, bool)`

GetEmailAttributeOk returns a tuple with the EmailAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEmailAttribute

`func (o *V11ProvidersLdapLdapItem) SetEmailAttribute(v string)`

SetEmailAttribute sets EmailAttribute field to given value.

### HasEmailAttribute

`func (o *V11ProvidersLdapLdapItem) HasEmailAttribute() bool`

HasEmailAttribute returns a boolean if a field has been set.

### GetEnabled

`func (o *V11ProvidersLdapLdapItem) GetEnabled() bool`

GetEnabled returns the Enabled field if non-nil, zero value otherwise.

### GetEnabledOk

`func (o *V11ProvidersLdapLdapItem) GetEnabledOk() (*bool, bool)`

GetEnabledOk returns a tuple with the Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabled

`func (o *V11ProvidersLdapLdapItem) SetEnabled(v bool)`

SetEnabled sets Enabled field to given value.

### HasEnabled

`func (o *V11ProvidersLdapLdapItem) HasEnabled() bool`

HasEnabled returns a boolean if a field has been set.

### GetEnumerateGroups

`func (o *V11ProvidersLdapLdapItem) GetEnumerateGroups() bool`

GetEnumerateGroups returns the EnumerateGroups field if non-nil, zero value otherwise.

### GetEnumerateGroupsOk

`func (o *V11ProvidersLdapLdapItem) GetEnumerateGroupsOk() (*bool, bool)`

GetEnumerateGroupsOk returns a tuple with the EnumerateGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnumerateGroups

`func (o *V11ProvidersLdapLdapItem) SetEnumerateGroups(v bool)`

SetEnumerateGroups sets EnumerateGroups field to given value.

### HasEnumerateGroups

`func (o *V11ProvidersLdapLdapItem) HasEnumerateGroups() bool`

HasEnumerateGroups returns a boolean if a field has been set.

### GetEnumerateUsers

`func (o *V11ProvidersLdapLdapItem) GetEnumerateUsers() bool`

GetEnumerateUsers returns the EnumerateUsers field if non-nil, zero value otherwise.

### GetEnumerateUsersOk

`func (o *V11ProvidersLdapLdapItem) GetEnumerateUsersOk() (*bool, bool)`

GetEnumerateUsersOk returns a tuple with the EnumerateUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnumerateUsers

`func (o *V11ProvidersLdapLdapItem) SetEnumerateUsers(v bool)`

SetEnumerateUsers sets EnumerateUsers field to given value.

### HasEnumerateUsers

`func (o *V11ProvidersLdapLdapItem) HasEnumerateUsers() bool`

HasEnumerateUsers returns a boolean if a field has been set.

### GetFindableGroups

`func (o *V11ProvidersLdapLdapItem) GetFindableGroups() []string`

GetFindableGroups returns the FindableGroups field if non-nil, zero value otherwise.

### GetFindableGroupsOk

`func (o *V11ProvidersLdapLdapItem) GetFindableGroupsOk() (*[]string, bool)`

GetFindableGroupsOk returns a tuple with the FindableGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFindableGroups

`func (o *V11ProvidersLdapLdapItem) SetFindableGroups(v []string)`

SetFindableGroups sets FindableGroups field to given value.

### HasFindableGroups

`func (o *V11ProvidersLdapLdapItem) HasFindableGroups() bool`

HasFindableGroups returns a boolean if a field has been set.

### GetFindableUsers

`func (o *V11ProvidersLdapLdapItem) GetFindableUsers() []string`

GetFindableUsers returns the FindableUsers field if non-nil, zero value otherwise.

### GetFindableUsersOk

`func (o *V11ProvidersLdapLdapItem) GetFindableUsersOk() (*[]string, bool)`

GetFindableUsersOk returns a tuple with the FindableUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFindableUsers

`func (o *V11ProvidersLdapLdapItem) SetFindableUsers(v []string)`

SetFindableUsers sets FindableUsers field to given value.

### HasFindableUsers

`func (o *V11ProvidersLdapLdapItem) HasFindableUsers() bool`

HasFindableUsers returns a boolean if a field has been set.

### GetGecosAttribute

`func (o *V11ProvidersLdapLdapItem) GetGecosAttribute() string`

GetGecosAttribute returns the GecosAttribute field if non-nil, zero value otherwise.

### GetGecosAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetGecosAttributeOk() (*string, bool)`

GetGecosAttributeOk returns a tuple with the GecosAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGecosAttribute

`func (o *V11ProvidersLdapLdapItem) SetGecosAttribute(v string)`

SetGecosAttribute sets GecosAttribute field to given value.

### HasGecosAttribute

`func (o *V11ProvidersLdapLdapItem) HasGecosAttribute() bool`

HasGecosAttribute returns a boolean if a field has been set.

### GetGidAttribute

`func (o *V11ProvidersLdapLdapItem) GetGidAttribute() string`

GetGidAttribute returns the GidAttribute field if non-nil, zero value otherwise.

### GetGidAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetGidAttributeOk() (*string, bool)`

GetGidAttributeOk returns a tuple with the GidAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGidAttribute

`func (o *V11ProvidersLdapLdapItem) SetGidAttribute(v string)`

SetGidAttribute sets GidAttribute field to given value.

### HasGidAttribute

`func (o *V11ProvidersLdapLdapItem) HasGidAttribute() bool`

HasGidAttribute returns a boolean if a field has been set.

### GetGroupBaseDn

`func (o *V11ProvidersLdapLdapItem) GetGroupBaseDn() string`

GetGroupBaseDn returns the GroupBaseDn field if non-nil, zero value otherwise.

### GetGroupBaseDnOk

`func (o *V11ProvidersLdapLdapItem) GetGroupBaseDnOk() (*string, bool)`

GetGroupBaseDnOk returns a tuple with the GroupBaseDn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupBaseDn

`func (o *V11ProvidersLdapLdapItem) SetGroupBaseDn(v string)`

SetGroupBaseDn sets GroupBaseDn field to given value.

### HasGroupBaseDn

`func (o *V11ProvidersLdapLdapItem) HasGroupBaseDn() bool`

HasGroupBaseDn returns a boolean if a field has been set.

### GetGroupDomain

`func (o *V11ProvidersLdapLdapItem) GetGroupDomain() string`

GetGroupDomain returns the GroupDomain field if non-nil, zero value otherwise.

### GetGroupDomainOk

`func (o *V11ProvidersLdapLdapItem) GetGroupDomainOk() (*string, bool)`

GetGroupDomainOk returns a tuple with the GroupDomain field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupDomain

`func (o *V11ProvidersLdapLdapItem) SetGroupDomain(v string)`

SetGroupDomain sets GroupDomain field to given value.

### HasGroupDomain

`func (o *V11ProvidersLdapLdapItem) HasGroupDomain() bool`

HasGroupDomain returns a boolean if a field has been set.

### GetGroupFilter

`func (o *V11ProvidersLdapLdapItem) GetGroupFilter() string`

GetGroupFilter returns the GroupFilter field if non-nil, zero value otherwise.

### GetGroupFilterOk

`func (o *V11ProvidersLdapLdapItem) GetGroupFilterOk() (*string, bool)`

GetGroupFilterOk returns a tuple with the GroupFilter field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupFilter

`func (o *V11ProvidersLdapLdapItem) SetGroupFilter(v string)`

SetGroupFilter sets GroupFilter field to given value.

### HasGroupFilter

`func (o *V11ProvidersLdapLdapItem) HasGroupFilter() bool`

HasGroupFilter returns a boolean if a field has been set.

### GetGroupMembersAttribute

`func (o *V11ProvidersLdapLdapItem) GetGroupMembersAttribute() string`

GetGroupMembersAttribute returns the GroupMembersAttribute field if non-nil, zero value otherwise.

### GetGroupMembersAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetGroupMembersAttributeOk() (*string, bool)`

GetGroupMembersAttributeOk returns a tuple with the GroupMembersAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupMembersAttribute

`func (o *V11ProvidersLdapLdapItem) SetGroupMembersAttribute(v string)`

SetGroupMembersAttribute sets GroupMembersAttribute field to given value.

### HasGroupMembersAttribute

`func (o *V11ProvidersLdapLdapItem) HasGroupMembersAttribute() bool`

HasGroupMembersAttribute returns a boolean if a field has been set.

### GetGroupSearchScope

`func (o *V11ProvidersLdapLdapItem) GetGroupSearchScope() string`

GetGroupSearchScope returns the GroupSearchScope field if non-nil, zero value otherwise.

### GetGroupSearchScopeOk

`func (o *V11ProvidersLdapLdapItem) GetGroupSearchScopeOk() (*string, bool)`

GetGroupSearchScopeOk returns a tuple with the GroupSearchScope field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupSearchScope

`func (o *V11ProvidersLdapLdapItem) SetGroupSearchScope(v string)`

SetGroupSearchScope sets GroupSearchScope field to given value.

### HasGroupSearchScope

`func (o *V11ProvidersLdapLdapItem) HasGroupSearchScope() bool`

HasGroupSearchScope returns a boolean if a field has been set.

### GetGroupnet

`func (o *V11ProvidersLdapLdapItem) GetGroupnet() string`

GetGroupnet returns the Groupnet field if non-nil, zero value otherwise.

### GetGroupnetOk

`func (o *V11ProvidersLdapLdapItem) GetGroupnetOk() (*string, bool)`

GetGroupnetOk returns a tuple with the Groupnet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupnet

`func (o *V11ProvidersLdapLdapItem) SetGroupnet(v string)`

SetGroupnet sets Groupnet field to given value.

### HasGroupnet

`func (o *V11ProvidersLdapLdapItem) HasGroupnet() bool`

HasGroupnet returns a boolean if a field has been set.

### GetHomeDirectoryTemplate

`func (o *V11ProvidersLdapLdapItem) GetHomeDirectoryTemplate() string`

GetHomeDirectoryTemplate returns the HomeDirectoryTemplate field if non-nil, zero value otherwise.

### GetHomeDirectoryTemplateOk

`func (o *V11ProvidersLdapLdapItem) GetHomeDirectoryTemplateOk() (*string, bool)`

GetHomeDirectoryTemplateOk returns a tuple with the HomeDirectoryTemplate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHomeDirectoryTemplate

`func (o *V11ProvidersLdapLdapItem) SetHomeDirectoryTemplate(v string)`

SetHomeDirectoryTemplate sets HomeDirectoryTemplate field to given value.

### HasHomeDirectoryTemplate

`func (o *V11ProvidersLdapLdapItem) HasHomeDirectoryTemplate() bool`

HasHomeDirectoryTemplate returns a boolean if a field has been set.

### GetHomedirAttribute

`func (o *V11ProvidersLdapLdapItem) GetHomedirAttribute() string`

GetHomedirAttribute returns the HomedirAttribute field if non-nil, zero value otherwise.

### GetHomedirAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetHomedirAttributeOk() (*string, bool)`

GetHomedirAttributeOk returns a tuple with the HomedirAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHomedirAttribute

`func (o *V11ProvidersLdapLdapItem) SetHomedirAttribute(v string)`

SetHomedirAttribute sets HomedirAttribute field to given value.

### HasHomedirAttribute

`func (o *V11ProvidersLdapLdapItem) HasHomedirAttribute() bool`

HasHomedirAttribute returns a boolean if a field has been set.

### GetId

`func (o *V11ProvidersLdapLdapItem) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V11ProvidersLdapLdapItem) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V11ProvidersLdapLdapItem) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V11ProvidersLdapLdapItem) HasId() bool`

HasId returns a boolean if a field has been set.

### GetIgnoreTlsErrors

`func (o *V11ProvidersLdapLdapItem) GetIgnoreTlsErrors() bool`

GetIgnoreTlsErrors returns the IgnoreTlsErrors field if non-nil, zero value otherwise.

### GetIgnoreTlsErrorsOk

`func (o *V11ProvidersLdapLdapItem) GetIgnoreTlsErrorsOk() (*bool, bool)`

GetIgnoreTlsErrorsOk returns a tuple with the IgnoreTlsErrors field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIgnoreTlsErrors

`func (o *V11ProvidersLdapLdapItem) SetIgnoreTlsErrors(v bool)`

SetIgnoreTlsErrors sets IgnoreTlsErrors field to given value.

### HasIgnoreTlsErrors

`func (o *V11ProvidersLdapLdapItem) HasIgnoreTlsErrors() bool`

HasIgnoreTlsErrors returns a boolean if a field has been set.

### GetListableGroups

`func (o *V11ProvidersLdapLdapItem) GetListableGroups() []string`

GetListableGroups returns the ListableGroups field if non-nil, zero value otherwise.

### GetListableGroupsOk

`func (o *V11ProvidersLdapLdapItem) GetListableGroupsOk() (*[]string, bool)`

GetListableGroupsOk returns a tuple with the ListableGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetListableGroups

`func (o *V11ProvidersLdapLdapItem) SetListableGroups(v []string)`

SetListableGroups sets ListableGroups field to given value.

### HasListableGroups

`func (o *V11ProvidersLdapLdapItem) HasListableGroups() bool`

HasListableGroups returns a boolean if a field has been set.

### GetListableUsers

`func (o *V11ProvidersLdapLdapItem) GetListableUsers() []string`

GetListableUsers returns the ListableUsers field if non-nil, zero value otherwise.

### GetListableUsersOk

`func (o *V11ProvidersLdapLdapItem) GetListableUsersOk() (*[]string, bool)`

GetListableUsersOk returns a tuple with the ListableUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetListableUsers

`func (o *V11ProvidersLdapLdapItem) SetListableUsers(v []string)`

SetListableUsers sets ListableUsers field to given value.

### HasListableUsers

`func (o *V11ProvidersLdapLdapItem) HasListableUsers() bool`

HasListableUsers returns a boolean if a field has been set.

### GetLoginShell

`func (o *V11ProvidersLdapLdapItem) GetLoginShell() string`

GetLoginShell returns the LoginShell field if non-nil, zero value otherwise.

### GetLoginShellOk

`func (o *V11ProvidersLdapLdapItem) GetLoginShellOk() (*string, bool)`

GetLoginShellOk returns a tuple with the LoginShell field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLoginShell

`func (o *V11ProvidersLdapLdapItem) SetLoginShell(v string)`

SetLoginShell sets LoginShell field to given value.

### HasLoginShell

`func (o *V11ProvidersLdapLdapItem) HasLoginShell() bool`

HasLoginShell returns a boolean if a field has been set.

### GetMemberLookupMethod

`func (o *V11ProvidersLdapLdapItem) GetMemberLookupMethod() string`

GetMemberLookupMethod returns the MemberLookupMethod field if non-nil, zero value otherwise.

### GetMemberLookupMethodOk

`func (o *V11ProvidersLdapLdapItem) GetMemberLookupMethodOk() (*string, bool)`

GetMemberLookupMethodOk returns a tuple with the MemberLookupMethod field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMemberLookupMethod

`func (o *V11ProvidersLdapLdapItem) SetMemberLookupMethod(v string)`

SetMemberLookupMethod sets MemberLookupMethod field to given value.

### HasMemberLookupMethod

`func (o *V11ProvidersLdapLdapItem) HasMemberLookupMethod() bool`

HasMemberLookupMethod returns a boolean if a field has been set.

### GetMemberOfAttribute

`func (o *V11ProvidersLdapLdapItem) GetMemberOfAttribute() string`

GetMemberOfAttribute returns the MemberOfAttribute field if non-nil, zero value otherwise.

### GetMemberOfAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetMemberOfAttributeOk() (*string, bool)`

GetMemberOfAttributeOk returns a tuple with the MemberOfAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMemberOfAttribute

`func (o *V11ProvidersLdapLdapItem) SetMemberOfAttribute(v string)`

SetMemberOfAttribute sets MemberOfAttribute field to given value.

### HasMemberOfAttribute

`func (o *V11ProvidersLdapLdapItem) HasMemberOfAttribute() bool`

HasMemberOfAttribute returns a boolean if a field has been set.

### GetName

`func (o *V11ProvidersLdapLdapItem) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V11ProvidersLdapLdapItem) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V11ProvidersLdapLdapItem) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V11ProvidersLdapLdapItem) HasName() bool`

HasName returns a boolean if a field has been set.

### GetNameAttribute

`func (o *V11ProvidersLdapLdapItem) GetNameAttribute() string`

GetNameAttribute returns the NameAttribute field if non-nil, zero value otherwise.

### GetNameAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetNameAttributeOk() (*string, bool)`

GetNameAttributeOk returns a tuple with the NameAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNameAttribute

`func (o *V11ProvidersLdapLdapItem) SetNameAttribute(v string)`

SetNameAttribute sets NameAttribute field to given value.

### HasNameAttribute

`func (o *V11ProvidersLdapLdapItem) HasNameAttribute() bool`

HasNameAttribute returns a boolean if a field has been set.

### GetNetgroupBaseDn

`func (o *V11ProvidersLdapLdapItem) GetNetgroupBaseDn() string`

GetNetgroupBaseDn returns the NetgroupBaseDn field if non-nil, zero value otherwise.

### GetNetgroupBaseDnOk

`func (o *V11ProvidersLdapLdapItem) GetNetgroupBaseDnOk() (*string, bool)`

GetNetgroupBaseDnOk returns a tuple with the NetgroupBaseDn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetgroupBaseDn

`func (o *V11ProvidersLdapLdapItem) SetNetgroupBaseDn(v string)`

SetNetgroupBaseDn sets NetgroupBaseDn field to given value.

### HasNetgroupBaseDn

`func (o *V11ProvidersLdapLdapItem) HasNetgroupBaseDn() bool`

HasNetgroupBaseDn returns a boolean if a field has been set.

### GetNetgroupFilter

`func (o *V11ProvidersLdapLdapItem) GetNetgroupFilter() string`

GetNetgroupFilter returns the NetgroupFilter field if non-nil, zero value otherwise.

### GetNetgroupFilterOk

`func (o *V11ProvidersLdapLdapItem) GetNetgroupFilterOk() (*string, bool)`

GetNetgroupFilterOk returns a tuple with the NetgroupFilter field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetgroupFilter

`func (o *V11ProvidersLdapLdapItem) SetNetgroupFilter(v string)`

SetNetgroupFilter sets NetgroupFilter field to given value.

### HasNetgroupFilter

`func (o *V11ProvidersLdapLdapItem) HasNetgroupFilter() bool`

HasNetgroupFilter returns a boolean if a field has been set.

### GetNetgroupMembersAttribute

`func (o *V11ProvidersLdapLdapItem) GetNetgroupMembersAttribute() string`

GetNetgroupMembersAttribute returns the NetgroupMembersAttribute field if non-nil, zero value otherwise.

### GetNetgroupMembersAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetNetgroupMembersAttributeOk() (*string, bool)`

GetNetgroupMembersAttributeOk returns a tuple with the NetgroupMembersAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetgroupMembersAttribute

`func (o *V11ProvidersLdapLdapItem) SetNetgroupMembersAttribute(v string)`

SetNetgroupMembersAttribute sets NetgroupMembersAttribute field to given value.

### HasNetgroupMembersAttribute

`func (o *V11ProvidersLdapLdapItem) HasNetgroupMembersAttribute() bool`

HasNetgroupMembersAttribute returns a boolean if a field has been set.

### GetNetgroupSearchScope

`func (o *V11ProvidersLdapLdapItem) GetNetgroupSearchScope() string`

GetNetgroupSearchScope returns the NetgroupSearchScope field if non-nil, zero value otherwise.

### GetNetgroupSearchScopeOk

`func (o *V11ProvidersLdapLdapItem) GetNetgroupSearchScopeOk() (*string, bool)`

GetNetgroupSearchScopeOk returns a tuple with the NetgroupSearchScope field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetgroupSearchScope

`func (o *V11ProvidersLdapLdapItem) SetNetgroupSearchScope(v string)`

SetNetgroupSearchScope sets NetgroupSearchScope field to given value.

### HasNetgroupSearchScope

`func (o *V11ProvidersLdapLdapItem) HasNetgroupSearchScope() bool`

HasNetgroupSearchScope returns a boolean if a field has been set.

### GetNetgroupTripleAttribute

`func (o *V11ProvidersLdapLdapItem) GetNetgroupTripleAttribute() string`

GetNetgroupTripleAttribute returns the NetgroupTripleAttribute field if non-nil, zero value otherwise.

### GetNetgroupTripleAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetNetgroupTripleAttributeOk() (*string, bool)`

GetNetgroupTripleAttributeOk returns a tuple with the NetgroupTripleAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetgroupTripleAttribute

`func (o *V11ProvidersLdapLdapItem) SetNetgroupTripleAttribute(v string)`

SetNetgroupTripleAttribute sets NetgroupTripleAttribute field to given value.

### HasNetgroupTripleAttribute

`func (o *V11ProvidersLdapLdapItem) HasNetgroupTripleAttribute() bool`

HasNetgroupTripleAttribute returns a boolean if a field has been set.

### GetNormalizeGroups

`func (o *V11ProvidersLdapLdapItem) GetNormalizeGroups() bool`

GetNormalizeGroups returns the NormalizeGroups field if non-nil, zero value otherwise.

### GetNormalizeGroupsOk

`func (o *V11ProvidersLdapLdapItem) GetNormalizeGroupsOk() (*bool, bool)`

GetNormalizeGroupsOk returns a tuple with the NormalizeGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNormalizeGroups

`func (o *V11ProvidersLdapLdapItem) SetNormalizeGroups(v bool)`

SetNormalizeGroups sets NormalizeGroups field to given value.

### HasNormalizeGroups

`func (o *V11ProvidersLdapLdapItem) HasNormalizeGroups() bool`

HasNormalizeGroups returns a boolean if a field has been set.

### GetNormalizeUsers

`func (o *V11ProvidersLdapLdapItem) GetNormalizeUsers() bool`

GetNormalizeUsers returns the NormalizeUsers field if non-nil, zero value otherwise.

### GetNormalizeUsersOk

`func (o *V11ProvidersLdapLdapItem) GetNormalizeUsersOk() (*bool, bool)`

GetNormalizeUsersOk returns a tuple with the NormalizeUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNormalizeUsers

`func (o *V11ProvidersLdapLdapItem) SetNormalizeUsers(v bool)`

SetNormalizeUsers sets NormalizeUsers field to given value.

### HasNormalizeUsers

`func (o *V11ProvidersLdapLdapItem) HasNormalizeUsers() bool`

HasNormalizeUsers returns a boolean if a field has been set.

### GetNtPasswordAttribute

`func (o *V11ProvidersLdapLdapItem) GetNtPasswordAttribute() string`

GetNtPasswordAttribute returns the NtPasswordAttribute field if non-nil, zero value otherwise.

### GetNtPasswordAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetNtPasswordAttributeOk() (*string, bool)`

GetNtPasswordAttributeOk returns a tuple with the NtPasswordAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNtPasswordAttribute

`func (o *V11ProvidersLdapLdapItem) SetNtPasswordAttribute(v string)`

SetNtPasswordAttribute sets NtPasswordAttribute field to given value.

### HasNtPasswordAttribute

`func (o *V11ProvidersLdapLdapItem) HasNtPasswordAttribute() bool`

HasNtPasswordAttribute returns a boolean if a field has been set.

### GetNtlmSupport

`func (o *V11ProvidersLdapLdapItem) GetNtlmSupport() string`

GetNtlmSupport returns the NtlmSupport field if non-nil, zero value otherwise.

### GetNtlmSupportOk

`func (o *V11ProvidersLdapLdapItem) GetNtlmSupportOk() (*string, bool)`

GetNtlmSupportOk returns a tuple with the NtlmSupport field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNtlmSupport

`func (o *V11ProvidersLdapLdapItem) SetNtlmSupport(v string)`

SetNtlmSupport sets NtlmSupport field to given value.

### HasNtlmSupport

`func (o *V11ProvidersLdapLdapItem) HasNtlmSupport() bool`

HasNtlmSupport returns a boolean if a field has been set.

### GetProviderDomain

`func (o *V11ProvidersLdapLdapItem) GetProviderDomain() string`

GetProviderDomain returns the ProviderDomain field if non-nil, zero value otherwise.

### GetProviderDomainOk

`func (o *V11ProvidersLdapLdapItem) GetProviderDomainOk() (*string, bool)`

GetProviderDomainOk returns a tuple with the ProviderDomain field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProviderDomain

`func (o *V11ProvidersLdapLdapItem) SetProviderDomain(v string)`

SetProviderDomain sets ProviderDomain field to given value.

### HasProviderDomain

`func (o *V11ProvidersLdapLdapItem) HasProviderDomain() bool`

HasProviderDomain returns a boolean if a field has been set.

### GetRequireSecureConnection

`func (o *V11ProvidersLdapLdapItem) GetRequireSecureConnection() bool`

GetRequireSecureConnection returns the RequireSecureConnection field if non-nil, zero value otherwise.

### GetRequireSecureConnectionOk

`func (o *V11ProvidersLdapLdapItem) GetRequireSecureConnectionOk() (*bool, bool)`

GetRequireSecureConnectionOk returns a tuple with the RequireSecureConnection field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRequireSecureConnection

`func (o *V11ProvidersLdapLdapItem) SetRequireSecureConnection(v bool)`

SetRequireSecureConnection sets RequireSecureConnection field to given value.

### HasRequireSecureConnection

`func (o *V11ProvidersLdapLdapItem) HasRequireSecureConnection() bool`

HasRequireSecureConnection returns a boolean if a field has been set.

### GetRestrictFindable

`func (o *V11ProvidersLdapLdapItem) GetRestrictFindable() bool`

GetRestrictFindable returns the RestrictFindable field if non-nil, zero value otherwise.

### GetRestrictFindableOk

`func (o *V11ProvidersLdapLdapItem) GetRestrictFindableOk() (*bool, bool)`

GetRestrictFindableOk returns a tuple with the RestrictFindable field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRestrictFindable

`func (o *V11ProvidersLdapLdapItem) SetRestrictFindable(v bool)`

SetRestrictFindable sets RestrictFindable field to given value.

### HasRestrictFindable

`func (o *V11ProvidersLdapLdapItem) HasRestrictFindable() bool`

HasRestrictFindable returns a boolean if a field has been set.

### GetRestrictListable

`func (o *V11ProvidersLdapLdapItem) GetRestrictListable() bool`

GetRestrictListable returns the RestrictListable field if non-nil, zero value otherwise.

### GetRestrictListableOk

`func (o *V11ProvidersLdapLdapItem) GetRestrictListableOk() (*bool, bool)`

GetRestrictListableOk returns a tuple with the RestrictListable field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRestrictListable

`func (o *V11ProvidersLdapLdapItem) SetRestrictListable(v bool)`

SetRestrictListable sets RestrictListable field to given value.

### HasRestrictListable

`func (o *V11ProvidersLdapLdapItem) HasRestrictListable() bool`

HasRestrictListable returns a boolean if a field has been set.

### GetSearchScope

`func (o *V11ProvidersLdapLdapItem) GetSearchScope() string`

GetSearchScope returns the SearchScope field if non-nil, zero value otherwise.

### GetSearchScopeOk

`func (o *V11ProvidersLdapLdapItem) GetSearchScopeOk() (*string, bool)`

GetSearchScopeOk returns a tuple with the SearchScope field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSearchScope

`func (o *V11ProvidersLdapLdapItem) SetSearchScope(v string)`

SetSearchScope sets SearchScope field to given value.

### HasSearchScope

`func (o *V11ProvidersLdapLdapItem) HasSearchScope() bool`

HasSearchScope returns a boolean if a field has been set.

### GetSearchTimeout

`func (o *V11ProvidersLdapLdapItem) GetSearchTimeout() int64`

GetSearchTimeout returns the SearchTimeout field if non-nil, zero value otherwise.

### GetSearchTimeoutOk

`func (o *V11ProvidersLdapLdapItem) GetSearchTimeoutOk() (*int64, bool)`

GetSearchTimeoutOk returns a tuple with the SearchTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSearchTimeout

`func (o *V11ProvidersLdapLdapItem) SetSearchTimeout(v int64)`

SetSearchTimeout sets SearchTimeout field to given value.

### HasSearchTimeout

`func (o *V11ProvidersLdapLdapItem) HasSearchTimeout() bool`

HasSearchTimeout returns a boolean if a field has been set.

### GetServerUris

`func (o *V11ProvidersLdapLdapItem) GetServerUris() []string`

GetServerUris returns the ServerUris field if non-nil, zero value otherwise.

### GetServerUrisOk

`func (o *V11ProvidersLdapLdapItem) GetServerUrisOk() (*[]string, bool)`

GetServerUrisOk returns a tuple with the ServerUris field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServerUris

`func (o *V11ProvidersLdapLdapItem) SetServerUris(v []string)`

SetServerUris sets ServerUris field to given value.

### HasServerUris

`func (o *V11ProvidersLdapLdapItem) HasServerUris() bool`

HasServerUris returns a boolean if a field has been set.

### GetShadowExpireAttribute

`func (o *V11ProvidersLdapLdapItem) GetShadowExpireAttribute() string`

GetShadowExpireAttribute returns the ShadowExpireAttribute field if non-nil, zero value otherwise.

### GetShadowExpireAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetShadowExpireAttributeOk() (*string, bool)`

GetShadowExpireAttributeOk returns a tuple with the ShadowExpireAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShadowExpireAttribute

`func (o *V11ProvidersLdapLdapItem) SetShadowExpireAttribute(v string)`

SetShadowExpireAttribute sets ShadowExpireAttribute field to given value.

### HasShadowExpireAttribute

`func (o *V11ProvidersLdapLdapItem) HasShadowExpireAttribute() bool`

HasShadowExpireAttribute returns a boolean if a field has been set.

### GetShadowFlagAttribute

`func (o *V11ProvidersLdapLdapItem) GetShadowFlagAttribute() string`

GetShadowFlagAttribute returns the ShadowFlagAttribute field if non-nil, zero value otherwise.

### GetShadowFlagAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetShadowFlagAttributeOk() (*string, bool)`

GetShadowFlagAttributeOk returns a tuple with the ShadowFlagAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShadowFlagAttribute

`func (o *V11ProvidersLdapLdapItem) SetShadowFlagAttribute(v string)`

SetShadowFlagAttribute sets ShadowFlagAttribute field to given value.

### HasShadowFlagAttribute

`func (o *V11ProvidersLdapLdapItem) HasShadowFlagAttribute() bool`

HasShadowFlagAttribute returns a boolean if a field has been set.

### GetShadowInactiveAttribute

`func (o *V11ProvidersLdapLdapItem) GetShadowInactiveAttribute() string`

GetShadowInactiveAttribute returns the ShadowInactiveAttribute field if non-nil, zero value otherwise.

### GetShadowInactiveAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetShadowInactiveAttributeOk() (*string, bool)`

GetShadowInactiveAttributeOk returns a tuple with the ShadowInactiveAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShadowInactiveAttribute

`func (o *V11ProvidersLdapLdapItem) SetShadowInactiveAttribute(v string)`

SetShadowInactiveAttribute sets ShadowInactiveAttribute field to given value.

### HasShadowInactiveAttribute

`func (o *V11ProvidersLdapLdapItem) HasShadowInactiveAttribute() bool`

HasShadowInactiveAttribute returns a boolean if a field has been set.

### GetShadowLastChangeAttribute

`func (o *V11ProvidersLdapLdapItem) GetShadowLastChangeAttribute() string`

GetShadowLastChangeAttribute returns the ShadowLastChangeAttribute field if non-nil, zero value otherwise.

### GetShadowLastChangeAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetShadowLastChangeAttributeOk() (*string, bool)`

GetShadowLastChangeAttributeOk returns a tuple with the ShadowLastChangeAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShadowLastChangeAttribute

`func (o *V11ProvidersLdapLdapItem) SetShadowLastChangeAttribute(v string)`

SetShadowLastChangeAttribute sets ShadowLastChangeAttribute field to given value.

### HasShadowLastChangeAttribute

`func (o *V11ProvidersLdapLdapItem) HasShadowLastChangeAttribute() bool`

HasShadowLastChangeAttribute returns a boolean if a field has been set.

### GetShadowMaxAttribute

`func (o *V11ProvidersLdapLdapItem) GetShadowMaxAttribute() string`

GetShadowMaxAttribute returns the ShadowMaxAttribute field if non-nil, zero value otherwise.

### GetShadowMaxAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetShadowMaxAttributeOk() (*string, bool)`

GetShadowMaxAttributeOk returns a tuple with the ShadowMaxAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShadowMaxAttribute

`func (o *V11ProvidersLdapLdapItem) SetShadowMaxAttribute(v string)`

SetShadowMaxAttribute sets ShadowMaxAttribute field to given value.

### HasShadowMaxAttribute

`func (o *V11ProvidersLdapLdapItem) HasShadowMaxAttribute() bool`

HasShadowMaxAttribute returns a boolean if a field has been set.

### GetShadowMinAttribute

`func (o *V11ProvidersLdapLdapItem) GetShadowMinAttribute() string`

GetShadowMinAttribute returns the ShadowMinAttribute field if non-nil, zero value otherwise.

### GetShadowMinAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetShadowMinAttributeOk() (*string, bool)`

GetShadowMinAttributeOk returns a tuple with the ShadowMinAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShadowMinAttribute

`func (o *V11ProvidersLdapLdapItem) SetShadowMinAttribute(v string)`

SetShadowMinAttribute sets ShadowMinAttribute field to given value.

### HasShadowMinAttribute

`func (o *V11ProvidersLdapLdapItem) HasShadowMinAttribute() bool`

HasShadowMinAttribute returns a boolean if a field has been set.

### GetShadowUserFilter

`func (o *V11ProvidersLdapLdapItem) GetShadowUserFilter() string`

GetShadowUserFilter returns the ShadowUserFilter field if non-nil, zero value otherwise.

### GetShadowUserFilterOk

`func (o *V11ProvidersLdapLdapItem) GetShadowUserFilterOk() (*string, bool)`

GetShadowUserFilterOk returns a tuple with the ShadowUserFilter field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShadowUserFilter

`func (o *V11ProvidersLdapLdapItem) SetShadowUserFilter(v string)`

SetShadowUserFilter sets ShadowUserFilter field to given value.

### HasShadowUserFilter

`func (o *V11ProvidersLdapLdapItem) HasShadowUserFilter() bool`

HasShadowUserFilter returns a boolean if a field has been set.

### GetShadowWarningAttribute

`func (o *V11ProvidersLdapLdapItem) GetShadowWarningAttribute() string`

GetShadowWarningAttribute returns the ShadowWarningAttribute field if non-nil, zero value otherwise.

### GetShadowWarningAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetShadowWarningAttributeOk() (*string, bool)`

GetShadowWarningAttributeOk returns a tuple with the ShadowWarningAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShadowWarningAttribute

`func (o *V11ProvidersLdapLdapItem) SetShadowWarningAttribute(v string)`

SetShadowWarningAttribute sets ShadowWarningAttribute field to given value.

### HasShadowWarningAttribute

`func (o *V11ProvidersLdapLdapItem) HasShadowWarningAttribute() bool`

HasShadowWarningAttribute returns a boolean if a field has been set.

### GetShellAttribute

`func (o *V11ProvidersLdapLdapItem) GetShellAttribute() string`

GetShellAttribute returns the ShellAttribute field if non-nil, zero value otherwise.

### GetShellAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetShellAttributeOk() (*string, bool)`

GetShellAttributeOk returns a tuple with the ShellAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShellAttribute

`func (o *V11ProvidersLdapLdapItem) SetShellAttribute(v string)`

SetShellAttribute sets ShellAttribute field to given value.

### HasShellAttribute

`func (o *V11ProvidersLdapLdapItem) HasShellAttribute() bool`

HasShellAttribute returns a boolean if a field has been set.

### GetSshPublicKeyAttribute

`func (o *V11ProvidersLdapLdapItem) GetSshPublicKeyAttribute() string`

GetSshPublicKeyAttribute returns the SshPublicKeyAttribute field if non-nil, zero value otherwise.

### GetSshPublicKeyAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetSshPublicKeyAttributeOk() (*string, bool)`

GetSshPublicKeyAttributeOk returns a tuple with the SshPublicKeyAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSshPublicKeyAttribute

`func (o *V11ProvidersLdapLdapItem) SetSshPublicKeyAttribute(v string)`

SetSshPublicKeyAttribute sets SshPublicKeyAttribute field to given value.

### HasSshPublicKeyAttribute

`func (o *V11ProvidersLdapLdapItem) HasSshPublicKeyAttribute() bool`

HasSshPublicKeyAttribute returns a boolean if a field has been set.

### GetStatus

`func (o *V11ProvidersLdapLdapItem) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V11ProvidersLdapLdapItem) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V11ProvidersLdapLdapItem) SetStatus(v string)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V11ProvidersLdapLdapItem) HasStatus() bool`

HasStatus returns a boolean if a field has been set.

### GetSystem

`func (o *V11ProvidersLdapLdapItem) GetSystem() bool`

GetSystem returns the System field if non-nil, zero value otherwise.

### GetSystemOk

`func (o *V11ProvidersLdapLdapItem) GetSystemOk() (*bool, bool)`

GetSystemOk returns a tuple with the System field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSystem

`func (o *V11ProvidersLdapLdapItem) SetSystem(v bool)`

SetSystem sets System field to given value.

### HasSystem

`func (o *V11ProvidersLdapLdapItem) HasSystem() bool`

HasSystem returns a boolean if a field has been set.

### GetTlsProtocolMin

`func (o *V11ProvidersLdapLdapItem) GetTlsProtocolMin() string`

GetTlsProtocolMin returns the TlsProtocolMin field if non-nil, zero value otherwise.

### GetTlsProtocolMinOk

`func (o *V11ProvidersLdapLdapItem) GetTlsProtocolMinOk() (*string, bool)`

GetTlsProtocolMinOk returns a tuple with the TlsProtocolMin field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTlsProtocolMin

`func (o *V11ProvidersLdapLdapItem) SetTlsProtocolMin(v string)`

SetTlsProtocolMin sets TlsProtocolMin field to given value.

### HasTlsProtocolMin

`func (o *V11ProvidersLdapLdapItem) HasTlsProtocolMin() bool`

HasTlsProtocolMin returns a boolean if a field has been set.

### GetUidAttribute

`func (o *V11ProvidersLdapLdapItem) GetUidAttribute() string`

GetUidAttribute returns the UidAttribute field if non-nil, zero value otherwise.

### GetUidAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetUidAttributeOk() (*string, bool)`

GetUidAttributeOk returns a tuple with the UidAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUidAttribute

`func (o *V11ProvidersLdapLdapItem) SetUidAttribute(v string)`

SetUidAttribute sets UidAttribute field to given value.

### HasUidAttribute

`func (o *V11ProvidersLdapLdapItem) HasUidAttribute() bool`

HasUidAttribute returns a boolean if a field has been set.

### GetUnfindableGroups

`func (o *V11ProvidersLdapLdapItem) GetUnfindableGroups() []string`

GetUnfindableGroups returns the UnfindableGroups field if non-nil, zero value otherwise.

### GetUnfindableGroupsOk

`func (o *V11ProvidersLdapLdapItem) GetUnfindableGroupsOk() (*[]string, bool)`

GetUnfindableGroupsOk returns a tuple with the UnfindableGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnfindableGroups

`func (o *V11ProvidersLdapLdapItem) SetUnfindableGroups(v []string)`

SetUnfindableGroups sets UnfindableGroups field to given value.

### HasUnfindableGroups

`func (o *V11ProvidersLdapLdapItem) HasUnfindableGroups() bool`

HasUnfindableGroups returns a boolean if a field has been set.

### GetUnfindableUsers

`func (o *V11ProvidersLdapLdapItem) GetUnfindableUsers() []string`

GetUnfindableUsers returns the UnfindableUsers field if non-nil, zero value otherwise.

### GetUnfindableUsersOk

`func (o *V11ProvidersLdapLdapItem) GetUnfindableUsersOk() (*[]string, bool)`

GetUnfindableUsersOk returns a tuple with the UnfindableUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnfindableUsers

`func (o *V11ProvidersLdapLdapItem) SetUnfindableUsers(v []string)`

SetUnfindableUsers sets UnfindableUsers field to given value.

### HasUnfindableUsers

`func (o *V11ProvidersLdapLdapItem) HasUnfindableUsers() bool`

HasUnfindableUsers returns a boolean if a field has been set.

### GetUniqueGroupMembersAttribute

`func (o *V11ProvidersLdapLdapItem) GetUniqueGroupMembersAttribute() string`

GetUniqueGroupMembersAttribute returns the UniqueGroupMembersAttribute field if non-nil, zero value otherwise.

### GetUniqueGroupMembersAttributeOk

`func (o *V11ProvidersLdapLdapItem) GetUniqueGroupMembersAttributeOk() (*string, bool)`

GetUniqueGroupMembersAttributeOk returns a tuple with the UniqueGroupMembersAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUniqueGroupMembersAttribute

`func (o *V11ProvidersLdapLdapItem) SetUniqueGroupMembersAttribute(v string)`

SetUniqueGroupMembersAttribute sets UniqueGroupMembersAttribute field to given value.

### HasUniqueGroupMembersAttribute

`func (o *V11ProvidersLdapLdapItem) HasUniqueGroupMembersAttribute() bool`

HasUniqueGroupMembersAttribute returns a boolean if a field has been set.

### GetUnlistableGroups

`func (o *V11ProvidersLdapLdapItem) GetUnlistableGroups() []string`

GetUnlistableGroups returns the UnlistableGroups field if non-nil, zero value otherwise.

### GetUnlistableGroupsOk

`func (o *V11ProvidersLdapLdapItem) GetUnlistableGroupsOk() (*[]string, bool)`

GetUnlistableGroupsOk returns a tuple with the UnlistableGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnlistableGroups

`func (o *V11ProvidersLdapLdapItem) SetUnlistableGroups(v []string)`

SetUnlistableGroups sets UnlistableGroups field to given value.

### HasUnlistableGroups

`func (o *V11ProvidersLdapLdapItem) HasUnlistableGroups() bool`

HasUnlistableGroups returns a boolean if a field has been set.

### GetUnlistableUsers

`func (o *V11ProvidersLdapLdapItem) GetUnlistableUsers() []string`

GetUnlistableUsers returns the UnlistableUsers field if non-nil, zero value otherwise.

### GetUnlistableUsersOk

`func (o *V11ProvidersLdapLdapItem) GetUnlistableUsersOk() (*[]string, bool)`

GetUnlistableUsersOk returns a tuple with the UnlistableUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnlistableUsers

`func (o *V11ProvidersLdapLdapItem) SetUnlistableUsers(v []string)`

SetUnlistableUsers sets UnlistableUsers field to given value.

### HasUnlistableUsers

`func (o *V11ProvidersLdapLdapItem) HasUnlistableUsers() bool`

HasUnlistableUsers returns a boolean if a field has been set.

### GetUserBaseDn

`func (o *V11ProvidersLdapLdapItem) GetUserBaseDn() string`

GetUserBaseDn returns the UserBaseDn field if non-nil, zero value otherwise.

### GetUserBaseDnOk

`func (o *V11ProvidersLdapLdapItem) GetUserBaseDnOk() (*string, bool)`

GetUserBaseDnOk returns a tuple with the UserBaseDn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUserBaseDn

`func (o *V11ProvidersLdapLdapItem) SetUserBaseDn(v string)`

SetUserBaseDn sets UserBaseDn field to given value.

### HasUserBaseDn

`func (o *V11ProvidersLdapLdapItem) HasUserBaseDn() bool`

HasUserBaseDn returns a boolean if a field has been set.

### GetUserDomain

`func (o *V11ProvidersLdapLdapItem) GetUserDomain() string`

GetUserDomain returns the UserDomain field if non-nil, zero value otherwise.

### GetUserDomainOk

`func (o *V11ProvidersLdapLdapItem) GetUserDomainOk() (*string, bool)`

GetUserDomainOk returns a tuple with the UserDomain field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUserDomain

`func (o *V11ProvidersLdapLdapItem) SetUserDomain(v string)`

SetUserDomain sets UserDomain field to given value.

### HasUserDomain

`func (o *V11ProvidersLdapLdapItem) HasUserDomain() bool`

HasUserDomain returns a boolean if a field has been set.

### GetUserFilter

`func (o *V11ProvidersLdapLdapItem) GetUserFilter() string`

GetUserFilter returns the UserFilter field if non-nil, zero value otherwise.

### GetUserFilterOk

`func (o *V11ProvidersLdapLdapItem) GetUserFilterOk() (*string, bool)`

GetUserFilterOk returns a tuple with the UserFilter field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUserFilter

`func (o *V11ProvidersLdapLdapItem) SetUserFilter(v string)`

SetUserFilter sets UserFilter field to given value.

### HasUserFilter

`func (o *V11ProvidersLdapLdapItem) HasUserFilter() bool`

HasUserFilter returns a boolean if a field has been set.

### GetUserSearchScope

`func (o *V11ProvidersLdapLdapItem) GetUserSearchScope() string`

GetUserSearchScope returns the UserSearchScope field if non-nil, zero value otherwise.

### GetUserSearchScopeOk

`func (o *V11ProvidersLdapLdapItem) GetUserSearchScopeOk() (*string, bool)`

GetUserSearchScopeOk returns a tuple with the UserSearchScope field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUserSearchScope

`func (o *V11ProvidersLdapLdapItem) SetUserSearchScope(v string)`

SetUserSearchScope sets UserSearchScope field to given value.

### HasUserSearchScope

`func (o *V11ProvidersLdapLdapItem) HasUserSearchScope() bool`

HasUserSearchScope returns a boolean if a field has been set.

### GetZoneName

`func (o *V11ProvidersLdapLdapItem) GetZoneName() string`

GetZoneName returns the ZoneName field if non-nil, zero value otherwise.

### GetZoneNameOk

`func (o *V11ProvidersLdapLdapItem) GetZoneNameOk() (*string, bool)`

GetZoneNameOk returns a tuple with the ZoneName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetZoneName

`func (o *V11ProvidersLdapLdapItem) SetZoneName(v string)`

SetZoneName sets ZoneName field to given value.

### HasZoneName

`func (o *V11ProvidersLdapLdapItem) HasZoneName() bool`

HasZoneName returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


