# V10ConfigUser

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**User** | Pointer to [**V10ConfigUserUser**](V10ConfigUserUser.md) |  | [optional] 

## Methods

### NewV10ConfigUser

`func NewV10ConfigUser() *V10ConfigUser`

NewV10ConfigUser instantiates a new V10ConfigUser object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ConfigUserWithDefaults

`func NewV10ConfigUserWithDefaults() *V10ConfigUser`

NewV10ConfigUserWithDefaults instantiates a new V10ConfigUser object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetUser

`func (o *V10ConfigUser) GetUser() V10ConfigUserUser`

GetUser returns the User field if non-nil, zero value otherwise.

### GetUserOk

`func (o *V10ConfigUser) GetUserOk() (*V10ConfigUserUser, bool)`

GetUserOk returns a tuple with the User field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUser

`func (o *V10ConfigUser) SetUser(v V10ConfigUserUser)`

SetUser sets User field to given value.

### HasUser

`func (o *V10ConfigUser) HasUser() bool`

HasUser returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


