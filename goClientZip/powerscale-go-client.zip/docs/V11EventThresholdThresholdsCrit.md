# V11EventThresholdThresholdsCrit

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Level** | Pointer to **string** |  | [optional] 
**Urgent** | Pointer to **bool** | If True all events are treated as new. | [optional] 
**Value** | Pointer to **string** |  | [optional] 

## Methods

### NewV11EventThresholdThresholdsCrit

`func NewV11EventThresholdThresholdsCrit() *V11EventThresholdThresholdsCrit`

NewV11EventThresholdThresholdsCrit instantiates a new V11EventThresholdThresholdsCrit object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11EventThresholdThresholdsCritWithDefaults

`func NewV11EventThresholdThresholdsCritWithDefaults() *V11EventThresholdThresholdsCrit`

NewV11EventThresholdThresholdsCritWithDefaults instantiates a new V11EventThresholdThresholdsCrit object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetLevel

`func (o *V11EventThresholdThresholdsCrit) GetLevel() string`

GetLevel returns the Level field if non-nil, zero value otherwise.

### GetLevelOk

`func (o *V11EventThresholdThresholdsCrit) GetLevelOk() (*string, bool)`

GetLevelOk returns a tuple with the Level field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLevel

`func (o *V11EventThresholdThresholdsCrit) SetLevel(v string)`

SetLevel sets Level field to given value.

### HasLevel

`func (o *V11EventThresholdThresholdsCrit) HasLevel() bool`

HasLevel returns a boolean if a field has been set.

### GetUrgent

`func (o *V11EventThresholdThresholdsCrit) GetUrgent() bool`

GetUrgent returns the Urgent field if non-nil, zero value otherwise.

### GetUrgentOk

`func (o *V11EventThresholdThresholdsCrit) GetUrgentOk() (*bool, bool)`

GetUrgentOk returns a tuple with the Urgent field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUrgent

`func (o *V11EventThresholdThresholdsCrit) SetUrgent(v bool)`

SetUrgent sets Urgent field to given value.

### HasUrgent

`func (o *V11EventThresholdThresholdsCrit) HasUrgent() bool`

HasUrgent returns a boolean if a field has been set.

### GetValue

`func (o *V11EventThresholdThresholdsCrit) GetValue() string`

GetValue returns the Value field if non-nil, zero value otherwise.

### GetValueOk

`func (o *V11EventThresholdThresholdsCrit) GetValueOk() (*string, bool)`

GetValueOk returns a tuple with the Value field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetValue

`func (o *V11EventThresholdThresholdsCrit) SetValue(v string)`

SetValue sets Value field to given value.

### HasValue

`func (o *V11EventThresholdThresholdsCrit) HasValue() bool`

HasValue returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


