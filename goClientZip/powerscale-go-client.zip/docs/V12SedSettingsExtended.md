# V12SedSettingsExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**KmipEnabled** | Pointer to **bool** | True if the KMIP SEDS feature is enabled and migration is allowed. When set to false, the KMIP SEDS feature is disabled, migration is not allowed. User can disable the feature only when ALL keys are in LOCAL status. | [optional] 

## Methods

### NewV12SedSettingsExtended

`func NewV12SedSettingsExtended() *V12SedSettingsExtended`

NewV12SedSettingsExtended instantiates a new V12SedSettingsExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12SedSettingsExtendedWithDefaults

`func NewV12SedSettingsExtendedWithDefaults() *V12SedSettingsExtended`

NewV12SedSettingsExtendedWithDefaults instantiates a new V12SedSettingsExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetKmipEnabled

`func (o *V12SedSettingsExtended) GetKmipEnabled() bool`

GetKmipEnabled returns the KmipEnabled field if non-nil, zero value otherwise.

### GetKmipEnabledOk

`func (o *V12SedSettingsExtended) GetKmipEnabledOk() (*bool, bool)`

GetKmipEnabledOk returns a tuple with the KmipEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetKmipEnabled

`func (o *V12SedSettingsExtended) SetKmipEnabled(v bool)`

SetKmipEnabled sets KmipEnabled field to given value.

### HasKmipEnabled

`func (o *V12SedSettingsExtended) HasKmipEnabled() bool`

HasKmipEnabled returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


