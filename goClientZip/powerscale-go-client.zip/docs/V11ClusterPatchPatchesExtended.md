# V11ClusterPatchPatchesExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Patches** | Pointer to [**[]V11ClusterPatchPatchesPatch**](V11ClusterPatchPatchesPatch.md) |  | [optional] 

## Methods

### NewV11ClusterPatchPatchesExtended

`func NewV11ClusterPatchPatchesExtended() *V11ClusterPatchPatchesExtended`

NewV11ClusterPatchPatchesExtended instantiates a new V11ClusterPatchPatchesExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11ClusterPatchPatchesExtendedWithDefaults

`func NewV11ClusterPatchPatchesExtendedWithDefaults() *V11ClusterPatchPatchesExtended`

NewV11ClusterPatchPatchesExtendedWithDefaults instantiates a new V11ClusterPatchPatchesExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetPatches

`func (o *V11ClusterPatchPatchesExtended) GetPatches() []V11ClusterPatchPatchesPatch`

GetPatches returns the Patches field if non-nil, zero value otherwise.

### GetPatchesOk

`func (o *V11ClusterPatchPatchesExtended) GetPatchesOk() (*[]V11ClusterPatchPatchesPatch, bool)`

GetPatchesOk returns a tuple with the Patches field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPatches

`func (o *V11ClusterPatchPatchesExtended) SetPatches(v []V11ClusterPatchPatchesPatch)`

SetPatches sets Patches field to given value.

### HasPatches

`func (o *V11ClusterPatchPatchesExtended) HasPatches() bool`

HasPatches returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


