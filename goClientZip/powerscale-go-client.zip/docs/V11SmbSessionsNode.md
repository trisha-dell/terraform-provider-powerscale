# V11SmbSessionsNode

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | Pointer to **int32** | Node ID (Device Number) of a node. | [optional] 
**Lnn** | Pointer to **int32** | Logical Node Number (LNN) of a node. | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Sessions** | Pointer to [**[]V1SmbSession**](V1SmbSession.md) | A list of open SMB sessions on node. | [optional] 
**Total** | Pointer to **int32** | The number of sessions returned. | [optional] 

## Methods

### NewV11SmbSessionsNode

`func NewV11SmbSessionsNode() *V11SmbSessionsNode`

NewV11SmbSessionsNode instantiates a new V11SmbSessionsNode object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11SmbSessionsNodeWithDefaults

`func NewV11SmbSessionsNodeWithDefaults() *V11SmbSessionsNode`

NewV11SmbSessionsNodeWithDefaults instantiates a new V11SmbSessionsNode object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *V11SmbSessionsNode) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V11SmbSessionsNode) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V11SmbSessionsNode) SetId(v int32)`

SetId sets Id field to given value.

### HasId

`func (o *V11SmbSessionsNode) HasId() bool`

HasId returns a boolean if a field has been set.

### GetLnn

`func (o *V11SmbSessionsNode) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V11SmbSessionsNode) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V11SmbSessionsNode) SetLnn(v int32)`

SetLnn sets Lnn field to given value.

### HasLnn

`func (o *V11SmbSessionsNode) HasLnn() bool`

HasLnn returns a boolean if a field has been set.

### GetResume

`func (o *V11SmbSessionsNode) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V11SmbSessionsNode) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V11SmbSessionsNode) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V11SmbSessionsNode) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetSessions

`func (o *V11SmbSessionsNode) GetSessions() []V1SmbSession`

GetSessions returns the Sessions field if non-nil, zero value otherwise.

### GetSessionsOk

`func (o *V11SmbSessionsNode) GetSessionsOk() (*[]V1SmbSession, bool)`

GetSessionsOk returns a tuple with the Sessions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSessions

`func (o *V11SmbSessionsNode) SetSessions(v []V1SmbSession)`

SetSessions sets Sessions field to given value.

### HasSessions

`func (o *V11SmbSessionsNode) HasSessions() bool`

HasSessions returns a boolean if a field has been set.

### GetTotal

`func (o *V11SmbSessionsNode) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V11SmbSessionsNode) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V11SmbSessionsNode) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V11SmbSessionsNode) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


