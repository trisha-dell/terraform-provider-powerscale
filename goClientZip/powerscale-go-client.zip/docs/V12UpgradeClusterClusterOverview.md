# V12UpgradeClusterClusterOverview

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NodesCurrent** | Pointer to **int32** | Number of nodes running the current OneFS version. | [optional] 
**NodesTotal** | Pointer to **int32** | Total number of nodes on the cluster. | [optional] 
**NodesTransitioning** | Pointer to **int32** | Number of nodes transitioning between OneFS versions. Null if the cluster_state is &#39;committed&#39; or &#39;assessing.&#39; | [optional] 
**NodesUpgraded** | Pointer to **int32** | Number of nodes running the upgraded OneFS version. Null if the cluster_state is &#39;committed&#39; or &#39;assessing.&#39; | [optional] 

## Methods

### NewV12UpgradeClusterClusterOverview

`func NewV12UpgradeClusterClusterOverview() *V12UpgradeClusterClusterOverview`

NewV12UpgradeClusterClusterOverview instantiates a new V12UpgradeClusterClusterOverview object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12UpgradeClusterClusterOverviewWithDefaults

`func NewV12UpgradeClusterClusterOverviewWithDefaults() *V12UpgradeClusterClusterOverview`

NewV12UpgradeClusterClusterOverviewWithDefaults instantiates a new V12UpgradeClusterClusterOverview object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNodesCurrent

`func (o *V12UpgradeClusterClusterOverview) GetNodesCurrent() int32`

GetNodesCurrent returns the NodesCurrent field if non-nil, zero value otherwise.

### GetNodesCurrentOk

`func (o *V12UpgradeClusterClusterOverview) GetNodesCurrentOk() (*int32, bool)`

GetNodesCurrentOk returns a tuple with the NodesCurrent field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodesCurrent

`func (o *V12UpgradeClusterClusterOverview) SetNodesCurrent(v int32)`

SetNodesCurrent sets NodesCurrent field to given value.

### HasNodesCurrent

`func (o *V12UpgradeClusterClusterOverview) HasNodesCurrent() bool`

HasNodesCurrent returns a boolean if a field has been set.

### GetNodesTotal

`func (o *V12UpgradeClusterClusterOverview) GetNodesTotal() int32`

GetNodesTotal returns the NodesTotal field if non-nil, zero value otherwise.

### GetNodesTotalOk

`func (o *V12UpgradeClusterClusterOverview) GetNodesTotalOk() (*int32, bool)`

GetNodesTotalOk returns a tuple with the NodesTotal field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodesTotal

`func (o *V12UpgradeClusterClusterOverview) SetNodesTotal(v int32)`

SetNodesTotal sets NodesTotal field to given value.

### HasNodesTotal

`func (o *V12UpgradeClusterClusterOverview) HasNodesTotal() bool`

HasNodesTotal returns a boolean if a field has been set.

### GetNodesTransitioning

`func (o *V12UpgradeClusterClusterOverview) GetNodesTransitioning() int32`

GetNodesTransitioning returns the NodesTransitioning field if non-nil, zero value otherwise.

### GetNodesTransitioningOk

`func (o *V12UpgradeClusterClusterOverview) GetNodesTransitioningOk() (*int32, bool)`

GetNodesTransitioningOk returns a tuple with the NodesTransitioning field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodesTransitioning

`func (o *V12UpgradeClusterClusterOverview) SetNodesTransitioning(v int32)`

SetNodesTransitioning sets NodesTransitioning field to given value.

### HasNodesTransitioning

`func (o *V12UpgradeClusterClusterOverview) HasNodesTransitioning() bool`

HasNodesTransitioning returns a boolean if a field has been set.

### GetNodesUpgraded

`func (o *V12UpgradeClusterClusterOverview) GetNodesUpgraded() int32`

GetNodesUpgraded returns the NodesUpgraded field if non-nil, zero value otherwise.

### GetNodesUpgradedOk

`func (o *V12UpgradeClusterClusterOverview) GetNodesUpgradedOk() (*int32, bool)`

GetNodesUpgradedOk returns a tuple with the NodesUpgraded field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodesUpgraded

`func (o *V12UpgradeClusterClusterOverview) SetNodesUpgraded(v int32)`

SetNodesUpgraded sets NodesUpgraded field to given value.

### HasNodesUpgraded

`func (o *V12UpgradeClusterClusterOverview) HasNodesUpgraded() bool`

HasNodesUpgraded returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


