# V11AvscanServersExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Servers** | Pointer to [**[]V11AvscanServerExtended**](V11AvscanServerExtended.md) |  | [optional] 

## Methods

### NewV11AvscanServersExtended

`func NewV11AvscanServersExtended() *V11AvscanServersExtended`

NewV11AvscanServersExtended instantiates a new V11AvscanServersExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11AvscanServersExtendedWithDefaults

`func NewV11AvscanServersExtendedWithDefaults() *V11AvscanServersExtended`

NewV11AvscanServersExtendedWithDefaults instantiates a new V11AvscanServersExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetServers

`func (o *V11AvscanServersExtended) GetServers() []V11AvscanServerExtended`

GetServers returns the Servers field if non-nil, zero value otherwise.

### GetServersOk

`func (o *V11AvscanServersExtended) GetServersOk() (*[]V11AvscanServerExtended, bool)`

GetServersOk returns a tuple with the Servers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServers

`func (o *V11AvscanServersExtended) SetServers(v []V11AvscanServerExtended)`

SetServers sets Servers field to given value.

### HasServers

`func (o *V11AvscanServersExtended) HasServers() bool`

HasServers returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


