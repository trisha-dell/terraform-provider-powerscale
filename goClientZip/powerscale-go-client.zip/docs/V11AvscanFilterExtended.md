# V11AvscanFilterExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FilterEnabled** | Pointer to **bool** | Access zone enabled for AV scanning. | [optional] 
**Id** | Pointer to **string** | A unique identifier for the zone. | [optional] 
**OpenOnFail** | Pointer to **bool** | Allow access to files when scanning fails. | [optional] 
**ScanCloudpoolFiles** | Pointer to **bool** | Perform real-time scans of cloudpool files? | [optional] 
**ScanOnClose** | Pointer to **bool** | Perform real-time scans of files when the file handle is closed. | [optional] 
**ScanOnRead** | Pointer to **bool** | Perform real-time scans of files on first file read. | [optional] 
**ScanOnRename** | Pointer to **bool** | Perform real-time scan of file when the file is renamed. | [optional] 
**ScanProfile** | Pointer to **string** | Type of scan profile applicable to the zone. | [optional] 
**ZoneName** | Pointer to **string** | Access zone name containing filter settings. | [optional] 
**FileExtensionAction** | Pointer to **string** | When a file matches an entry in the list of file extensions, do we include or exclude it?. | [optional] 
**FileExtensions** | Pointer to **[]string** | Array of file extensions to use in scanning decision. | [optional] 
**PathsToExclude** | Pointer to **[]string** | Array of relative paths under zone root not to scan. | [optional] 
**ScanIfNoExtension** | Pointer to **bool** | Scan files without extensions? | [optional] 

## Methods

### NewV11AvscanFilterExtended

`func NewV11AvscanFilterExtended() *V11AvscanFilterExtended`

NewV11AvscanFilterExtended instantiates a new V11AvscanFilterExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11AvscanFilterExtendedWithDefaults

`func NewV11AvscanFilterExtendedWithDefaults() *V11AvscanFilterExtended`

NewV11AvscanFilterExtendedWithDefaults instantiates a new V11AvscanFilterExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFilterEnabled

`func (o *V11AvscanFilterExtended) GetFilterEnabled() bool`

GetFilterEnabled returns the FilterEnabled field if non-nil, zero value otherwise.

### GetFilterEnabledOk

`func (o *V11AvscanFilterExtended) GetFilterEnabledOk() (*bool, bool)`

GetFilterEnabledOk returns a tuple with the FilterEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFilterEnabled

`func (o *V11AvscanFilterExtended) SetFilterEnabled(v bool)`

SetFilterEnabled sets FilterEnabled field to given value.

### HasFilterEnabled

`func (o *V11AvscanFilterExtended) HasFilterEnabled() bool`

HasFilterEnabled returns a boolean if a field has been set.

### GetId

`func (o *V11AvscanFilterExtended) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V11AvscanFilterExtended) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V11AvscanFilterExtended) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V11AvscanFilterExtended) HasId() bool`

HasId returns a boolean if a field has been set.

### GetOpenOnFail

`func (o *V11AvscanFilterExtended) GetOpenOnFail() bool`

GetOpenOnFail returns the OpenOnFail field if non-nil, zero value otherwise.

### GetOpenOnFailOk

`func (o *V11AvscanFilterExtended) GetOpenOnFailOk() (*bool, bool)`

GetOpenOnFailOk returns a tuple with the OpenOnFail field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOpenOnFail

`func (o *V11AvscanFilterExtended) SetOpenOnFail(v bool)`

SetOpenOnFail sets OpenOnFail field to given value.

### HasOpenOnFail

`func (o *V11AvscanFilterExtended) HasOpenOnFail() bool`

HasOpenOnFail returns a boolean if a field has been set.

### GetScanCloudpoolFiles

`func (o *V11AvscanFilterExtended) GetScanCloudpoolFiles() bool`

GetScanCloudpoolFiles returns the ScanCloudpoolFiles field if non-nil, zero value otherwise.

### GetScanCloudpoolFilesOk

`func (o *V11AvscanFilterExtended) GetScanCloudpoolFilesOk() (*bool, bool)`

GetScanCloudpoolFilesOk returns a tuple with the ScanCloudpoolFiles field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanCloudpoolFiles

`func (o *V11AvscanFilterExtended) SetScanCloudpoolFiles(v bool)`

SetScanCloudpoolFiles sets ScanCloudpoolFiles field to given value.

### HasScanCloudpoolFiles

`func (o *V11AvscanFilterExtended) HasScanCloudpoolFiles() bool`

HasScanCloudpoolFiles returns a boolean if a field has been set.

### GetScanOnClose

`func (o *V11AvscanFilterExtended) GetScanOnClose() bool`

GetScanOnClose returns the ScanOnClose field if non-nil, zero value otherwise.

### GetScanOnCloseOk

`func (o *V11AvscanFilterExtended) GetScanOnCloseOk() (*bool, bool)`

GetScanOnCloseOk returns a tuple with the ScanOnClose field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanOnClose

`func (o *V11AvscanFilterExtended) SetScanOnClose(v bool)`

SetScanOnClose sets ScanOnClose field to given value.

### HasScanOnClose

`func (o *V11AvscanFilterExtended) HasScanOnClose() bool`

HasScanOnClose returns a boolean if a field has been set.

### GetScanOnRead

`func (o *V11AvscanFilterExtended) GetScanOnRead() bool`

GetScanOnRead returns the ScanOnRead field if non-nil, zero value otherwise.

### GetScanOnReadOk

`func (o *V11AvscanFilterExtended) GetScanOnReadOk() (*bool, bool)`

GetScanOnReadOk returns a tuple with the ScanOnRead field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanOnRead

`func (o *V11AvscanFilterExtended) SetScanOnRead(v bool)`

SetScanOnRead sets ScanOnRead field to given value.

### HasScanOnRead

`func (o *V11AvscanFilterExtended) HasScanOnRead() bool`

HasScanOnRead returns a boolean if a field has been set.

### GetScanOnRename

`func (o *V11AvscanFilterExtended) GetScanOnRename() bool`

GetScanOnRename returns the ScanOnRename field if non-nil, zero value otherwise.

### GetScanOnRenameOk

`func (o *V11AvscanFilterExtended) GetScanOnRenameOk() (*bool, bool)`

GetScanOnRenameOk returns a tuple with the ScanOnRename field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanOnRename

`func (o *V11AvscanFilterExtended) SetScanOnRename(v bool)`

SetScanOnRename sets ScanOnRename field to given value.

### HasScanOnRename

`func (o *V11AvscanFilterExtended) HasScanOnRename() bool`

HasScanOnRename returns a boolean if a field has been set.

### GetScanProfile

`func (o *V11AvscanFilterExtended) GetScanProfile() string`

GetScanProfile returns the ScanProfile field if non-nil, zero value otherwise.

### GetScanProfileOk

`func (o *V11AvscanFilterExtended) GetScanProfileOk() (*string, bool)`

GetScanProfileOk returns a tuple with the ScanProfile field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanProfile

`func (o *V11AvscanFilterExtended) SetScanProfile(v string)`

SetScanProfile sets ScanProfile field to given value.

### HasScanProfile

`func (o *V11AvscanFilterExtended) HasScanProfile() bool`

HasScanProfile returns a boolean if a field has been set.

### GetZoneName

`func (o *V11AvscanFilterExtended) GetZoneName() string`

GetZoneName returns the ZoneName field if non-nil, zero value otherwise.

### GetZoneNameOk

`func (o *V11AvscanFilterExtended) GetZoneNameOk() (*string, bool)`

GetZoneNameOk returns a tuple with the ZoneName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetZoneName

`func (o *V11AvscanFilterExtended) SetZoneName(v string)`

SetZoneName sets ZoneName field to given value.

### HasZoneName

`func (o *V11AvscanFilterExtended) HasZoneName() bool`

HasZoneName returns a boolean if a field has been set.

### GetFileExtensionAction

`func (o *V11AvscanFilterExtended) GetFileExtensionAction() string`

GetFileExtensionAction returns the FileExtensionAction field if non-nil, zero value otherwise.

### GetFileExtensionActionOk

`func (o *V11AvscanFilterExtended) GetFileExtensionActionOk() (*string, bool)`

GetFileExtensionActionOk returns a tuple with the FileExtensionAction field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFileExtensionAction

`func (o *V11AvscanFilterExtended) SetFileExtensionAction(v string)`

SetFileExtensionAction sets FileExtensionAction field to given value.

### HasFileExtensionAction

`func (o *V11AvscanFilterExtended) HasFileExtensionAction() bool`

HasFileExtensionAction returns a boolean if a field has been set.

### GetFileExtensions

`func (o *V11AvscanFilterExtended) GetFileExtensions() []string`

GetFileExtensions returns the FileExtensions field if non-nil, zero value otherwise.

### GetFileExtensionsOk

`func (o *V11AvscanFilterExtended) GetFileExtensionsOk() (*[]string, bool)`

GetFileExtensionsOk returns a tuple with the FileExtensions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFileExtensions

`func (o *V11AvscanFilterExtended) SetFileExtensions(v []string)`

SetFileExtensions sets FileExtensions field to given value.

### HasFileExtensions

`func (o *V11AvscanFilterExtended) HasFileExtensions() bool`

HasFileExtensions returns a boolean if a field has been set.

### GetPathsToExclude

`func (o *V11AvscanFilterExtended) GetPathsToExclude() []string`

GetPathsToExclude returns the PathsToExclude field if non-nil, zero value otherwise.

### GetPathsToExcludeOk

`func (o *V11AvscanFilterExtended) GetPathsToExcludeOk() (*[]string, bool)`

GetPathsToExcludeOk returns a tuple with the PathsToExclude field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPathsToExclude

`func (o *V11AvscanFilterExtended) SetPathsToExclude(v []string)`

SetPathsToExclude sets PathsToExclude field to given value.

### HasPathsToExclude

`func (o *V11AvscanFilterExtended) HasPathsToExclude() bool`

HasPathsToExclude returns a boolean if a field has been set.

### GetScanIfNoExtension

`func (o *V11AvscanFilterExtended) GetScanIfNoExtension() bool`

GetScanIfNoExtension returns the ScanIfNoExtension field if non-nil, zero value otherwise.

### GetScanIfNoExtensionOk

`func (o *V11AvscanFilterExtended) GetScanIfNoExtensionOk() (*bool, bool)`

GetScanIfNoExtensionOk returns a tuple with the ScanIfNoExtension field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanIfNoExtension

`func (o *V11AvscanFilterExtended) SetScanIfNoExtension(v bool)`

SetScanIfNoExtension sets ScanIfNoExtension field to given value.

### HasScanIfNoExtension

`func (o *V11AvscanFilterExtended) HasScanIfNoExtension() bool`

HasScanIfNoExtension returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


