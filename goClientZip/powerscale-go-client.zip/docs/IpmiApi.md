# \IpmiApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetIpmiv10ConfigFeature**](IpmiApi.md#GetIpmiv10ConfigFeature) | **Get** /platform/10/ipmi/config/features/{v10ConfigFeatureId} | 
[**GetIpmiv10ConfigFeatures**](IpmiApi.md#GetIpmiv10ConfigFeatures) | **Get** /platform/10/ipmi/config/features | 
[**GetIpmiv10ConfigNetwork**](IpmiApi.md#GetIpmiv10ConfigNetwork) | **Get** /platform/10/ipmi/config/network | 
[**GetIpmiv10ConfigNode**](IpmiApi.md#GetIpmiv10ConfigNode) | **Get** /platform/10/ipmi/config/nodes/{v10ConfigNodeId} | 
[**GetIpmiv10ConfigNodes**](IpmiApi.md#GetIpmiv10ConfigNodes) | **Get** /platform/10/ipmi/config/nodes | 
[**GetIpmiv10ConfigSettings**](IpmiApi.md#GetIpmiv10ConfigSettings) | **Get** /platform/10/ipmi/config/settings | 
[**GetIpmiv10ConfigUser**](IpmiApi.md#GetIpmiv10ConfigUser) | **Get** /platform/10/ipmi/config/user | 
[**UpdateIpmiv10ConfigFeature**](IpmiApi.md#UpdateIpmiv10ConfigFeature) | **Put** /platform/10/ipmi/config/features/{v10ConfigFeatureId} | 
[**UpdateIpmiv10ConfigNetwork**](IpmiApi.md#UpdateIpmiv10ConfigNetwork) | **Put** /platform/10/ipmi/config/network | 
[**UpdateIpmiv10ConfigSettings**](IpmiApi.md#UpdateIpmiv10ConfigSettings) | **Put** /platform/10/ipmi/config/settings | 
[**UpdateIpmiv10ConfigUser**](IpmiApi.md#UpdateIpmiv10ConfigUser) | **Put** /platform/10/ipmi/config/user | 



## GetIpmiv10ConfigFeature

> V10ConfigFeaturesExtended GetIpmiv10ConfigFeature(ctx, v10ConfigFeatureId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10ConfigFeatureId := "v10ConfigFeatureId_example" // string | Retrieve the Remote IPMI Management feature configuration.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.IpmiApi.GetIpmiv10ConfigFeature(context.Background(), v10ConfigFeatureId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `IpmiApi.GetIpmiv10ConfigFeature``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetIpmiv10ConfigFeature`: V10ConfigFeaturesExtended
    fmt.Fprintf(os.Stdout, "Response from `IpmiApi.GetIpmiv10ConfigFeature`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10ConfigFeatureId** | **string** | Retrieve the Remote IPMI Management feature configuration. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetIpmiv10ConfigFeatureRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V10ConfigFeaturesExtended**](V10ConfigFeaturesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetIpmiv10ConfigFeatures

> V10ConfigFeatures GetIpmiv10ConfigFeatures(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.IpmiApi.GetIpmiv10ConfigFeatures(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `IpmiApi.GetIpmiv10ConfigFeatures``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetIpmiv10ConfigFeatures`: V10ConfigFeatures
    fmt.Fprintf(os.Stdout, "Response from `IpmiApi.GetIpmiv10ConfigFeatures`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetIpmiv10ConfigFeaturesRequest struct via the builder pattern


### Return type

[**V10ConfigFeatures**](V10ConfigFeatures.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetIpmiv10ConfigNetwork

> V10ConfigNetwork GetIpmiv10ConfigNetwork(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.IpmiApi.GetIpmiv10ConfigNetwork(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `IpmiApi.GetIpmiv10ConfigNetwork``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetIpmiv10ConfigNetwork`: V10ConfigNetwork
    fmt.Fprintf(os.Stdout, "Response from `IpmiApi.GetIpmiv10ConfigNetwork`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetIpmiv10ConfigNetworkRequest struct via the builder pattern


### Return type

[**V10ConfigNetwork**](V10ConfigNetwork.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetIpmiv10ConfigNode

> V10ConfigNodesExtended GetIpmiv10ConfigNode(ctx, v10ConfigNodeId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10ConfigNodeId := int32(56) // int32 | Retrieve the Remote IPMI Management node configuration.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.IpmiApi.GetIpmiv10ConfigNode(context.Background(), v10ConfigNodeId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `IpmiApi.GetIpmiv10ConfigNode``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetIpmiv10ConfigNode`: V10ConfigNodesExtended
    fmt.Fprintf(os.Stdout, "Response from `IpmiApi.GetIpmiv10ConfigNode`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10ConfigNodeId** | **int32** | Retrieve the Remote IPMI Management node configuration. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetIpmiv10ConfigNodeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V10ConfigNodesExtended**](V10ConfigNodesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetIpmiv10ConfigNodes

> V10ConfigNodes GetIpmiv10ConfigNodes(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.IpmiApi.GetIpmiv10ConfigNodes(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `IpmiApi.GetIpmiv10ConfigNodes``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetIpmiv10ConfigNodes`: V10ConfigNodes
    fmt.Fprintf(os.Stdout, "Response from `IpmiApi.GetIpmiv10ConfigNodes`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetIpmiv10ConfigNodesRequest struct via the builder pattern


### Return type

[**V10ConfigNodes**](V10ConfigNodes.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetIpmiv10ConfigSettings

> V10ConfigSettings GetIpmiv10ConfigSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.IpmiApi.GetIpmiv10ConfigSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `IpmiApi.GetIpmiv10ConfigSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetIpmiv10ConfigSettings`: V10ConfigSettings
    fmt.Fprintf(os.Stdout, "Response from `IpmiApi.GetIpmiv10ConfigSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetIpmiv10ConfigSettingsRequest struct via the builder pattern


### Return type

[**V10ConfigSettings**](V10ConfigSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetIpmiv10ConfigUser

> V10ConfigUser GetIpmiv10ConfigUser(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.IpmiApi.GetIpmiv10ConfigUser(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `IpmiApi.GetIpmiv10ConfigUser``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetIpmiv10ConfigUser`: V10ConfigUser
    fmt.Fprintf(os.Stdout, "Response from `IpmiApi.GetIpmiv10ConfigUser`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetIpmiv10ConfigUserRequest struct via the builder pattern


### Return type

[**V10ConfigUser**](V10ConfigUser.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateIpmiv10ConfigFeature

> UpdateIpmiv10ConfigFeature(ctx, v10ConfigFeatureId).V10ConfigFeature(v10ConfigFeature).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10ConfigFeatureId := "v10ConfigFeatureId_example" // string | Modify remote IPMI Management feature settings
    v10ConfigFeature := *openapiclient.NewV10ConfigFeatureExtended() // V10ConfigFeatureExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.IpmiApi.UpdateIpmiv10ConfigFeature(context.Background(), v10ConfigFeatureId).V10ConfigFeature(v10ConfigFeature).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `IpmiApi.UpdateIpmiv10ConfigFeature``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10ConfigFeatureId** | **string** | Modify remote IPMI Management feature settings | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateIpmiv10ConfigFeatureRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v10ConfigFeature** | [**V10ConfigFeatureExtended**](V10ConfigFeatureExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateIpmiv10ConfigNetwork

> UpdateIpmiv10ConfigNetwork(ctx).V10ConfigNetwork(v10ConfigNetwork).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10ConfigNetwork := *openapiclient.NewV10ConfigNetworkExtended() // V10ConfigNetworkExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.IpmiApi.UpdateIpmiv10ConfigNetwork(context.Background()).V10ConfigNetwork(v10ConfigNetwork).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `IpmiApi.UpdateIpmiv10ConfigNetwork``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateIpmiv10ConfigNetworkRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v10ConfigNetwork** | [**V10ConfigNetworkExtended**](V10ConfigNetworkExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateIpmiv10ConfigSettings

> UpdateIpmiv10ConfigSettings(ctx).V10ConfigSettings(v10ConfigSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10ConfigSettings := *openapiclient.NewV10ConfigSettingsSettings() // V10ConfigSettingsSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.IpmiApi.UpdateIpmiv10ConfigSettings(context.Background()).V10ConfigSettings(v10ConfigSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `IpmiApi.UpdateIpmiv10ConfigSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateIpmiv10ConfigSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v10ConfigSettings** | [**V10ConfigSettingsSettings**](V10ConfigSettingsSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateIpmiv10ConfigUser

> UpdateIpmiv10ConfigUser(ctx).V10ConfigUser(v10ConfigUser).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10ConfigUser := *openapiclient.NewV10ConfigUserExtended() // V10ConfigUserExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.IpmiApi.UpdateIpmiv10ConfigUser(context.Background()).V10ConfigUser(v10ConfigUser).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `IpmiApi.UpdateIpmiv10ConfigUser``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateIpmiv10ConfigUserRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v10ConfigUser** | [**V10ConfigUserExtended**](V10ConfigUserExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

