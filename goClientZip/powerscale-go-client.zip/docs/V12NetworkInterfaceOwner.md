# V12NetworkInterfaceOwner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccessZone** | Pointer to **string** | Name of configured Access Zone. | [optional] 
**Groupnet** | Pointer to **string** |  | [optional] 
**Id** | Pointer to **string** | The id of the owner. The concatenation of the groupnet, subnet, and pool fields as relevant. | [optional] 
**IpAddrs** | Pointer to **[]string** | List of IPs on this interface in the pool | [optional] 
**Pool** | Pointer to **string** |  | [optional] 
**Subnet** | Pointer to **string** |  | [optional] 
**Type** | Pointer to **string** | Specifies the type of network addresses that this interface owner contains. | [optional] 
**VlanId** | Pointer to **int32** | the VLAN ID that corresponds to the ID number for the VLAN set on the switch, with a value from 1 to 4094. | [optional] 

## Methods

### NewV12NetworkInterfaceOwner

`func NewV12NetworkInterfaceOwner() *V12NetworkInterfaceOwner`

NewV12NetworkInterfaceOwner instantiates a new V12NetworkInterfaceOwner object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12NetworkInterfaceOwnerWithDefaults

`func NewV12NetworkInterfaceOwnerWithDefaults() *V12NetworkInterfaceOwner`

NewV12NetworkInterfaceOwnerWithDefaults instantiates a new V12NetworkInterfaceOwner object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAccessZone

`func (o *V12NetworkInterfaceOwner) GetAccessZone() string`

GetAccessZone returns the AccessZone field if non-nil, zero value otherwise.

### GetAccessZoneOk

`func (o *V12NetworkInterfaceOwner) GetAccessZoneOk() (*string, bool)`

GetAccessZoneOk returns a tuple with the AccessZone field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAccessZone

`func (o *V12NetworkInterfaceOwner) SetAccessZone(v string)`

SetAccessZone sets AccessZone field to given value.

### HasAccessZone

`func (o *V12NetworkInterfaceOwner) HasAccessZone() bool`

HasAccessZone returns a boolean if a field has been set.

### GetGroupnet

`func (o *V12NetworkInterfaceOwner) GetGroupnet() string`

GetGroupnet returns the Groupnet field if non-nil, zero value otherwise.

### GetGroupnetOk

`func (o *V12NetworkInterfaceOwner) GetGroupnetOk() (*string, bool)`

GetGroupnetOk returns a tuple with the Groupnet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupnet

`func (o *V12NetworkInterfaceOwner) SetGroupnet(v string)`

SetGroupnet sets Groupnet field to given value.

### HasGroupnet

`func (o *V12NetworkInterfaceOwner) HasGroupnet() bool`

HasGroupnet returns a boolean if a field has been set.

### GetId

`func (o *V12NetworkInterfaceOwner) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12NetworkInterfaceOwner) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12NetworkInterfaceOwner) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V12NetworkInterfaceOwner) HasId() bool`

HasId returns a boolean if a field has been set.

### GetIpAddrs

`func (o *V12NetworkInterfaceOwner) GetIpAddrs() []string`

GetIpAddrs returns the IpAddrs field if non-nil, zero value otherwise.

### GetIpAddrsOk

`func (o *V12NetworkInterfaceOwner) GetIpAddrsOk() (*[]string, bool)`

GetIpAddrsOk returns a tuple with the IpAddrs field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpAddrs

`func (o *V12NetworkInterfaceOwner) SetIpAddrs(v []string)`

SetIpAddrs sets IpAddrs field to given value.

### HasIpAddrs

`func (o *V12NetworkInterfaceOwner) HasIpAddrs() bool`

HasIpAddrs returns a boolean if a field has been set.

### GetPool

`func (o *V12NetworkInterfaceOwner) GetPool() string`

GetPool returns the Pool field if non-nil, zero value otherwise.

### GetPoolOk

`func (o *V12NetworkInterfaceOwner) GetPoolOk() (*string, bool)`

GetPoolOk returns a tuple with the Pool field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPool

`func (o *V12NetworkInterfaceOwner) SetPool(v string)`

SetPool sets Pool field to given value.

### HasPool

`func (o *V12NetworkInterfaceOwner) HasPool() bool`

HasPool returns a boolean if a field has been set.

### GetSubnet

`func (o *V12NetworkInterfaceOwner) GetSubnet() string`

GetSubnet returns the Subnet field if non-nil, zero value otherwise.

### GetSubnetOk

`func (o *V12NetworkInterfaceOwner) GetSubnetOk() (*string, bool)`

GetSubnetOk returns a tuple with the Subnet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSubnet

`func (o *V12NetworkInterfaceOwner) SetSubnet(v string)`

SetSubnet sets Subnet field to given value.

### HasSubnet

`func (o *V12NetworkInterfaceOwner) HasSubnet() bool`

HasSubnet returns a boolean if a field has been set.

### GetType

`func (o *V12NetworkInterfaceOwner) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *V12NetworkInterfaceOwner) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *V12NetworkInterfaceOwner) SetType(v string)`

SetType sets Type field to given value.

### HasType

`func (o *V12NetworkInterfaceOwner) HasType() bool`

HasType returns a boolean if a field has been set.

### GetVlanId

`func (o *V12NetworkInterfaceOwner) GetVlanId() int32`

GetVlanId returns the VlanId field if non-nil, zero value otherwise.

### GetVlanIdOk

`func (o *V12NetworkInterfaceOwner) GetVlanIdOk() (*int32, bool)`

GetVlanIdOk returns a tuple with the VlanId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVlanId

`func (o *V12NetworkInterfaceOwner) SetVlanId(v int32)`

SetVlanId sets VlanId field to given value.

### HasVlanId

`func (o *V12NetworkInterfaceOwner) HasVlanId() bool`

HasVlanId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


