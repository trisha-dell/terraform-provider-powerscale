# V10ConfigNetworkNetwork

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Gateway** | **string** | IPv4 address in the format: xxx.xxx.xxx.xxx | 
**Prefixlen** | Pointer to **int32** | Prefixlen specifies the length of network bits used in an IP address. This field is the right-hand part of the CIDR notation representing the subnet mask. | [optional] 
**Ranges** | Pointer to [**[]V7ClusterInternalNetworksFailoverIpAddresse**](V7ClusterInternalNetworksFailoverIpAddresse.md) | List of IP address ranges. | [optional] 

## Methods

### NewV10ConfigNetworkNetwork

`func NewV10ConfigNetworkNetwork(gateway string, ) *V10ConfigNetworkNetwork`

NewV10ConfigNetworkNetwork instantiates a new V10ConfigNetworkNetwork object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ConfigNetworkNetworkWithDefaults

`func NewV10ConfigNetworkNetworkWithDefaults() *V10ConfigNetworkNetwork`

NewV10ConfigNetworkNetworkWithDefaults instantiates a new V10ConfigNetworkNetwork object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetGateway

`func (o *V10ConfigNetworkNetwork) GetGateway() string`

GetGateway returns the Gateway field if non-nil, zero value otherwise.

### GetGatewayOk

`func (o *V10ConfigNetworkNetwork) GetGatewayOk() (*string, bool)`

GetGatewayOk returns a tuple with the Gateway field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGateway

`func (o *V10ConfigNetworkNetwork) SetGateway(v string)`

SetGateway sets Gateway field to given value.


### GetPrefixlen

`func (o *V10ConfigNetworkNetwork) GetPrefixlen() int32`

GetPrefixlen returns the Prefixlen field if non-nil, zero value otherwise.

### GetPrefixlenOk

`func (o *V10ConfigNetworkNetwork) GetPrefixlenOk() (*int32, bool)`

GetPrefixlenOk returns a tuple with the Prefixlen field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrefixlen

`func (o *V10ConfigNetworkNetwork) SetPrefixlen(v int32)`

SetPrefixlen sets Prefixlen field to given value.

### HasPrefixlen

`func (o *V10ConfigNetworkNetwork) HasPrefixlen() bool`

HasPrefixlen returns a boolean if a field has been set.

### GetRanges

`func (o *V10ConfigNetworkNetwork) GetRanges() []V7ClusterInternalNetworksFailoverIpAddresse`

GetRanges returns the Ranges field if non-nil, zero value otherwise.

### GetRangesOk

`func (o *V10ConfigNetworkNetwork) GetRangesOk() (*[]V7ClusterInternalNetworksFailoverIpAddresse, bool)`

GetRangesOk returns a tuple with the Ranges field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRanges

`func (o *V10ConfigNetworkNetwork) SetRanges(v []V7ClusterInternalNetworksFailoverIpAddresse)`

SetRanges sets Ranges field to given value.

### HasRanges

`func (o *V10ConfigNetworkNetwork) HasRanges() bool`

HasRanges returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


