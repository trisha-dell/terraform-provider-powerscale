# \CatalogApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetCatalogv14CatalogList**](CatalogApi.md#GetCatalogv14CatalogList) | **Get** /platform/14/catalog/list | 
[**GetCatalogv14CatalogReadme**](CatalogApi.md#GetCatalogv14CatalogReadme) | **Get** /platform/14/catalog/readme | 
[**GetCatalogv14CatalogVerify**](CatalogApi.md#GetCatalogv14CatalogVerify) | **Get** /platform/14/catalog/verify | 
[**UpdateCatalogv14CatalogClean**](CatalogApi.md#UpdateCatalogv14CatalogClean) | **Put** /platform/14/catalog/clean | 
[**UpdateCatalogv14CatalogExport**](CatalogApi.md#UpdateCatalogv14CatalogExport) | **Put** /platform/14/catalog/export | 
[**UpdateCatalogv14CatalogImport**](CatalogApi.md#UpdateCatalogv14CatalogImport) | **Put** /platform/14/catalog/import | 
[**UpdateCatalogv14CatalogRemove**](CatalogApi.md#UpdateCatalogv14CatalogRemove) | **Put** /platform/14/catalog/remove | 
[**UpdateCatalogv14CatalogRepair**](CatalogApi.md#UpdateCatalogv14CatalogRepair) | **Put** /platform/14/catalog/repair | 



## GetCatalogv14CatalogList

> V14CatalogList GetCatalogv14CatalogList(ctx).OnefsVersion(onefsVersion).Reference(reference).ContentType(contentType).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    onefsVersion := int32(56) // int32 | onefs version (optional)
    reference := "reference_example" // string | onefs component that references this entry. (optional)
    contentType := "contentType_example" // string | the type of upgrade (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CatalogApi.GetCatalogv14CatalogList(context.Background()).OnefsVersion(onefsVersion).Reference(reference).ContentType(contentType).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CatalogApi.GetCatalogv14CatalogList``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetCatalogv14CatalogList`: V14CatalogList
    fmt.Fprintf(os.Stdout, "Response from `CatalogApi.GetCatalogv14CatalogList`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetCatalogv14CatalogListRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **onefsVersion** | **int32** | onefs version | 
 **reference** | **string** | onefs component that references this entry. | 
 **contentType** | **string** | the type of upgrade | 

### Return type

[**V14CatalogList**](V14CatalogList.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetCatalogv14CatalogReadme

> V14CatalogReadme GetCatalogv14CatalogReadme(ctx).Hash(hash).File(file).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    hash := "hash_example" // string | The sha256 hash of the file stored in catalog (optional)
    file := "file_example" // string | Path of the signed file to import in the catalog (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CatalogApi.GetCatalogv14CatalogReadme(context.Background()).Hash(hash).File(file).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CatalogApi.GetCatalogv14CatalogReadme``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetCatalogv14CatalogReadme`: V14CatalogReadme
    fmt.Fprintf(os.Stdout, "Response from `CatalogApi.GetCatalogv14CatalogReadme`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetCatalogv14CatalogReadmeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hash** | **string** | The sha256 hash of the file stored in catalog | 
 **file** | **string** | Path of the signed file to import in the catalog | 

### Return type

[**V14CatalogReadme**](V14CatalogReadme.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetCatalogv14CatalogVerify

> V14CatalogVerify GetCatalogv14CatalogVerify(ctx).Hash(hash).File(file).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    hash := "hash_example" // string | The sha256 hash of the file stored in catalog (optional)
    file := "file_example" // string | Path to unsigned file to verify (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CatalogApi.GetCatalogv14CatalogVerify(context.Background()).Hash(hash).File(file).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CatalogApi.GetCatalogv14CatalogVerify``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetCatalogv14CatalogVerify`: V14CatalogVerify
    fmt.Fprintf(os.Stdout, "Response from `CatalogApi.GetCatalogv14CatalogVerify`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetCatalogv14CatalogVerifyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hash** | **string** | The sha256 hash of the file stored in catalog | 
 **file** | **string** | Path to unsigned file to verify | 

### Return type

[**V14CatalogVerify**](V14CatalogVerify.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateCatalogv14CatalogClean

> UpdateCatalogv14CatalogClean(ctx).V14CatalogClean(v14CatalogClean).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14CatalogClean := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CatalogApi.UpdateCatalogv14CatalogClean(context.Background()).V14CatalogClean(v14CatalogClean).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CatalogApi.UpdateCatalogv14CatalogClean``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateCatalogv14CatalogCleanRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v14CatalogClean** | **map[string]interface{}** |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateCatalogv14CatalogExport

> UpdateCatalogv14CatalogExport(ctx).V14CatalogExport(v14CatalogExport).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14CatalogExport := *openapiclient.NewV14CatalogExport("File_example", "Hash_example") // V14CatalogExport | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CatalogApi.UpdateCatalogv14CatalogExport(context.Background()).V14CatalogExport(v14CatalogExport).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CatalogApi.UpdateCatalogv14CatalogExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateCatalogv14CatalogExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v14CatalogExport** | [**V14CatalogExport**](V14CatalogExport.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateCatalogv14CatalogImport

> UpdateCatalogv14CatalogImport(ctx).V14CatalogImport(v14CatalogImport).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14CatalogImport := *openapiclient.NewV14CatalogImport("File_example") // V14CatalogImport | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CatalogApi.UpdateCatalogv14CatalogImport(context.Background()).V14CatalogImport(v14CatalogImport).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CatalogApi.UpdateCatalogv14CatalogImport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateCatalogv14CatalogImportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v14CatalogImport** | [**V14CatalogImport**](V14CatalogImport.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateCatalogv14CatalogRemove

> UpdateCatalogv14CatalogRemove(ctx).V14CatalogRemove(v14CatalogRemove).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14CatalogRemove := *openapiclient.NewV14CatalogRemove("Hash_example") // V14CatalogRemove | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CatalogApi.UpdateCatalogv14CatalogRemove(context.Background()).V14CatalogRemove(v14CatalogRemove).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CatalogApi.UpdateCatalogv14CatalogRemove``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateCatalogv14CatalogRemoveRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v14CatalogRemove** | [**V14CatalogRemove**](V14CatalogRemove.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateCatalogv14CatalogRepair

> UpdateCatalogv14CatalogRepair(ctx).V14CatalogRepair(v14CatalogRepair).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14CatalogRepair := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CatalogApi.UpdateCatalogv14CatalogRepair(context.Background()).V14CatalogRepair(v14CatalogRepair).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CatalogApi.UpdateCatalogv14CatalogRepair``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateCatalogv14CatalogRepairRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v14CatalogRepair** | **map[string]interface{}** |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

