# \NetworkGroupnetsApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateNetworkGroupnetsv12GroupnetSubnet**](NetworkGroupnetsApi.md#CreateNetworkGroupnetsv12GroupnetSubnet) | **Post** /platform/12/network/groupnets/{Groupnet}/subnets | 
[**CreateNetworkGroupnetsv12SubnetsSubnetPool**](NetworkGroupnetsApi.md#CreateNetworkGroupnetsv12SubnetsSubnetPool) | **Post** /platform/12/network/groupnets/{Groupnet}/subnets/{Subnet}/pools | 
[**CreateNetworkGroupnetsv16GroupnetSubnet**](NetworkGroupnetsApi.md#CreateNetworkGroupnetsv16GroupnetSubnet) | **Post** /platform/16/network/groupnets/{Groupnet}/subnets | 
[**CreateNetworkGroupnetsv16SubnetsSubnetPool**](NetworkGroupnetsApi.md#CreateNetworkGroupnetsv16SubnetsSubnetPool) | **Post** /platform/16/network/groupnets/{Groupnet}/subnets/{Subnet}/pools | 
[**CreateNetworkGroupnetsv3GroupnetSubnet**](NetworkGroupnetsApi.md#CreateNetworkGroupnetsv3GroupnetSubnet) | **Post** /platform/3/network/groupnets/{Groupnet}/subnets | 
[**CreateNetworkGroupnetsv3SubnetsSubnetPool**](NetworkGroupnetsApi.md#CreateNetworkGroupnetsv3SubnetsSubnetPool) | **Post** /platform/3/network/groupnets/{Groupnet}/subnets/{Subnet}/pools | 
[**CreateNetworkGroupnetsv4GroupnetSubnet**](NetworkGroupnetsApi.md#CreateNetworkGroupnetsv4GroupnetSubnet) | **Post** /platform/4/network/groupnets/{Groupnet}/subnets | 
[**CreateNetworkGroupnetsv7GroupnetSubnet**](NetworkGroupnetsApi.md#CreateNetworkGroupnetsv7GroupnetSubnet) | **Post** /platform/7/network/groupnets/{Groupnet}/subnets | 
[**ListNetworkGroupnetsv12GroupnetSubnets**](NetworkGroupnetsApi.md#ListNetworkGroupnetsv12GroupnetSubnets) | **Get** /platform/12/network/groupnets/{Groupnet}/subnets | 
[**ListNetworkGroupnetsv12SubnetsSubnetPools**](NetworkGroupnetsApi.md#ListNetworkGroupnetsv12SubnetsSubnetPools) | **Get** /platform/12/network/groupnets/{Groupnet}/subnets/{Subnet}/pools | 
[**ListNetworkGroupnetsv16GroupnetSubnets**](NetworkGroupnetsApi.md#ListNetworkGroupnetsv16GroupnetSubnets) | **Get** /platform/16/network/groupnets/{Groupnet}/subnets | 
[**ListNetworkGroupnetsv16SubnetsSubnetPools**](NetworkGroupnetsApi.md#ListNetworkGroupnetsv16SubnetsSubnetPools) | **Get** /platform/16/network/groupnets/{Groupnet}/subnets/{Subnet}/pools | 
[**ListNetworkGroupnetsv3GroupnetSubnets**](NetworkGroupnetsApi.md#ListNetworkGroupnetsv3GroupnetSubnets) | **Get** /platform/3/network/groupnets/{Groupnet}/subnets | 
[**ListNetworkGroupnetsv3SubnetsSubnetPools**](NetworkGroupnetsApi.md#ListNetworkGroupnetsv3SubnetsSubnetPools) | **Get** /platform/3/network/groupnets/{Groupnet}/subnets/{Subnet}/pools | 
[**ListNetworkGroupnetsv4GroupnetSubnets**](NetworkGroupnetsApi.md#ListNetworkGroupnetsv4GroupnetSubnets) | **Get** /platform/4/network/groupnets/{Groupnet}/subnets | 
[**ListNetworkGroupnetsv7GroupnetSubnets**](NetworkGroupnetsApi.md#ListNetworkGroupnetsv7GroupnetSubnets) | **Get** /platform/7/network/groupnets/{Groupnet}/subnets | 



## CreateNetworkGroupnetsv12GroupnetSubnet

> CreateResponse CreateNetworkGroupnetsv12GroupnetSubnet(ctx, groupnet).V12GroupnetSubnet(v12GroupnetSubnet).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    v12GroupnetSubnet := *openapiclient.NewV12GroupnetSubnet("AddrFamily_example", "Name_example", int32(123)) // V12GroupnetSubnet | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsApi.CreateNetworkGroupnetsv12GroupnetSubnet(context.Background(), groupnet).V12GroupnetSubnet(v12GroupnetSubnet).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsApi.CreateNetworkGroupnetsv12GroupnetSubnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNetworkGroupnetsv12GroupnetSubnet`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsApi.CreateNetworkGroupnetsv12GroupnetSubnet`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateNetworkGroupnetsv12GroupnetSubnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v12GroupnetSubnet** | [**V12GroupnetSubnet**](V12GroupnetSubnet.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateNetworkGroupnetsv12SubnetsSubnetPool

> CreateResponse CreateNetworkGroupnetsv12SubnetsSubnetPool(ctx, groupnet, subnet).V12SubnetsSubnetPool(v12SubnetsSubnetPool).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 
    v12SubnetsSubnetPool := *openapiclient.NewV12SubnetsSubnetPool("Name_example") // V12SubnetsSubnetPool | 
    force := true // bool | Force creating this pool even if it causes an MTU conflict. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsApi.CreateNetworkGroupnetsv12SubnetsSubnetPool(context.Background(), groupnet, subnet).V12SubnetsSubnetPool(v12SubnetsSubnetPool).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsApi.CreateNetworkGroupnetsv12SubnetsSubnetPool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNetworkGroupnetsv12SubnetsSubnetPool`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsApi.CreateNetworkGroupnetsv12SubnetsSubnetPool`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 
**subnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateNetworkGroupnetsv12SubnetsSubnetPoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v12SubnetsSubnetPool** | [**V12SubnetsSubnetPool**](V12SubnetsSubnetPool.md) |  | 
 **force** | **bool** | Force creating this pool even if it causes an MTU conflict. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateNetworkGroupnetsv16GroupnetSubnet

> CreateResponse CreateNetworkGroupnetsv16GroupnetSubnet(ctx, groupnet).V16GroupnetSubnet(v16GroupnetSubnet).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    v16GroupnetSubnet := *openapiclient.NewV12GroupnetSubnet("AddrFamily_example", "Name_example", int32(123)) // V12GroupnetSubnet | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsApi.CreateNetworkGroupnetsv16GroupnetSubnet(context.Background(), groupnet).V16GroupnetSubnet(v16GroupnetSubnet).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsApi.CreateNetworkGroupnetsv16GroupnetSubnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNetworkGroupnetsv16GroupnetSubnet`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsApi.CreateNetworkGroupnetsv16GroupnetSubnet`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateNetworkGroupnetsv16GroupnetSubnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v16GroupnetSubnet** | [**V12GroupnetSubnet**](V12GroupnetSubnet.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateNetworkGroupnetsv16SubnetsSubnetPool

> CreateResponse CreateNetworkGroupnetsv16SubnetsSubnetPool(ctx, groupnet, subnet).V16SubnetsSubnetPool(v16SubnetsSubnetPool).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 
    v16SubnetsSubnetPool := *openapiclient.NewV16SubnetsSubnetPool("Name_example") // V16SubnetsSubnetPool | 
    force := true // bool | Force creating this pool even if it causes an MTU conflict. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsApi.CreateNetworkGroupnetsv16SubnetsSubnetPool(context.Background(), groupnet, subnet).V16SubnetsSubnetPool(v16SubnetsSubnetPool).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsApi.CreateNetworkGroupnetsv16SubnetsSubnetPool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNetworkGroupnetsv16SubnetsSubnetPool`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsApi.CreateNetworkGroupnetsv16SubnetsSubnetPool`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 
**subnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateNetworkGroupnetsv16SubnetsSubnetPoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v16SubnetsSubnetPool** | [**V16SubnetsSubnetPool**](V16SubnetsSubnetPool.md) |  | 
 **force** | **bool** | Force creating this pool even if it causes an MTU conflict. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateNetworkGroupnetsv3GroupnetSubnet

> CreateResponse CreateNetworkGroupnetsv3GroupnetSubnet(ctx, groupnet).V3GroupnetSubnet(v3GroupnetSubnet).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    v3GroupnetSubnet := *openapiclient.NewV3GroupnetSubnet("AddrFamily_example", "Name_example", int32(123)) // V3GroupnetSubnet | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsApi.CreateNetworkGroupnetsv3GroupnetSubnet(context.Background(), groupnet).V3GroupnetSubnet(v3GroupnetSubnet).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsApi.CreateNetworkGroupnetsv3GroupnetSubnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNetworkGroupnetsv3GroupnetSubnet`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsApi.CreateNetworkGroupnetsv3GroupnetSubnet`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateNetworkGroupnetsv3GroupnetSubnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3GroupnetSubnet** | [**V3GroupnetSubnet**](V3GroupnetSubnet.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateNetworkGroupnetsv3SubnetsSubnetPool

> CreateResponse CreateNetworkGroupnetsv3SubnetsSubnetPool(ctx, groupnet, subnet).V3SubnetsSubnetPool(v3SubnetsSubnetPool).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 
    v3SubnetsSubnetPool := *openapiclient.NewV3SubnetsSubnetPool("Name_example") // V3SubnetsSubnetPool | 
    force := true // bool | Force creating this pool even if it causes an MTU conflict. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsApi.CreateNetworkGroupnetsv3SubnetsSubnetPool(context.Background(), groupnet, subnet).V3SubnetsSubnetPool(v3SubnetsSubnetPool).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsApi.CreateNetworkGroupnetsv3SubnetsSubnetPool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNetworkGroupnetsv3SubnetsSubnetPool`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsApi.CreateNetworkGroupnetsv3SubnetsSubnetPool`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 
**subnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateNetworkGroupnetsv3SubnetsSubnetPoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v3SubnetsSubnetPool** | [**V3SubnetsSubnetPool**](V3SubnetsSubnetPool.md) |  | 
 **force** | **bool** | Force creating this pool even if it causes an MTU conflict. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateNetworkGroupnetsv4GroupnetSubnet

> CreateResponse CreateNetworkGroupnetsv4GroupnetSubnet(ctx, groupnet).V4GroupnetSubnet(v4GroupnetSubnet).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    v4GroupnetSubnet := *openapiclient.NewV4GroupnetSubnet("AddrFamily_example", "Name_example", int32(123)) // V4GroupnetSubnet | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsApi.CreateNetworkGroupnetsv4GroupnetSubnet(context.Background(), groupnet).V4GroupnetSubnet(v4GroupnetSubnet).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsApi.CreateNetworkGroupnetsv4GroupnetSubnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNetworkGroupnetsv4GroupnetSubnet`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsApi.CreateNetworkGroupnetsv4GroupnetSubnet`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateNetworkGroupnetsv4GroupnetSubnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v4GroupnetSubnet** | [**V4GroupnetSubnet**](V4GroupnetSubnet.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateNetworkGroupnetsv7GroupnetSubnet

> CreateResponse CreateNetworkGroupnetsv7GroupnetSubnet(ctx, groupnet).V7GroupnetSubnet(v7GroupnetSubnet).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    v7GroupnetSubnet := *openapiclient.NewV12GroupnetSubnet("AddrFamily_example", "Name_example", int32(123)) // V12GroupnetSubnet | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsApi.CreateNetworkGroupnetsv7GroupnetSubnet(context.Background(), groupnet).V7GroupnetSubnet(v7GroupnetSubnet).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsApi.CreateNetworkGroupnetsv7GroupnetSubnet``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNetworkGroupnetsv7GroupnetSubnet`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsApi.CreateNetworkGroupnetsv7GroupnetSubnet`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateNetworkGroupnetsv7GroupnetSubnetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7GroupnetSubnet** | [**V12GroupnetSubnet**](V12GroupnetSubnet.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListNetworkGroupnetsv12GroupnetSubnets

> V12GroupnetSubnets ListNetworkGroupnetsv12GroupnetSubnets(ctx, groupnet).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsApi.ListNetworkGroupnetsv12GroupnetSubnets(context.Background(), groupnet).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsApi.ListNetworkGroupnetsv12GroupnetSubnets``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListNetworkGroupnetsv12GroupnetSubnets`: V12GroupnetSubnets
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsApi.ListNetworkGroupnetsv12GroupnetSubnets`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListNetworkGroupnetsv12GroupnetSubnetsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V12GroupnetSubnets**](V12GroupnetSubnets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListNetworkGroupnetsv12SubnetsSubnetPools

> V12SubnetsSubnetPools ListNetworkGroupnetsv12SubnetsSubnetPools(ctx, groupnet, subnet).Sort(sort).Resume(resume).AccessZone(accessZone).AllocMethod(allocMethod).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    accessZone := "accessZone_example" // string | If specified, only pools with this zone name will be returned. (optional)
    allocMethod := "allocMethod_example" // string | If specified, only pools with this allocation type will be returned. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsApi.ListNetworkGroupnetsv12SubnetsSubnetPools(context.Background(), groupnet, subnet).Sort(sort).Resume(resume).AccessZone(accessZone).AllocMethod(allocMethod).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsApi.ListNetworkGroupnetsv12SubnetsSubnetPools``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListNetworkGroupnetsv12SubnetsSubnetPools`: V12SubnetsSubnetPools
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsApi.ListNetworkGroupnetsv12SubnetsSubnetPools`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 
**subnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListNetworkGroupnetsv12SubnetsSubnetPoolsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **accessZone** | **string** | If specified, only pools with this zone name will be returned. | 
 **allocMethod** | **string** | If specified, only pools with this allocation type will be returned. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V12SubnetsSubnetPools**](V12SubnetsSubnetPools.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListNetworkGroupnetsv16GroupnetSubnets

> V16GroupnetSubnets ListNetworkGroupnetsv16GroupnetSubnets(ctx, groupnet).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsApi.ListNetworkGroupnetsv16GroupnetSubnets(context.Background(), groupnet).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsApi.ListNetworkGroupnetsv16GroupnetSubnets``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListNetworkGroupnetsv16GroupnetSubnets`: V16GroupnetSubnets
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsApi.ListNetworkGroupnetsv16GroupnetSubnets`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListNetworkGroupnetsv16GroupnetSubnetsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V16GroupnetSubnets**](V16GroupnetSubnets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListNetworkGroupnetsv16SubnetsSubnetPools

> V16SubnetsSubnetPools ListNetworkGroupnetsv16SubnetsSubnetPools(ctx, groupnet, subnet).Sort(sort).Resume(resume).AccessZone(accessZone).AllocMethod(allocMethod).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    accessZone := "accessZone_example" // string | If specified, only pools with this zone name will be returned. (optional)
    allocMethod := "allocMethod_example" // string | If specified, only pools with this allocation type will be returned. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsApi.ListNetworkGroupnetsv16SubnetsSubnetPools(context.Background(), groupnet, subnet).Sort(sort).Resume(resume).AccessZone(accessZone).AllocMethod(allocMethod).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsApi.ListNetworkGroupnetsv16SubnetsSubnetPools``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListNetworkGroupnetsv16SubnetsSubnetPools`: V16SubnetsSubnetPools
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsApi.ListNetworkGroupnetsv16SubnetsSubnetPools`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 
**subnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListNetworkGroupnetsv16SubnetsSubnetPoolsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **accessZone** | **string** | If specified, only pools with this zone name will be returned. | 
 **allocMethod** | **string** | If specified, only pools with this allocation type will be returned. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V16SubnetsSubnetPools**](V16SubnetsSubnetPools.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListNetworkGroupnetsv3GroupnetSubnets

> V3GroupnetSubnets ListNetworkGroupnetsv3GroupnetSubnets(ctx, groupnet).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsApi.ListNetworkGroupnetsv3GroupnetSubnets(context.Background(), groupnet).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsApi.ListNetworkGroupnetsv3GroupnetSubnets``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListNetworkGroupnetsv3GroupnetSubnets`: V3GroupnetSubnets
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsApi.ListNetworkGroupnetsv3GroupnetSubnets`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListNetworkGroupnetsv3GroupnetSubnetsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3GroupnetSubnets**](V3GroupnetSubnets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListNetworkGroupnetsv3SubnetsSubnetPools

> V3SubnetsSubnetPools ListNetworkGroupnetsv3SubnetsSubnetPools(ctx, groupnet, subnet).Sort(sort).Resume(resume).AccessZone(accessZone).AllocMethod(allocMethod).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    accessZone := "accessZone_example" // string | If specified, only pools with this zone name will be returned. (optional)
    allocMethod := "allocMethod_example" // string | If specified, only pools with this allocation type will be returned. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsApi.ListNetworkGroupnetsv3SubnetsSubnetPools(context.Background(), groupnet, subnet).Sort(sort).Resume(resume).AccessZone(accessZone).AllocMethod(allocMethod).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsApi.ListNetworkGroupnetsv3SubnetsSubnetPools``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListNetworkGroupnetsv3SubnetsSubnetPools`: V3SubnetsSubnetPools
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsApi.ListNetworkGroupnetsv3SubnetsSubnetPools`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 
**subnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListNetworkGroupnetsv3SubnetsSubnetPoolsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **accessZone** | **string** | If specified, only pools with this zone name will be returned. | 
 **allocMethod** | **string** | If specified, only pools with this allocation type will be returned. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V3SubnetsSubnetPools**](V3SubnetsSubnetPools.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListNetworkGroupnetsv4GroupnetSubnets

> V4GroupnetSubnets ListNetworkGroupnetsv4GroupnetSubnets(ctx, groupnet).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsApi.ListNetworkGroupnetsv4GroupnetSubnets(context.Background(), groupnet).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsApi.ListNetworkGroupnetsv4GroupnetSubnets``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListNetworkGroupnetsv4GroupnetSubnets`: V4GroupnetSubnets
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsApi.ListNetworkGroupnetsv4GroupnetSubnets`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListNetworkGroupnetsv4GroupnetSubnetsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V4GroupnetSubnets**](V4GroupnetSubnets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListNetworkGroupnetsv7GroupnetSubnets

> V12GroupnetSubnets ListNetworkGroupnetsv7GroupnetSubnets(ctx, groupnet).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsApi.ListNetworkGroupnetsv7GroupnetSubnets(context.Background(), groupnet).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsApi.ListNetworkGroupnetsv7GroupnetSubnets``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListNetworkGroupnetsv7GroupnetSubnets`: V12GroupnetSubnets
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsApi.ListNetworkGroupnetsv7GroupnetSubnets`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListNetworkGroupnetsv7GroupnetSubnetsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V12GroupnetSubnets**](V12GroupnetSubnets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

