# V11AvscanSettingsSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IpPool** | Pointer to **string** | The IP Pool to be used by the CAVA server. | [optional] 
**ReportExpiry** | Pointer to **int32** | How many seconds a scan report will be kept. | [optional] 
**ScanCloudpoolTimeout** | Pointer to **int32** | How many seconds SMB will wait for an AV scan of a cloudpool to complete. | [optional] 
**ScanSizeMaximum** | Pointer to **int32** | Maximum size file that will be scanned (in kBs). 0 means no limit. | [optional] 
**ScanTimeout** | Pointer to **int32** | How many seconds SMB will wait for an AV scan to complete. | [optional] 
**ScanZones** | Pointer to **[]string** | Array of access zones that are enabled for antivirus scanning. | [optional] 
**ServiceEnabled** | Pointer to **bool** | CAVA antivirus service is on/off. | [optional] 

## Methods

### NewV11AvscanSettingsSettings

`func NewV11AvscanSettingsSettings() *V11AvscanSettingsSettings`

NewV11AvscanSettingsSettings instantiates a new V11AvscanSettingsSettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11AvscanSettingsSettingsWithDefaults

`func NewV11AvscanSettingsSettingsWithDefaults() *V11AvscanSettingsSettings`

NewV11AvscanSettingsSettingsWithDefaults instantiates a new V11AvscanSettingsSettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetIpPool

`func (o *V11AvscanSettingsSettings) GetIpPool() string`

GetIpPool returns the IpPool field if non-nil, zero value otherwise.

### GetIpPoolOk

`func (o *V11AvscanSettingsSettings) GetIpPoolOk() (*string, bool)`

GetIpPoolOk returns a tuple with the IpPool field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpPool

`func (o *V11AvscanSettingsSettings) SetIpPool(v string)`

SetIpPool sets IpPool field to given value.

### HasIpPool

`func (o *V11AvscanSettingsSettings) HasIpPool() bool`

HasIpPool returns a boolean if a field has been set.

### GetReportExpiry

`func (o *V11AvscanSettingsSettings) GetReportExpiry() int32`

GetReportExpiry returns the ReportExpiry field if non-nil, zero value otherwise.

### GetReportExpiryOk

`func (o *V11AvscanSettingsSettings) GetReportExpiryOk() (*int32, bool)`

GetReportExpiryOk returns a tuple with the ReportExpiry field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReportExpiry

`func (o *V11AvscanSettingsSettings) SetReportExpiry(v int32)`

SetReportExpiry sets ReportExpiry field to given value.

### HasReportExpiry

`func (o *V11AvscanSettingsSettings) HasReportExpiry() bool`

HasReportExpiry returns a boolean if a field has been set.

### GetScanCloudpoolTimeout

`func (o *V11AvscanSettingsSettings) GetScanCloudpoolTimeout() int32`

GetScanCloudpoolTimeout returns the ScanCloudpoolTimeout field if non-nil, zero value otherwise.

### GetScanCloudpoolTimeoutOk

`func (o *V11AvscanSettingsSettings) GetScanCloudpoolTimeoutOk() (*int32, bool)`

GetScanCloudpoolTimeoutOk returns a tuple with the ScanCloudpoolTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanCloudpoolTimeout

`func (o *V11AvscanSettingsSettings) SetScanCloudpoolTimeout(v int32)`

SetScanCloudpoolTimeout sets ScanCloudpoolTimeout field to given value.

### HasScanCloudpoolTimeout

`func (o *V11AvscanSettingsSettings) HasScanCloudpoolTimeout() bool`

HasScanCloudpoolTimeout returns a boolean if a field has been set.

### GetScanSizeMaximum

`func (o *V11AvscanSettingsSettings) GetScanSizeMaximum() int32`

GetScanSizeMaximum returns the ScanSizeMaximum field if non-nil, zero value otherwise.

### GetScanSizeMaximumOk

`func (o *V11AvscanSettingsSettings) GetScanSizeMaximumOk() (*int32, bool)`

GetScanSizeMaximumOk returns a tuple with the ScanSizeMaximum field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanSizeMaximum

`func (o *V11AvscanSettingsSettings) SetScanSizeMaximum(v int32)`

SetScanSizeMaximum sets ScanSizeMaximum field to given value.

### HasScanSizeMaximum

`func (o *V11AvscanSettingsSettings) HasScanSizeMaximum() bool`

HasScanSizeMaximum returns a boolean if a field has been set.

### GetScanTimeout

`func (o *V11AvscanSettingsSettings) GetScanTimeout() int32`

GetScanTimeout returns the ScanTimeout field if non-nil, zero value otherwise.

### GetScanTimeoutOk

`func (o *V11AvscanSettingsSettings) GetScanTimeoutOk() (*int32, bool)`

GetScanTimeoutOk returns a tuple with the ScanTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanTimeout

`func (o *V11AvscanSettingsSettings) SetScanTimeout(v int32)`

SetScanTimeout sets ScanTimeout field to given value.

### HasScanTimeout

`func (o *V11AvscanSettingsSettings) HasScanTimeout() bool`

HasScanTimeout returns a boolean if a field has been set.

### GetScanZones

`func (o *V11AvscanSettingsSettings) GetScanZones() []string`

GetScanZones returns the ScanZones field if non-nil, zero value otherwise.

### GetScanZonesOk

`func (o *V11AvscanSettingsSettings) GetScanZonesOk() (*[]string, bool)`

GetScanZonesOk returns a tuple with the ScanZones field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanZones

`func (o *V11AvscanSettingsSettings) SetScanZones(v []string)`

SetScanZones sets ScanZones field to given value.

### HasScanZones

`func (o *V11AvscanSettingsSettings) HasScanZones() bool`

HasScanZones returns a boolean if a field has been set.

### GetServiceEnabled

`func (o *V11AvscanSettingsSettings) GetServiceEnabled() bool`

GetServiceEnabled returns the ServiceEnabled field if non-nil, zero value otherwise.

### GetServiceEnabledOk

`func (o *V11AvscanSettingsSettings) GetServiceEnabledOk() (*bool, bool)`

GetServiceEnabledOk returns a tuple with the ServiceEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServiceEnabled

`func (o *V11AvscanSettingsSettings) SetServiceEnabled(v bool)`

SetServiceEnabled sets ServiceEnabled field to given value.

### HasServiceEnabled

`func (o *V11AvscanSettingsSettings) HasServiceEnabled() bool`

HasServiceEnabled returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


