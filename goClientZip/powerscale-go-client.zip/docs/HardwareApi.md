# \HardwareApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateHardwarev3HardwareTapeName**](HardwareApi.md#CreateHardwarev3HardwareTapeName) | **Post** /platform/3/hardware/tape/{v3HardwareTapeName} | 
[**DeleteHardwarev3HardwareTapeName**](HardwareApi.md#DeleteHardwarev3HardwareTapeName) | **Delete** /platform/3/hardware/tape/{v3HardwareTapeName} | 
[**GetHardwarev3HardwareFcport**](HardwareApi.md#GetHardwarev3HardwareFcport) | **Get** /platform/3/hardware/fcports/{v3HardwareFcportId} | 
[**GetHardwarev3HardwareFcports**](HardwareApi.md#GetHardwarev3HardwareFcports) | **Get** /platform/3/hardware/fcports | 
[**GetHardwarev3HardwareTapes**](HardwareApi.md#GetHardwarev3HardwareTapes) | **Get** /platform/3/hardware/tapes | 
[**UpdateHardwarev3HardwareFcport**](HardwareApi.md#UpdateHardwarev3HardwareFcport) | **Put** /platform/3/hardware/fcports/{v3HardwareFcportId} | 
[**UpdateHardwarev3HardwareTapeName**](HardwareApi.md#UpdateHardwarev3HardwareTapeName) | **Put** /platform/3/hardware/tape/{v3HardwareTapeName} | 



## CreateHardwarev3HardwareTapeName

> Createv3HardwareTapeNameResponse CreateHardwarev3HardwareTapeName(ctx, v3HardwareTapeName).V3HardwareTapeName2(v3HardwareTapeName2).Lnn(lnn).Port(port).Timeout(timeout).Reconcile(reconcile).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3HardwareTapeName := "v3HardwareTapeName_example" // string | Tape/Changer devices rescan
    v3HardwareTapeName2 := map[string]interface{}{ ... } // map[string]interface{} | 
    lnn := "lnn_example" // string | Logical node number. (optional)
    port := int32(56) // int32 | Scan only specified port. (optional)
    timeout := float32(8.14) // float32 | Timeout for request. (optional)
    reconcile := true // bool | Remove entries for devices or paths that have become inaccessible. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HardwareApi.CreateHardwarev3HardwareTapeName(context.Background(), v3HardwareTapeName).V3HardwareTapeName2(v3HardwareTapeName2).Lnn(lnn).Port(port).Timeout(timeout).Reconcile(reconcile).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HardwareApi.CreateHardwarev3HardwareTapeName``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateHardwarev3HardwareTapeName`: Createv3HardwareTapeNameResponse
    fmt.Fprintf(os.Stdout, "Response from `HardwareApi.CreateHardwarev3HardwareTapeName`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3HardwareTapeName** | **string** | Tape/Changer devices rescan | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateHardwarev3HardwareTapeNameRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3HardwareTapeName2** | **map[string]interface{}** |  | 
 **lnn** | **string** | Logical node number. | 
 **port** | **int32** | Scan only specified port. | 
 **timeout** | **float32** | Timeout for request. | 
 **reconcile** | **bool** | Remove entries for devices or paths that have become inaccessible. | 

### Return type

[**Createv3HardwareTapeNameResponse**](Createv3HardwareTapeNameResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteHardwarev3HardwareTapeName

> DeleteHardwarev3HardwareTapeName(ctx, v3HardwareTapeName).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3HardwareTapeName := "v3HardwareTapeName_example" // string | Tape/Changer devices remove

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.HardwareApi.DeleteHardwarev3HardwareTapeName(context.Background(), v3HardwareTapeName).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HardwareApi.DeleteHardwarev3HardwareTapeName``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3HardwareTapeName** | **string** | Tape/Changer devices remove | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteHardwarev3HardwareTapeNameRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetHardwarev3HardwareFcport

> V3HardwareFcports GetHardwarev3HardwareFcport(ctx, v3HardwareFcportId).Lnn(lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3HardwareFcportId := int32(56) // int32 | Get one fibre-channel port
    lnn := "lnn_example" // string | Logical node number. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HardwareApi.GetHardwarev3HardwareFcport(context.Background(), v3HardwareFcportId).Lnn(lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HardwareApi.GetHardwarev3HardwareFcport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetHardwarev3HardwareFcport`: V3HardwareFcports
    fmt.Fprintf(os.Stdout, "Response from `HardwareApi.GetHardwarev3HardwareFcport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3HardwareFcportId** | **int32** | Get one fibre-channel port | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetHardwarev3HardwareFcportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **lnn** | **string** | Logical node number. | 

### Return type

[**V3HardwareFcports**](V3HardwareFcports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetHardwarev3HardwareFcports

> V3HardwareFcports GetHardwarev3HardwareFcports(ctx).Lnn(lnn).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := "lnn_example" // string | Logical node number. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HardwareApi.GetHardwarev3HardwareFcports(context.Background()).Lnn(lnn).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HardwareApi.GetHardwarev3HardwareFcports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetHardwarev3HardwareFcports`: V3HardwareFcports
    fmt.Fprintf(os.Stdout, "Response from `HardwareApi.GetHardwarev3HardwareFcports`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetHardwarev3HardwareFcportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **lnn** | **string** | Logical node number. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3HardwareFcports**](V3HardwareFcports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetHardwarev3HardwareTapes

> V3HardwareTapes GetHardwarev3HardwareTapes(ctx).Node(node).Resume(resume).Devname(devname).Limit(limit).Activepath(activepath).Type_(type_).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    node := "node_example" // string | List only devices on the specified node. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    devname := "devname_example" // string | List only the named device. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    activepath := "activepath_example" // string | List devices with only active paths. (optional)
    type_ := "type__example" // string | Restrict to list on tape or mc device. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HardwareApi.GetHardwarev3HardwareTapes(context.Background()).Node(node).Resume(resume).Devname(devname).Limit(limit).Activepath(activepath).Type_(type_).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HardwareApi.GetHardwarev3HardwareTapes``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetHardwarev3HardwareTapes`: V3HardwareTapes
    fmt.Fprintf(os.Stdout, "Response from `HardwareApi.GetHardwarev3HardwareTapes`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetHardwarev3HardwareTapesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **node** | **string** | List only devices on the specified node. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **devname** | **string** | List only the named device. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **activepath** | **string** | List devices with only active paths. | 
 **type_** | **string** | Restrict to list on tape or mc device. | 

### Return type

[**V3HardwareTapes**](V3HardwareTapes.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateHardwarev3HardwareFcport

> UpdateHardwarev3HardwareFcport(ctx, v3HardwareFcportId).V3HardwareFcport(v3HardwareFcport).Lnn(lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3HardwareFcportId := int32(56) // int32 | Change wwnn, wwpn, state, topology, or rate of a FC port
    v3HardwareFcport := *openapiclient.NewV3HardwareFcport() // V3HardwareFcport | 
    lnn := "lnn_example" // string | Logical node number. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.HardwareApi.UpdateHardwarev3HardwareFcport(context.Background(), v3HardwareFcportId).V3HardwareFcport(v3HardwareFcport).Lnn(lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HardwareApi.UpdateHardwarev3HardwareFcport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3HardwareFcportId** | **int32** | Change wwnn, wwpn, state, topology, or rate of a FC port | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateHardwarev3HardwareFcportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3HardwareFcport** | [**V3HardwareFcport**](V3HardwareFcport.md) |  | 
 **lnn** | **string** | Logical node number. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateHardwarev3HardwareTapeName

> UpdateHardwarev3HardwareTapeName(ctx, v3HardwareTapeName).V3HardwareTapeNameParams(v3HardwareTapeNameParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3HardwareTapeName := "v3HardwareTapeName_example" // string | Tape/Changer device modify
    v3HardwareTapeNameParams := *openapiclient.NewV3HardwareTapeNameParams() // V3HardwareTapeNameParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.HardwareApi.UpdateHardwarev3HardwareTapeName(context.Background(), v3HardwareTapeName).V3HardwareTapeNameParams(v3HardwareTapeNameParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HardwareApi.UpdateHardwarev3HardwareTapeName``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3HardwareTapeName** | **string** | Tape/Changer device modify | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateHardwarev3HardwareTapeNameRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3HardwareTapeNameParams** | [**V3HardwareTapeNameParams**](V3HardwareTapeNameParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

