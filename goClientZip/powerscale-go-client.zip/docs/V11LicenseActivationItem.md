# V11LicenseActivationItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Lacs** | Pointer to **[]string** | An array of licenses not included in activation file. | [optional] 
**LicensesToExclude** | Pointer to **string** | Licenses to omit from activation file. | [optional] 
**LicensesToInclude** | Pointer to **string** | Licenses to include in activation file. | [optional] 
**OnlyTheseLicenses** | Pointer to **string** | Activate only the defined licenses. This setting overrides all other license activation settings. | [optional] 

## Methods

### NewV11LicenseActivationItem

`func NewV11LicenseActivationItem() *V11LicenseActivationItem`

NewV11LicenseActivationItem instantiates a new V11LicenseActivationItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11LicenseActivationItemWithDefaults

`func NewV11LicenseActivationItemWithDefaults() *V11LicenseActivationItem`

NewV11LicenseActivationItemWithDefaults instantiates a new V11LicenseActivationItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetLacs

`func (o *V11LicenseActivationItem) GetLacs() []string`

GetLacs returns the Lacs field if non-nil, zero value otherwise.

### GetLacsOk

`func (o *V11LicenseActivationItem) GetLacsOk() (*[]string, bool)`

GetLacsOk returns a tuple with the Lacs field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLacs

`func (o *V11LicenseActivationItem) SetLacs(v []string)`

SetLacs sets Lacs field to given value.

### HasLacs

`func (o *V11LicenseActivationItem) HasLacs() bool`

HasLacs returns a boolean if a field has been set.

### GetLicensesToExclude

`func (o *V11LicenseActivationItem) GetLicensesToExclude() string`

GetLicensesToExclude returns the LicensesToExclude field if non-nil, zero value otherwise.

### GetLicensesToExcludeOk

`func (o *V11LicenseActivationItem) GetLicensesToExcludeOk() (*string, bool)`

GetLicensesToExcludeOk returns a tuple with the LicensesToExclude field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLicensesToExclude

`func (o *V11LicenseActivationItem) SetLicensesToExclude(v string)`

SetLicensesToExclude sets LicensesToExclude field to given value.

### HasLicensesToExclude

`func (o *V11LicenseActivationItem) HasLicensesToExclude() bool`

HasLicensesToExclude returns a boolean if a field has been set.

### GetLicensesToInclude

`func (o *V11LicenseActivationItem) GetLicensesToInclude() string`

GetLicensesToInclude returns the LicensesToInclude field if non-nil, zero value otherwise.

### GetLicensesToIncludeOk

`func (o *V11LicenseActivationItem) GetLicensesToIncludeOk() (*string, bool)`

GetLicensesToIncludeOk returns a tuple with the LicensesToInclude field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLicensesToInclude

`func (o *V11LicenseActivationItem) SetLicensesToInclude(v string)`

SetLicensesToInclude sets LicensesToInclude field to given value.

### HasLicensesToInclude

`func (o *V11LicenseActivationItem) HasLicensesToInclude() bool`

HasLicensesToInclude returns a boolean if a field has been set.

### GetOnlyTheseLicenses

`func (o *V11LicenseActivationItem) GetOnlyTheseLicenses() string`

GetOnlyTheseLicenses returns the OnlyTheseLicenses field if non-nil, zero value otherwise.

### GetOnlyTheseLicensesOk

`func (o *V11LicenseActivationItem) GetOnlyTheseLicensesOk() (*string, bool)`

GetOnlyTheseLicensesOk returns a tuple with the OnlyTheseLicenses field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOnlyTheseLicenses

`func (o *V11LicenseActivationItem) SetOnlyTheseLicenses(v string)`

SetOnlyTheseLicenses sets OnlyTheseLicenses field to given value.

### HasOnlyTheseLicenses

`func (o *V11LicenseActivationItem) HasOnlyTheseLicenses() bool`

HasOnlyTheseLicenses returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


