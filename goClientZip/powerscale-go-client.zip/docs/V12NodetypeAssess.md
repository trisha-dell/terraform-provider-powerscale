# V12NodetypeAssess

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FromNodepools** | [**[]V10NodetypeAssessNodetypeFromNodepoolItem**](V10NodetypeAssessNodetypeFromNodepoolItem.md) | Pools assessed for removing nodetype. | 
**ToNodepools** | [**[]V10NodetypeAssessNodetypeFromNodepoolItem**](V10NodetypeAssessNodetypeFromNodepoolItem.md) | Pools assessed for adding nodetype. | 

## Methods

### NewV12NodetypeAssess

`func NewV12NodetypeAssess(fromNodepools []V10NodetypeAssessNodetypeFromNodepoolItem, toNodepools []V10NodetypeAssessNodetypeFromNodepoolItem, ) *V12NodetypeAssess`

NewV12NodetypeAssess instantiates a new V12NodetypeAssess object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12NodetypeAssessWithDefaults

`func NewV12NodetypeAssessWithDefaults() *V12NodetypeAssess`

NewV12NodetypeAssessWithDefaults instantiates a new V12NodetypeAssess object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFromNodepools

`func (o *V12NodetypeAssess) GetFromNodepools() []V10NodetypeAssessNodetypeFromNodepoolItem`

GetFromNodepools returns the FromNodepools field if non-nil, zero value otherwise.

### GetFromNodepoolsOk

`func (o *V12NodetypeAssess) GetFromNodepoolsOk() (*[]V10NodetypeAssessNodetypeFromNodepoolItem, bool)`

GetFromNodepoolsOk returns a tuple with the FromNodepools field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFromNodepools

`func (o *V12NodetypeAssess) SetFromNodepools(v []V10NodetypeAssessNodetypeFromNodepoolItem)`

SetFromNodepools sets FromNodepools field to given value.


### GetToNodepools

`func (o *V12NodetypeAssess) GetToNodepools() []V10NodetypeAssessNodetypeFromNodepoolItem`

GetToNodepools returns the ToNodepools field if non-nil, zero value otherwise.

### GetToNodepoolsOk

`func (o *V12NodetypeAssess) GetToNodepoolsOk() (*[]V10NodetypeAssessNodetypeFromNodepoolItem, bool)`

GetToNodepoolsOk returns a tuple with the ToNodepools field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetToNodepools

`func (o *V12NodetypeAssess) SetToNodepools(v []V10NodetypeAssessNodetypeFromNodepoolItem)`

SetToNodepools sets ToNodepools field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


