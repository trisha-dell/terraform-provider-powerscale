# V10HealthcheckChecklistItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Freshness** | Pointer to **int32** | Optional freshness override | [optional] 
**Name** | Pointer to **string** | Name of item | [optional] 
**Parameters** | Pointer to **map[string]interface{}** |  | [optional] 
**PassStatus** | Pointer to **string** | Optional pass status override | [optional] 
**Thresholds** | Pointer to [**V10HealthcheckChecklistItemThresholds**](V10HealthcheckChecklistItemThresholds.md) |  | [optional] 

## Methods

### NewV10HealthcheckChecklistItem

`func NewV10HealthcheckChecklistItem() *V10HealthcheckChecklistItem`

NewV10HealthcheckChecklistItem instantiates a new V10HealthcheckChecklistItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10HealthcheckChecklistItemWithDefaults

`func NewV10HealthcheckChecklistItemWithDefaults() *V10HealthcheckChecklistItem`

NewV10HealthcheckChecklistItemWithDefaults instantiates a new V10HealthcheckChecklistItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFreshness

`func (o *V10HealthcheckChecklistItem) GetFreshness() int32`

GetFreshness returns the Freshness field if non-nil, zero value otherwise.

### GetFreshnessOk

`func (o *V10HealthcheckChecklistItem) GetFreshnessOk() (*int32, bool)`

GetFreshnessOk returns a tuple with the Freshness field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFreshness

`func (o *V10HealthcheckChecklistItem) SetFreshness(v int32)`

SetFreshness sets Freshness field to given value.

### HasFreshness

`func (o *V10HealthcheckChecklistItem) HasFreshness() bool`

HasFreshness returns a boolean if a field has been set.

### GetName

`func (o *V10HealthcheckChecklistItem) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V10HealthcheckChecklistItem) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V10HealthcheckChecklistItem) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V10HealthcheckChecklistItem) HasName() bool`

HasName returns a boolean if a field has been set.

### GetParameters

`func (o *V10HealthcheckChecklistItem) GetParameters() map[string]interface{}`

GetParameters returns the Parameters field if non-nil, zero value otherwise.

### GetParametersOk

`func (o *V10HealthcheckChecklistItem) GetParametersOk() (*map[string]interface{}, bool)`

GetParametersOk returns a tuple with the Parameters field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetParameters

`func (o *V10HealthcheckChecklistItem) SetParameters(v map[string]interface{})`

SetParameters sets Parameters field to given value.

### HasParameters

`func (o *V10HealthcheckChecklistItem) HasParameters() bool`

HasParameters returns a boolean if a field has been set.

### GetPassStatus

`func (o *V10HealthcheckChecklistItem) GetPassStatus() string`

GetPassStatus returns the PassStatus field if non-nil, zero value otherwise.

### GetPassStatusOk

`func (o *V10HealthcheckChecklistItem) GetPassStatusOk() (*string, bool)`

GetPassStatusOk returns a tuple with the PassStatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPassStatus

`func (o *V10HealthcheckChecklistItem) SetPassStatus(v string)`

SetPassStatus sets PassStatus field to given value.

### HasPassStatus

`func (o *V10HealthcheckChecklistItem) HasPassStatus() bool`

HasPassStatus returns a boolean if a field has been set.

### GetThresholds

`func (o *V10HealthcheckChecklistItem) GetThresholds() V10HealthcheckChecklistItemThresholds`

GetThresholds returns the Thresholds field if non-nil, zero value otherwise.

### GetThresholdsOk

`func (o *V10HealthcheckChecklistItem) GetThresholdsOk() (*V10HealthcheckChecklistItemThresholds, bool)`

GetThresholdsOk returns a tuple with the Thresholds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetThresholds

`func (o *V10HealthcheckChecklistItem) SetThresholds(v V10HealthcheckChecklistItemThresholds)`

SetThresholds sets Thresholds field to given value.

### HasThresholds

`func (o *V10HealthcheckChecklistItem) HasThresholds() bool`

HasThresholds returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


