# V11NfsExportExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AllDirs** | Pointer to **bool** | True if all directories under the specified paths are mountable. | [optional] 
**BlockSize** | Pointer to **int32** | Specifies the block size returned by the NFS statfs procedure. | [optional] 
**CanSetTime** | Pointer to **bool** | True if the client can set file times through the NFS set attribute request. This parameter does not affect server behavior, but is included to accommodate legacy client requirements. | [optional] 
**CaseInsensitive** | Pointer to **bool** | True if the case is ignored for file names. This parameter does not affect server behavior, but is included to accommodate legacy client requirements. | [optional] 
**CasePreserving** | Pointer to **bool** | True if the case is preserved for file names. This parameter does not affect server behavior, but is included to accommodate legacy client requirements. | [optional] 
**ChownRestricted** | Pointer to **bool** | True if the superuser can change file ownership. This parameter does not affect server behavior, but is included to accommodate legacy client requirements. | [optional] 
**Clients** | Pointer to **[]string** | Specifies the clients with root access to the export. | [optional] 
**CommitAsynchronous** | Pointer to **bool** | True if NFS  commit  requests execute asynchronously. | [optional] 
**Description** | Pointer to **string** | Specifies the user-defined string that is used to identify the export. | [optional] 
**DirectoryTransferSize** | Pointer to **int32** | Specifies the preferred size for directory read operations. This value is used to advise the client of optimal settings for the server, but is not enforced. | [optional] 
**Encoding** | Pointer to **string** | Specifies the default character set encoding of the clients connecting to the export, unless otherwise specified. | [optional] 
**LinkMax** | Pointer to **int32** | Specifies the reported maximum number of links to a file. This parameter does not affect server behavior, but is included to accommodate legacy client requirements. | [optional] 
**MapAll** | Pointer to [**V11NfsExportMapAll**](V11NfsExportMapAll.md) |  | [optional] 
**MapFailure** | Pointer to [**V11NfsExportMapAll**](V11NfsExportMapAll.md) |  | [optional] 
**MapFull** | Pointer to **bool** | True if user mappings query the OneFS user database. When set to false, user mappings only query local authentication. | [optional] 
**MapLookupUid** | Pointer to **bool** | True if incoming user IDs (UIDs) are mapped to users in the OneFS user database. When set to false, incoming UIDs are applied directly to file operations. | [optional] 
**MapNonRoot** | Pointer to [**V11NfsExportMapAll**](V11NfsExportMapAll.md) |  | [optional] 
**MapRetry** | Pointer to **bool** | Determines whether searches for users specified in &#39;map_all&#39;, &#39;map_root&#39; or &#39;map_nonroot&#39; are retried if the search fails. | [optional] 
**MapRoot** | Pointer to [**V11NfsExportMapAll**](V11NfsExportMapAll.md) |  | [optional] 
**MaxFileSize** | Pointer to **int32** | Specifies the maximum file size for any file accessed from the export. This parameter does not affect server behavior, but is included to accommodate legacy client requirements. | [optional] 
**NameMaxSize** | Pointer to **int32** | Specifies the reported maximum length of a file name. This parameter does not affect server behavior, but is included to accommodate legacy client requirements. | [optional] 
**NoTruncate** | Pointer to **bool** | True if long file names result in an error. This parameter does not affect server behavior, but is included to accommodate legacy client requirements. | [optional] 
**Paths** | Pointer to **[]string** | Specifies the paths under /ifs that are exported. | [optional] 
**ReadOnly** | Pointer to **bool** | True if the export is set to read-only. | [optional] 
**ReadOnlyClients** | Pointer to **[]string** | Specifies the clients with read-only access to the export. | [optional] 
**ReadTransferMaxSize** | Pointer to **int32** | Specifies the maximum buffer size that clients should use on NFS read requests. This value is used to advise the client of optimal settings for the server, but is not enforced. | [optional] 
**ReadTransferMultiple** | Pointer to **int32** | Specifies the preferred multiple size for NFS read requests. This value is used to advise the client of optimal settings for the server, but is not enforced. | [optional] 
**ReadTransferSize** | Pointer to **int32** | Specifies the preferred size for NFS read requests. This value is used to advise the client of optimal settings for the server, but is not enforced. | [optional] 
**ReadWriteClients** | Pointer to **[]string** | Specifies the clients with both read and write access to the export, even when the export is set to read-only. | [optional] 
**Readdirplus** | Pointer to **bool** | True if &#39;readdirplus&#39; requests are enabled. Enabling this property might improve network performance and is only available for NFSv3. | [optional] 
**ReaddirplusPrefetch** | Pointer to **int32** | Sets the number of directory entries that are prefetched when a &#39;readdirplus&#39; request is processed. (Deprecated.) | [optional] 
**Return32bitFileIds** | Pointer to **bool** | Limits the size of file identifiers returned by NFSv3+ to 32-bit values (may require remount). | [optional] 
**RootClients** | Pointer to **[]string** | Clients that have root access to the export. | [optional] 
**SecurityFlavors** | Pointer to **[]string** | Specifies the authentication types that are supported for this export. | [optional] 
**SetattrAsynchronous** | Pointer to **bool** | True if set attribute operations execute asynchronously. | [optional] 
**Snapshot** | Pointer to **string** | Specifies the snapshot for all mounts. | [optional] 
**Symlinks** | Pointer to **bool** | True if symlinks are supported. This value is used to advise the client of optimal settings for the server, but is not enforced. | [optional] 
**TimeDelta** | Pointer to **float32** | Specifies the resolution of all time values that are returned to the clients | [optional] 
**WriteDatasyncAction** | Pointer to **string** | Specifies the action to be taken when an NFSv3+ datasync write is requested. | [optional] 
**WriteDatasyncReply** | Pointer to **string** | Specifies the stability disposition returned when an NFSv3+ datasync write is processed. | [optional] 
**WriteFilesyncAction** | Pointer to **string** | Specifies the action to be taken when an NFSv3+ filesync write is requested. | [optional] 
**WriteFilesyncReply** | Pointer to **string** | Specifies the stability disposition returned when an NFSv3+ filesync write is processed. | [optional] 
**WriteTransferMaxSize** | Pointer to **int32** | Specifies the maximum buffer size that clients should use on NFS write requests. This value is used to advise the client of optimal settings for the server, but is not enforced. | [optional] 
**WriteTransferMultiple** | Pointer to **int32** | Specifies the preferred multiple size for NFS write requests. This value is used to advise the client of optimal settings for the server, but is not enforced. | [optional] 
**WriteTransferSize** | Pointer to **int32** | Specifies the preferred multiple size for NFS write requests. This value is used to advise the client of optimal settings for the server, but is not enforced. | [optional] 
**WriteUnstableAction** | Pointer to **string** | Specifies the action to be taken when an NFSv3+ unstable write is requested. | [optional] 
**WriteUnstableReply** | Pointer to **string** | Specifies the stability disposition returned when an NFSv3+ unstable write is processed. | [optional] 
**ConflictingPaths** | Pointer to **[]string** | Reports the paths that conflict with another export. | [optional] 
**Id** | Pointer to **int32** | Specifies the system-assigned ID for the export. This ID is returned when an export is created through the POST method. | [optional] 
**UnresolvedClients** | Pointer to **[]string** | Reports clients that cannot be resolved. | [optional] 
**Zone** | Pointer to **string** | Specifies the zone in which the export is valid. | [optional] 

## Methods

### NewV11NfsExportExtended

`func NewV11NfsExportExtended() *V11NfsExportExtended`

NewV11NfsExportExtended instantiates a new V11NfsExportExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11NfsExportExtendedWithDefaults

`func NewV11NfsExportExtendedWithDefaults() *V11NfsExportExtended`

NewV11NfsExportExtendedWithDefaults instantiates a new V11NfsExportExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAllDirs

`func (o *V11NfsExportExtended) GetAllDirs() bool`

GetAllDirs returns the AllDirs field if non-nil, zero value otherwise.

### GetAllDirsOk

`func (o *V11NfsExportExtended) GetAllDirsOk() (*bool, bool)`

GetAllDirsOk returns a tuple with the AllDirs field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllDirs

`func (o *V11NfsExportExtended) SetAllDirs(v bool)`

SetAllDirs sets AllDirs field to given value.

### HasAllDirs

`func (o *V11NfsExportExtended) HasAllDirs() bool`

HasAllDirs returns a boolean if a field has been set.

### GetBlockSize

`func (o *V11NfsExportExtended) GetBlockSize() int32`

GetBlockSize returns the BlockSize field if non-nil, zero value otherwise.

### GetBlockSizeOk

`func (o *V11NfsExportExtended) GetBlockSizeOk() (*int32, bool)`

GetBlockSizeOk returns a tuple with the BlockSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBlockSize

`func (o *V11NfsExportExtended) SetBlockSize(v int32)`

SetBlockSize sets BlockSize field to given value.

### HasBlockSize

`func (o *V11NfsExportExtended) HasBlockSize() bool`

HasBlockSize returns a boolean if a field has been set.

### GetCanSetTime

`func (o *V11NfsExportExtended) GetCanSetTime() bool`

GetCanSetTime returns the CanSetTime field if non-nil, zero value otherwise.

### GetCanSetTimeOk

`func (o *V11NfsExportExtended) GetCanSetTimeOk() (*bool, bool)`

GetCanSetTimeOk returns a tuple with the CanSetTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCanSetTime

`func (o *V11NfsExportExtended) SetCanSetTime(v bool)`

SetCanSetTime sets CanSetTime field to given value.

### HasCanSetTime

`func (o *V11NfsExportExtended) HasCanSetTime() bool`

HasCanSetTime returns a boolean if a field has been set.

### GetCaseInsensitive

`func (o *V11NfsExportExtended) GetCaseInsensitive() bool`

GetCaseInsensitive returns the CaseInsensitive field if non-nil, zero value otherwise.

### GetCaseInsensitiveOk

`func (o *V11NfsExportExtended) GetCaseInsensitiveOk() (*bool, bool)`

GetCaseInsensitiveOk returns a tuple with the CaseInsensitive field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCaseInsensitive

`func (o *V11NfsExportExtended) SetCaseInsensitive(v bool)`

SetCaseInsensitive sets CaseInsensitive field to given value.

### HasCaseInsensitive

`func (o *V11NfsExportExtended) HasCaseInsensitive() bool`

HasCaseInsensitive returns a boolean if a field has been set.

### GetCasePreserving

`func (o *V11NfsExportExtended) GetCasePreserving() bool`

GetCasePreserving returns the CasePreserving field if non-nil, zero value otherwise.

### GetCasePreservingOk

`func (o *V11NfsExportExtended) GetCasePreservingOk() (*bool, bool)`

GetCasePreservingOk returns a tuple with the CasePreserving field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCasePreserving

`func (o *V11NfsExportExtended) SetCasePreserving(v bool)`

SetCasePreserving sets CasePreserving field to given value.

### HasCasePreserving

`func (o *V11NfsExportExtended) HasCasePreserving() bool`

HasCasePreserving returns a boolean if a field has been set.

### GetChownRestricted

`func (o *V11NfsExportExtended) GetChownRestricted() bool`

GetChownRestricted returns the ChownRestricted field if non-nil, zero value otherwise.

### GetChownRestrictedOk

`func (o *V11NfsExportExtended) GetChownRestrictedOk() (*bool, bool)`

GetChownRestrictedOk returns a tuple with the ChownRestricted field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChownRestricted

`func (o *V11NfsExportExtended) SetChownRestricted(v bool)`

SetChownRestricted sets ChownRestricted field to given value.

### HasChownRestricted

`func (o *V11NfsExportExtended) HasChownRestricted() bool`

HasChownRestricted returns a boolean if a field has been set.

### GetClients

`func (o *V11NfsExportExtended) GetClients() []string`

GetClients returns the Clients field if non-nil, zero value otherwise.

### GetClientsOk

`func (o *V11NfsExportExtended) GetClientsOk() (*[]string, bool)`

GetClientsOk returns a tuple with the Clients field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClients

`func (o *V11NfsExportExtended) SetClients(v []string)`

SetClients sets Clients field to given value.

### HasClients

`func (o *V11NfsExportExtended) HasClients() bool`

HasClients returns a boolean if a field has been set.

### GetCommitAsynchronous

`func (o *V11NfsExportExtended) GetCommitAsynchronous() bool`

GetCommitAsynchronous returns the CommitAsynchronous field if non-nil, zero value otherwise.

### GetCommitAsynchronousOk

`func (o *V11NfsExportExtended) GetCommitAsynchronousOk() (*bool, bool)`

GetCommitAsynchronousOk returns a tuple with the CommitAsynchronous field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCommitAsynchronous

`func (o *V11NfsExportExtended) SetCommitAsynchronous(v bool)`

SetCommitAsynchronous sets CommitAsynchronous field to given value.

### HasCommitAsynchronous

`func (o *V11NfsExportExtended) HasCommitAsynchronous() bool`

HasCommitAsynchronous returns a boolean if a field has been set.

### GetDescription

`func (o *V11NfsExportExtended) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V11NfsExportExtended) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V11NfsExportExtended) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *V11NfsExportExtended) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetDirectoryTransferSize

`func (o *V11NfsExportExtended) GetDirectoryTransferSize() int32`

GetDirectoryTransferSize returns the DirectoryTransferSize field if non-nil, zero value otherwise.

### GetDirectoryTransferSizeOk

`func (o *V11NfsExportExtended) GetDirectoryTransferSizeOk() (*int32, bool)`

GetDirectoryTransferSizeOk returns a tuple with the DirectoryTransferSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDirectoryTransferSize

`func (o *V11NfsExportExtended) SetDirectoryTransferSize(v int32)`

SetDirectoryTransferSize sets DirectoryTransferSize field to given value.

### HasDirectoryTransferSize

`func (o *V11NfsExportExtended) HasDirectoryTransferSize() bool`

HasDirectoryTransferSize returns a boolean if a field has been set.

### GetEncoding

`func (o *V11NfsExportExtended) GetEncoding() string`

GetEncoding returns the Encoding field if non-nil, zero value otherwise.

### GetEncodingOk

`func (o *V11NfsExportExtended) GetEncodingOk() (*string, bool)`

GetEncodingOk returns a tuple with the Encoding field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEncoding

`func (o *V11NfsExportExtended) SetEncoding(v string)`

SetEncoding sets Encoding field to given value.

### HasEncoding

`func (o *V11NfsExportExtended) HasEncoding() bool`

HasEncoding returns a boolean if a field has been set.

### GetLinkMax

`func (o *V11NfsExportExtended) GetLinkMax() int32`

GetLinkMax returns the LinkMax field if non-nil, zero value otherwise.

### GetLinkMaxOk

`func (o *V11NfsExportExtended) GetLinkMaxOk() (*int32, bool)`

GetLinkMaxOk returns a tuple with the LinkMax field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLinkMax

`func (o *V11NfsExportExtended) SetLinkMax(v int32)`

SetLinkMax sets LinkMax field to given value.

### HasLinkMax

`func (o *V11NfsExportExtended) HasLinkMax() bool`

HasLinkMax returns a boolean if a field has been set.

### GetMapAll

`func (o *V11NfsExportExtended) GetMapAll() V11NfsExportMapAll`

GetMapAll returns the MapAll field if non-nil, zero value otherwise.

### GetMapAllOk

`func (o *V11NfsExportExtended) GetMapAllOk() (*V11NfsExportMapAll, bool)`

GetMapAllOk returns a tuple with the MapAll field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMapAll

`func (o *V11NfsExportExtended) SetMapAll(v V11NfsExportMapAll)`

SetMapAll sets MapAll field to given value.

### HasMapAll

`func (o *V11NfsExportExtended) HasMapAll() bool`

HasMapAll returns a boolean if a field has been set.

### GetMapFailure

`func (o *V11NfsExportExtended) GetMapFailure() V11NfsExportMapAll`

GetMapFailure returns the MapFailure field if non-nil, zero value otherwise.

### GetMapFailureOk

`func (o *V11NfsExportExtended) GetMapFailureOk() (*V11NfsExportMapAll, bool)`

GetMapFailureOk returns a tuple with the MapFailure field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMapFailure

`func (o *V11NfsExportExtended) SetMapFailure(v V11NfsExportMapAll)`

SetMapFailure sets MapFailure field to given value.

### HasMapFailure

`func (o *V11NfsExportExtended) HasMapFailure() bool`

HasMapFailure returns a boolean if a field has been set.

### GetMapFull

`func (o *V11NfsExportExtended) GetMapFull() bool`

GetMapFull returns the MapFull field if non-nil, zero value otherwise.

### GetMapFullOk

`func (o *V11NfsExportExtended) GetMapFullOk() (*bool, bool)`

GetMapFullOk returns a tuple with the MapFull field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMapFull

`func (o *V11NfsExportExtended) SetMapFull(v bool)`

SetMapFull sets MapFull field to given value.

### HasMapFull

`func (o *V11NfsExportExtended) HasMapFull() bool`

HasMapFull returns a boolean if a field has been set.

### GetMapLookupUid

`func (o *V11NfsExportExtended) GetMapLookupUid() bool`

GetMapLookupUid returns the MapLookupUid field if non-nil, zero value otherwise.

### GetMapLookupUidOk

`func (o *V11NfsExportExtended) GetMapLookupUidOk() (*bool, bool)`

GetMapLookupUidOk returns a tuple with the MapLookupUid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMapLookupUid

`func (o *V11NfsExportExtended) SetMapLookupUid(v bool)`

SetMapLookupUid sets MapLookupUid field to given value.

### HasMapLookupUid

`func (o *V11NfsExportExtended) HasMapLookupUid() bool`

HasMapLookupUid returns a boolean if a field has been set.

### GetMapNonRoot

`func (o *V11NfsExportExtended) GetMapNonRoot() V11NfsExportMapAll`

GetMapNonRoot returns the MapNonRoot field if non-nil, zero value otherwise.

### GetMapNonRootOk

`func (o *V11NfsExportExtended) GetMapNonRootOk() (*V11NfsExportMapAll, bool)`

GetMapNonRootOk returns a tuple with the MapNonRoot field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMapNonRoot

`func (o *V11NfsExportExtended) SetMapNonRoot(v V11NfsExportMapAll)`

SetMapNonRoot sets MapNonRoot field to given value.

### HasMapNonRoot

`func (o *V11NfsExportExtended) HasMapNonRoot() bool`

HasMapNonRoot returns a boolean if a field has been set.

### GetMapRetry

`func (o *V11NfsExportExtended) GetMapRetry() bool`

GetMapRetry returns the MapRetry field if non-nil, zero value otherwise.

### GetMapRetryOk

`func (o *V11NfsExportExtended) GetMapRetryOk() (*bool, bool)`

GetMapRetryOk returns a tuple with the MapRetry field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMapRetry

`func (o *V11NfsExportExtended) SetMapRetry(v bool)`

SetMapRetry sets MapRetry field to given value.

### HasMapRetry

`func (o *V11NfsExportExtended) HasMapRetry() bool`

HasMapRetry returns a boolean if a field has been set.

### GetMapRoot

`func (o *V11NfsExportExtended) GetMapRoot() V11NfsExportMapAll`

GetMapRoot returns the MapRoot field if non-nil, zero value otherwise.

### GetMapRootOk

`func (o *V11NfsExportExtended) GetMapRootOk() (*V11NfsExportMapAll, bool)`

GetMapRootOk returns a tuple with the MapRoot field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMapRoot

`func (o *V11NfsExportExtended) SetMapRoot(v V11NfsExportMapAll)`

SetMapRoot sets MapRoot field to given value.

### HasMapRoot

`func (o *V11NfsExportExtended) HasMapRoot() bool`

HasMapRoot returns a boolean if a field has been set.

### GetMaxFileSize

`func (o *V11NfsExportExtended) GetMaxFileSize() int32`

GetMaxFileSize returns the MaxFileSize field if non-nil, zero value otherwise.

### GetMaxFileSizeOk

`func (o *V11NfsExportExtended) GetMaxFileSizeOk() (*int32, bool)`

GetMaxFileSizeOk returns a tuple with the MaxFileSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaxFileSize

`func (o *V11NfsExportExtended) SetMaxFileSize(v int32)`

SetMaxFileSize sets MaxFileSize field to given value.

### HasMaxFileSize

`func (o *V11NfsExportExtended) HasMaxFileSize() bool`

HasMaxFileSize returns a boolean if a field has been set.

### GetNameMaxSize

`func (o *V11NfsExportExtended) GetNameMaxSize() int32`

GetNameMaxSize returns the NameMaxSize field if non-nil, zero value otherwise.

### GetNameMaxSizeOk

`func (o *V11NfsExportExtended) GetNameMaxSizeOk() (*int32, bool)`

GetNameMaxSizeOk returns a tuple with the NameMaxSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNameMaxSize

`func (o *V11NfsExportExtended) SetNameMaxSize(v int32)`

SetNameMaxSize sets NameMaxSize field to given value.

### HasNameMaxSize

`func (o *V11NfsExportExtended) HasNameMaxSize() bool`

HasNameMaxSize returns a boolean if a field has been set.

### GetNoTruncate

`func (o *V11NfsExportExtended) GetNoTruncate() bool`

GetNoTruncate returns the NoTruncate field if non-nil, zero value otherwise.

### GetNoTruncateOk

`func (o *V11NfsExportExtended) GetNoTruncateOk() (*bool, bool)`

GetNoTruncateOk returns a tuple with the NoTruncate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNoTruncate

`func (o *V11NfsExportExtended) SetNoTruncate(v bool)`

SetNoTruncate sets NoTruncate field to given value.

### HasNoTruncate

`func (o *V11NfsExportExtended) HasNoTruncate() bool`

HasNoTruncate returns a boolean if a field has been set.

### GetPaths

`func (o *V11NfsExportExtended) GetPaths() []string`

GetPaths returns the Paths field if non-nil, zero value otherwise.

### GetPathsOk

`func (o *V11NfsExportExtended) GetPathsOk() (*[]string, bool)`

GetPathsOk returns a tuple with the Paths field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPaths

`func (o *V11NfsExportExtended) SetPaths(v []string)`

SetPaths sets Paths field to given value.

### HasPaths

`func (o *V11NfsExportExtended) HasPaths() bool`

HasPaths returns a boolean if a field has been set.

### GetReadOnly

`func (o *V11NfsExportExtended) GetReadOnly() bool`

GetReadOnly returns the ReadOnly field if non-nil, zero value otherwise.

### GetReadOnlyOk

`func (o *V11NfsExportExtended) GetReadOnlyOk() (*bool, bool)`

GetReadOnlyOk returns a tuple with the ReadOnly field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadOnly

`func (o *V11NfsExportExtended) SetReadOnly(v bool)`

SetReadOnly sets ReadOnly field to given value.

### HasReadOnly

`func (o *V11NfsExportExtended) HasReadOnly() bool`

HasReadOnly returns a boolean if a field has been set.

### GetReadOnlyClients

`func (o *V11NfsExportExtended) GetReadOnlyClients() []string`

GetReadOnlyClients returns the ReadOnlyClients field if non-nil, zero value otherwise.

### GetReadOnlyClientsOk

`func (o *V11NfsExportExtended) GetReadOnlyClientsOk() (*[]string, bool)`

GetReadOnlyClientsOk returns a tuple with the ReadOnlyClients field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadOnlyClients

`func (o *V11NfsExportExtended) SetReadOnlyClients(v []string)`

SetReadOnlyClients sets ReadOnlyClients field to given value.

### HasReadOnlyClients

`func (o *V11NfsExportExtended) HasReadOnlyClients() bool`

HasReadOnlyClients returns a boolean if a field has been set.

### GetReadTransferMaxSize

`func (o *V11NfsExportExtended) GetReadTransferMaxSize() int32`

GetReadTransferMaxSize returns the ReadTransferMaxSize field if non-nil, zero value otherwise.

### GetReadTransferMaxSizeOk

`func (o *V11NfsExportExtended) GetReadTransferMaxSizeOk() (*int32, bool)`

GetReadTransferMaxSizeOk returns a tuple with the ReadTransferMaxSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadTransferMaxSize

`func (o *V11NfsExportExtended) SetReadTransferMaxSize(v int32)`

SetReadTransferMaxSize sets ReadTransferMaxSize field to given value.

### HasReadTransferMaxSize

`func (o *V11NfsExportExtended) HasReadTransferMaxSize() bool`

HasReadTransferMaxSize returns a boolean if a field has been set.

### GetReadTransferMultiple

`func (o *V11NfsExportExtended) GetReadTransferMultiple() int32`

GetReadTransferMultiple returns the ReadTransferMultiple field if non-nil, zero value otherwise.

### GetReadTransferMultipleOk

`func (o *V11NfsExportExtended) GetReadTransferMultipleOk() (*int32, bool)`

GetReadTransferMultipleOk returns a tuple with the ReadTransferMultiple field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadTransferMultiple

`func (o *V11NfsExportExtended) SetReadTransferMultiple(v int32)`

SetReadTransferMultiple sets ReadTransferMultiple field to given value.

### HasReadTransferMultiple

`func (o *V11NfsExportExtended) HasReadTransferMultiple() bool`

HasReadTransferMultiple returns a boolean if a field has been set.

### GetReadTransferSize

`func (o *V11NfsExportExtended) GetReadTransferSize() int32`

GetReadTransferSize returns the ReadTransferSize field if non-nil, zero value otherwise.

### GetReadTransferSizeOk

`func (o *V11NfsExportExtended) GetReadTransferSizeOk() (*int32, bool)`

GetReadTransferSizeOk returns a tuple with the ReadTransferSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadTransferSize

`func (o *V11NfsExportExtended) SetReadTransferSize(v int32)`

SetReadTransferSize sets ReadTransferSize field to given value.

### HasReadTransferSize

`func (o *V11NfsExportExtended) HasReadTransferSize() bool`

HasReadTransferSize returns a boolean if a field has been set.

### GetReadWriteClients

`func (o *V11NfsExportExtended) GetReadWriteClients() []string`

GetReadWriteClients returns the ReadWriteClients field if non-nil, zero value otherwise.

### GetReadWriteClientsOk

`func (o *V11NfsExportExtended) GetReadWriteClientsOk() (*[]string, bool)`

GetReadWriteClientsOk returns a tuple with the ReadWriteClients field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadWriteClients

`func (o *V11NfsExportExtended) SetReadWriteClients(v []string)`

SetReadWriteClients sets ReadWriteClients field to given value.

### HasReadWriteClients

`func (o *V11NfsExportExtended) HasReadWriteClients() bool`

HasReadWriteClients returns a boolean if a field has been set.

### GetReaddirplus

`func (o *V11NfsExportExtended) GetReaddirplus() bool`

GetReaddirplus returns the Readdirplus field if non-nil, zero value otherwise.

### GetReaddirplusOk

`func (o *V11NfsExportExtended) GetReaddirplusOk() (*bool, bool)`

GetReaddirplusOk returns a tuple with the Readdirplus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReaddirplus

`func (o *V11NfsExportExtended) SetReaddirplus(v bool)`

SetReaddirplus sets Readdirplus field to given value.

### HasReaddirplus

`func (o *V11NfsExportExtended) HasReaddirplus() bool`

HasReaddirplus returns a boolean if a field has been set.

### GetReaddirplusPrefetch

`func (o *V11NfsExportExtended) GetReaddirplusPrefetch() int32`

GetReaddirplusPrefetch returns the ReaddirplusPrefetch field if non-nil, zero value otherwise.

### GetReaddirplusPrefetchOk

`func (o *V11NfsExportExtended) GetReaddirplusPrefetchOk() (*int32, bool)`

GetReaddirplusPrefetchOk returns a tuple with the ReaddirplusPrefetch field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReaddirplusPrefetch

`func (o *V11NfsExportExtended) SetReaddirplusPrefetch(v int32)`

SetReaddirplusPrefetch sets ReaddirplusPrefetch field to given value.

### HasReaddirplusPrefetch

`func (o *V11NfsExportExtended) HasReaddirplusPrefetch() bool`

HasReaddirplusPrefetch returns a boolean if a field has been set.

### GetReturn32bitFileIds

`func (o *V11NfsExportExtended) GetReturn32bitFileIds() bool`

GetReturn32bitFileIds returns the Return32bitFileIds field if non-nil, zero value otherwise.

### GetReturn32bitFileIdsOk

`func (o *V11NfsExportExtended) GetReturn32bitFileIdsOk() (*bool, bool)`

GetReturn32bitFileIdsOk returns a tuple with the Return32bitFileIds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReturn32bitFileIds

`func (o *V11NfsExportExtended) SetReturn32bitFileIds(v bool)`

SetReturn32bitFileIds sets Return32bitFileIds field to given value.

### HasReturn32bitFileIds

`func (o *V11NfsExportExtended) HasReturn32bitFileIds() bool`

HasReturn32bitFileIds returns a boolean if a field has been set.

### GetRootClients

`func (o *V11NfsExportExtended) GetRootClients() []string`

GetRootClients returns the RootClients field if non-nil, zero value otherwise.

### GetRootClientsOk

`func (o *V11NfsExportExtended) GetRootClientsOk() (*[]string, bool)`

GetRootClientsOk returns a tuple with the RootClients field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRootClients

`func (o *V11NfsExportExtended) SetRootClients(v []string)`

SetRootClients sets RootClients field to given value.

### HasRootClients

`func (o *V11NfsExportExtended) HasRootClients() bool`

HasRootClients returns a boolean if a field has been set.

### GetSecurityFlavors

`func (o *V11NfsExportExtended) GetSecurityFlavors() []string`

GetSecurityFlavors returns the SecurityFlavors field if non-nil, zero value otherwise.

### GetSecurityFlavorsOk

`func (o *V11NfsExportExtended) GetSecurityFlavorsOk() (*[]string, bool)`

GetSecurityFlavorsOk returns a tuple with the SecurityFlavors field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSecurityFlavors

`func (o *V11NfsExportExtended) SetSecurityFlavors(v []string)`

SetSecurityFlavors sets SecurityFlavors field to given value.

### HasSecurityFlavors

`func (o *V11NfsExportExtended) HasSecurityFlavors() bool`

HasSecurityFlavors returns a boolean if a field has been set.

### GetSetattrAsynchronous

`func (o *V11NfsExportExtended) GetSetattrAsynchronous() bool`

GetSetattrAsynchronous returns the SetattrAsynchronous field if non-nil, zero value otherwise.

### GetSetattrAsynchronousOk

`func (o *V11NfsExportExtended) GetSetattrAsynchronousOk() (*bool, bool)`

GetSetattrAsynchronousOk returns a tuple with the SetattrAsynchronous field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSetattrAsynchronous

`func (o *V11NfsExportExtended) SetSetattrAsynchronous(v bool)`

SetSetattrAsynchronous sets SetattrAsynchronous field to given value.

### HasSetattrAsynchronous

`func (o *V11NfsExportExtended) HasSetattrAsynchronous() bool`

HasSetattrAsynchronous returns a boolean if a field has been set.

### GetSnapshot

`func (o *V11NfsExportExtended) GetSnapshot() string`

GetSnapshot returns the Snapshot field if non-nil, zero value otherwise.

### GetSnapshotOk

`func (o *V11NfsExportExtended) GetSnapshotOk() (*string, bool)`

GetSnapshotOk returns a tuple with the Snapshot field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSnapshot

`func (o *V11NfsExportExtended) SetSnapshot(v string)`

SetSnapshot sets Snapshot field to given value.

### HasSnapshot

`func (o *V11NfsExportExtended) HasSnapshot() bool`

HasSnapshot returns a boolean if a field has been set.

### GetSymlinks

`func (o *V11NfsExportExtended) GetSymlinks() bool`

GetSymlinks returns the Symlinks field if non-nil, zero value otherwise.

### GetSymlinksOk

`func (o *V11NfsExportExtended) GetSymlinksOk() (*bool, bool)`

GetSymlinksOk returns a tuple with the Symlinks field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSymlinks

`func (o *V11NfsExportExtended) SetSymlinks(v bool)`

SetSymlinks sets Symlinks field to given value.

### HasSymlinks

`func (o *V11NfsExportExtended) HasSymlinks() bool`

HasSymlinks returns a boolean if a field has been set.

### GetTimeDelta

`func (o *V11NfsExportExtended) GetTimeDelta() float32`

GetTimeDelta returns the TimeDelta field if non-nil, zero value otherwise.

### GetTimeDeltaOk

`func (o *V11NfsExportExtended) GetTimeDeltaOk() (*float32, bool)`

GetTimeDeltaOk returns a tuple with the TimeDelta field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTimeDelta

`func (o *V11NfsExportExtended) SetTimeDelta(v float32)`

SetTimeDelta sets TimeDelta field to given value.

### HasTimeDelta

`func (o *V11NfsExportExtended) HasTimeDelta() bool`

HasTimeDelta returns a boolean if a field has been set.

### GetWriteDatasyncAction

`func (o *V11NfsExportExtended) GetWriteDatasyncAction() string`

GetWriteDatasyncAction returns the WriteDatasyncAction field if non-nil, zero value otherwise.

### GetWriteDatasyncActionOk

`func (o *V11NfsExportExtended) GetWriteDatasyncActionOk() (*string, bool)`

GetWriteDatasyncActionOk returns a tuple with the WriteDatasyncAction field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWriteDatasyncAction

`func (o *V11NfsExportExtended) SetWriteDatasyncAction(v string)`

SetWriteDatasyncAction sets WriteDatasyncAction field to given value.

### HasWriteDatasyncAction

`func (o *V11NfsExportExtended) HasWriteDatasyncAction() bool`

HasWriteDatasyncAction returns a boolean if a field has been set.

### GetWriteDatasyncReply

`func (o *V11NfsExportExtended) GetWriteDatasyncReply() string`

GetWriteDatasyncReply returns the WriteDatasyncReply field if non-nil, zero value otherwise.

### GetWriteDatasyncReplyOk

`func (o *V11NfsExportExtended) GetWriteDatasyncReplyOk() (*string, bool)`

GetWriteDatasyncReplyOk returns a tuple with the WriteDatasyncReply field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWriteDatasyncReply

`func (o *V11NfsExportExtended) SetWriteDatasyncReply(v string)`

SetWriteDatasyncReply sets WriteDatasyncReply field to given value.

### HasWriteDatasyncReply

`func (o *V11NfsExportExtended) HasWriteDatasyncReply() bool`

HasWriteDatasyncReply returns a boolean if a field has been set.

### GetWriteFilesyncAction

`func (o *V11NfsExportExtended) GetWriteFilesyncAction() string`

GetWriteFilesyncAction returns the WriteFilesyncAction field if non-nil, zero value otherwise.

### GetWriteFilesyncActionOk

`func (o *V11NfsExportExtended) GetWriteFilesyncActionOk() (*string, bool)`

GetWriteFilesyncActionOk returns a tuple with the WriteFilesyncAction field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWriteFilesyncAction

`func (o *V11NfsExportExtended) SetWriteFilesyncAction(v string)`

SetWriteFilesyncAction sets WriteFilesyncAction field to given value.

### HasWriteFilesyncAction

`func (o *V11NfsExportExtended) HasWriteFilesyncAction() bool`

HasWriteFilesyncAction returns a boolean if a field has been set.

### GetWriteFilesyncReply

`func (o *V11NfsExportExtended) GetWriteFilesyncReply() string`

GetWriteFilesyncReply returns the WriteFilesyncReply field if non-nil, zero value otherwise.

### GetWriteFilesyncReplyOk

`func (o *V11NfsExportExtended) GetWriteFilesyncReplyOk() (*string, bool)`

GetWriteFilesyncReplyOk returns a tuple with the WriteFilesyncReply field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWriteFilesyncReply

`func (o *V11NfsExportExtended) SetWriteFilesyncReply(v string)`

SetWriteFilesyncReply sets WriteFilesyncReply field to given value.

### HasWriteFilesyncReply

`func (o *V11NfsExportExtended) HasWriteFilesyncReply() bool`

HasWriteFilesyncReply returns a boolean if a field has been set.

### GetWriteTransferMaxSize

`func (o *V11NfsExportExtended) GetWriteTransferMaxSize() int32`

GetWriteTransferMaxSize returns the WriteTransferMaxSize field if non-nil, zero value otherwise.

### GetWriteTransferMaxSizeOk

`func (o *V11NfsExportExtended) GetWriteTransferMaxSizeOk() (*int32, bool)`

GetWriteTransferMaxSizeOk returns a tuple with the WriteTransferMaxSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWriteTransferMaxSize

`func (o *V11NfsExportExtended) SetWriteTransferMaxSize(v int32)`

SetWriteTransferMaxSize sets WriteTransferMaxSize field to given value.

### HasWriteTransferMaxSize

`func (o *V11NfsExportExtended) HasWriteTransferMaxSize() bool`

HasWriteTransferMaxSize returns a boolean if a field has been set.

### GetWriteTransferMultiple

`func (o *V11NfsExportExtended) GetWriteTransferMultiple() int32`

GetWriteTransferMultiple returns the WriteTransferMultiple field if non-nil, zero value otherwise.

### GetWriteTransferMultipleOk

`func (o *V11NfsExportExtended) GetWriteTransferMultipleOk() (*int32, bool)`

GetWriteTransferMultipleOk returns a tuple with the WriteTransferMultiple field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWriteTransferMultiple

`func (o *V11NfsExportExtended) SetWriteTransferMultiple(v int32)`

SetWriteTransferMultiple sets WriteTransferMultiple field to given value.

### HasWriteTransferMultiple

`func (o *V11NfsExportExtended) HasWriteTransferMultiple() bool`

HasWriteTransferMultiple returns a boolean if a field has been set.

### GetWriteTransferSize

`func (o *V11NfsExportExtended) GetWriteTransferSize() int32`

GetWriteTransferSize returns the WriteTransferSize field if non-nil, zero value otherwise.

### GetWriteTransferSizeOk

`func (o *V11NfsExportExtended) GetWriteTransferSizeOk() (*int32, bool)`

GetWriteTransferSizeOk returns a tuple with the WriteTransferSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWriteTransferSize

`func (o *V11NfsExportExtended) SetWriteTransferSize(v int32)`

SetWriteTransferSize sets WriteTransferSize field to given value.

### HasWriteTransferSize

`func (o *V11NfsExportExtended) HasWriteTransferSize() bool`

HasWriteTransferSize returns a boolean if a field has been set.

### GetWriteUnstableAction

`func (o *V11NfsExportExtended) GetWriteUnstableAction() string`

GetWriteUnstableAction returns the WriteUnstableAction field if non-nil, zero value otherwise.

### GetWriteUnstableActionOk

`func (o *V11NfsExportExtended) GetWriteUnstableActionOk() (*string, bool)`

GetWriteUnstableActionOk returns a tuple with the WriteUnstableAction field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWriteUnstableAction

`func (o *V11NfsExportExtended) SetWriteUnstableAction(v string)`

SetWriteUnstableAction sets WriteUnstableAction field to given value.

### HasWriteUnstableAction

`func (o *V11NfsExportExtended) HasWriteUnstableAction() bool`

HasWriteUnstableAction returns a boolean if a field has been set.

### GetWriteUnstableReply

`func (o *V11NfsExportExtended) GetWriteUnstableReply() string`

GetWriteUnstableReply returns the WriteUnstableReply field if non-nil, zero value otherwise.

### GetWriteUnstableReplyOk

`func (o *V11NfsExportExtended) GetWriteUnstableReplyOk() (*string, bool)`

GetWriteUnstableReplyOk returns a tuple with the WriteUnstableReply field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWriteUnstableReply

`func (o *V11NfsExportExtended) SetWriteUnstableReply(v string)`

SetWriteUnstableReply sets WriteUnstableReply field to given value.

### HasWriteUnstableReply

`func (o *V11NfsExportExtended) HasWriteUnstableReply() bool`

HasWriteUnstableReply returns a boolean if a field has been set.

### GetConflictingPaths

`func (o *V11NfsExportExtended) GetConflictingPaths() []string`

GetConflictingPaths returns the ConflictingPaths field if non-nil, zero value otherwise.

### GetConflictingPathsOk

`func (o *V11NfsExportExtended) GetConflictingPathsOk() (*[]string, bool)`

GetConflictingPathsOk returns a tuple with the ConflictingPaths field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetConflictingPaths

`func (o *V11NfsExportExtended) SetConflictingPaths(v []string)`

SetConflictingPaths sets ConflictingPaths field to given value.

### HasConflictingPaths

`func (o *V11NfsExportExtended) HasConflictingPaths() bool`

HasConflictingPaths returns a boolean if a field has been set.

### GetId

`func (o *V11NfsExportExtended) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V11NfsExportExtended) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V11NfsExportExtended) SetId(v int32)`

SetId sets Id field to given value.

### HasId

`func (o *V11NfsExportExtended) HasId() bool`

HasId returns a boolean if a field has been set.

### GetUnresolvedClients

`func (o *V11NfsExportExtended) GetUnresolvedClients() []string`

GetUnresolvedClients returns the UnresolvedClients field if non-nil, zero value otherwise.

### GetUnresolvedClientsOk

`func (o *V11NfsExportExtended) GetUnresolvedClientsOk() (*[]string, bool)`

GetUnresolvedClientsOk returns a tuple with the UnresolvedClients field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnresolvedClients

`func (o *V11NfsExportExtended) SetUnresolvedClients(v []string)`

SetUnresolvedClients sets UnresolvedClients field to given value.

### HasUnresolvedClients

`func (o *V11NfsExportExtended) HasUnresolvedClients() bool`

HasUnresolvedClients returns a boolean if a field has been set.

### GetZone

`func (o *V11NfsExportExtended) GetZone() string`

GetZone returns the Zone field if non-nil, zero value otherwise.

### GetZoneOk

`func (o *V11NfsExportExtended) GetZoneOk() (*string, bool)`

GetZoneOk returns a tuple with the Zone field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetZone

`func (o *V11NfsExportExtended) SetZone(v string)`

SetZone sets Zone field to given value.

### HasZone

`func (o *V11NfsExportExtended) HasZone() bool`

HasZone returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


