# V11AvscanFilter

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FilterEnabled** | Pointer to **bool** | Access zone enabled for AV scanning. | [optional] 
**Id** | Pointer to **string** | A unique identifier for the zone. | [optional] 
**OpenOnFail** | Pointer to **bool** | Allow access to files when scanning fails. | [optional] 
**ScanCloudpoolFiles** | Pointer to **bool** | Perform real-time scans of cloudpool files? | [optional] 
**ScanOnClose** | Pointer to **bool** | Perform real-time scans of files when the file handle is closed. | [optional] 
**ScanOnRead** | Pointer to **bool** | Perform real-time scans of files on first file read. | [optional] 
**ScanOnRename** | Pointer to **bool** | Perform real-time scan of file when the file is renamed. | [optional] 
**ScanProfile** | Pointer to **string** | Type of scan profile applicable to the zone. | [optional] 
**ZoneName** | Pointer to **string** | Access zone name containing filter settings. | [optional] 

## Methods

### NewV11AvscanFilter

`func NewV11AvscanFilter() *V11AvscanFilter`

NewV11AvscanFilter instantiates a new V11AvscanFilter object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11AvscanFilterWithDefaults

`func NewV11AvscanFilterWithDefaults() *V11AvscanFilter`

NewV11AvscanFilterWithDefaults instantiates a new V11AvscanFilter object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFilterEnabled

`func (o *V11AvscanFilter) GetFilterEnabled() bool`

GetFilterEnabled returns the FilterEnabled field if non-nil, zero value otherwise.

### GetFilterEnabledOk

`func (o *V11AvscanFilter) GetFilterEnabledOk() (*bool, bool)`

GetFilterEnabledOk returns a tuple with the FilterEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFilterEnabled

`func (o *V11AvscanFilter) SetFilterEnabled(v bool)`

SetFilterEnabled sets FilterEnabled field to given value.

### HasFilterEnabled

`func (o *V11AvscanFilter) HasFilterEnabled() bool`

HasFilterEnabled returns a boolean if a field has been set.

### GetId

`func (o *V11AvscanFilter) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V11AvscanFilter) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V11AvscanFilter) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V11AvscanFilter) HasId() bool`

HasId returns a boolean if a field has been set.

### GetOpenOnFail

`func (o *V11AvscanFilter) GetOpenOnFail() bool`

GetOpenOnFail returns the OpenOnFail field if non-nil, zero value otherwise.

### GetOpenOnFailOk

`func (o *V11AvscanFilter) GetOpenOnFailOk() (*bool, bool)`

GetOpenOnFailOk returns a tuple with the OpenOnFail field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOpenOnFail

`func (o *V11AvscanFilter) SetOpenOnFail(v bool)`

SetOpenOnFail sets OpenOnFail field to given value.

### HasOpenOnFail

`func (o *V11AvscanFilter) HasOpenOnFail() bool`

HasOpenOnFail returns a boolean if a field has been set.

### GetScanCloudpoolFiles

`func (o *V11AvscanFilter) GetScanCloudpoolFiles() bool`

GetScanCloudpoolFiles returns the ScanCloudpoolFiles field if non-nil, zero value otherwise.

### GetScanCloudpoolFilesOk

`func (o *V11AvscanFilter) GetScanCloudpoolFilesOk() (*bool, bool)`

GetScanCloudpoolFilesOk returns a tuple with the ScanCloudpoolFiles field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanCloudpoolFiles

`func (o *V11AvscanFilter) SetScanCloudpoolFiles(v bool)`

SetScanCloudpoolFiles sets ScanCloudpoolFiles field to given value.

### HasScanCloudpoolFiles

`func (o *V11AvscanFilter) HasScanCloudpoolFiles() bool`

HasScanCloudpoolFiles returns a boolean if a field has been set.

### GetScanOnClose

`func (o *V11AvscanFilter) GetScanOnClose() bool`

GetScanOnClose returns the ScanOnClose field if non-nil, zero value otherwise.

### GetScanOnCloseOk

`func (o *V11AvscanFilter) GetScanOnCloseOk() (*bool, bool)`

GetScanOnCloseOk returns a tuple with the ScanOnClose field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanOnClose

`func (o *V11AvscanFilter) SetScanOnClose(v bool)`

SetScanOnClose sets ScanOnClose field to given value.

### HasScanOnClose

`func (o *V11AvscanFilter) HasScanOnClose() bool`

HasScanOnClose returns a boolean if a field has been set.

### GetScanOnRead

`func (o *V11AvscanFilter) GetScanOnRead() bool`

GetScanOnRead returns the ScanOnRead field if non-nil, zero value otherwise.

### GetScanOnReadOk

`func (o *V11AvscanFilter) GetScanOnReadOk() (*bool, bool)`

GetScanOnReadOk returns a tuple with the ScanOnRead field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanOnRead

`func (o *V11AvscanFilter) SetScanOnRead(v bool)`

SetScanOnRead sets ScanOnRead field to given value.

### HasScanOnRead

`func (o *V11AvscanFilter) HasScanOnRead() bool`

HasScanOnRead returns a boolean if a field has been set.

### GetScanOnRename

`func (o *V11AvscanFilter) GetScanOnRename() bool`

GetScanOnRename returns the ScanOnRename field if non-nil, zero value otherwise.

### GetScanOnRenameOk

`func (o *V11AvscanFilter) GetScanOnRenameOk() (*bool, bool)`

GetScanOnRenameOk returns a tuple with the ScanOnRename field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanOnRename

`func (o *V11AvscanFilter) SetScanOnRename(v bool)`

SetScanOnRename sets ScanOnRename field to given value.

### HasScanOnRename

`func (o *V11AvscanFilter) HasScanOnRename() bool`

HasScanOnRename returns a boolean if a field has been set.

### GetScanProfile

`func (o *V11AvscanFilter) GetScanProfile() string`

GetScanProfile returns the ScanProfile field if non-nil, zero value otherwise.

### GetScanProfileOk

`func (o *V11AvscanFilter) GetScanProfileOk() (*string, bool)`

GetScanProfileOk returns a tuple with the ScanProfile field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanProfile

`func (o *V11AvscanFilter) SetScanProfile(v string)`

SetScanProfile sets ScanProfile field to given value.

### HasScanProfile

`func (o *V11AvscanFilter) HasScanProfile() bool`

HasScanProfile returns a boolean if a field has been set.

### GetZoneName

`func (o *V11AvscanFilter) GetZoneName() string`

GetZoneName returns the ZoneName field if non-nil, zero value otherwise.

### GetZoneNameOk

`func (o *V11AvscanFilter) GetZoneNameOk() (*string, bool)`

GetZoneNameOk returns a tuple with the ZoneName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetZoneName

`func (o *V11AvscanFilter) SetZoneName(v string)`

SetZoneName sets ZoneName field to given value.

### HasZoneName

`func (o *V11AvscanFilter) HasZoneName() bool`

HasZoneName returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


