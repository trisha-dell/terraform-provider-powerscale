# V12HdfsSettingsSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AmbariMetricsCollector** | Pointer to **string** | Ambari metrics collector. | [optional] 
**AmbariNamenode** | Pointer to **string** | NameNode of Ambari server. | [optional] 
**AmbariServer** | Pointer to **string** | Ambari server | [optional] 
**AuthenticationMode** | Pointer to **string** | Type of authentication for HDFS protocol. | [optional] 
**DataTransferCipher** | Pointer to **string** | Encryption algorithm to use for data transfer (if any). | [optional] 
**DefaultBlockSize** | Pointer to **int32** | Block size (size&#x3D;2**value) reported by HDFS server. | [optional] 
**DefaultChecksumType** | Pointer to **string** | Checksum type reported by HDFS server. | [optional] 
**HadoopVersion3OrLater** | Pointer to **bool** | Hadoop client version is 3 or later. | [optional] 
**HdfsAclEnabled** | Pointer to **bool** | Enable HDFS ACL on the zone | [optional] 
**OdpVersion** | Pointer to **string** | ODP stack repository version number. | [optional] 
**RootDirectory** | Pointer to **string** | HDFS root directory. | [optional] 
**Service** | Pointer to **bool** | Enable or disable the HDFS service. | [optional] 
**WebhdfsEnabled** | Pointer to **bool** | Enable or disable WebHDFS. | [optional] 

## Methods

### NewV12HdfsSettingsSettings

`func NewV12HdfsSettingsSettings() *V12HdfsSettingsSettings`

NewV12HdfsSettingsSettings instantiates a new V12HdfsSettingsSettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12HdfsSettingsSettingsWithDefaults

`func NewV12HdfsSettingsSettingsWithDefaults() *V12HdfsSettingsSettings`

NewV12HdfsSettingsSettingsWithDefaults instantiates a new V12HdfsSettingsSettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAmbariMetricsCollector

`func (o *V12HdfsSettingsSettings) GetAmbariMetricsCollector() string`

GetAmbariMetricsCollector returns the AmbariMetricsCollector field if non-nil, zero value otherwise.

### GetAmbariMetricsCollectorOk

`func (o *V12HdfsSettingsSettings) GetAmbariMetricsCollectorOk() (*string, bool)`

GetAmbariMetricsCollectorOk returns a tuple with the AmbariMetricsCollector field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAmbariMetricsCollector

`func (o *V12HdfsSettingsSettings) SetAmbariMetricsCollector(v string)`

SetAmbariMetricsCollector sets AmbariMetricsCollector field to given value.

### HasAmbariMetricsCollector

`func (o *V12HdfsSettingsSettings) HasAmbariMetricsCollector() bool`

HasAmbariMetricsCollector returns a boolean if a field has been set.

### GetAmbariNamenode

`func (o *V12HdfsSettingsSettings) GetAmbariNamenode() string`

GetAmbariNamenode returns the AmbariNamenode field if non-nil, zero value otherwise.

### GetAmbariNamenodeOk

`func (o *V12HdfsSettingsSettings) GetAmbariNamenodeOk() (*string, bool)`

GetAmbariNamenodeOk returns a tuple with the AmbariNamenode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAmbariNamenode

`func (o *V12HdfsSettingsSettings) SetAmbariNamenode(v string)`

SetAmbariNamenode sets AmbariNamenode field to given value.

### HasAmbariNamenode

`func (o *V12HdfsSettingsSettings) HasAmbariNamenode() bool`

HasAmbariNamenode returns a boolean if a field has been set.

### GetAmbariServer

`func (o *V12HdfsSettingsSettings) GetAmbariServer() string`

GetAmbariServer returns the AmbariServer field if non-nil, zero value otherwise.

### GetAmbariServerOk

`func (o *V12HdfsSettingsSettings) GetAmbariServerOk() (*string, bool)`

GetAmbariServerOk returns a tuple with the AmbariServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAmbariServer

`func (o *V12HdfsSettingsSettings) SetAmbariServer(v string)`

SetAmbariServer sets AmbariServer field to given value.

### HasAmbariServer

`func (o *V12HdfsSettingsSettings) HasAmbariServer() bool`

HasAmbariServer returns a boolean if a field has been set.

### GetAuthenticationMode

`func (o *V12HdfsSettingsSettings) GetAuthenticationMode() string`

GetAuthenticationMode returns the AuthenticationMode field if non-nil, zero value otherwise.

### GetAuthenticationModeOk

`func (o *V12HdfsSettingsSettings) GetAuthenticationModeOk() (*string, bool)`

GetAuthenticationModeOk returns a tuple with the AuthenticationMode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAuthenticationMode

`func (o *V12HdfsSettingsSettings) SetAuthenticationMode(v string)`

SetAuthenticationMode sets AuthenticationMode field to given value.

### HasAuthenticationMode

`func (o *V12HdfsSettingsSettings) HasAuthenticationMode() bool`

HasAuthenticationMode returns a boolean if a field has been set.

### GetDataTransferCipher

`func (o *V12HdfsSettingsSettings) GetDataTransferCipher() string`

GetDataTransferCipher returns the DataTransferCipher field if non-nil, zero value otherwise.

### GetDataTransferCipherOk

`func (o *V12HdfsSettingsSettings) GetDataTransferCipherOk() (*string, bool)`

GetDataTransferCipherOk returns a tuple with the DataTransferCipher field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataTransferCipher

`func (o *V12HdfsSettingsSettings) SetDataTransferCipher(v string)`

SetDataTransferCipher sets DataTransferCipher field to given value.

### HasDataTransferCipher

`func (o *V12HdfsSettingsSettings) HasDataTransferCipher() bool`

HasDataTransferCipher returns a boolean if a field has been set.

### GetDefaultBlockSize

`func (o *V12HdfsSettingsSettings) GetDefaultBlockSize() int32`

GetDefaultBlockSize returns the DefaultBlockSize field if non-nil, zero value otherwise.

### GetDefaultBlockSizeOk

`func (o *V12HdfsSettingsSettings) GetDefaultBlockSizeOk() (*int32, bool)`

GetDefaultBlockSizeOk returns a tuple with the DefaultBlockSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDefaultBlockSize

`func (o *V12HdfsSettingsSettings) SetDefaultBlockSize(v int32)`

SetDefaultBlockSize sets DefaultBlockSize field to given value.

### HasDefaultBlockSize

`func (o *V12HdfsSettingsSettings) HasDefaultBlockSize() bool`

HasDefaultBlockSize returns a boolean if a field has been set.

### GetDefaultChecksumType

`func (o *V12HdfsSettingsSettings) GetDefaultChecksumType() string`

GetDefaultChecksumType returns the DefaultChecksumType field if non-nil, zero value otherwise.

### GetDefaultChecksumTypeOk

`func (o *V12HdfsSettingsSettings) GetDefaultChecksumTypeOk() (*string, bool)`

GetDefaultChecksumTypeOk returns a tuple with the DefaultChecksumType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDefaultChecksumType

`func (o *V12HdfsSettingsSettings) SetDefaultChecksumType(v string)`

SetDefaultChecksumType sets DefaultChecksumType field to given value.

### HasDefaultChecksumType

`func (o *V12HdfsSettingsSettings) HasDefaultChecksumType() bool`

HasDefaultChecksumType returns a boolean if a field has been set.

### GetHadoopVersion3OrLater

`func (o *V12HdfsSettingsSettings) GetHadoopVersion3OrLater() bool`

GetHadoopVersion3OrLater returns the HadoopVersion3OrLater field if non-nil, zero value otherwise.

### GetHadoopVersion3OrLaterOk

`func (o *V12HdfsSettingsSettings) GetHadoopVersion3OrLaterOk() (*bool, bool)`

GetHadoopVersion3OrLaterOk returns a tuple with the HadoopVersion3OrLater field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHadoopVersion3OrLater

`func (o *V12HdfsSettingsSettings) SetHadoopVersion3OrLater(v bool)`

SetHadoopVersion3OrLater sets HadoopVersion3OrLater field to given value.

### HasHadoopVersion3OrLater

`func (o *V12HdfsSettingsSettings) HasHadoopVersion3OrLater() bool`

HasHadoopVersion3OrLater returns a boolean if a field has been set.

### GetHdfsAclEnabled

`func (o *V12HdfsSettingsSettings) GetHdfsAclEnabled() bool`

GetHdfsAclEnabled returns the HdfsAclEnabled field if non-nil, zero value otherwise.

### GetHdfsAclEnabledOk

`func (o *V12HdfsSettingsSettings) GetHdfsAclEnabledOk() (*bool, bool)`

GetHdfsAclEnabledOk returns a tuple with the HdfsAclEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHdfsAclEnabled

`func (o *V12HdfsSettingsSettings) SetHdfsAclEnabled(v bool)`

SetHdfsAclEnabled sets HdfsAclEnabled field to given value.

### HasHdfsAclEnabled

`func (o *V12HdfsSettingsSettings) HasHdfsAclEnabled() bool`

HasHdfsAclEnabled returns a boolean if a field has been set.

### GetOdpVersion

`func (o *V12HdfsSettingsSettings) GetOdpVersion() string`

GetOdpVersion returns the OdpVersion field if non-nil, zero value otherwise.

### GetOdpVersionOk

`func (o *V12HdfsSettingsSettings) GetOdpVersionOk() (*string, bool)`

GetOdpVersionOk returns a tuple with the OdpVersion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOdpVersion

`func (o *V12HdfsSettingsSettings) SetOdpVersion(v string)`

SetOdpVersion sets OdpVersion field to given value.

### HasOdpVersion

`func (o *V12HdfsSettingsSettings) HasOdpVersion() bool`

HasOdpVersion returns a boolean if a field has been set.

### GetRootDirectory

`func (o *V12HdfsSettingsSettings) GetRootDirectory() string`

GetRootDirectory returns the RootDirectory field if non-nil, zero value otherwise.

### GetRootDirectoryOk

`func (o *V12HdfsSettingsSettings) GetRootDirectoryOk() (*string, bool)`

GetRootDirectoryOk returns a tuple with the RootDirectory field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRootDirectory

`func (o *V12HdfsSettingsSettings) SetRootDirectory(v string)`

SetRootDirectory sets RootDirectory field to given value.

### HasRootDirectory

`func (o *V12HdfsSettingsSettings) HasRootDirectory() bool`

HasRootDirectory returns a boolean if a field has been set.

### GetService

`func (o *V12HdfsSettingsSettings) GetService() bool`

GetService returns the Service field if non-nil, zero value otherwise.

### GetServiceOk

`func (o *V12HdfsSettingsSettings) GetServiceOk() (*bool, bool)`

GetServiceOk returns a tuple with the Service field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetService

`func (o *V12HdfsSettingsSettings) SetService(v bool)`

SetService sets Service field to given value.

### HasService

`func (o *V12HdfsSettingsSettings) HasService() bool`

HasService returns a boolean if a field has been set.

### GetWebhdfsEnabled

`func (o *V12HdfsSettingsSettings) GetWebhdfsEnabled() bool`

GetWebhdfsEnabled returns the WebhdfsEnabled field if non-nil, zero value otherwise.

### GetWebhdfsEnabledOk

`func (o *V12HdfsSettingsSettings) GetWebhdfsEnabledOk() (*bool, bool)`

GetWebhdfsEnabledOk returns a tuple with the WebhdfsEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWebhdfsEnabled

`func (o *V12HdfsSettingsSettings) SetWebhdfsEnabled(v bool)`

SetWebhdfsEnabled sets WebhdfsEnabled field to given value.

### HasWebhdfsEnabled

`func (o *V12HdfsSettingsSettings) HasWebhdfsEnabled() bool`

HasWebhdfsEnabled returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


