# \SyncReportsApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetSyncReportsv15ReportSubreports**](SyncReportsApi.md#GetSyncReportsv15ReportSubreports) | **Get** /platform/15/sync/reports/{Rid}/subreports | 
[**GetSyncReportsv1ReportSubreports**](SyncReportsApi.md#GetSyncReportsv1ReportSubreports) | **Get** /platform/1/sync/reports/{Rid}/subreports | 
[**GetSyncReportsv4ReportSubreports**](SyncReportsApi.md#GetSyncReportsv4ReportSubreports) | **Get** /platform/4/sync/reports/{Rid}/subreports | 
[**GetSyncReportsv7ReportSubreports**](SyncReportsApi.md#GetSyncReportsv7ReportSubreports) | **Get** /platform/7/sync/reports/{Rid}/subreports | 



## GetSyncReportsv15ReportSubreports

> V15ReportSubreports GetSyncReportsv15ReportSubreports(ctx, rid).Sort(sort).Resume(resume).NewerThan(newerThan).State(state).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    rid := "rid_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    newerThan := int32(56) // int32 | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. (optional)
    state := "state_example" // string | Filter the returned reports to include only those whose jobs are in this state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncReportsApi.GetSyncReportsv15ReportSubreports(context.Background(), rid).Sort(sort).Resume(resume).NewerThan(newerThan).State(state).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncReportsApi.GetSyncReportsv15ReportSubreports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncReportsv15ReportSubreports`: V15ReportSubreports
    fmt.Fprintf(os.Stdout, "Response from `SyncReportsApi.GetSyncReportsv15ReportSubreports`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**rid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncReportsv15ReportSubreportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **newerThan** | **int32** | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. | 
 **state** | **string** | Filter the returned reports to include only those whose jobs are in this state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V15ReportSubreports**](V15ReportSubreports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncReportsv1ReportSubreports

> V1ReportSubreports GetSyncReportsv1ReportSubreports(ctx, rid).Sort(sort).Resume(resume).NewerThan(newerThan).State(state).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    rid := "rid_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    newerThan := int32(56) // int32 | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. (optional)
    state := "state_example" // string | Filter the returned reports to include only those whose jobs are in this state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncReportsApi.GetSyncReportsv1ReportSubreports(context.Background(), rid).Sort(sort).Resume(resume).NewerThan(newerThan).State(state).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncReportsApi.GetSyncReportsv1ReportSubreports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncReportsv1ReportSubreports`: V1ReportSubreports
    fmt.Fprintf(os.Stdout, "Response from `SyncReportsApi.GetSyncReportsv1ReportSubreports`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**rid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncReportsv1ReportSubreportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **newerThan** | **int32** | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. | 
 **state** | **string** | Filter the returned reports to include only those whose jobs are in this state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V1ReportSubreports**](V1ReportSubreports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncReportsv4ReportSubreports

> V4ReportSubreports GetSyncReportsv4ReportSubreports(ctx, rid).Sort(sort).Resume(resume).NewerThan(newerThan).State(state).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    rid := "rid_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    newerThan := int32(56) // int32 | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. (optional)
    state := "state_example" // string | Filter the returned reports to include only those whose jobs are in this state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncReportsApi.GetSyncReportsv4ReportSubreports(context.Background(), rid).Sort(sort).Resume(resume).NewerThan(newerThan).State(state).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncReportsApi.GetSyncReportsv4ReportSubreports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncReportsv4ReportSubreports`: V4ReportSubreports
    fmt.Fprintf(os.Stdout, "Response from `SyncReportsApi.GetSyncReportsv4ReportSubreports`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**rid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncReportsv4ReportSubreportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **newerThan** | **int32** | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. | 
 **state** | **string** | Filter the returned reports to include only those whose jobs are in this state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V4ReportSubreports**](V4ReportSubreports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncReportsv7ReportSubreports

> V7ReportSubreports GetSyncReportsv7ReportSubreports(ctx, rid).Sort(sort).Resume(resume).NewerThan(newerThan).State(state).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    rid := "rid_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    newerThan := int32(56) // int32 | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. (optional)
    state := "state_example" // string | Filter the returned reports to include only those whose jobs are in this state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncReportsApi.GetSyncReportsv7ReportSubreports(context.Background(), rid).Sort(sort).Resume(resume).NewerThan(newerThan).State(state).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncReportsApi.GetSyncReportsv7ReportSubreports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncReportsv7ReportSubreports`: V7ReportSubreports
    fmt.Fprintf(os.Stdout, "Response from `SyncReportsApi.GetSyncReportsv7ReportSubreports`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**rid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncReportsv7ReportSubreportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **newerThan** | **int32** | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. | 
 **state** | **string** | Filter the returned reports to include only those whose jobs are in this state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V7ReportSubreports**](V7ReportSubreports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

