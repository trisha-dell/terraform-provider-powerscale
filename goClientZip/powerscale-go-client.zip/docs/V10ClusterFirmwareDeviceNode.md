# V10ClusterFirmwareDeviceNode

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Devices** | Pointer to [**[]V10ClusterFirmwareDeviceNodeDevice**](V10ClusterFirmwareDeviceNodeDevice.md) | List of the firmware status for hardware components on the node. | [optional] 
**Error** | Pointer to **string** | Error message, if the HTTP status returned from this node was not 200. | [optional] 
**Id** | Pointer to **int32** | Node ID (Device Number) of a node. | [optional] 
**Lnn** | Pointer to **int32** | Logical Node Number (LNN) of a node. | [optional] 
**NodeUnavailable** | Pointer to **bool** | Node is unavailable. | [optional] 
**Package** | Pointer to [**[]V10ClusterFirmwareDeviceNodePackageItem**](V10ClusterFirmwareDeviceNodePackageItem.md) | List of the firmware binary information for the installed firmware package. | [optional] 
**Status** | Pointer to **int32** | Status of the HTTP response from this node if not 200.  If 200, this field does not appear. | [optional] 

## Methods

### NewV10ClusterFirmwareDeviceNode

`func NewV10ClusterFirmwareDeviceNode() *V10ClusterFirmwareDeviceNode`

NewV10ClusterFirmwareDeviceNode instantiates a new V10ClusterFirmwareDeviceNode object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterFirmwareDeviceNodeWithDefaults

`func NewV10ClusterFirmwareDeviceNodeWithDefaults() *V10ClusterFirmwareDeviceNode`

NewV10ClusterFirmwareDeviceNodeWithDefaults instantiates a new V10ClusterFirmwareDeviceNode object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDevices

`func (o *V10ClusterFirmwareDeviceNode) GetDevices() []V10ClusterFirmwareDeviceNodeDevice`

GetDevices returns the Devices field if non-nil, zero value otherwise.

### GetDevicesOk

`func (o *V10ClusterFirmwareDeviceNode) GetDevicesOk() (*[]V10ClusterFirmwareDeviceNodeDevice, bool)`

GetDevicesOk returns a tuple with the Devices field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDevices

`func (o *V10ClusterFirmwareDeviceNode) SetDevices(v []V10ClusterFirmwareDeviceNodeDevice)`

SetDevices sets Devices field to given value.

### HasDevices

`func (o *V10ClusterFirmwareDeviceNode) HasDevices() bool`

HasDevices returns a boolean if a field has been set.

### GetError

`func (o *V10ClusterFirmwareDeviceNode) GetError() string`

GetError returns the Error field if non-nil, zero value otherwise.

### GetErrorOk

`func (o *V10ClusterFirmwareDeviceNode) GetErrorOk() (*string, bool)`

GetErrorOk returns a tuple with the Error field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetError

`func (o *V10ClusterFirmwareDeviceNode) SetError(v string)`

SetError sets Error field to given value.

### HasError

`func (o *V10ClusterFirmwareDeviceNode) HasError() bool`

HasError returns a boolean if a field has been set.

### GetId

`func (o *V10ClusterFirmwareDeviceNode) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V10ClusterFirmwareDeviceNode) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V10ClusterFirmwareDeviceNode) SetId(v int32)`

SetId sets Id field to given value.

### HasId

`func (o *V10ClusterFirmwareDeviceNode) HasId() bool`

HasId returns a boolean if a field has been set.

### GetLnn

`func (o *V10ClusterFirmwareDeviceNode) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V10ClusterFirmwareDeviceNode) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V10ClusterFirmwareDeviceNode) SetLnn(v int32)`

SetLnn sets Lnn field to given value.

### HasLnn

`func (o *V10ClusterFirmwareDeviceNode) HasLnn() bool`

HasLnn returns a boolean if a field has been set.

### GetNodeUnavailable

`func (o *V10ClusterFirmwareDeviceNode) GetNodeUnavailable() bool`

GetNodeUnavailable returns the NodeUnavailable field if non-nil, zero value otherwise.

### GetNodeUnavailableOk

`func (o *V10ClusterFirmwareDeviceNode) GetNodeUnavailableOk() (*bool, bool)`

GetNodeUnavailableOk returns a tuple with the NodeUnavailable field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodeUnavailable

`func (o *V10ClusterFirmwareDeviceNode) SetNodeUnavailable(v bool)`

SetNodeUnavailable sets NodeUnavailable field to given value.

### HasNodeUnavailable

`func (o *V10ClusterFirmwareDeviceNode) HasNodeUnavailable() bool`

HasNodeUnavailable returns a boolean if a field has been set.

### GetPackage

`func (o *V10ClusterFirmwareDeviceNode) GetPackage() []V10ClusterFirmwareDeviceNodePackageItem`

GetPackage returns the Package field if non-nil, zero value otherwise.

### GetPackageOk

`func (o *V10ClusterFirmwareDeviceNode) GetPackageOk() (*[]V10ClusterFirmwareDeviceNodePackageItem, bool)`

GetPackageOk returns a tuple with the Package field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPackage

`func (o *V10ClusterFirmwareDeviceNode) SetPackage(v []V10ClusterFirmwareDeviceNodePackageItem)`

SetPackage sets Package field to given value.

### HasPackage

`func (o *V10ClusterFirmwareDeviceNode) HasPackage() bool`

HasPackage returns a boolean if a field has been set.

### GetStatus

`func (o *V10ClusterFirmwareDeviceNode) GetStatus() int32`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V10ClusterFirmwareDeviceNode) GetStatusOk() (*int32, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V10ClusterFirmwareDeviceNode) SetStatus(v int32)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V10ClusterFirmwareDeviceNode) HasStatus() bool`

HasStatus returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


