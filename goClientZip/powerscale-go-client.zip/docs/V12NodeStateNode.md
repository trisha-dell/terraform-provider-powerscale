# V12NodeStateNode

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Error** | Pointer to **string** | Error message, if the HTTP status returned from this node was not 200. | [optional] 
**Id** | Pointer to **int32** | Node ID (Device Number) of a node. | [optional] 
**Lnn** | Pointer to **int32** | Logical Node Number (LNN) of a node. | [optional] 
**Readonly** | Pointer to [**V10ClusterNodeStateReadonly**](V10ClusterNodeStateReadonly.md) |  | [optional] 
**Servicelight** | Pointer to [**V12ClusterNodeStateServicelight**](V12ClusterNodeStateServicelight.md) |  | [optional] 
**Smartfail** | Pointer to [**V10ClusterNodeStateSmartfail**](V10ClusterNodeStateSmartfail.md) |  | [optional] 
**Status** | Pointer to **int32** | Status of the HTTP response from this node if not 200.  If 200, this field does not appear. | [optional] 

## Methods

### NewV12NodeStateNode

`func NewV12NodeStateNode() *V12NodeStateNode`

NewV12NodeStateNode instantiates a new V12NodeStateNode object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12NodeStateNodeWithDefaults

`func NewV12NodeStateNodeWithDefaults() *V12NodeStateNode`

NewV12NodeStateNodeWithDefaults instantiates a new V12NodeStateNode object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetError

`func (o *V12NodeStateNode) GetError() string`

GetError returns the Error field if non-nil, zero value otherwise.

### GetErrorOk

`func (o *V12NodeStateNode) GetErrorOk() (*string, bool)`

GetErrorOk returns a tuple with the Error field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetError

`func (o *V12NodeStateNode) SetError(v string)`

SetError sets Error field to given value.

### HasError

`func (o *V12NodeStateNode) HasError() bool`

HasError returns a boolean if a field has been set.

### GetId

`func (o *V12NodeStateNode) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12NodeStateNode) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12NodeStateNode) SetId(v int32)`

SetId sets Id field to given value.

### HasId

`func (o *V12NodeStateNode) HasId() bool`

HasId returns a boolean if a field has been set.

### GetLnn

`func (o *V12NodeStateNode) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V12NodeStateNode) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V12NodeStateNode) SetLnn(v int32)`

SetLnn sets Lnn field to given value.

### HasLnn

`func (o *V12NodeStateNode) HasLnn() bool`

HasLnn returns a boolean if a field has been set.

### GetReadonly

`func (o *V12NodeStateNode) GetReadonly() V10ClusterNodeStateReadonly`

GetReadonly returns the Readonly field if non-nil, zero value otherwise.

### GetReadonlyOk

`func (o *V12NodeStateNode) GetReadonlyOk() (*V10ClusterNodeStateReadonly, bool)`

GetReadonlyOk returns a tuple with the Readonly field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadonly

`func (o *V12NodeStateNode) SetReadonly(v V10ClusterNodeStateReadonly)`

SetReadonly sets Readonly field to given value.

### HasReadonly

`func (o *V12NodeStateNode) HasReadonly() bool`

HasReadonly returns a boolean if a field has been set.

### GetServicelight

`func (o *V12NodeStateNode) GetServicelight() V12ClusterNodeStateServicelight`

GetServicelight returns the Servicelight field if non-nil, zero value otherwise.

### GetServicelightOk

`func (o *V12NodeStateNode) GetServicelightOk() (*V12ClusterNodeStateServicelight, bool)`

GetServicelightOk returns a tuple with the Servicelight field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServicelight

`func (o *V12NodeStateNode) SetServicelight(v V12ClusterNodeStateServicelight)`

SetServicelight sets Servicelight field to given value.

### HasServicelight

`func (o *V12NodeStateNode) HasServicelight() bool`

HasServicelight returns a boolean if a field has been set.

### GetSmartfail

`func (o *V12NodeStateNode) GetSmartfail() V10ClusterNodeStateSmartfail`

GetSmartfail returns the Smartfail field if non-nil, zero value otherwise.

### GetSmartfailOk

`func (o *V12NodeStateNode) GetSmartfailOk() (*V10ClusterNodeStateSmartfail, bool)`

GetSmartfailOk returns a tuple with the Smartfail field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmartfail

`func (o *V12NodeStateNode) SetSmartfail(v V10ClusterNodeStateSmartfail)`

SetSmartfail sets Smartfail field to given value.

### HasSmartfail

`func (o *V12NodeStateNode) HasSmartfail() bool`

HasSmartfail returns a boolean if a field has been set.

### GetStatus

`func (o *V12NodeStateNode) GetStatus() int32`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V12NodeStateNode) GetStatusOk() (*int32, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V12NodeStateNode) SetStatus(v int32)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V12NodeStateNode) HasStatus() bool`

HasStatus returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


