# V11AntivirusScanItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**File** | **string** | The full path of the file to scan. | 
**IgnorePreviousScanStatus** | Pointer to **bool** | Forces the scan to run regardless of whether the files were recently scanned. The default value is true. | [optional] 
**Policy** | Pointer to **string** | The ID of the policy to use for the scan. By default, the scan will use the MANUAL policy. | [optional] 
**ReportId** | Pointer to **string** | The ID for the report for this scan. A report ID will be generated if one is not provided. | [optional] 

## Methods

### NewV11AntivirusScanItem

`func NewV11AntivirusScanItem(file string, ) *V11AntivirusScanItem`

NewV11AntivirusScanItem instantiates a new V11AntivirusScanItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11AntivirusScanItemWithDefaults

`func NewV11AntivirusScanItemWithDefaults() *V11AntivirusScanItem`

NewV11AntivirusScanItemWithDefaults instantiates a new V11AntivirusScanItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFile

`func (o *V11AntivirusScanItem) GetFile() string`

GetFile returns the File field if non-nil, zero value otherwise.

### GetFileOk

`func (o *V11AntivirusScanItem) GetFileOk() (*string, bool)`

GetFileOk returns a tuple with the File field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFile

`func (o *V11AntivirusScanItem) SetFile(v string)`

SetFile sets File field to given value.


### GetIgnorePreviousScanStatus

`func (o *V11AntivirusScanItem) GetIgnorePreviousScanStatus() bool`

GetIgnorePreviousScanStatus returns the IgnorePreviousScanStatus field if non-nil, zero value otherwise.

### GetIgnorePreviousScanStatusOk

`func (o *V11AntivirusScanItem) GetIgnorePreviousScanStatusOk() (*bool, bool)`

GetIgnorePreviousScanStatusOk returns a tuple with the IgnorePreviousScanStatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIgnorePreviousScanStatus

`func (o *V11AntivirusScanItem) SetIgnorePreviousScanStatus(v bool)`

SetIgnorePreviousScanStatus sets IgnorePreviousScanStatus field to given value.

### HasIgnorePreviousScanStatus

`func (o *V11AntivirusScanItem) HasIgnorePreviousScanStatus() bool`

HasIgnorePreviousScanStatus returns a boolean if a field has been set.

### GetPolicy

`func (o *V11AntivirusScanItem) GetPolicy() string`

GetPolicy returns the Policy field if non-nil, zero value otherwise.

### GetPolicyOk

`func (o *V11AntivirusScanItem) GetPolicyOk() (*string, bool)`

GetPolicyOk returns a tuple with the Policy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPolicy

`func (o *V11AntivirusScanItem) SetPolicy(v string)`

SetPolicy sets Policy field to given value.

### HasPolicy

`func (o *V11AntivirusScanItem) HasPolicy() bool`

HasPolicy returns a boolean if a field has been set.

### GetReportId

`func (o *V11AntivirusScanItem) GetReportId() string`

GetReportId returns the ReportId field if non-nil, zero value otherwise.

### GetReportIdOk

`func (o *V11AntivirusScanItem) GetReportIdOk() (*string, bool)`

GetReportIdOk returns a tuple with the ReportId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReportId

`func (o *V11AntivirusScanItem) SetReportId(v string)`

SetReportId sets ReportId field to given value.

### HasReportId

`func (o *V11AntivirusScanItem) HasReportId() bool`

HasReportId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


