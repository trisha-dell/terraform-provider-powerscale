# V11ClusterPatchPatch

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Location** | Pointer to **string** | The path location of the patch file. | [optional] 
**Patch** | **string** | The id or filename of the patch to install. | 
**ProcessType** | Pointer to **string** | Process type can be &#39;simultaneous&#39;, &#39;rolling&#39;, or &#39;parallel&#39; | [optional] 

## Methods

### NewV11ClusterPatchPatch

`func NewV11ClusterPatchPatch(patch string, ) *V11ClusterPatchPatch`

NewV11ClusterPatchPatch instantiates a new V11ClusterPatchPatch object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11ClusterPatchPatchWithDefaults

`func NewV11ClusterPatchPatchWithDefaults() *V11ClusterPatchPatch`

NewV11ClusterPatchPatchWithDefaults instantiates a new V11ClusterPatchPatch object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetLocation

`func (o *V11ClusterPatchPatch) GetLocation() string`

GetLocation returns the Location field if non-nil, zero value otherwise.

### GetLocationOk

`func (o *V11ClusterPatchPatch) GetLocationOk() (*string, bool)`

GetLocationOk returns a tuple with the Location field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLocation

`func (o *V11ClusterPatchPatch) SetLocation(v string)`

SetLocation sets Location field to given value.

### HasLocation

`func (o *V11ClusterPatchPatch) HasLocation() bool`

HasLocation returns a boolean if a field has been set.

### GetPatch

`func (o *V11ClusterPatchPatch) GetPatch() string`

GetPatch returns the Patch field if non-nil, zero value otherwise.

### GetPatchOk

`func (o *V11ClusterPatchPatch) GetPatchOk() (*string, bool)`

GetPatchOk returns a tuple with the Patch field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPatch

`func (o *V11ClusterPatchPatch) SetPatch(v string)`

SetPatch sets Patch field to given value.


### GetProcessType

`func (o *V11ClusterPatchPatch) GetProcessType() string`

GetProcessType returns the ProcessType field if non-nil, zero value otherwise.

### GetProcessTypeOk

`func (o *V11ClusterPatchPatch) GetProcessTypeOk() (*string, bool)`

GetProcessTypeOk returns a tuple with the ProcessType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProcessType

`func (o *V11ClusterPatchPatch) SetProcessType(v string)`

SetProcessType sets ProcessType field to given value.

### HasProcessType

`func (o *V11ClusterPatchPatch) HasProcessType() bool`

HasProcessType returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


