# Createv7WormDomainResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AutocommitOffset** | **int32** | Specifies the autocommit time period for the domain in seconds.  After a file is in the domain without being modified for the specified time period, the file is automatically committed. If this parameter is set to null, there is no autocommit time, and files must be committed manually. | 
**DefaultRetention** | **string** | Specifies the default amount of time, in seconds, that a file in this domain will be protected for. The default retention period is applied if no retention date is manually set on the file. This parameter can also be set to &#39;forever&#39;, &#39;use_min&#39; (which applies the &#39;min_retention&#39; option), or &#39;use_max&#39; (which applies the &#39;max_retention&#39; option). | 
**Exclusions** | [**[]V7WormDomainExclusion**](V7WormDomainExclusion.md) | A list of directories excluded from WORM protection. In a POST/PUT request this collection specifies the directories that the user wishes to create SmartLock exclusion directories on underneath this SmartLock directory. In a GET request this collection specifies all of the exclusion directories that exist underneath this SmartLock directory. | 
**Id** | **int32** | Specifies the system-assigned ID for the protection domain. | 
**Incomplete** | **bool** | True if OneFS is still in the process of creating this domain and is unable to prevent files from being modified or deleted. If false, indicates that the domain is fully created and is able to prevent files from being modified or deleted. | 
**Lin** | **int32** | Specifies the logical inode number (LIN) for the root of this domain. | 
**MaxModifies** | **int32** | Specifies the maximum amount of time, in seconds, that a file in this domain will be protected. This setting will override the retention period of any file committed with a longer retention period. If this parameter is set to null, an infinite length retention period is set. | 
**MaxRetention** | **string** | Specifies the maximum amount of time, in seconds, that a file in this domain will be protected. This setting will override the retention period of any file committed with a longer retention period. If this parameter is set to null, an infinite length retention period is set. | 
**MinRetention** | **string** | Specifies the minimum amount of time, in seconds, that a file in this domain will be protected. This setting will override the retention period of any file committed with a shorter retention period. If this parameter is set to null, this minimum value is not enforced. This parameter can also be set to &#39;forever&#39;. | 
**OverrideDate** | **int32** | Specifies the override retention date for the domain. If this date is later than the retention date for any committed file, the file will remain protected until the override retention date. | 
**Path** | **string** | Specifies the root path of this domain. Files in this directory and all sub-directories will be protected. | 
**PrivilegedDelete** | **string** | When this value is set to &#39;on&#39;, files in this domain can be deleted through the privileged delete feature. If this value is set to &#39;disabled&#39;, privileged file deletes are permanently disabled and cannot be turned on again. | 
**SetPendingDelete** | **bool** | If true, the domain is irreversibly marked for deletion. This is used for compliance domains and allows compliance store directories to be deleted, while disallowing the creation or committing of new/existing files. | 
**TotalModifies** | **int32** | Specifies the number of times this domain has been modified and the number of times the attributes for the domain have changed. A SmartLock domain can be modified a fixed number of times as defined by the &#39;max_modifies&#39; parameter. | 
**Type** | **string** | Specifies whether the domain is an enterprise domain or a compliance domain. Compliance domains can not be created on enterprise clusters. Enterprise and compliance domains can be created on compliance clusters. | 

## Methods

### NewCreatev7WormDomainResponse

`func NewCreatev7WormDomainResponse(autocommitOffset int32, defaultRetention string, exclusions []V7WormDomainExclusion, id int32, incomplete bool, lin int32, maxModifies int32, maxRetention string, minRetention string, overrideDate int32, path string, privilegedDelete string, setPendingDelete bool, totalModifies int32, type_ string, ) *Createv7WormDomainResponse`

NewCreatev7WormDomainResponse instantiates a new Createv7WormDomainResponse object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev7WormDomainResponseWithDefaults

`func NewCreatev7WormDomainResponseWithDefaults() *Createv7WormDomainResponse`

NewCreatev7WormDomainResponseWithDefaults instantiates a new Createv7WormDomainResponse object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAutocommitOffset

`func (o *Createv7WormDomainResponse) GetAutocommitOffset() int32`

GetAutocommitOffset returns the AutocommitOffset field if non-nil, zero value otherwise.

### GetAutocommitOffsetOk

`func (o *Createv7WormDomainResponse) GetAutocommitOffsetOk() (*int32, bool)`

GetAutocommitOffsetOk returns a tuple with the AutocommitOffset field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAutocommitOffset

`func (o *Createv7WormDomainResponse) SetAutocommitOffset(v int32)`

SetAutocommitOffset sets AutocommitOffset field to given value.


### GetDefaultRetention

`func (o *Createv7WormDomainResponse) GetDefaultRetention() string`

GetDefaultRetention returns the DefaultRetention field if non-nil, zero value otherwise.

### GetDefaultRetentionOk

`func (o *Createv7WormDomainResponse) GetDefaultRetentionOk() (*string, bool)`

GetDefaultRetentionOk returns a tuple with the DefaultRetention field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDefaultRetention

`func (o *Createv7WormDomainResponse) SetDefaultRetention(v string)`

SetDefaultRetention sets DefaultRetention field to given value.


### GetExclusions

`func (o *Createv7WormDomainResponse) GetExclusions() []V7WormDomainExclusion`

GetExclusions returns the Exclusions field if non-nil, zero value otherwise.

### GetExclusionsOk

`func (o *Createv7WormDomainResponse) GetExclusionsOk() (*[]V7WormDomainExclusion, bool)`

GetExclusionsOk returns a tuple with the Exclusions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExclusions

`func (o *Createv7WormDomainResponse) SetExclusions(v []V7WormDomainExclusion)`

SetExclusions sets Exclusions field to given value.


### GetId

`func (o *Createv7WormDomainResponse) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *Createv7WormDomainResponse) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *Createv7WormDomainResponse) SetId(v int32)`

SetId sets Id field to given value.


### GetIncomplete

`func (o *Createv7WormDomainResponse) GetIncomplete() bool`

GetIncomplete returns the Incomplete field if non-nil, zero value otherwise.

### GetIncompleteOk

`func (o *Createv7WormDomainResponse) GetIncompleteOk() (*bool, bool)`

GetIncompleteOk returns a tuple with the Incomplete field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIncomplete

`func (o *Createv7WormDomainResponse) SetIncomplete(v bool)`

SetIncomplete sets Incomplete field to given value.


### GetLin

`func (o *Createv7WormDomainResponse) GetLin() int32`

GetLin returns the Lin field if non-nil, zero value otherwise.

### GetLinOk

`func (o *Createv7WormDomainResponse) GetLinOk() (*int32, bool)`

GetLinOk returns a tuple with the Lin field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLin

`func (o *Createv7WormDomainResponse) SetLin(v int32)`

SetLin sets Lin field to given value.


### GetMaxModifies

`func (o *Createv7WormDomainResponse) GetMaxModifies() int32`

GetMaxModifies returns the MaxModifies field if non-nil, zero value otherwise.

### GetMaxModifiesOk

`func (o *Createv7WormDomainResponse) GetMaxModifiesOk() (*int32, bool)`

GetMaxModifiesOk returns a tuple with the MaxModifies field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaxModifies

`func (o *Createv7WormDomainResponse) SetMaxModifies(v int32)`

SetMaxModifies sets MaxModifies field to given value.


### GetMaxRetention

`func (o *Createv7WormDomainResponse) GetMaxRetention() string`

GetMaxRetention returns the MaxRetention field if non-nil, zero value otherwise.

### GetMaxRetentionOk

`func (o *Createv7WormDomainResponse) GetMaxRetentionOk() (*string, bool)`

GetMaxRetentionOk returns a tuple with the MaxRetention field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaxRetention

`func (o *Createv7WormDomainResponse) SetMaxRetention(v string)`

SetMaxRetention sets MaxRetention field to given value.


### GetMinRetention

`func (o *Createv7WormDomainResponse) GetMinRetention() string`

GetMinRetention returns the MinRetention field if non-nil, zero value otherwise.

### GetMinRetentionOk

`func (o *Createv7WormDomainResponse) GetMinRetentionOk() (*string, bool)`

GetMinRetentionOk returns a tuple with the MinRetention field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMinRetention

`func (o *Createv7WormDomainResponse) SetMinRetention(v string)`

SetMinRetention sets MinRetention field to given value.


### GetOverrideDate

`func (o *Createv7WormDomainResponse) GetOverrideDate() int32`

GetOverrideDate returns the OverrideDate field if non-nil, zero value otherwise.

### GetOverrideDateOk

`func (o *Createv7WormDomainResponse) GetOverrideDateOk() (*int32, bool)`

GetOverrideDateOk returns a tuple with the OverrideDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOverrideDate

`func (o *Createv7WormDomainResponse) SetOverrideDate(v int32)`

SetOverrideDate sets OverrideDate field to given value.


### GetPath

`func (o *Createv7WormDomainResponse) GetPath() string`

GetPath returns the Path field if non-nil, zero value otherwise.

### GetPathOk

`func (o *Createv7WormDomainResponse) GetPathOk() (*string, bool)`

GetPathOk returns a tuple with the Path field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPath

`func (o *Createv7WormDomainResponse) SetPath(v string)`

SetPath sets Path field to given value.


### GetPrivilegedDelete

`func (o *Createv7WormDomainResponse) GetPrivilegedDelete() string`

GetPrivilegedDelete returns the PrivilegedDelete field if non-nil, zero value otherwise.

### GetPrivilegedDeleteOk

`func (o *Createv7WormDomainResponse) GetPrivilegedDeleteOk() (*string, bool)`

GetPrivilegedDeleteOk returns a tuple with the PrivilegedDelete field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrivilegedDelete

`func (o *Createv7WormDomainResponse) SetPrivilegedDelete(v string)`

SetPrivilegedDelete sets PrivilegedDelete field to given value.


### GetSetPendingDelete

`func (o *Createv7WormDomainResponse) GetSetPendingDelete() bool`

GetSetPendingDelete returns the SetPendingDelete field if non-nil, zero value otherwise.

### GetSetPendingDeleteOk

`func (o *Createv7WormDomainResponse) GetSetPendingDeleteOk() (*bool, bool)`

GetSetPendingDeleteOk returns a tuple with the SetPendingDelete field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSetPendingDelete

`func (o *Createv7WormDomainResponse) SetSetPendingDelete(v bool)`

SetSetPendingDelete sets SetPendingDelete field to given value.


### GetTotalModifies

`func (o *Createv7WormDomainResponse) GetTotalModifies() int32`

GetTotalModifies returns the TotalModifies field if non-nil, zero value otherwise.

### GetTotalModifiesOk

`func (o *Createv7WormDomainResponse) GetTotalModifiesOk() (*int32, bool)`

GetTotalModifiesOk returns a tuple with the TotalModifies field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotalModifies

`func (o *Createv7WormDomainResponse) SetTotalModifies(v int32)`

SetTotalModifies sets TotalModifies field to given value.


### GetType

`func (o *Createv7WormDomainResponse) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *Createv7WormDomainResponse) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *Createv7WormDomainResponse) SetType(v string)`

SetType sets Type field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


