# Createv3HardwareTapeNameResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Errors** | Pointer to [**[]V11NodeStatusError**](V11NodeStatusError.md) | A list of errors encountered by the individual nodes involved in this request, or an empty list if there were no errors. | [optional] 
**Nodes** | Pointer to [**[]Createv3HardwareTapeNameResponseNode**](Createv3HardwareTapeNameResponseNode.md) | The responses from the individual nodes involved in this request. | [optional] 
**Total** | Pointer to **int32** | The total number of nodes responding. | [optional] 

## Methods

### NewCreatev3HardwareTapeNameResponse

`func NewCreatev3HardwareTapeNameResponse() *Createv3HardwareTapeNameResponse`

NewCreatev3HardwareTapeNameResponse instantiates a new Createv3HardwareTapeNameResponse object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev3HardwareTapeNameResponseWithDefaults

`func NewCreatev3HardwareTapeNameResponseWithDefaults() *Createv3HardwareTapeNameResponse`

NewCreatev3HardwareTapeNameResponseWithDefaults instantiates a new Createv3HardwareTapeNameResponse object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetErrors

`func (o *Createv3HardwareTapeNameResponse) GetErrors() []V11NodeStatusError`

GetErrors returns the Errors field if non-nil, zero value otherwise.

### GetErrorsOk

`func (o *Createv3HardwareTapeNameResponse) GetErrorsOk() (*[]V11NodeStatusError, bool)`

GetErrorsOk returns a tuple with the Errors field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetErrors

`func (o *Createv3HardwareTapeNameResponse) SetErrors(v []V11NodeStatusError)`

SetErrors sets Errors field to given value.

### HasErrors

`func (o *Createv3HardwareTapeNameResponse) HasErrors() bool`

HasErrors returns a boolean if a field has been set.

### GetNodes

`func (o *Createv3HardwareTapeNameResponse) GetNodes() []Createv3HardwareTapeNameResponseNode`

GetNodes returns the Nodes field if non-nil, zero value otherwise.

### GetNodesOk

`func (o *Createv3HardwareTapeNameResponse) GetNodesOk() (*[]Createv3HardwareTapeNameResponseNode, bool)`

GetNodesOk returns a tuple with the Nodes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodes

`func (o *Createv3HardwareTapeNameResponse) SetNodes(v []Createv3HardwareTapeNameResponseNode)`

SetNodes sets Nodes field to given value.

### HasNodes

`func (o *Createv3HardwareTapeNameResponse) HasNodes() bool`

HasNodes returns a boolean if a field has been set.

### GetTotal

`func (o *Createv3HardwareTapeNameResponse) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *Createv3HardwareTapeNameResponse) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *Createv3HardwareTapeNameResponse) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *Createv3HardwareTapeNameResponse) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


