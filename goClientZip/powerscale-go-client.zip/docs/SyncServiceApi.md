# \SyncServiceApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateSyncServicev7PoliciesPolicyResetItem**](SyncServiceApi.md#CreateSyncServicev7PoliciesPolicyResetItem) | **Post** /platform/7/sync/service/policies/{Policy}/reset | 



## CreateSyncServicev7PoliciesPolicyResetItem

> CreateResponse CreateSyncServicev7PoliciesPolicyResetItem(ctx, policy).V7PoliciesPolicyResetItem(v7PoliciesPolicyResetItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    policy := "policy_example" // string | 
    v7PoliciesPolicyResetItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncServiceApi.CreateSyncServicev7PoliciesPolicyResetItem(context.Background(), policy).V7PoliciesPolicyResetItem(v7PoliciesPolicyResetItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncServiceApi.CreateSyncServicev7PoliciesPolicyResetItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSyncServicev7PoliciesPolicyResetItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `SyncServiceApi.CreateSyncServicev7PoliciesPolicyResetItem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**policy** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateSyncServicev7PoliciesPolicyResetItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7PoliciesPolicyResetItem** | **map[string]interface{}** |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

