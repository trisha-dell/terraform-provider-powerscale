# \PerformanceApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreatePerformancev10PerformanceDataset**](PerformanceApi.md#CreatePerformancev10PerformanceDataset) | **Post** /platform/10/performance/datasets | 
[**CreatePerformancev12PerformanceDataset**](PerformanceApi.md#CreatePerformancev12PerformanceDataset) | **Post** /platform/12/performance/datasets | 
[**CreatePerformancev7PerformanceDataset**](PerformanceApi.md#CreatePerformancev7PerformanceDataset) | **Post** /platform/7/performance/datasets | 
[**CreatePerformancev9PerformanceDataset**](PerformanceApi.md#CreatePerformancev9PerformanceDataset) | **Post** /platform/9/performance/datasets | 
[**DeletePerformancev10DatasetsDatasetFilter**](PerformanceApi.md#DeletePerformancev10DatasetsDatasetFilter) | **Delete** /platform/10/performance/datasets/{Dataset}/filters/{v10DatasetsDatasetFilterId} | 
[**DeletePerformancev10DatasetsDatasetWorkload**](PerformanceApi.md#DeletePerformancev10DatasetsDatasetWorkload) | **Delete** /platform/10/performance/datasets/{Dataset}/workloads/{v10DatasetsDatasetWorkloadId} | 
[**DeletePerformancev10PerformanceDataset**](PerformanceApi.md#DeletePerformancev10PerformanceDataset) | **Delete** /platform/10/performance/datasets/{v10PerformanceDatasetId} | 
[**DeletePerformancev12DatasetsDatasetFilter**](PerformanceApi.md#DeletePerformancev12DatasetsDatasetFilter) | **Delete** /platform/12/performance/datasets/{Dataset}/filters/{v12DatasetsDatasetFilterId} | 
[**DeletePerformancev12DatasetsDatasetWorkload**](PerformanceApi.md#DeletePerformancev12DatasetsDatasetWorkload) | **Delete** /platform/12/performance/datasets/{Dataset}/workloads/{v12DatasetsDatasetWorkloadId} | 
[**DeletePerformancev12PerformanceDataset**](PerformanceApi.md#DeletePerformancev12PerformanceDataset) | **Delete** /platform/12/performance/datasets/{v12PerformanceDatasetId} | 
[**DeletePerformancev16DatasetsDatasetWorkload**](PerformanceApi.md#DeletePerformancev16DatasetsDatasetWorkload) | **Delete** /platform/16/performance/datasets/{Dataset}/workloads/{v16DatasetsDatasetWorkloadId} | 
[**DeletePerformancev16DatasetsDatasetWorkloadsWorkloadLimit**](PerformanceApi.md#DeletePerformancev16DatasetsDatasetWorkloadsWorkloadLimit) | **Delete** /platform/16/performance/datasets/{Dataset}/workloads/{Workload}/limits/{v16DatasetsDatasetWorkloadsWorkloadLimitId} | 
[**DeletePerformancev7DatasetsDatasetFilter**](PerformanceApi.md#DeletePerformancev7DatasetsDatasetFilter) | **Delete** /platform/7/performance/datasets/{Dataset}/filters/{v7DatasetsDatasetFilterId} | 
[**DeletePerformancev7DatasetsDatasetWorkload**](PerformanceApi.md#DeletePerformancev7DatasetsDatasetWorkload) | **Delete** /platform/7/performance/datasets/{Dataset}/workloads/{v7DatasetsDatasetWorkloadId} | 
[**DeletePerformancev7PerformanceDataset**](PerformanceApi.md#DeletePerformancev7PerformanceDataset) | **Delete** /platform/7/performance/datasets/{v7PerformanceDatasetId} | 
[**DeletePerformancev9DatasetsDatasetFilter**](PerformanceApi.md#DeletePerformancev9DatasetsDatasetFilter) | **Delete** /platform/9/performance/datasets/{Dataset}/filters/{v9DatasetsDatasetFilterId} | 
[**DeletePerformancev9DatasetsDatasetWorkload**](PerformanceApi.md#DeletePerformancev9DatasetsDatasetWorkload) | **Delete** /platform/9/performance/datasets/{Dataset}/workloads/{v9DatasetsDatasetWorkloadId} | 
[**DeletePerformancev9PerformanceDataset**](PerformanceApi.md#DeletePerformancev9PerformanceDataset) | **Delete** /platform/9/performance/datasets/{v9PerformanceDatasetId} | 
[**GetPerformancev10DatasetsDatasetFilter**](PerformanceApi.md#GetPerformancev10DatasetsDatasetFilter) | **Get** /platform/10/performance/datasets/{Dataset}/filters/{v10DatasetsDatasetFilterId} | 
[**GetPerformancev10DatasetsDatasetWorkload**](PerformanceApi.md#GetPerformancev10DatasetsDatasetWorkload) | **Get** /platform/10/performance/datasets/{Dataset}/workloads/{v10DatasetsDatasetWorkloadId} | 
[**GetPerformancev10PerformanceDataset**](PerformanceApi.md#GetPerformancev10PerformanceDataset) | **Get** /platform/10/performance/datasets/{v10PerformanceDatasetId} | 
[**GetPerformancev10PerformanceMetric**](PerformanceApi.md#GetPerformancev10PerformanceMetric) | **Get** /platform/10/performance/metrics/{v10PerformanceMetricId} | 
[**GetPerformancev10PerformanceMetrics**](PerformanceApi.md#GetPerformancev10PerformanceMetrics) | **Get** /platform/10/performance/metrics | 
[**GetPerformancev10PerformanceSettings**](PerformanceApi.md#GetPerformancev10PerformanceSettings) | **Get** /platform/10/performance/settings | 
[**GetPerformancev12DatasetsDatasetFilter**](PerformanceApi.md#GetPerformancev12DatasetsDatasetFilter) | **Get** /platform/12/performance/datasets/{Dataset}/filters/{v12DatasetsDatasetFilterId} | 
[**GetPerformancev12DatasetsDatasetWorkload**](PerformanceApi.md#GetPerformancev12DatasetsDatasetWorkload) | **Get** /platform/12/performance/datasets/{Dataset}/workloads/{v12DatasetsDatasetWorkloadId} | 
[**GetPerformancev12PerformanceDataset**](PerformanceApi.md#GetPerformancev12PerformanceDataset) | **Get** /platform/12/performance/datasets/{v12PerformanceDatasetId} | 
[**GetPerformancev12PerformanceMetric**](PerformanceApi.md#GetPerformancev12PerformanceMetric) | **Get** /platform/12/performance/metrics/{v12PerformanceMetricId} | 
[**GetPerformancev12PerformanceMetrics**](PerformanceApi.md#GetPerformancev12PerformanceMetrics) | **Get** /platform/12/performance/metrics | 
[**GetPerformancev12PerformanceSettings**](PerformanceApi.md#GetPerformancev12PerformanceSettings) | **Get** /platform/12/performance/settings | 
[**GetPerformancev16DatasetsDatasetWorkload**](PerformanceApi.md#GetPerformancev16DatasetsDatasetWorkload) | **Get** /platform/16/performance/datasets/{Dataset}/workloads/{v16DatasetsDatasetWorkloadId} | 
[**GetPerformancev16PerformanceSettings**](PerformanceApi.md#GetPerformancev16PerformanceSettings) | **Get** /platform/16/performance/settings | 
[**GetPerformancev7DatasetsDatasetFilter**](PerformanceApi.md#GetPerformancev7DatasetsDatasetFilter) | **Get** /platform/7/performance/datasets/{Dataset}/filters/{v7DatasetsDatasetFilterId} | 
[**GetPerformancev7DatasetsDatasetWorkload**](PerformanceApi.md#GetPerformancev7DatasetsDatasetWorkload) | **Get** /platform/7/performance/datasets/{Dataset}/workloads/{v7DatasetsDatasetWorkloadId} | 
[**GetPerformancev7PerformanceDataset**](PerformanceApi.md#GetPerformancev7PerformanceDataset) | **Get** /platform/7/performance/datasets/{v7PerformanceDatasetId} | 
[**GetPerformancev7PerformanceMetric**](PerformanceApi.md#GetPerformancev7PerformanceMetric) | **Get** /platform/7/performance/metrics/{v7PerformanceMetricId} | 
[**GetPerformancev7PerformanceMetrics**](PerformanceApi.md#GetPerformancev7PerformanceMetrics) | **Get** /platform/7/performance/metrics | 
[**GetPerformancev7PerformanceSettings**](PerformanceApi.md#GetPerformancev7PerformanceSettings) | **Get** /platform/7/performance/settings | 
[**GetPerformancev9DatasetsDatasetFilter**](PerformanceApi.md#GetPerformancev9DatasetsDatasetFilter) | **Get** /platform/9/performance/datasets/{Dataset}/filters/{v9DatasetsDatasetFilterId} | 
[**GetPerformancev9DatasetsDatasetWorkload**](PerformanceApi.md#GetPerformancev9DatasetsDatasetWorkload) | **Get** /platform/9/performance/datasets/{Dataset}/workloads/{v9DatasetsDatasetWorkloadId} | 
[**GetPerformancev9PerformanceDataset**](PerformanceApi.md#GetPerformancev9PerformanceDataset) | **Get** /platform/9/performance/datasets/{v9PerformanceDatasetId} | 
[**GetPerformancev9PerformanceMetric**](PerformanceApi.md#GetPerformancev9PerformanceMetric) | **Get** /platform/9/performance/metrics/{v9PerformanceMetricId} | 
[**GetPerformancev9PerformanceMetrics**](PerformanceApi.md#GetPerformancev9PerformanceMetrics) | **Get** /platform/9/performance/metrics | 
[**GetPerformancev9PerformanceSettings**](PerformanceApi.md#GetPerformancev9PerformanceSettings) | **Get** /platform/9/performance/settings | 
[**ListPerformancev10PerformanceDatasets**](PerformanceApi.md#ListPerformancev10PerformanceDatasets) | **Get** /platform/10/performance/datasets | 
[**ListPerformancev12PerformanceDatasets**](PerformanceApi.md#ListPerformancev12PerformanceDatasets) | **Get** /platform/12/performance/datasets | 
[**ListPerformancev7PerformanceDatasets**](PerformanceApi.md#ListPerformancev7PerformanceDatasets) | **Get** /platform/7/performance/datasets | 
[**ListPerformancev9PerformanceDatasets**](PerformanceApi.md#ListPerformancev9PerformanceDatasets) | **Get** /platform/9/performance/datasets | 
[**UpdatePerformancev10DatasetsDatasetFilter**](PerformanceApi.md#UpdatePerformancev10DatasetsDatasetFilter) | **Put** /platform/10/performance/datasets/{Dataset}/filters/{v10DatasetsDatasetFilterId} | 
[**UpdatePerformancev10DatasetsDatasetWorkload**](PerformanceApi.md#UpdatePerformancev10DatasetsDatasetWorkload) | **Put** /platform/10/performance/datasets/{Dataset}/workloads/{v10DatasetsDatasetWorkloadId} | 
[**UpdatePerformancev10PerformanceDataset**](PerformanceApi.md#UpdatePerformancev10PerformanceDataset) | **Put** /platform/10/performance/datasets/{v10PerformanceDatasetId} | 
[**UpdatePerformancev10PerformanceSettings**](PerformanceApi.md#UpdatePerformancev10PerformanceSettings) | **Put** /platform/10/performance/settings | 
[**UpdatePerformancev12DatasetsDatasetFilter**](PerformanceApi.md#UpdatePerformancev12DatasetsDatasetFilter) | **Put** /platform/12/performance/datasets/{Dataset}/filters/{v12DatasetsDatasetFilterId} | 
[**UpdatePerformancev12DatasetsDatasetWorkload**](PerformanceApi.md#UpdatePerformancev12DatasetsDatasetWorkload) | **Put** /platform/12/performance/datasets/{Dataset}/workloads/{v12DatasetsDatasetWorkloadId} | 
[**UpdatePerformancev12PerformanceDataset**](PerformanceApi.md#UpdatePerformancev12PerformanceDataset) | **Put** /platform/12/performance/datasets/{v12PerformanceDatasetId} | 
[**UpdatePerformancev12PerformanceSettings**](PerformanceApi.md#UpdatePerformancev12PerformanceSettings) | **Put** /platform/12/performance/settings | 
[**UpdatePerformancev16DatasetsDatasetWorkload**](PerformanceApi.md#UpdatePerformancev16DatasetsDatasetWorkload) | **Put** /platform/16/performance/datasets/{Dataset}/workloads/{v16DatasetsDatasetWorkloadId} | 
[**UpdatePerformancev16PerformanceSettings**](PerformanceApi.md#UpdatePerformancev16PerformanceSettings) | **Put** /platform/16/performance/settings | 
[**UpdatePerformancev7DatasetsDatasetFilter**](PerformanceApi.md#UpdatePerformancev7DatasetsDatasetFilter) | **Put** /platform/7/performance/datasets/{Dataset}/filters/{v7DatasetsDatasetFilterId} | 
[**UpdatePerformancev7DatasetsDatasetWorkload**](PerformanceApi.md#UpdatePerformancev7DatasetsDatasetWorkload) | **Put** /platform/7/performance/datasets/{Dataset}/workloads/{v7DatasetsDatasetWorkloadId} | 
[**UpdatePerformancev7PerformanceDataset**](PerformanceApi.md#UpdatePerformancev7PerformanceDataset) | **Put** /platform/7/performance/datasets/{v7PerformanceDatasetId} | 
[**UpdatePerformancev7PerformanceSettings**](PerformanceApi.md#UpdatePerformancev7PerformanceSettings) | **Put** /platform/7/performance/settings | 
[**UpdatePerformancev9DatasetsDatasetFilter**](PerformanceApi.md#UpdatePerformancev9DatasetsDatasetFilter) | **Put** /platform/9/performance/datasets/{Dataset}/filters/{v9DatasetsDatasetFilterId} | 
[**UpdatePerformancev9DatasetsDatasetWorkload**](PerformanceApi.md#UpdatePerformancev9DatasetsDatasetWorkload) | **Put** /platform/9/performance/datasets/{Dataset}/workloads/{v9DatasetsDatasetWorkloadId} | 
[**UpdatePerformancev9PerformanceDataset**](PerformanceApi.md#UpdatePerformancev9PerformanceDataset) | **Put** /platform/9/performance/datasets/{v9PerformanceDatasetId} | 
[**UpdatePerformancev9PerformanceSettings**](PerformanceApi.md#UpdatePerformancev9PerformanceSettings) | **Put** /platform/9/performance/settings | 



## CreatePerformancev10PerformanceDataset

> Createv10PerformanceDatasetResponse CreatePerformancev10PerformanceDataset(ctx).V10PerformanceDataset(v10PerformanceDataset).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10PerformanceDataset := *openapiclient.NewV10PerformanceDataset([]string{"Metrics_example"}) // V10PerformanceDataset | 
    force := true // bool | For use by support only. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.CreatePerformancev10PerformanceDataset(context.Background()).V10PerformanceDataset(v10PerformanceDataset).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.CreatePerformancev10PerformanceDataset``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreatePerformancev10PerformanceDataset`: Createv10PerformanceDatasetResponse
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.CreatePerformancev10PerformanceDataset`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreatePerformancev10PerformanceDatasetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v10PerformanceDataset** | [**V10PerformanceDataset**](V10PerformanceDataset.md) |  | 
 **force** | **bool** | For use by support only. | 

### Return type

[**Createv10PerformanceDatasetResponse**](Createv10PerformanceDatasetResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreatePerformancev12PerformanceDataset

> Createv10PerformanceDatasetResponse CreatePerformancev12PerformanceDataset(ctx).V12PerformanceDataset(v12PerformanceDataset).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12PerformanceDataset := *openapiclient.NewV10PerformanceDataset([]string{"Metrics_example"}) // V10PerformanceDataset | 
    force := true // bool | For use by support only. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.CreatePerformancev12PerformanceDataset(context.Background()).V12PerformanceDataset(v12PerformanceDataset).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.CreatePerformancev12PerformanceDataset``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreatePerformancev12PerformanceDataset`: Createv10PerformanceDatasetResponse
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.CreatePerformancev12PerformanceDataset`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreatePerformancev12PerformanceDatasetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12PerformanceDataset** | [**V10PerformanceDataset**](V10PerformanceDataset.md) |  | 
 **force** | **bool** | For use by support only. | 

### Return type

[**Createv10PerformanceDatasetResponse**](Createv10PerformanceDatasetResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreatePerformancev7PerformanceDataset

> Createv7PerformanceDatasetResponse CreatePerformancev7PerformanceDataset(ctx).V7PerformanceDataset(v7PerformanceDataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7PerformanceDataset := *openapiclient.NewV7PerformanceDataset([]string{"Metrics_example"}) // V7PerformanceDataset | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.CreatePerformancev7PerformanceDataset(context.Background()).V7PerformanceDataset(v7PerformanceDataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.CreatePerformancev7PerformanceDataset``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreatePerformancev7PerformanceDataset`: Createv7PerformanceDatasetResponse
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.CreatePerformancev7PerformanceDataset`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreatePerformancev7PerformanceDatasetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7PerformanceDataset** | [**V7PerformanceDataset**](V7PerformanceDataset.md) |  | 

### Return type

[**Createv7PerformanceDatasetResponse**](Createv7PerformanceDatasetResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreatePerformancev9PerformanceDataset

> Createv10PerformanceDatasetResponse CreatePerformancev9PerformanceDataset(ctx).V9PerformanceDataset(v9PerformanceDataset).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9PerformanceDataset := *openapiclient.NewV10PerformanceDataset([]string{"Metrics_example"}) // V10PerformanceDataset | 
    force := true // bool | For use by support only. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.CreatePerformancev9PerformanceDataset(context.Background()).V9PerformanceDataset(v9PerformanceDataset).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.CreatePerformancev9PerformanceDataset``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreatePerformancev9PerformanceDataset`: Createv10PerformanceDatasetResponse
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.CreatePerformancev9PerformanceDataset`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreatePerformancev9PerformanceDatasetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v9PerformanceDataset** | [**V10PerformanceDataset**](V10PerformanceDataset.md) |  | 
 **force** | **bool** | For use by support only. | 

### Return type

[**Createv10PerformanceDatasetResponse**](Createv10PerformanceDatasetResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformancev10DatasetsDatasetFilter

> DeletePerformancev10DatasetsDatasetFilter(ctx, v10DatasetsDatasetFilterId, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10DatasetsDatasetFilterId := "v10DatasetsDatasetFilterId_example" // string | Delete the filter.
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.DeletePerformancev10DatasetsDatasetFilter(context.Background(), v10DatasetsDatasetFilterId, dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.DeletePerformancev10DatasetsDatasetFilter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10DatasetsDatasetFilterId** | **string** | Delete the filter. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformancev10DatasetsDatasetFilterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformancev10DatasetsDatasetWorkload

> DeletePerformancev10DatasetsDatasetWorkload(ctx, v10DatasetsDatasetWorkloadId, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10DatasetsDatasetWorkloadId := "v10DatasetsDatasetWorkloadId_example" // string | Delete the workload.
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.DeletePerformancev10DatasetsDatasetWorkload(context.Background(), v10DatasetsDatasetWorkloadId, dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.DeletePerformancev10DatasetsDatasetWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10DatasetsDatasetWorkloadId** | **string** | Delete the workload. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformancev10DatasetsDatasetWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformancev10PerformanceDataset

> DeletePerformancev10PerformanceDataset(ctx, v10PerformanceDatasetId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10PerformanceDatasetId := "v10PerformanceDatasetId_example" // string | Delete the performance dataset.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.DeletePerformancev10PerformanceDataset(context.Background(), v10PerformanceDatasetId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.DeletePerformancev10PerformanceDataset``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10PerformanceDatasetId** | **string** | Delete the performance dataset. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformancev10PerformanceDatasetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformancev12DatasetsDatasetFilter

> DeletePerformancev12DatasetsDatasetFilter(ctx, v12DatasetsDatasetFilterId, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12DatasetsDatasetFilterId := "v12DatasetsDatasetFilterId_example" // string | Delete the filter.
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.DeletePerformancev12DatasetsDatasetFilter(context.Background(), v12DatasetsDatasetFilterId, dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.DeletePerformancev12DatasetsDatasetFilter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12DatasetsDatasetFilterId** | **string** | Delete the filter. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformancev12DatasetsDatasetFilterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformancev12DatasetsDatasetWorkload

> DeletePerformancev12DatasetsDatasetWorkload(ctx, v12DatasetsDatasetWorkloadId, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12DatasetsDatasetWorkloadId := "v12DatasetsDatasetWorkloadId_example" // string | Delete the workload.
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.DeletePerformancev12DatasetsDatasetWorkload(context.Background(), v12DatasetsDatasetWorkloadId, dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.DeletePerformancev12DatasetsDatasetWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12DatasetsDatasetWorkloadId** | **string** | Delete the workload. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformancev12DatasetsDatasetWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformancev12PerformanceDataset

> DeletePerformancev12PerformanceDataset(ctx, v12PerformanceDatasetId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12PerformanceDatasetId := "v12PerformanceDatasetId_example" // string | Delete the performance dataset.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.DeletePerformancev12PerformanceDataset(context.Background(), v12PerformanceDatasetId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.DeletePerformancev12PerformanceDataset``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12PerformanceDatasetId** | **string** | Delete the performance dataset. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformancev12PerformanceDatasetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformancev16DatasetsDatasetWorkload

> DeletePerformancev16DatasetsDatasetWorkload(ctx, v16DatasetsDatasetWorkloadId, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16DatasetsDatasetWorkloadId := "v16DatasetsDatasetWorkloadId_example" // string | Delete the workload.
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.DeletePerformancev16DatasetsDatasetWorkload(context.Background(), v16DatasetsDatasetWorkloadId, dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.DeletePerformancev16DatasetsDatasetWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v16DatasetsDatasetWorkloadId** | **string** | Delete the workload. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformancev16DatasetsDatasetWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformancev16DatasetsDatasetWorkloadsWorkloadLimit

> DeletePerformancev16DatasetsDatasetWorkloadsWorkloadLimit(ctx, v16DatasetsDatasetWorkloadsWorkloadLimitId, dataset, workload).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16DatasetsDatasetWorkloadsWorkloadLimitId := "v16DatasetsDatasetWorkloadsWorkloadLimitId_example" // string | Delete the workload limit.
    dataset := "dataset_example" // string | 
    workload := "workload_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.DeletePerformancev16DatasetsDatasetWorkloadsWorkloadLimit(context.Background(), v16DatasetsDatasetWorkloadsWorkloadLimitId, dataset, workload).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.DeletePerformancev16DatasetsDatasetWorkloadsWorkloadLimit``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v16DatasetsDatasetWorkloadsWorkloadLimitId** | **string** | Delete the workload limit. | 
**dataset** | **string** |  | 
**workload** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformancev16DatasetsDatasetWorkloadsWorkloadLimitRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------




### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformancev7DatasetsDatasetFilter

> DeletePerformancev7DatasetsDatasetFilter(ctx, v7DatasetsDatasetFilterId, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7DatasetsDatasetFilterId := "v7DatasetsDatasetFilterId_example" // string | Delete the filter.
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.DeletePerformancev7DatasetsDatasetFilter(context.Background(), v7DatasetsDatasetFilterId, dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.DeletePerformancev7DatasetsDatasetFilter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7DatasetsDatasetFilterId** | **string** | Delete the filter. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformancev7DatasetsDatasetFilterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformancev7DatasetsDatasetWorkload

> DeletePerformancev7DatasetsDatasetWorkload(ctx, v7DatasetsDatasetWorkloadId, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7DatasetsDatasetWorkloadId := "v7DatasetsDatasetWorkloadId_example" // string | Delete the workload.
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.DeletePerformancev7DatasetsDatasetWorkload(context.Background(), v7DatasetsDatasetWorkloadId, dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.DeletePerformancev7DatasetsDatasetWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7DatasetsDatasetWorkloadId** | **string** | Delete the workload. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformancev7DatasetsDatasetWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformancev7PerformanceDataset

> DeletePerformancev7PerformanceDataset(ctx, v7PerformanceDatasetId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7PerformanceDatasetId := "v7PerformanceDatasetId_example" // string | Delete the performance dataset.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.DeletePerformancev7PerformanceDataset(context.Background(), v7PerformanceDatasetId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.DeletePerformancev7PerformanceDataset``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7PerformanceDatasetId** | **string** | Delete the performance dataset. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformancev7PerformanceDatasetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformancev9DatasetsDatasetFilter

> DeletePerformancev9DatasetsDatasetFilter(ctx, v9DatasetsDatasetFilterId, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9DatasetsDatasetFilterId := "v9DatasetsDatasetFilterId_example" // string | Delete the filter.
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.DeletePerformancev9DatasetsDatasetFilter(context.Background(), v9DatasetsDatasetFilterId, dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.DeletePerformancev9DatasetsDatasetFilter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v9DatasetsDatasetFilterId** | **string** | Delete the filter. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformancev9DatasetsDatasetFilterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformancev9DatasetsDatasetWorkload

> DeletePerformancev9DatasetsDatasetWorkload(ctx, v9DatasetsDatasetWorkloadId, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9DatasetsDatasetWorkloadId := "v9DatasetsDatasetWorkloadId_example" // string | Delete the workload.
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.DeletePerformancev9DatasetsDatasetWorkload(context.Background(), v9DatasetsDatasetWorkloadId, dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.DeletePerformancev9DatasetsDatasetWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v9DatasetsDatasetWorkloadId** | **string** | Delete the workload. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformancev9DatasetsDatasetWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformancev9PerformanceDataset

> DeletePerformancev9PerformanceDataset(ctx, v9PerformanceDatasetId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9PerformanceDatasetId := "v9PerformanceDatasetId_example" // string | Delete the performance dataset.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.DeletePerformancev9PerformanceDataset(context.Background(), v9PerformanceDatasetId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.DeletePerformancev9PerformanceDataset``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v9PerformanceDatasetId** | **string** | Delete the performance dataset. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformancev9PerformanceDatasetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev10DatasetsDatasetFilter

> V10DatasetsDatasetFilters GetPerformancev10DatasetsDatasetFilter(ctx, v10DatasetsDatasetFilterId, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10DatasetsDatasetFilterId := "v10DatasetsDatasetFilterId_example" // string | Retrieve the filter.
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev10DatasetsDatasetFilter(context.Background(), v10DatasetsDatasetFilterId, dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev10DatasetsDatasetFilter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev10DatasetsDatasetFilter`: V10DatasetsDatasetFilters
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev10DatasetsDatasetFilter`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10DatasetsDatasetFilterId** | **string** | Retrieve the filter. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev10DatasetsDatasetFilterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V10DatasetsDatasetFilters**](V10DatasetsDatasetFilters.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev10DatasetsDatasetWorkload

> V10DatasetsDatasetWorkloads GetPerformancev10DatasetsDatasetWorkload(ctx, v10DatasetsDatasetWorkloadId, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10DatasetsDatasetWorkloadId := "v10DatasetsDatasetWorkloadId_example" // string | Retrieve the workload.
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev10DatasetsDatasetWorkload(context.Background(), v10DatasetsDatasetWorkloadId, dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev10DatasetsDatasetWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev10DatasetsDatasetWorkload`: V10DatasetsDatasetWorkloads
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev10DatasetsDatasetWorkload`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10DatasetsDatasetWorkloadId** | **string** | Retrieve the workload. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev10DatasetsDatasetWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V10DatasetsDatasetWorkloads**](V10DatasetsDatasetWorkloads.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev10PerformanceDataset

> V10PerformanceDatasetsExtended GetPerformancev10PerformanceDataset(ctx, v10PerformanceDatasetId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10PerformanceDatasetId := "v10PerformanceDatasetId_example" // string | Retrieve the performance dataset.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev10PerformanceDataset(context.Background(), v10PerformanceDatasetId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev10PerformanceDataset``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev10PerformanceDataset`: V10PerformanceDatasetsExtended
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev10PerformanceDataset`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10PerformanceDatasetId** | **string** | Retrieve the performance dataset. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev10PerformanceDatasetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V10PerformanceDatasetsExtended**](V10PerformanceDatasetsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev10PerformanceMetric

> V10PerformanceMetricsExtended GetPerformancev10PerformanceMetric(ctx, v10PerformanceMetricId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10PerformanceMetricId := "v10PerformanceMetricId_example" // string | View a single performance metric.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev10PerformanceMetric(context.Background(), v10PerformanceMetricId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev10PerformanceMetric``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev10PerformanceMetric`: V10PerformanceMetricsExtended
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev10PerformanceMetric`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10PerformanceMetricId** | **string** | View a single performance metric. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev10PerformanceMetricRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V10PerformanceMetricsExtended**](V10PerformanceMetricsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev10PerformanceMetrics

> V10PerformanceMetrics GetPerformancev10PerformanceMetrics(ctx).Sort(sort).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev10PerformanceMetrics(context.Background()).Sort(sort).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev10PerformanceMetrics``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev10PerformanceMetrics`: V10PerformanceMetrics
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev10PerformanceMetrics`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev10PerformanceMetricsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V10PerformanceMetrics**](V10PerformanceMetrics.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev10PerformanceSettings

> V10PerformanceSettings GetPerformancev10PerformanceSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev10PerformanceSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev10PerformanceSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev10PerformanceSettings`: V10PerformanceSettings
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev10PerformanceSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev10PerformanceSettingsRequest struct via the builder pattern


### Return type

[**V10PerformanceSettings**](V10PerformanceSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev12DatasetsDatasetFilter

> V12DatasetsDatasetFilters GetPerformancev12DatasetsDatasetFilter(ctx, v12DatasetsDatasetFilterId, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12DatasetsDatasetFilterId := "v12DatasetsDatasetFilterId_example" // string | Retrieve the filter.
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev12DatasetsDatasetFilter(context.Background(), v12DatasetsDatasetFilterId, dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev12DatasetsDatasetFilter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev12DatasetsDatasetFilter`: V12DatasetsDatasetFilters
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev12DatasetsDatasetFilter`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12DatasetsDatasetFilterId** | **string** | Retrieve the filter. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev12DatasetsDatasetFilterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V12DatasetsDatasetFilters**](V12DatasetsDatasetFilters.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev12DatasetsDatasetWorkload

> V12DatasetsDatasetWorkloads GetPerformancev12DatasetsDatasetWorkload(ctx, v12DatasetsDatasetWorkloadId, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12DatasetsDatasetWorkloadId := "v12DatasetsDatasetWorkloadId_example" // string | Retrieve the workload.
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev12DatasetsDatasetWorkload(context.Background(), v12DatasetsDatasetWorkloadId, dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev12DatasetsDatasetWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev12DatasetsDatasetWorkload`: V12DatasetsDatasetWorkloads
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev12DatasetsDatasetWorkload`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12DatasetsDatasetWorkloadId** | **string** | Retrieve the workload. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev12DatasetsDatasetWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V12DatasetsDatasetWorkloads**](V12DatasetsDatasetWorkloads.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev12PerformanceDataset

> V10PerformanceDatasetsExtended GetPerformancev12PerformanceDataset(ctx, v12PerformanceDatasetId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12PerformanceDatasetId := "v12PerformanceDatasetId_example" // string | Retrieve the performance dataset.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev12PerformanceDataset(context.Background(), v12PerformanceDatasetId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev12PerformanceDataset``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev12PerformanceDataset`: V10PerformanceDatasetsExtended
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev12PerformanceDataset`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12PerformanceDatasetId** | **string** | Retrieve the performance dataset. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev12PerformanceDatasetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V10PerformanceDatasetsExtended**](V10PerformanceDatasetsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev12PerformanceMetric

> V10PerformanceMetricsExtended GetPerformancev12PerformanceMetric(ctx, v12PerformanceMetricId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12PerformanceMetricId := "v12PerformanceMetricId_example" // string | View a single performance metric.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev12PerformanceMetric(context.Background(), v12PerformanceMetricId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev12PerformanceMetric``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev12PerformanceMetric`: V10PerformanceMetricsExtended
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev12PerformanceMetric`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12PerformanceMetricId** | **string** | View a single performance metric. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev12PerformanceMetricRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V10PerformanceMetricsExtended**](V10PerformanceMetricsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev12PerformanceMetrics

> V10PerformanceMetrics GetPerformancev12PerformanceMetrics(ctx).Sort(sort).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev12PerformanceMetrics(context.Background()).Sort(sort).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev12PerformanceMetrics``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev12PerformanceMetrics`: V10PerformanceMetrics
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev12PerformanceMetrics`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev12PerformanceMetricsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V10PerformanceMetrics**](V10PerformanceMetrics.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev12PerformanceSettings

> V10PerformanceSettings GetPerformancev12PerformanceSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev12PerformanceSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev12PerformanceSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev12PerformanceSettings`: V10PerformanceSettings
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev12PerformanceSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev12PerformanceSettingsRequest struct via the builder pattern


### Return type

[**V10PerformanceSettings**](V10PerformanceSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev16DatasetsDatasetWorkload

> V16DatasetsDatasetWorkloads GetPerformancev16DatasetsDatasetWorkload(ctx, v16DatasetsDatasetWorkloadId, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16DatasetsDatasetWorkloadId := "v16DatasetsDatasetWorkloadId_example" // string | Retrieve the workload.
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev16DatasetsDatasetWorkload(context.Background(), v16DatasetsDatasetWorkloadId, dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev16DatasetsDatasetWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev16DatasetsDatasetWorkload`: V16DatasetsDatasetWorkloads
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev16DatasetsDatasetWorkload`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v16DatasetsDatasetWorkloadId** | **string** | Retrieve the workload. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev16DatasetsDatasetWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V16DatasetsDatasetWorkloads**](V16DatasetsDatasetWorkloads.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev16PerformanceSettings

> V16PerformanceSettings GetPerformancev16PerformanceSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev16PerformanceSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev16PerformanceSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev16PerformanceSettings`: V16PerformanceSettings
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev16PerformanceSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev16PerformanceSettingsRequest struct via the builder pattern


### Return type

[**V16PerformanceSettings**](V16PerformanceSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev7DatasetsDatasetFilter

> V7DatasetsDatasetFilters GetPerformancev7DatasetsDatasetFilter(ctx, v7DatasetsDatasetFilterId, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7DatasetsDatasetFilterId := "v7DatasetsDatasetFilterId_example" // string | Retrieve the filter.
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev7DatasetsDatasetFilter(context.Background(), v7DatasetsDatasetFilterId, dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev7DatasetsDatasetFilter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev7DatasetsDatasetFilter`: V7DatasetsDatasetFilters
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev7DatasetsDatasetFilter`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7DatasetsDatasetFilterId** | **string** | Retrieve the filter. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev7DatasetsDatasetFilterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V7DatasetsDatasetFilters**](V7DatasetsDatasetFilters.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev7DatasetsDatasetWorkload

> V7DatasetsDatasetWorkloads GetPerformancev7DatasetsDatasetWorkload(ctx, v7DatasetsDatasetWorkloadId, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7DatasetsDatasetWorkloadId := "v7DatasetsDatasetWorkloadId_example" // string | Retrieve the workload.
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev7DatasetsDatasetWorkload(context.Background(), v7DatasetsDatasetWorkloadId, dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev7DatasetsDatasetWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev7DatasetsDatasetWorkload`: V7DatasetsDatasetWorkloads
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev7DatasetsDatasetWorkload`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7DatasetsDatasetWorkloadId** | **string** | Retrieve the workload. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev7DatasetsDatasetWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V7DatasetsDatasetWorkloads**](V7DatasetsDatasetWorkloads.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev7PerformanceDataset

> V7PerformanceDatasetsExtended GetPerformancev7PerformanceDataset(ctx, v7PerformanceDatasetId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7PerformanceDatasetId := "v7PerformanceDatasetId_example" // string | Retrieve the performance dataset.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev7PerformanceDataset(context.Background(), v7PerformanceDatasetId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev7PerformanceDataset``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev7PerformanceDataset`: V7PerformanceDatasetsExtended
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev7PerformanceDataset`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7PerformanceDatasetId** | **string** | Retrieve the performance dataset. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev7PerformanceDatasetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7PerformanceDatasetsExtended**](V7PerformanceDatasetsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev7PerformanceMetric

> V7PerformanceMetricsExtended GetPerformancev7PerformanceMetric(ctx, v7PerformanceMetricId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7PerformanceMetricId := "v7PerformanceMetricId_example" // string | View a single performance metric.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev7PerformanceMetric(context.Background(), v7PerformanceMetricId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev7PerformanceMetric``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev7PerformanceMetric`: V7PerformanceMetricsExtended
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev7PerformanceMetric`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7PerformanceMetricId** | **string** | View a single performance metric. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev7PerformanceMetricRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7PerformanceMetricsExtended**](V7PerformanceMetricsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev7PerformanceMetrics

> V7PerformanceMetrics GetPerformancev7PerformanceMetrics(ctx).Sort(sort).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev7PerformanceMetrics(context.Background()).Sort(sort).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev7PerformanceMetrics``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev7PerformanceMetrics`: V7PerformanceMetrics
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev7PerformanceMetrics`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev7PerformanceMetricsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V7PerformanceMetrics**](V7PerformanceMetrics.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev7PerformanceSettings

> V10PerformanceSettings GetPerformancev7PerformanceSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev7PerformanceSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev7PerformanceSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev7PerformanceSettings`: V10PerformanceSettings
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev7PerformanceSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev7PerformanceSettingsRequest struct via the builder pattern


### Return type

[**V10PerformanceSettings**](V10PerformanceSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev9DatasetsDatasetFilter

> V9DatasetsDatasetFilters GetPerformancev9DatasetsDatasetFilter(ctx, v9DatasetsDatasetFilterId, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9DatasetsDatasetFilterId := "v9DatasetsDatasetFilterId_example" // string | Retrieve the filter.
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev9DatasetsDatasetFilter(context.Background(), v9DatasetsDatasetFilterId, dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev9DatasetsDatasetFilter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev9DatasetsDatasetFilter`: V9DatasetsDatasetFilters
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev9DatasetsDatasetFilter`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v9DatasetsDatasetFilterId** | **string** | Retrieve the filter. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev9DatasetsDatasetFilterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V9DatasetsDatasetFilters**](V9DatasetsDatasetFilters.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev9DatasetsDatasetWorkload

> V9DatasetsDatasetWorkloads GetPerformancev9DatasetsDatasetWorkload(ctx, v9DatasetsDatasetWorkloadId, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9DatasetsDatasetWorkloadId := "v9DatasetsDatasetWorkloadId_example" // string | Retrieve the workload.
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev9DatasetsDatasetWorkload(context.Background(), v9DatasetsDatasetWorkloadId, dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev9DatasetsDatasetWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev9DatasetsDatasetWorkload`: V9DatasetsDatasetWorkloads
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev9DatasetsDatasetWorkload`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v9DatasetsDatasetWorkloadId** | **string** | Retrieve the workload. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev9DatasetsDatasetWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V9DatasetsDatasetWorkloads**](V9DatasetsDatasetWorkloads.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev9PerformanceDataset

> V10PerformanceDatasetsExtended GetPerformancev9PerformanceDataset(ctx, v9PerformanceDatasetId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9PerformanceDatasetId := "v9PerformanceDatasetId_example" // string | Retrieve the performance dataset.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev9PerformanceDataset(context.Background(), v9PerformanceDatasetId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev9PerformanceDataset``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev9PerformanceDataset`: V10PerformanceDatasetsExtended
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev9PerformanceDataset`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v9PerformanceDatasetId** | **string** | Retrieve the performance dataset. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev9PerformanceDatasetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V10PerformanceDatasetsExtended**](V10PerformanceDatasetsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev9PerformanceMetric

> V10PerformanceMetricsExtended GetPerformancev9PerformanceMetric(ctx, v9PerformanceMetricId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9PerformanceMetricId := "v9PerformanceMetricId_example" // string | View a single performance metric.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev9PerformanceMetric(context.Background(), v9PerformanceMetricId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev9PerformanceMetric``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev9PerformanceMetric`: V10PerformanceMetricsExtended
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev9PerformanceMetric`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v9PerformanceMetricId** | **string** | View a single performance metric. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev9PerformanceMetricRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V10PerformanceMetricsExtended**](V10PerformanceMetricsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev9PerformanceMetrics

> V10PerformanceMetrics GetPerformancev9PerformanceMetrics(ctx).Sort(sort).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev9PerformanceMetrics(context.Background()).Sort(sort).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev9PerformanceMetrics``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev9PerformanceMetrics`: V10PerformanceMetrics
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev9PerformanceMetrics`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev9PerformanceMetricsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V10PerformanceMetrics**](V10PerformanceMetrics.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetPerformancev9PerformanceSettings

> V10PerformanceSettings GetPerformancev9PerformanceSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.GetPerformancev9PerformanceSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.GetPerformancev9PerformanceSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPerformancev9PerformanceSettings`: V10PerformanceSettings
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.GetPerformancev9PerformanceSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetPerformancev9PerformanceSettingsRequest struct via the builder pattern


### Return type

[**V10PerformanceSettings**](V10PerformanceSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListPerformancev10PerformanceDatasets

> V10PerformanceDatasets ListPerformancev10PerformanceDatasets(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.ListPerformancev10PerformanceDatasets(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.ListPerformancev10PerformanceDatasets``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListPerformancev10PerformanceDatasets`: V10PerformanceDatasets
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.ListPerformancev10PerformanceDatasets`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListPerformancev10PerformanceDatasetsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V10PerformanceDatasets**](V10PerformanceDatasets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListPerformancev12PerformanceDatasets

> V10PerformanceDatasets ListPerformancev12PerformanceDatasets(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.ListPerformancev12PerformanceDatasets(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.ListPerformancev12PerformanceDatasets``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListPerformancev12PerformanceDatasets`: V10PerformanceDatasets
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.ListPerformancev12PerformanceDatasets`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListPerformancev12PerformanceDatasetsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V10PerformanceDatasets**](V10PerformanceDatasets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListPerformancev7PerformanceDatasets

> V7PerformanceDatasets ListPerformancev7PerformanceDatasets(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.ListPerformancev7PerformanceDatasets(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.ListPerformancev7PerformanceDatasets``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListPerformancev7PerformanceDatasets`: V7PerformanceDatasets
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.ListPerformancev7PerformanceDatasets`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListPerformancev7PerformanceDatasetsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V7PerformanceDatasets**](V7PerformanceDatasets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListPerformancev9PerformanceDatasets

> V10PerformanceDatasets ListPerformancev9PerformanceDatasets(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceApi.ListPerformancev9PerformanceDatasets(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.ListPerformancev9PerformanceDatasets``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListPerformancev9PerformanceDatasets`: V10PerformanceDatasets
    fmt.Fprintf(os.Stdout, "Response from `PerformanceApi.ListPerformancev9PerformanceDatasets`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListPerformancev9PerformanceDatasetsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V10PerformanceDatasets**](V10PerformanceDatasets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdatePerformancev10DatasetsDatasetFilter

> UpdatePerformancev10DatasetsDatasetFilter(ctx, v10DatasetsDatasetFilterId, dataset).V10DatasetsDatasetFilter(v10DatasetsDatasetFilter).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10DatasetsDatasetFilterId := "v10DatasetsDatasetFilterId_example" // string | Modify the filter.
    dataset := "dataset_example" // string | 
    v10DatasetsDatasetFilter := *openapiclient.NewV10DatasetsDatasetFilter() // V10DatasetsDatasetFilter | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.UpdatePerformancev10DatasetsDatasetFilter(context.Background(), v10DatasetsDatasetFilterId, dataset).V10DatasetsDatasetFilter(v10DatasetsDatasetFilter).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.UpdatePerformancev10DatasetsDatasetFilter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10DatasetsDatasetFilterId** | **string** | Modify the filter. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdatePerformancev10DatasetsDatasetFilterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v10DatasetsDatasetFilter** | [**V10DatasetsDatasetFilter**](V10DatasetsDatasetFilter.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdatePerformancev10DatasetsDatasetWorkload

> UpdatePerformancev10DatasetsDatasetWorkload(ctx, v10DatasetsDatasetWorkloadId, dataset).V10DatasetsDatasetWorkload(v10DatasetsDatasetWorkload).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10DatasetsDatasetWorkloadId := "v10DatasetsDatasetWorkloadId_example" // string | Modify the workload.
    dataset := "dataset_example" // string | 
    v10DatasetsDatasetWorkload := *openapiclient.NewV10DatasetsDatasetWorkload() // V10DatasetsDatasetWorkload | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.UpdatePerformancev10DatasetsDatasetWorkload(context.Background(), v10DatasetsDatasetWorkloadId, dataset).V10DatasetsDatasetWorkload(v10DatasetsDatasetWorkload).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.UpdatePerformancev10DatasetsDatasetWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10DatasetsDatasetWorkloadId** | **string** | Modify the workload. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdatePerformancev10DatasetsDatasetWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v10DatasetsDatasetWorkload** | [**V10DatasetsDatasetWorkload**](V10DatasetsDatasetWorkload.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdatePerformancev10PerformanceDataset

> UpdatePerformancev10PerformanceDataset(ctx, v10PerformanceDatasetId).V10PerformanceDataset(v10PerformanceDataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10PerformanceDatasetId := "v10PerformanceDatasetId_example" // string | Modify the name of the performance dataset.
    v10PerformanceDataset := *openapiclient.NewV10PerformanceDatasetExtendedExtended() // V10PerformanceDatasetExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.UpdatePerformancev10PerformanceDataset(context.Background(), v10PerformanceDatasetId).V10PerformanceDataset(v10PerformanceDataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.UpdatePerformancev10PerformanceDataset``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10PerformanceDatasetId** | **string** | Modify the name of the performance dataset. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdatePerformancev10PerformanceDatasetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v10PerformanceDataset** | [**V10PerformanceDatasetExtendedExtended**](V10PerformanceDatasetExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdatePerformancev10PerformanceSettings

> UpdatePerformancev10PerformanceSettings(ctx).V10PerformanceSettings(v10PerformanceSettings).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10PerformanceSettings := *openapiclient.NewV10PerformanceSettingsExtended() // V10PerformanceSettingsExtended | 
    force := true // bool | Allow modification of settings outside of recommended limits (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.UpdatePerformancev10PerformanceSettings(context.Background()).V10PerformanceSettings(v10PerformanceSettings).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.UpdatePerformancev10PerformanceSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdatePerformancev10PerformanceSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v10PerformanceSettings** | [**V10PerformanceSettingsExtended**](V10PerformanceSettingsExtended.md) |  | 
 **force** | **bool** | Allow modification of settings outside of recommended limits | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdatePerformancev12DatasetsDatasetFilter

> UpdatePerformancev12DatasetsDatasetFilter(ctx, v12DatasetsDatasetFilterId, dataset).V12DatasetsDatasetFilter(v12DatasetsDatasetFilter).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12DatasetsDatasetFilterId := "v12DatasetsDatasetFilterId_example" // string | Modify the filter.
    dataset := "dataset_example" // string | 
    v12DatasetsDatasetFilter := *openapiclient.NewV10DatasetsDatasetFilter() // V10DatasetsDatasetFilter | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.UpdatePerformancev12DatasetsDatasetFilter(context.Background(), v12DatasetsDatasetFilterId, dataset).V12DatasetsDatasetFilter(v12DatasetsDatasetFilter).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.UpdatePerformancev12DatasetsDatasetFilter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12DatasetsDatasetFilterId** | **string** | Modify the filter. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdatePerformancev12DatasetsDatasetFilterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v12DatasetsDatasetFilter** | [**V10DatasetsDatasetFilter**](V10DatasetsDatasetFilter.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdatePerformancev12DatasetsDatasetWorkload

> UpdatePerformancev12DatasetsDatasetWorkload(ctx, v12DatasetsDatasetWorkloadId, dataset).V12DatasetsDatasetWorkload(v12DatasetsDatasetWorkload).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12DatasetsDatasetWorkloadId := "v12DatasetsDatasetWorkloadId_example" // string | Modify the workload.
    dataset := "dataset_example" // string | 
    v12DatasetsDatasetWorkload := *openapiclient.NewV10DatasetsDatasetWorkload() // V10DatasetsDatasetWorkload | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.UpdatePerformancev12DatasetsDatasetWorkload(context.Background(), v12DatasetsDatasetWorkloadId, dataset).V12DatasetsDatasetWorkload(v12DatasetsDatasetWorkload).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.UpdatePerformancev12DatasetsDatasetWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12DatasetsDatasetWorkloadId** | **string** | Modify the workload. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdatePerformancev12DatasetsDatasetWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v12DatasetsDatasetWorkload** | [**V10DatasetsDatasetWorkload**](V10DatasetsDatasetWorkload.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdatePerformancev12PerformanceDataset

> UpdatePerformancev12PerformanceDataset(ctx, v12PerformanceDatasetId).V12PerformanceDataset(v12PerformanceDataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12PerformanceDatasetId := "v12PerformanceDatasetId_example" // string | Modify the name of the performance dataset.
    v12PerformanceDataset := *openapiclient.NewV10PerformanceDatasetExtendedExtended() // V10PerformanceDatasetExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.UpdatePerformancev12PerformanceDataset(context.Background(), v12PerformanceDatasetId).V12PerformanceDataset(v12PerformanceDataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.UpdatePerformancev12PerformanceDataset``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12PerformanceDatasetId** | **string** | Modify the name of the performance dataset. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdatePerformancev12PerformanceDatasetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v12PerformanceDataset** | [**V10PerformanceDatasetExtendedExtended**](V10PerformanceDatasetExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdatePerformancev12PerformanceSettings

> UpdatePerformancev12PerformanceSettings(ctx).V12PerformanceSettings(v12PerformanceSettings).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12PerformanceSettings := *openapiclient.NewV10PerformanceSettingsExtended() // V10PerformanceSettingsExtended | 
    force := true // bool | Allow modification of settings outside of recommended limits (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.UpdatePerformancev12PerformanceSettings(context.Background()).V12PerformanceSettings(v12PerformanceSettings).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.UpdatePerformancev12PerformanceSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdatePerformancev12PerformanceSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12PerformanceSettings** | [**V10PerformanceSettingsExtended**](V10PerformanceSettingsExtended.md) |  | 
 **force** | **bool** | Allow modification of settings outside of recommended limits | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdatePerformancev16DatasetsDatasetWorkload

> UpdatePerformancev16DatasetsDatasetWorkload(ctx, v16DatasetsDatasetWorkloadId, dataset).V16DatasetsDatasetWorkload(v16DatasetsDatasetWorkload).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16DatasetsDatasetWorkloadId := "v16DatasetsDatasetWorkloadId_example" // string | Modify the workload.
    dataset := "dataset_example" // string | 
    v16DatasetsDatasetWorkload := *openapiclient.NewV16DatasetsDatasetWorkload() // V16DatasetsDatasetWorkload | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.UpdatePerformancev16DatasetsDatasetWorkload(context.Background(), v16DatasetsDatasetWorkloadId, dataset).V16DatasetsDatasetWorkload(v16DatasetsDatasetWorkload).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.UpdatePerformancev16DatasetsDatasetWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v16DatasetsDatasetWorkloadId** | **string** | Modify the workload. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdatePerformancev16DatasetsDatasetWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v16DatasetsDatasetWorkload** | [**V16DatasetsDatasetWorkload**](V16DatasetsDatasetWorkload.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdatePerformancev16PerformanceSettings

> UpdatePerformancev16PerformanceSettings(ctx).V16PerformanceSettings(v16PerformanceSettings).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16PerformanceSettings := *openapiclient.NewV16PerformanceSettingsExtended() // V16PerformanceSettingsExtended | 
    force := true // bool | Allow modification of settings outside of recommended limits (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.UpdatePerformancev16PerformanceSettings(context.Background()).V16PerformanceSettings(v16PerformanceSettings).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.UpdatePerformancev16PerformanceSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdatePerformancev16PerformanceSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16PerformanceSettings** | [**V16PerformanceSettingsExtended**](V16PerformanceSettingsExtended.md) |  | 
 **force** | **bool** | Allow modification of settings outside of recommended limits | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdatePerformancev7DatasetsDatasetFilter

> UpdatePerformancev7DatasetsDatasetFilter(ctx, v7DatasetsDatasetFilterId, dataset).V7DatasetsDatasetFilter(v7DatasetsDatasetFilter).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7DatasetsDatasetFilterId := "v7DatasetsDatasetFilterId_example" // string | Modify the filter.
    dataset := "dataset_example" // string | 
    v7DatasetsDatasetFilter := *openapiclient.NewV10DatasetsDatasetFilter() // V10DatasetsDatasetFilter | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.UpdatePerformancev7DatasetsDatasetFilter(context.Background(), v7DatasetsDatasetFilterId, dataset).V7DatasetsDatasetFilter(v7DatasetsDatasetFilter).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.UpdatePerformancev7DatasetsDatasetFilter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7DatasetsDatasetFilterId** | **string** | Modify the filter. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdatePerformancev7DatasetsDatasetFilterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v7DatasetsDatasetFilter** | [**V10DatasetsDatasetFilter**](V10DatasetsDatasetFilter.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdatePerformancev7DatasetsDatasetWorkload

> UpdatePerformancev7DatasetsDatasetWorkload(ctx, v7DatasetsDatasetWorkloadId, dataset).V7DatasetsDatasetWorkload(v7DatasetsDatasetWorkload).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7DatasetsDatasetWorkloadId := "v7DatasetsDatasetWorkloadId_example" // string | Modify the workload.
    dataset := "dataset_example" // string | 
    v7DatasetsDatasetWorkload := *openapiclient.NewV10DatasetsDatasetWorkload() // V10DatasetsDatasetWorkload | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.UpdatePerformancev7DatasetsDatasetWorkload(context.Background(), v7DatasetsDatasetWorkloadId, dataset).V7DatasetsDatasetWorkload(v7DatasetsDatasetWorkload).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.UpdatePerformancev7DatasetsDatasetWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7DatasetsDatasetWorkloadId** | **string** | Modify the workload. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdatePerformancev7DatasetsDatasetWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v7DatasetsDatasetWorkload** | [**V10DatasetsDatasetWorkload**](V10DatasetsDatasetWorkload.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdatePerformancev7PerformanceDataset

> UpdatePerformancev7PerformanceDataset(ctx, v7PerformanceDatasetId).V7PerformanceDataset(v7PerformanceDataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7PerformanceDatasetId := "v7PerformanceDatasetId_example" // string | Modify the name of the performance dataset.
    v7PerformanceDataset := *openapiclient.NewV10PerformanceDatasetExtendedExtended() // V10PerformanceDatasetExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.UpdatePerformancev7PerformanceDataset(context.Background(), v7PerformanceDatasetId).V7PerformanceDataset(v7PerformanceDataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.UpdatePerformancev7PerformanceDataset``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7PerformanceDatasetId** | **string** | Modify the name of the performance dataset. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdatePerformancev7PerformanceDatasetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7PerformanceDataset** | [**V10PerformanceDatasetExtendedExtended**](V10PerformanceDatasetExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdatePerformancev7PerformanceSettings

> UpdatePerformancev7PerformanceSettings(ctx).V7PerformanceSettings(v7PerformanceSettings).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7PerformanceSettings := *openapiclient.NewV10PerformanceSettingsExtended() // V10PerformanceSettingsExtended | 
    force := true // bool | Allow modification of settings outside of recommended limits (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.UpdatePerformancev7PerformanceSettings(context.Background()).V7PerformanceSettings(v7PerformanceSettings).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.UpdatePerformancev7PerformanceSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdatePerformancev7PerformanceSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7PerformanceSettings** | [**V10PerformanceSettingsExtended**](V10PerformanceSettingsExtended.md) |  | 
 **force** | **bool** | Allow modification of settings outside of recommended limits | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdatePerformancev9DatasetsDatasetFilter

> UpdatePerformancev9DatasetsDatasetFilter(ctx, v9DatasetsDatasetFilterId, dataset).V9DatasetsDatasetFilter(v9DatasetsDatasetFilter).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9DatasetsDatasetFilterId := "v9DatasetsDatasetFilterId_example" // string | Modify the filter.
    dataset := "dataset_example" // string | 
    v9DatasetsDatasetFilter := *openapiclient.NewV10DatasetsDatasetFilter() // V10DatasetsDatasetFilter | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.UpdatePerformancev9DatasetsDatasetFilter(context.Background(), v9DatasetsDatasetFilterId, dataset).V9DatasetsDatasetFilter(v9DatasetsDatasetFilter).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.UpdatePerformancev9DatasetsDatasetFilter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v9DatasetsDatasetFilterId** | **string** | Modify the filter. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdatePerformancev9DatasetsDatasetFilterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v9DatasetsDatasetFilter** | [**V10DatasetsDatasetFilter**](V10DatasetsDatasetFilter.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdatePerformancev9DatasetsDatasetWorkload

> UpdatePerformancev9DatasetsDatasetWorkload(ctx, v9DatasetsDatasetWorkloadId, dataset).V9DatasetsDatasetWorkload(v9DatasetsDatasetWorkload).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9DatasetsDatasetWorkloadId := "v9DatasetsDatasetWorkloadId_example" // string | Modify the workload.
    dataset := "dataset_example" // string | 
    v9DatasetsDatasetWorkload := *openapiclient.NewV10DatasetsDatasetWorkload() // V10DatasetsDatasetWorkload | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.UpdatePerformancev9DatasetsDatasetWorkload(context.Background(), v9DatasetsDatasetWorkloadId, dataset).V9DatasetsDatasetWorkload(v9DatasetsDatasetWorkload).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.UpdatePerformancev9DatasetsDatasetWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v9DatasetsDatasetWorkloadId** | **string** | Modify the workload. | 
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdatePerformancev9DatasetsDatasetWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v9DatasetsDatasetWorkload** | [**V10DatasetsDatasetWorkload**](V10DatasetsDatasetWorkload.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdatePerformancev9PerformanceDataset

> UpdatePerformancev9PerformanceDataset(ctx, v9PerformanceDatasetId).V9PerformanceDataset(v9PerformanceDataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9PerformanceDatasetId := "v9PerformanceDatasetId_example" // string | Modify the name of the performance dataset.
    v9PerformanceDataset := *openapiclient.NewV10PerformanceDatasetExtendedExtended() // V10PerformanceDatasetExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.UpdatePerformancev9PerformanceDataset(context.Background(), v9PerformanceDatasetId).V9PerformanceDataset(v9PerformanceDataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.UpdatePerformancev9PerformanceDataset``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v9PerformanceDatasetId** | **string** | Modify the name of the performance dataset. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdatePerformancev9PerformanceDatasetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v9PerformanceDataset** | [**V10PerformanceDatasetExtendedExtended**](V10PerformanceDatasetExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdatePerformancev9PerformanceSettings

> UpdatePerformancev9PerformanceSettings(ctx).V9PerformanceSettings(v9PerformanceSettings).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9PerformanceSettings := *openapiclient.NewV10PerformanceSettingsExtended() // V10PerformanceSettingsExtended | 
    force := true // bool | Allow modification of settings outside of recommended limits (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceApi.UpdatePerformancev9PerformanceSettings(context.Background()).V9PerformanceSettings(v9PerformanceSettings).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceApi.UpdatePerformancev9PerformanceSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdatePerformancev9PerformanceSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v9PerformanceSettings** | [**V10PerformanceSettingsExtended**](V10PerformanceSettingsExtended.md) |  | 
 **force** | **bool** | Allow modification of settings outside of recommended limits | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

