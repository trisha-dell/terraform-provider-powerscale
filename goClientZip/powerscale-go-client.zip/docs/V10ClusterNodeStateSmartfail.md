# V10ClusterNodeStateSmartfail

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Dead** | Pointer to **bool** | This node is dead (dead_devs). | [optional] 
**Down** | Pointer to **bool** | This node is down (down_devs). | [optional] 
**InCluster** | Pointer to **bool** | This node is in the cluster (all_devs). | [optional] 
**Readonly** | Pointer to **bool** | This node is readonly (ro_devs). | [optional] 
**ShutdownReadonly** | Pointer to **bool** | This node is shutdown readonly (down_devs). | [optional] 
**Smartfailed** | Pointer to **bool** | This node is smartfailed (soft_devs). | [optional] 

## Methods

### NewV10ClusterNodeStateSmartfail

`func NewV10ClusterNodeStateSmartfail() *V10ClusterNodeStateSmartfail`

NewV10ClusterNodeStateSmartfail instantiates a new V10ClusterNodeStateSmartfail object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeStateSmartfailWithDefaults

`func NewV10ClusterNodeStateSmartfailWithDefaults() *V10ClusterNodeStateSmartfail`

NewV10ClusterNodeStateSmartfailWithDefaults instantiates a new V10ClusterNodeStateSmartfail object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDead

`func (o *V10ClusterNodeStateSmartfail) GetDead() bool`

GetDead returns the Dead field if non-nil, zero value otherwise.

### GetDeadOk

`func (o *V10ClusterNodeStateSmartfail) GetDeadOk() (*bool, bool)`

GetDeadOk returns a tuple with the Dead field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDead

`func (o *V10ClusterNodeStateSmartfail) SetDead(v bool)`

SetDead sets Dead field to given value.

### HasDead

`func (o *V10ClusterNodeStateSmartfail) HasDead() bool`

HasDead returns a boolean if a field has been set.

### GetDown

`func (o *V10ClusterNodeStateSmartfail) GetDown() bool`

GetDown returns the Down field if non-nil, zero value otherwise.

### GetDownOk

`func (o *V10ClusterNodeStateSmartfail) GetDownOk() (*bool, bool)`

GetDownOk returns a tuple with the Down field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDown

`func (o *V10ClusterNodeStateSmartfail) SetDown(v bool)`

SetDown sets Down field to given value.

### HasDown

`func (o *V10ClusterNodeStateSmartfail) HasDown() bool`

HasDown returns a boolean if a field has been set.

### GetInCluster

`func (o *V10ClusterNodeStateSmartfail) GetInCluster() bool`

GetInCluster returns the InCluster field if non-nil, zero value otherwise.

### GetInClusterOk

`func (o *V10ClusterNodeStateSmartfail) GetInClusterOk() (*bool, bool)`

GetInClusterOk returns a tuple with the InCluster field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInCluster

`func (o *V10ClusterNodeStateSmartfail) SetInCluster(v bool)`

SetInCluster sets InCluster field to given value.

### HasInCluster

`func (o *V10ClusterNodeStateSmartfail) HasInCluster() bool`

HasInCluster returns a boolean if a field has been set.

### GetReadonly

`func (o *V10ClusterNodeStateSmartfail) GetReadonly() bool`

GetReadonly returns the Readonly field if non-nil, zero value otherwise.

### GetReadonlyOk

`func (o *V10ClusterNodeStateSmartfail) GetReadonlyOk() (*bool, bool)`

GetReadonlyOk returns a tuple with the Readonly field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadonly

`func (o *V10ClusterNodeStateSmartfail) SetReadonly(v bool)`

SetReadonly sets Readonly field to given value.

### HasReadonly

`func (o *V10ClusterNodeStateSmartfail) HasReadonly() bool`

HasReadonly returns a boolean if a field has been set.

### GetShutdownReadonly

`func (o *V10ClusterNodeStateSmartfail) GetShutdownReadonly() bool`

GetShutdownReadonly returns the ShutdownReadonly field if non-nil, zero value otherwise.

### GetShutdownReadonlyOk

`func (o *V10ClusterNodeStateSmartfail) GetShutdownReadonlyOk() (*bool, bool)`

GetShutdownReadonlyOk returns a tuple with the ShutdownReadonly field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShutdownReadonly

`func (o *V10ClusterNodeStateSmartfail) SetShutdownReadonly(v bool)`

SetShutdownReadonly sets ShutdownReadonly field to given value.

### HasShutdownReadonly

`func (o *V10ClusterNodeStateSmartfail) HasShutdownReadonly() bool`

HasShutdownReadonly returns a boolean if a field has been set.

### GetSmartfailed

`func (o *V10ClusterNodeStateSmartfail) GetSmartfailed() bool`

GetSmartfailed returns the Smartfailed field if non-nil, zero value otherwise.

### GetSmartfailedOk

`func (o *V10ClusterNodeStateSmartfail) GetSmartfailedOk() (*bool, bool)`

GetSmartfailedOk returns a tuple with the Smartfailed field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmartfailed

`func (o *V10ClusterNodeStateSmartfail) SetSmartfailed(v bool)`

SetSmartfailed sets Smartfailed field to given value.

### HasSmartfailed

`func (o *V10ClusterNodeStateSmartfail) HasSmartfailed() bool`

HasSmartfailed returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


