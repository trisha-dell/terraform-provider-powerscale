# Createv12AdsProviderSearchItemResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Objects** | Pointer to [**[]Createv12AdsProviderSearchItemResponseObject**](Createv12AdsProviderSearchItemResponseObject.md) |  | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 

## Methods

### NewCreatev12AdsProviderSearchItemResponse

`func NewCreatev12AdsProviderSearchItemResponse() *Createv12AdsProviderSearchItemResponse`

NewCreatev12AdsProviderSearchItemResponse instantiates a new Createv12AdsProviderSearchItemResponse object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev12AdsProviderSearchItemResponseWithDefaults

`func NewCreatev12AdsProviderSearchItemResponseWithDefaults() *Createv12AdsProviderSearchItemResponse`

NewCreatev12AdsProviderSearchItemResponseWithDefaults instantiates a new Createv12AdsProviderSearchItemResponse object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetObjects

`func (o *Createv12AdsProviderSearchItemResponse) GetObjects() []Createv12AdsProviderSearchItemResponseObject`

GetObjects returns the Objects field if non-nil, zero value otherwise.

### GetObjectsOk

`func (o *Createv12AdsProviderSearchItemResponse) GetObjectsOk() (*[]Createv12AdsProviderSearchItemResponseObject, bool)`

GetObjectsOk returns a tuple with the Objects field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetObjects

`func (o *Createv12AdsProviderSearchItemResponse) SetObjects(v []Createv12AdsProviderSearchItemResponseObject)`

SetObjects sets Objects field to given value.

### HasObjects

`func (o *Createv12AdsProviderSearchItemResponse) HasObjects() bool`

HasObjects returns a boolean if a field has been set.

### GetResume

`func (o *Createv12AdsProviderSearchItemResponse) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *Createv12AdsProviderSearchItemResponse) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *Createv12AdsProviderSearchItemResponse) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *Createv12AdsProviderSearchItemResponse) HasResume() bool`

HasResume returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


