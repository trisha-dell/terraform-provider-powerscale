# V10ClusterNodeStatusBatterystatus

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LastTestTime1** | Pointer to **string** | The last battery test time for battery 1. | [optional] 
**LastTestTime2** | Pointer to **string** | The last battery test time for battery 2. | [optional] 
**NextTestTime1** | Pointer to **string** | The next checkup for battery 1. | [optional] 
**NextTestTime2** | Pointer to **string** | The next checkup for battery 2. | [optional] 
**Present** | Pointer to **bool** | Node has battery status. | [optional] 
**Result1** | Pointer to **string** | The result of the last battery test for battery 1. | [optional] 
**Result2** | Pointer to **string** | The result of the last battery test for battery 2. | [optional] 
**Status1** | Pointer to **string** | The status of battery 1. | [optional] 
**Status2** | Pointer to **string** | The status of battery 2. | [optional] 
**Supported** | Pointer to **bool** | Node supports battery status. | [optional] 

## Methods

### NewV10ClusterNodeStatusBatterystatus

`func NewV10ClusterNodeStatusBatterystatus() *V10ClusterNodeStatusBatterystatus`

NewV10ClusterNodeStatusBatterystatus instantiates a new V10ClusterNodeStatusBatterystatus object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeStatusBatterystatusWithDefaults

`func NewV10ClusterNodeStatusBatterystatusWithDefaults() *V10ClusterNodeStatusBatterystatus`

NewV10ClusterNodeStatusBatterystatusWithDefaults instantiates a new V10ClusterNodeStatusBatterystatus object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetLastTestTime1

`func (o *V10ClusterNodeStatusBatterystatus) GetLastTestTime1() string`

GetLastTestTime1 returns the LastTestTime1 field if non-nil, zero value otherwise.

### GetLastTestTime1Ok

`func (o *V10ClusterNodeStatusBatterystatus) GetLastTestTime1Ok() (*string, bool)`

GetLastTestTime1Ok returns a tuple with the LastTestTime1 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastTestTime1

`func (o *V10ClusterNodeStatusBatterystatus) SetLastTestTime1(v string)`

SetLastTestTime1 sets LastTestTime1 field to given value.

### HasLastTestTime1

`func (o *V10ClusterNodeStatusBatterystatus) HasLastTestTime1() bool`

HasLastTestTime1 returns a boolean if a field has been set.

### GetLastTestTime2

`func (o *V10ClusterNodeStatusBatterystatus) GetLastTestTime2() string`

GetLastTestTime2 returns the LastTestTime2 field if non-nil, zero value otherwise.

### GetLastTestTime2Ok

`func (o *V10ClusterNodeStatusBatterystatus) GetLastTestTime2Ok() (*string, bool)`

GetLastTestTime2Ok returns a tuple with the LastTestTime2 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastTestTime2

`func (o *V10ClusterNodeStatusBatterystatus) SetLastTestTime2(v string)`

SetLastTestTime2 sets LastTestTime2 field to given value.

### HasLastTestTime2

`func (o *V10ClusterNodeStatusBatterystatus) HasLastTestTime2() bool`

HasLastTestTime2 returns a boolean if a field has been set.

### GetNextTestTime1

`func (o *V10ClusterNodeStatusBatterystatus) GetNextTestTime1() string`

GetNextTestTime1 returns the NextTestTime1 field if non-nil, zero value otherwise.

### GetNextTestTime1Ok

`func (o *V10ClusterNodeStatusBatterystatus) GetNextTestTime1Ok() (*string, bool)`

GetNextTestTime1Ok returns a tuple with the NextTestTime1 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNextTestTime1

`func (o *V10ClusterNodeStatusBatterystatus) SetNextTestTime1(v string)`

SetNextTestTime1 sets NextTestTime1 field to given value.

### HasNextTestTime1

`func (o *V10ClusterNodeStatusBatterystatus) HasNextTestTime1() bool`

HasNextTestTime1 returns a boolean if a field has been set.

### GetNextTestTime2

`func (o *V10ClusterNodeStatusBatterystatus) GetNextTestTime2() string`

GetNextTestTime2 returns the NextTestTime2 field if non-nil, zero value otherwise.

### GetNextTestTime2Ok

`func (o *V10ClusterNodeStatusBatterystatus) GetNextTestTime2Ok() (*string, bool)`

GetNextTestTime2Ok returns a tuple with the NextTestTime2 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNextTestTime2

`func (o *V10ClusterNodeStatusBatterystatus) SetNextTestTime2(v string)`

SetNextTestTime2 sets NextTestTime2 field to given value.

### HasNextTestTime2

`func (o *V10ClusterNodeStatusBatterystatus) HasNextTestTime2() bool`

HasNextTestTime2 returns a boolean if a field has been set.

### GetPresent

`func (o *V10ClusterNodeStatusBatterystatus) GetPresent() bool`

GetPresent returns the Present field if non-nil, zero value otherwise.

### GetPresentOk

`func (o *V10ClusterNodeStatusBatterystatus) GetPresentOk() (*bool, bool)`

GetPresentOk returns a tuple with the Present field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPresent

`func (o *V10ClusterNodeStatusBatterystatus) SetPresent(v bool)`

SetPresent sets Present field to given value.

### HasPresent

`func (o *V10ClusterNodeStatusBatterystatus) HasPresent() bool`

HasPresent returns a boolean if a field has been set.

### GetResult1

`func (o *V10ClusterNodeStatusBatterystatus) GetResult1() string`

GetResult1 returns the Result1 field if non-nil, zero value otherwise.

### GetResult1Ok

`func (o *V10ClusterNodeStatusBatterystatus) GetResult1Ok() (*string, bool)`

GetResult1Ok returns a tuple with the Result1 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResult1

`func (o *V10ClusterNodeStatusBatterystatus) SetResult1(v string)`

SetResult1 sets Result1 field to given value.

### HasResult1

`func (o *V10ClusterNodeStatusBatterystatus) HasResult1() bool`

HasResult1 returns a boolean if a field has been set.

### GetResult2

`func (o *V10ClusterNodeStatusBatterystatus) GetResult2() string`

GetResult2 returns the Result2 field if non-nil, zero value otherwise.

### GetResult2Ok

`func (o *V10ClusterNodeStatusBatterystatus) GetResult2Ok() (*string, bool)`

GetResult2Ok returns a tuple with the Result2 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResult2

`func (o *V10ClusterNodeStatusBatterystatus) SetResult2(v string)`

SetResult2 sets Result2 field to given value.

### HasResult2

`func (o *V10ClusterNodeStatusBatterystatus) HasResult2() bool`

HasResult2 returns a boolean if a field has been set.

### GetStatus1

`func (o *V10ClusterNodeStatusBatterystatus) GetStatus1() string`

GetStatus1 returns the Status1 field if non-nil, zero value otherwise.

### GetStatus1Ok

`func (o *V10ClusterNodeStatusBatterystatus) GetStatus1Ok() (*string, bool)`

GetStatus1Ok returns a tuple with the Status1 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus1

`func (o *V10ClusterNodeStatusBatterystatus) SetStatus1(v string)`

SetStatus1 sets Status1 field to given value.

### HasStatus1

`func (o *V10ClusterNodeStatusBatterystatus) HasStatus1() bool`

HasStatus1 returns a boolean if a field has been set.

### GetStatus2

`func (o *V10ClusterNodeStatusBatterystatus) GetStatus2() string`

GetStatus2 returns the Status2 field if non-nil, zero value otherwise.

### GetStatus2Ok

`func (o *V10ClusterNodeStatusBatterystatus) GetStatus2Ok() (*string, bool)`

GetStatus2Ok returns a tuple with the Status2 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus2

`func (o *V10ClusterNodeStatusBatterystatus) SetStatus2(v string)`

SetStatus2 sets Status2 field to given value.

### HasStatus2

`func (o *V10ClusterNodeStatusBatterystatus) HasStatus2() bool`

HasStatus2 returns a boolean if a field has been set.

### GetSupported

`func (o *V10ClusterNodeStatusBatterystatus) GetSupported() bool`

GetSupported returns the Supported field if non-nil, zero value otherwise.

### GetSupportedOk

`func (o *V10ClusterNodeStatusBatterystatus) GetSupportedOk() (*bool, bool)`

GetSupportedOk returns a tuple with the Supported field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSupported

`func (o *V10ClusterNodeStatusBatterystatus) SetSupported(v bool)`

SetSupported sets Supported field to given value.

### HasSupported

`func (o *V10ClusterNodeStatusBatterystatus) HasSupported() bool`

HasSupported returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


