# V12EventMaintenance

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**History** | Pointer to **[]int32** | Start and stop times of maintenance mode, &#39;end&#39; equals 0 indicates that maintenance mode is enabled. | [optional] 
**Maintenance** | Pointer to **bool** | Indicates if maintenance mode is enabled. | [optional] 

## Methods

### NewV12EventMaintenance

`func NewV12EventMaintenance() *V12EventMaintenance`

NewV12EventMaintenance instantiates a new V12EventMaintenance object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12EventMaintenanceWithDefaults

`func NewV12EventMaintenanceWithDefaults() *V12EventMaintenance`

NewV12EventMaintenanceWithDefaults instantiates a new V12EventMaintenance object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetHistory

`func (o *V12EventMaintenance) GetHistory() []int32`

GetHistory returns the History field if non-nil, zero value otherwise.

### GetHistoryOk

`func (o *V12EventMaintenance) GetHistoryOk() (*[]int32, bool)`

GetHistoryOk returns a tuple with the History field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHistory

`func (o *V12EventMaintenance) SetHistory(v []int32)`

SetHistory sets History field to given value.

### HasHistory

`func (o *V12EventMaintenance) HasHistory() bool`

HasHistory returns a boolean if a field has been set.

### GetMaintenance

`func (o *V12EventMaintenance) GetMaintenance() bool`

GetMaintenance returns the Maintenance field if non-nil, zero value otherwise.

### GetMaintenanceOk

`func (o *V12EventMaintenance) GetMaintenanceOk() (*bool, bool)`

GetMaintenanceOk returns a tuple with the Maintenance field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaintenance

`func (o *V12EventMaintenance) SetMaintenance(v bool)`

SetMaintenance sets Maintenance field to given value.

### HasMaintenance

`func (o *V12EventMaintenance) HasMaintenance() bool`

HasMaintenance returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


