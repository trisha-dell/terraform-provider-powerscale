# \SupportassistApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateSupportassistv16SupportassistDataItem**](SupportassistApi.md#CreateSupportassistv16SupportassistDataItem) | **Post** /platform/16/supportassist/data | 
[**CreateSupportassistv16SupportassistPayloadItem**](SupportassistApi.md#CreateSupportassistv16SupportassistPayloadItem) | **Post** /platform/16/supportassist/payload | 
[**CreateSupportassistv16SupportassistTaskItem**](SupportassistApi.md#CreateSupportassistv16SupportassistTaskItem) | **Post** /platform/16/supportassist/task | 
[**CreateSupportassistv17SupportassistTaskItem**](SupportassistApi.md#CreateSupportassistv17SupportassistTaskItem) | **Post** /platform/17/supportassist/task | 
[**DeleteSupportassistv16SupportassistTaskById**](SupportassistApi.md#DeleteSupportassistv16SupportassistTaskById) | **Delete** /platform/16/supportassist/task/{v16SupportassistTaskId} | 
[**DeleteSupportassistv17SupportassistTaskById**](SupportassistApi.md#DeleteSupportassistv17SupportassistTaskById) | **Delete** /platform/17/supportassist/task/{v17SupportassistTaskId} | 
[**GetSupportassistv16SupportassistLicense**](SupportassistApi.md#GetSupportassistv16SupportassistLicense) | **Get** /platform/16/supportassist/license | 
[**GetSupportassistv16SupportassistSettings**](SupportassistApi.md#GetSupportassistv16SupportassistSettings) | **Get** /platform/16/supportassist/settings | 
[**GetSupportassistv16SupportassistStatus**](SupportassistApi.md#GetSupportassistv16SupportassistStatus) | **Get** /platform/16/supportassist/status | 
[**GetSupportassistv16SupportassistTaskById**](SupportassistApi.md#GetSupportassistv16SupportassistTaskById) | **Get** /platform/16/supportassist/task/{v16SupportassistTaskId} | 
[**GetSupportassistv16SupportassistTerms**](SupportassistApi.md#GetSupportassistv16SupportassistTerms) | **Get** /platform/16/supportassist/terms | 
[**GetSupportassistv17SupportassistTaskById**](SupportassistApi.md#GetSupportassistv17SupportassistTaskById) | **Get** /platform/17/supportassist/task/{v17SupportassistTaskId} | 
[**ListSupportassistv16SupportassistTask**](SupportassistApi.md#ListSupportassistv16SupportassistTask) | **Get** /platform/16/supportassist/task | 
[**ListSupportassistv17SupportassistTask**](SupportassistApi.md#ListSupportassistv17SupportassistTask) | **Get** /platform/17/supportassist/task | 
[**UpdateSupportassistv16SupportassistSettings**](SupportassistApi.md#UpdateSupportassistv16SupportassistSettings) | **Put** /platform/16/supportassist/settings | 
[**UpdateSupportassistv16SupportassistStatus**](SupportassistApi.md#UpdateSupportassistv16SupportassistStatus) | **Put** /platform/16/supportassist/status | 
[**UpdateSupportassistv16SupportassistTerms**](SupportassistApi.md#UpdateSupportassistv16SupportassistTerms) | **Put** /platform/16/supportassist/terms | 



## CreateSupportassistv16SupportassistDataItem

> CreateResponse CreateSupportassistv16SupportassistDataItem(ctx).V16SupportassistDataItem(v16SupportassistDataItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16SupportassistDataItem := *openapiclient.NewV16SupportassistDataItem("PayloadType_example", "PayloadVersion_example") // V16SupportassistDataItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SupportassistApi.CreateSupportassistv16SupportassistDataItem(context.Background()).V16SupportassistDataItem(v16SupportassistDataItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SupportassistApi.CreateSupportassistv16SupportassistDataItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSupportassistv16SupportassistDataItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `SupportassistApi.CreateSupportassistv16SupportassistDataItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSupportassistv16SupportassistDataItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16SupportassistDataItem** | [**V16SupportassistDataItem**](V16SupportassistDataItem.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSupportassistv16SupportassistPayloadItem

> CreateResponse CreateSupportassistv16SupportassistPayloadItem(ctx).V16SupportassistPayloadItem(v16SupportassistPayloadItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16SupportassistPayloadItem := *openapiclient.NewV16SupportassistPayloadItem("PayloadType_example") // V16SupportassistPayloadItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SupportassistApi.CreateSupportassistv16SupportassistPayloadItem(context.Background()).V16SupportassistPayloadItem(v16SupportassistPayloadItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SupportassistApi.CreateSupportassistv16SupportassistPayloadItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSupportassistv16SupportassistPayloadItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `SupportassistApi.CreateSupportassistv16SupportassistPayloadItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSupportassistv16SupportassistPayloadItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16SupportassistPayloadItem** | [**V16SupportassistPayloadItem**](V16SupportassistPayloadItem.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSupportassistv16SupportassistTaskItem

> CreateTaskResponse CreateSupportassistv16SupportassistTaskItem(ctx).V16SupportassistTaskItem(v16SupportassistTaskItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16SupportassistTaskItem := *openapiclient.NewV16SupportassistTaskItem("Source_example") // V16SupportassistTaskItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SupportassistApi.CreateSupportassistv16SupportassistTaskItem(context.Background()).V16SupportassistTaskItem(v16SupportassistTaskItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SupportassistApi.CreateSupportassistv16SupportassistTaskItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSupportassistv16SupportassistTaskItem`: CreateTaskResponse
    fmt.Fprintf(os.Stdout, "Response from `SupportassistApi.CreateSupportassistv16SupportassistTaskItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSupportassistv16SupportassistTaskItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16SupportassistTaskItem** | [**V16SupportassistTaskItem**](V16SupportassistTaskItem.md) |  | 

### Return type

[**CreateTaskResponse**](CreateTaskResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSupportassistv17SupportassistTaskItem

> CreateTaskResponse CreateSupportassistv17SupportassistTaskItem(ctx).V17SupportassistTaskItem(v17SupportassistTaskItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v17SupportassistTaskItem := *openapiclient.NewV16SupportassistTaskItem("Source_example") // V16SupportassistTaskItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SupportassistApi.CreateSupportassistv17SupportassistTaskItem(context.Background()).V17SupportassistTaskItem(v17SupportassistTaskItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SupportassistApi.CreateSupportassistv17SupportassistTaskItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSupportassistv17SupportassistTaskItem`: CreateTaskResponse
    fmt.Fprintf(os.Stdout, "Response from `SupportassistApi.CreateSupportassistv17SupportassistTaskItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSupportassistv17SupportassistTaskItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v17SupportassistTaskItem** | [**V16SupportassistTaskItem**](V16SupportassistTaskItem.md) |  | 

### Return type

[**CreateTaskResponse**](CreateTaskResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSupportassistv16SupportassistTaskById

> DeleteSupportassistv16SupportassistTaskById(ctx, v16SupportassistTaskId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16SupportassistTaskId := "v16SupportassistTaskId_example" // string | Delete a SupportAssist task by ID.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SupportassistApi.DeleteSupportassistv16SupportassistTaskById(context.Background(), v16SupportassistTaskId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SupportassistApi.DeleteSupportassistv16SupportassistTaskById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v16SupportassistTaskId** | **string** | Delete a SupportAssist task by ID. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSupportassistv16SupportassistTaskByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSupportassistv17SupportassistTaskById

> DeleteSupportassistv17SupportassistTaskById(ctx, v17SupportassistTaskId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v17SupportassistTaskId := "v17SupportassistTaskId_example" // string | Delete a SupportAssist task by ID.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SupportassistApi.DeleteSupportassistv17SupportassistTaskById(context.Background(), v17SupportassistTaskId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SupportassistApi.DeleteSupportassistv17SupportassistTaskById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v17SupportassistTaskId** | **string** | Delete a SupportAssist task by ID. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSupportassistv17SupportassistTaskByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSupportassistv16SupportassistLicense

> V16SupportassistLicense GetSupportassistv16SupportassistLicense(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SupportassistApi.GetSupportassistv16SupportassistLicense(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SupportassistApi.GetSupportassistv16SupportassistLicense``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSupportassistv16SupportassistLicense`: V16SupportassistLicense
    fmt.Fprintf(os.Stdout, "Response from `SupportassistApi.GetSupportassistv16SupportassistLicense`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetSupportassistv16SupportassistLicenseRequest struct via the builder pattern


### Return type

[**V16SupportassistLicense**](V16SupportassistLicense.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSupportassistv16SupportassistSettings

> V16SupportassistSettings GetSupportassistv16SupportassistSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SupportassistApi.GetSupportassistv16SupportassistSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SupportassistApi.GetSupportassistv16SupportassistSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSupportassistv16SupportassistSettings`: V16SupportassistSettings
    fmt.Fprintf(os.Stdout, "Response from `SupportassistApi.GetSupportassistv16SupportassistSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetSupportassistv16SupportassistSettingsRequest struct via the builder pattern


### Return type

[**V16SupportassistSettings**](V16SupportassistSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSupportassistv16SupportassistStatus

> V16SupportassistStatus GetSupportassistv16SupportassistStatus(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SupportassistApi.GetSupportassistv16SupportassistStatus(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SupportassistApi.GetSupportassistv16SupportassistStatus``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSupportassistv16SupportassistStatus`: V16SupportassistStatus
    fmt.Fprintf(os.Stdout, "Response from `SupportassistApi.GetSupportassistv16SupportassistStatus`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetSupportassistv16SupportassistStatusRequest struct via the builder pattern


### Return type

[**V16SupportassistStatus**](V16SupportassistStatus.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSupportassistv16SupportassistTaskById

> V16SupportassistTaskId GetSupportassistv16SupportassistTaskById(ctx, v16SupportassistTaskId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16SupportassistTaskId := "v16SupportassistTaskId_example" // string | Get the status of a SupportAssist task by ID or all tasks from the specified source.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SupportassistApi.GetSupportassistv16SupportassistTaskById(context.Background(), v16SupportassistTaskId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SupportassistApi.GetSupportassistv16SupportassistTaskById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSupportassistv16SupportassistTaskById`: V16SupportassistTaskId
    fmt.Fprintf(os.Stdout, "Response from `SupportassistApi.GetSupportassistv16SupportassistTaskById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v16SupportassistTaskId** | **string** | Get the status of a SupportAssist task by ID or all tasks from the specified source. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSupportassistv16SupportassistTaskByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V16SupportassistTaskId**](V16SupportassistTaskId.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSupportassistv16SupportassistTerms

> V16SupportassistTerms GetSupportassistv16SupportassistTerms(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SupportassistApi.GetSupportassistv16SupportassistTerms(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SupportassistApi.GetSupportassistv16SupportassistTerms``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSupportassistv16SupportassistTerms`: V16SupportassistTerms
    fmt.Fprintf(os.Stdout, "Response from `SupportassistApi.GetSupportassistv16SupportassistTerms`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetSupportassistv16SupportassistTermsRequest struct via the builder pattern


### Return type

[**V16SupportassistTerms**](V16SupportassistTerms.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSupportassistv17SupportassistTaskById

> V16SupportassistTaskId GetSupportassistv17SupportassistTaskById(ctx, v17SupportassistTaskId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v17SupportassistTaskId := "v17SupportassistTaskId_example" // string | Get the status of a SupportAssist task by ID or all tasks from the specified source.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SupportassistApi.GetSupportassistv17SupportassistTaskById(context.Background(), v17SupportassistTaskId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SupportassistApi.GetSupportassistv17SupportassistTaskById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSupportassistv17SupportassistTaskById`: V16SupportassistTaskId
    fmt.Fprintf(os.Stdout, "Response from `SupportassistApi.GetSupportassistv17SupportassistTaskById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v17SupportassistTaskId** | **string** | Get the status of a SupportAssist task by ID or all tasks from the specified source. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSupportassistv17SupportassistTaskByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V16SupportassistTaskId**](V16SupportassistTaskId.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSupportassistv16SupportassistTask

> V16SupportassistTask ListSupportassistv16SupportassistTask(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SupportassistApi.ListSupportassistv16SupportassistTask(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SupportassistApi.ListSupportassistv16SupportassistTask``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSupportassistv16SupportassistTask`: V16SupportassistTask
    fmt.Fprintf(os.Stdout, "Response from `SupportassistApi.ListSupportassistv16SupportassistTask`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListSupportassistv16SupportassistTaskRequest struct via the builder pattern


### Return type

[**V16SupportassistTask**](V16SupportassistTask.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSupportassistv17SupportassistTask

> V16SupportassistTask ListSupportassistv17SupportassistTask(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SupportassistApi.ListSupportassistv17SupportassistTask(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SupportassistApi.ListSupportassistv17SupportassistTask``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSupportassistv17SupportassistTask`: V16SupportassistTask
    fmt.Fprintf(os.Stdout, "Response from `SupportassistApi.ListSupportassistv17SupportassistTask`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListSupportassistv17SupportassistTaskRequest struct via the builder pattern


### Return type

[**V16SupportassistTask**](V16SupportassistTask.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSupportassistv16SupportassistSettings

> UpdateSupportassistv16SupportassistSettings(ctx).V16SupportassistSettings(v16SupportassistSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16SupportassistSettings := *openapiclient.NewV16SupportassistSettingsExtended() // V16SupportassistSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SupportassistApi.UpdateSupportassistv16SupportassistSettings(context.Background()).V16SupportassistSettings(v16SupportassistSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SupportassistApi.UpdateSupportassistv16SupportassistSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSupportassistv16SupportassistSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16SupportassistSettings** | [**V16SupportassistSettingsExtended**](V16SupportassistSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSupportassistv16SupportassistStatus

> UpdateSupportassistv16SupportassistStatus(ctx).V16SupportassistStatus(v16SupportassistStatus).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16SupportassistStatus := *openapiclient.NewV16SupportassistStatusExtended() // V16SupportassistStatusExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SupportassistApi.UpdateSupportassistv16SupportassistStatus(context.Background()).V16SupportassistStatus(v16SupportassistStatus).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SupportassistApi.UpdateSupportassistv16SupportassistStatus``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSupportassistv16SupportassistStatusRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16SupportassistStatus** | [**V16SupportassistStatusExtended**](V16SupportassistStatusExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSupportassistv16SupportassistTerms

> UpdateSupportassistv16SupportassistTerms(ctx).V16SupportassistTerms(v16SupportassistTerms).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16SupportassistTerms := *openapiclient.NewV16SupportassistTermsExtended(false) // V16SupportassistTermsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SupportassistApi.UpdateSupportassistv16SupportassistTerms(context.Background()).V16SupportassistTerms(v16SupportassistTerms).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SupportassistApi.UpdateSupportassistv16SupportassistTerms``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSupportassistv16SupportassistTermsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16SupportassistTerms** | [**V16SupportassistTermsExtended**](V16SupportassistTermsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

