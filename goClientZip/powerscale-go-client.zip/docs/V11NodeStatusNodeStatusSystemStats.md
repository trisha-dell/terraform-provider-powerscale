# V11NodeStatusNodeStatusSystemStats

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AllScanRequests** | Pointer to **int32** | Total number of scan requests received by the CAVA antivirus system. | [optional] 
**AvgScanBlockTime** | Pointer to **int32** | Average time spent during which the scan requests are blocked. | [optional] 
**AvgScanDuration** | Pointer to **int32** | Average time to scan a file (in milliseconds). | [optional] 
**BatchFileQueueMaxSize** | Pointer to **int32** | Maximum number of files that can be queued in the batch file queue. | [optional] 
**BatchFileQueueSize** | Pointer to **int32** | Number of scan requests queued for scanning in the batch file queue. | [optional] 
**CeeFailureCount** | Pointer to **int32** | Number of scan failure responses received from CEE server. | [optional] 
**CeeInfectedCount** | Pointer to **int32** | Number of scan infected responses received from CEE server. | [optional] 
**CeeSuccessCount** | Pointer to **int32** | Number of scan success responses received from CEE server. | [optional] 
**FastFileQueueMaxSize** | Pointer to **int32** | Maximum number of files that can be queued in the fast file queue. | [optional] 
**FastFileQueueSize** | Pointer to **int32** | Number of scan requests queued for scanning in the fast file queue. | [optional] 
**FilesProcessed** | Pointer to **int32** | Total number of files processed by the CAVA antivirus system. | [optional] 
**FilesSkippedPerFilter** | Pointer to **int32** | Total number of files skipped per filter settings. | [optional] 
**FilesSkippedPerSize** | Pointer to **int32** | Total number of files skipped per maximum size setting. | [optional] 
**JobScanRequests** | Pointer to **int32** | Total number of scan requests received from the job engine. | [optional] 
**ManualScanRequests** | Pointer to **int32** | Total number of scan requests initiated through PAPI. | [optional] 
**OnDemandScanRequests** | Pointer to **int32** | Total number of on-demand (protocol) scan requests received. | [optional] 
**ScanFails** | Pointer to **int32** | Number of scan failures occurred while scanning. | [optional] 
**ScanTimeouts** | Pointer to **int32** | Number of scan timeouts occurred while scanning. | [optional] 
**SlowFileQueueMaxSize** | Pointer to **int32** | Maximum number of files that can be queued in the slow (large/cloudpool) file queue. | [optional] 
**SlowFileQueueSize** | Pointer to **int32** | Number of scan requests queued for scanning in the slow (large/cloudpool) file queue. | [optional] 

## Methods

### NewV11NodeStatusNodeStatusSystemStats

`func NewV11NodeStatusNodeStatusSystemStats() *V11NodeStatusNodeStatusSystemStats`

NewV11NodeStatusNodeStatusSystemStats instantiates a new V11NodeStatusNodeStatusSystemStats object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11NodeStatusNodeStatusSystemStatsWithDefaults

`func NewV11NodeStatusNodeStatusSystemStatsWithDefaults() *V11NodeStatusNodeStatusSystemStats`

NewV11NodeStatusNodeStatusSystemStatsWithDefaults instantiates a new V11NodeStatusNodeStatusSystemStats object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAllScanRequests

`func (o *V11NodeStatusNodeStatusSystemStats) GetAllScanRequests() int32`

GetAllScanRequests returns the AllScanRequests field if non-nil, zero value otherwise.

### GetAllScanRequestsOk

`func (o *V11NodeStatusNodeStatusSystemStats) GetAllScanRequestsOk() (*int32, bool)`

GetAllScanRequestsOk returns a tuple with the AllScanRequests field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllScanRequests

`func (o *V11NodeStatusNodeStatusSystemStats) SetAllScanRequests(v int32)`

SetAllScanRequests sets AllScanRequests field to given value.

### HasAllScanRequests

`func (o *V11NodeStatusNodeStatusSystemStats) HasAllScanRequests() bool`

HasAllScanRequests returns a boolean if a field has been set.

### GetAvgScanBlockTime

`func (o *V11NodeStatusNodeStatusSystemStats) GetAvgScanBlockTime() int32`

GetAvgScanBlockTime returns the AvgScanBlockTime field if non-nil, zero value otherwise.

### GetAvgScanBlockTimeOk

`func (o *V11NodeStatusNodeStatusSystemStats) GetAvgScanBlockTimeOk() (*int32, bool)`

GetAvgScanBlockTimeOk returns a tuple with the AvgScanBlockTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAvgScanBlockTime

`func (o *V11NodeStatusNodeStatusSystemStats) SetAvgScanBlockTime(v int32)`

SetAvgScanBlockTime sets AvgScanBlockTime field to given value.

### HasAvgScanBlockTime

`func (o *V11NodeStatusNodeStatusSystemStats) HasAvgScanBlockTime() bool`

HasAvgScanBlockTime returns a boolean if a field has been set.

### GetAvgScanDuration

`func (o *V11NodeStatusNodeStatusSystemStats) GetAvgScanDuration() int32`

GetAvgScanDuration returns the AvgScanDuration field if non-nil, zero value otherwise.

### GetAvgScanDurationOk

`func (o *V11NodeStatusNodeStatusSystemStats) GetAvgScanDurationOk() (*int32, bool)`

GetAvgScanDurationOk returns a tuple with the AvgScanDuration field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAvgScanDuration

`func (o *V11NodeStatusNodeStatusSystemStats) SetAvgScanDuration(v int32)`

SetAvgScanDuration sets AvgScanDuration field to given value.

### HasAvgScanDuration

`func (o *V11NodeStatusNodeStatusSystemStats) HasAvgScanDuration() bool`

HasAvgScanDuration returns a boolean if a field has been set.

### GetBatchFileQueueMaxSize

`func (o *V11NodeStatusNodeStatusSystemStats) GetBatchFileQueueMaxSize() int32`

GetBatchFileQueueMaxSize returns the BatchFileQueueMaxSize field if non-nil, zero value otherwise.

### GetBatchFileQueueMaxSizeOk

`func (o *V11NodeStatusNodeStatusSystemStats) GetBatchFileQueueMaxSizeOk() (*int32, bool)`

GetBatchFileQueueMaxSizeOk returns a tuple with the BatchFileQueueMaxSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBatchFileQueueMaxSize

`func (o *V11NodeStatusNodeStatusSystemStats) SetBatchFileQueueMaxSize(v int32)`

SetBatchFileQueueMaxSize sets BatchFileQueueMaxSize field to given value.

### HasBatchFileQueueMaxSize

`func (o *V11NodeStatusNodeStatusSystemStats) HasBatchFileQueueMaxSize() bool`

HasBatchFileQueueMaxSize returns a boolean if a field has been set.

### GetBatchFileQueueSize

`func (o *V11NodeStatusNodeStatusSystemStats) GetBatchFileQueueSize() int32`

GetBatchFileQueueSize returns the BatchFileQueueSize field if non-nil, zero value otherwise.

### GetBatchFileQueueSizeOk

`func (o *V11NodeStatusNodeStatusSystemStats) GetBatchFileQueueSizeOk() (*int32, bool)`

GetBatchFileQueueSizeOk returns a tuple with the BatchFileQueueSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBatchFileQueueSize

`func (o *V11NodeStatusNodeStatusSystemStats) SetBatchFileQueueSize(v int32)`

SetBatchFileQueueSize sets BatchFileQueueSize field to given value.

### HasBatchFileQueueSize

`func (o *V11NodeStatusNodeStatusSystemStats) HasBatchFileQueueSize() bool`

HasBatchFileQueueSize returns a boolean if a field has been set.

### GetCeeFailureCount

`func (o *V11NodeStatusNodeStatusSystemStats) GetCeeFailureCount() int32`

GetCeeFailureCount returns the CeeFailureCount field if non-nil, zero value otherwise.

### GetCeeFailureCountOk

`func (o *V11NodeStatusNodeStatusSystemStats) GetCeeFailureCountOk() (*int32, bool)`

GetCeeFailureCountOk returns a tuple with the CeeFailureCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCeeFailureCount

`func (o *V11NodeStatusNodeStatusSystemStats) SetCeeFailureCount(v int32)`

SetCeeFailureCount sets CeeFailureCount field to given value.

### HasCeeFailureCount

`func (o *V11NodeStatusNodeStatusSystemStats) HasCeeFailureCount() bool`

HasCeeFailureCount returns a boolean if a field has been set.

### GetCeeInfectedCount

`func (o *V11NodeStatusNodeStatusSystemStats) GetCeeInfectedCount() int32`

GetCeeInfectedCount returns the CeeInfectedCount field if non-nil, zero value otherwise.

### GetCeeInfectedCountOk

`func (o *V11NodeStatusNodeStatusSystemStats) GetCeeInfectedCountOk() (*int32, bool)`

GetCeeInfectedCountOk returns a tuple with the CeeInfectedCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCeeInfectedCount

`func (o *V11NodeStatusNodeStatusSystemStats) SetCeeInfectedCount(v int32)`

SetCeeInfectedCount sets CeeInfectedCount field to given value.

### HasCeeInfectedCount

`func (o *V11NodeStatusNodeStatusSystemStats) HasCeeInfectedCount() bool`

HasCeeInfectedCount returns a boolean if a field has been set.

### GetCeeSuccessCount

`func (o *V11NodeStatusNodeStatusSystemStats) GetCeeSuccessCount() int32`

GetCeeSuccessCount returns the CeeSuccessCount field if non-nil, zero value otherwise.

### GetCeeSuccessCountOk

`func (o *V11NodeStatusNodeStatusSystemStats) GetCeeSuccessCountOk() (*int32, bool)`

GetCeeSuccessCountOk returns a tuple with the CeeSuccessCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCeeSuccessCount

`func (o *V11NodeStatusNodeStatusSystemStats) SetCeeSuccessCount(v int32)`

SetCeeSuccessCount sets CeeSuccessCount field to given value.

### HasCeeSuccessCount

`func (o *V11NodeStatusNodeStatusSystemStats) HasCeeSuccessCount() bool`

HasCeeSuccessCount returns a boolean if a field has been set.

### GetFastFileQueueMaxSize

`func (o *V11NodeStatusNodeStatusSystemStats) GetFastFileQueueMaxSize() int32`

GetFastFileQueueMaxSize returns the FastFileQueueMaxSize field if non-nil, zero value otherwise.

### GetFastFileQueueMaxSizeOk

`func (o *V11NodeStatusNodeStatusSystemStats) GetFastFileQueueMaxSizeOk() (*int32, bool)`

GetFastFileQueueMaxSizeOk returns a tuple with the FastFileQueueMaxSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFastFileQueueMaxSize

`func (o *V11NodeStatusNodeStatusSystemStats) SetFastFileQueueMaxSize(v int32)`

SetFastFileQueueMaxSize sets FastFileQueueMaxSize field to given value.

### HasFastFileQueueMaxSize

`func (o *V11NodeStatusNodeStatusSystemStats) HasFastFileQueueMaxSize() bool`

HasFastFileQueueMaxSize returns a boolean if a field has been set.

### GetFastFileQueueSize

`func (o *V11NodeStatusNodeStatusSystemStats) GetFastFileQueueSize() int32`

GetFastFileQueueSize returns the FastFileQueueSize field if non-nil, zero value otherwise.

### GetFastFileQueueSizeOk

`func (o *V11NodeStatusNodeStatusSystemStats) GetFastFileQueueSizeOk() (*int32, bool)`

GetFastFileQueueSizeOk returns a tuple with the FastFileQueueSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFastFileQueueSize

`func (o *V11NodeStatusNodeStatusSystemStats) SetFastFileQueueSize(v int32)`

SetFastFileQueueSize sets FastFileQueueSize field to given value.

### HasFastFileQueueSize

`func (o *V11NodeStatusNodeStatusSystemStats) HasFastFileQueueSize() bool`

HasFastFileQueueSize returns a boolean if a field has been set.

### GetFilesProcessed

`func (o *V11NodeStatusNodeStatusSystemStats) GetFilesProcessed() int32`

GetFilesProcessed returns the FilesProcessed field if non-nil, zero value otherwise.

### GetFilesProcessedOk

`func (o *V11NodeStatusNodeStatusSystemStats) GetFilesProcessedOk() (*int32, bool)`

GetFilesProcessedOk returns a tuple with the FilesProcessed field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFilesProcessed

`func (o *V11NodeStatusNodeStatusSystemStats) SetFilesProcessed(v int32)`

SetFilesProcessed sets FilesProcessed field to given value.

### HasFilesProcessed

`func (o *V11NodeStatusNodeStatusSystemStats) HasFilesProcessed() bool`

HasFilesProcessed returns a boolean if a field has been set.

### GetFilesSkippedPerFilter

`func (o *V11NodeStatusNodeStatusSystemStats) GetFilesSkippedPerFilter() int32`

GetFilesSkippedPerFilter returns the FilesSkippedPerFilter field if non-nil, zero value otherwise.

### GetFilesSkippedPerFilterOk

`func (o *V11NodeStatusNodeStatusSystemStats) GetFilesSkippedPerFilterOk() (*int32, bool)`

GetFilesSkippedPerFilterOk returns a tuple with the FilesSkippedPerFilter field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFilesSkippedPerFilter

`func (o *V11NodeStatusNodeStatusSystemStats) SetFilesSkippedPerFilter(v int32)`

SetFilesSkippedPerFilter sets FilesSkippedPerFilter field to given value.

### HasFilesSkippedPerFilter

`func (o *V11NodeStatusNodeStatusSystemStats) HasFilesSkippedPerFilter() bool`

HasFilesSkippedPerFilter returns a boolean if a field has been set.

### GetFilesSkippedPerSize

`func (o *V11NodeStatusNodeStatusSystemStats) GetFilesSkippedPerSize() int32`

GetFilesSkippedPerSize returns the FilesSkippedPerSize field if non-nil, zero value otherwise.

### GetFilesSkippedPerSizeOk

`func (o *V11NodeStatusNodeStatusSystemStats) GetFilesSkippedPerSizeOk() (*int32, bool)`

GetFilesSkippedPerSizeOk returns a tuple with the FilesSkippedPerSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFilesSkippedPerSize

`func (o *V11NodeStatusNodeStatusSystemStats) SetFilesSkippedPerSize(v int32)`

SetFilesSkippedPerSize sets FilesSkippedPerSize field to given value.

### HasFilesSkippedPerSize

`func (o *V11NodeStatusNodeStatusSystemStats) HasFilesSkippedPerSize() bool`

HasFilesSkippedPerSize returns a boolean if a field has been set.

### GetJobScanRequests

`func (o *V11NodeStatusNodeStatusSystemStats) GetJobScanRequests() int32`

GetJobScanRequests returns the JobScanRequests field if non-nil, zero value otherwise.

### GetJobScanRequestsOk

`func (o *V11NodeStatusNodeStatusSystemStats) GetJobScanRequestsOk() (*int32, bool)`

GetJobScanRequestsOk returns a tuple with the JobScanRequests field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetJobScanRequests

`func (o *V11NodeStatusNodeStatusSystemStats) SetJobScanRequests(v int32)`

SetJobScanRequests sets JobScanRequests field to given value.

### HasJobScanRequests

`func (o *V11NodeStatusNodeStatusSystemStats) HasJobScanRequests() bool`

HasJobScanRequests returns a boolean if a field has been set.

### GetManualScanRequests

`func (o *V11NodeStatusNodeStatusSystemStats) GetManualScanRequests() int32`

GetManualScanRequests returns the ManualScanRequests field if non-nil, zero value otherwise.

### GetManualScanRequestsOk

`func (o *V11NodeStatusNodeStatusSystemStats) GetManualScanRequestsOk() (*int32, bool)`

GetManualScanRequestsOk returns a tuple with the ManualScanRequests field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetManualScanRequests

`func (o *V11NodeStatusNodeStatusSystemStats) SetManualScanRequests(v int32)`

SetManualScanRequests sets ManualScanRequests field to given value.

### HasManualScanRequests

`func (o *V11NodeStatusNodeStatusSystemStats) HasManualScanRequests() bool`

HasManualScanRequests returns a boolean if a field has been set.

### GetOnDemandScanRequests

`func (o *V11NodeStatusNodeStatusSystemStats) GetOnDemandScanRequests() int32`

GetOnDemandScanRequests returns the OnDemandScanRequests field if non-nil, zero value otherwise.

### GetOnDemandScanRequestsOk

`func (o *V11NodeStatusNodeStatusSystemStats) GetOnDemandScanRequestsOk() (*int32, bool)`

GetOnDemandScanRequestsOk returns a tuple with the OnDemandScanRequests field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOnDemandScanRequests

`func (o *V11NodeStatusNodeStatusSystemStats) SetOnDemandScanRequests(v int32)`

SetOnDemandScanRequests sets OnDemandScanRequests field to given value.

### HasOnDemandScanRequests

`func (o *V11NodeStatusNodeStatusSystemStats) HasOnDemandScanRequests() bool`

HasOnDemandScanRequests returns a boolean if a field has been set.

### GetScanFails

`func (o *V11NodeStatusNodeStatusSystemStats) GetScanFails() int32`

GetScanFails returns the ScanFails field if non-nil, zero value otherwise.

### GetScanFailsOk

`func (o *V11NodeStatusNodeStatusSystemStats) GetScanFailsOk() (*int32, bool)`

GetScanFailsOk returns a tuple with the ScanFails field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanFails

`func (o *V11NodeStatusNodeStatusSystemStats) SetScanFails(v int32)`

SetScanFails sets ScanFails field to given value.

### HasScanFails

`func (o *V11NodeStatusNodeStatusSystemStats) HasScanFails() bool`

HasScanFails returns a boolean if a field has been set.

### GetScanTimeouts

`func (o *V11NodeStatusNodeStatusSystemStats) GetScanTimeouts() int32`

GetScanTimeouts returns the ScanTimeouts field if non-nil, zero value otherwise.

### GetScanTimeoutsOk

`func (o *V11NodeStatusNodeStatusSystemStats) GetScanTimeoutsOk() (*int32, bool)`

GetScanTimeoutsOk returns a tuple with the ScanTimeouts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanTimeouts

`func (o *V11NodeStatusNodeStatusSystemStats) SetScanTimeouts(v int32)`

SetScanTimeouts sets ScanTimeouts field to given value.

### HasScanTimeouts

`func (o *V11NodeStatusNodeStatusSystemStats) HasScanTimeouts() bool`

HasScanTimeouts returns a boolean if a field has been set.

### GetSlowFileQueueMaxSize

`func (o *V11NodeStatusNodeStatusSystemStats) GetSlowFileQueueMaxSize() int32`

GetSlowFileQueueMaxSize returns the SlowFileQueueMaxSize field if non-nil, zero value otherwise.

### GetSlowFileQueueMaxSizeOk

`func (o *V11NodeStatusNodeStatusSystemStats) GetSlowFileQueueMaxSizeOk() (*int32, bool)`

GetSlowFileQueueMaxSizeOk returns a tuple with the SlowFileQueueMaxSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSlowFileQueueMaxSize

`func (o *V11NodeStatusNodeStatusSystemStats) SetSlowFileQueueMaxSize(v int32)`

SetSlowFileQueueMaxSize sets SlowFileQueueMaxSize field to given value.

### HasSlowFileQueueMaxSize

`func (o *V11NodeStatusNodeStatusSystemStats) HasSlowFileQueueMaxSize() bool`

HasSlowFileQueueMaxSize returns a boolean if a field has been set.

### GetSlowFileQueueSize

`func (o *V11NodeStatusNodeStatusSystemStats) GetSlowFileQueueSize() int32`

GetSlowFileQueueSize returns the SlowFileQueueSize field if non-nil, zero value otherwise.

### GetSlowFileQueueSizeOk

`func (o *V11NodeStatusNodeStatusSystemStats) GetSlowFileQueueSizeOk() (*int32, bool)`

GetSlowFileQueueSizeOk returns a tuple with the SlowFileQueueSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSlowFileQueueSize

`func (o *V11NodeStatusNodeStatusSystemStats) SetSlowFileQueueSize(v int32)`

SetSlowFileQueueSize sets SlowFileQueueSize field to given value.

### HasSlowFileQueueSize

`func (o *V11NodeStatusNodeStatusSystemStats) HasSlowFileQueueSize() bool`

HasSlowFileQueueSize returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


