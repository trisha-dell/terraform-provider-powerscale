# V12StoragepoolNodetypes

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Nodetypes** | Pointer to [**[]V12StoragepoolNodetype**](V12StoragepoolNodetype.md) |  | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV12StoragepoolNodetypes

`func NewV12StoragepoolNodetypes() *V12StoragepoolNodetypes`

NewV12StoragepoolNodetypes instantiates a new V12StoragepoolNodetypes object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12StoragepoolNodetypesWithDefaults

`func NewV12StoragepoolNodetypesWithDefaults() *V12StoragepoolNodetypes`

NewV12StoragepoolNodetypesWithDefaults instantiates a new V12StoragepoolNodetypes object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNodetypes

`func (o *V12StoragepoolNodetypes) GetNodetypes() []V12StoragepoolNodetype`

GetNodetypes returns the Nodetypes field if non-nil, zero value otherwise.

### GetNodetypesOk

`func (o *V12StoragepoolNodetypes) GetNodetypesOk() (*[]V12StoragepoolNodetype, bool)`

GetNodetypesOk returns a tuple with the Nodetypes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodetypes

`func (o *V12StoragepoolNodetypes) SetNodetypes(v []V12StoragepoolNodetype)`

SetNodetypes sets Nodetypes field to given value.

### HasNodetypes

`func (o *V12StoragepoolNodetypes) HasNodetypes() bool`

HasNodetypes returns a boolean if a field has been set.

### GetTotal

`func (o *V12StoragepoolNodetypes) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V12StoragepoolNodetypes) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V12StoragepoolNodetypes) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V12StoragepoolNodetypes) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


