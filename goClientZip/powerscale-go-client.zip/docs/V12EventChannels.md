# V12EventChannels

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AllowedNodes** | Pointer to **[]int32** | Nodes (LNNs) that can be masters for this channel. | [optional] 
**Enabled** | Pointer to **bool** | Channel is to be used or not. | [optional] 
**ExcludedNodes** | Pointer to **[]int32** | Nodes (LNNs) that can NOT be the masters for this channel. | [optional] 
**Id** | Pointer to **int32** | Unique identifier. | [optional] 
**Name** | **string** | Channel name, may not contain /. | 
**Parameters** | Pointer to [**V12EventChannelsParameters**](V12EventChannelsParameters.md) |  | [optional] 
**System** | Pointer to **bool** | Channel is a pre-defined system channel. | [optional] 
**Type** | **string** | The mechanism used by the channel. | 

## Methods

### NewV12EventChannels

`func NewV12EventChannels(name string, type_ string, ) *V12EventChannels`

NewV12EventChannels instantiates a new V12EventChannels object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12EventChannelsWithDefaults

`func NewV12EventChannelsWithDefaults() *V12EventChannels`

NewV12EventChannelsWithDefaults instantiates a new V12EventChannels object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAllowedNodes

`func (o *V12EventChannels) GetAllowedNodes() []int32`

GetAllowedNodes returns the AllowedNodes field if non-nil, zero value otherwise.

### GetAllowedNodesOk

`func (o *V12EventChannels) GetAllowedNodesOk() (*[]int32, bool)`

GetAllowedNodesOk returns a tuple with the AllowedNodes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllowedNodes

`func (o *V12EventChannels) SetAllowedNodes(v []int32)`

SetAllowedNodes sets AllowedNodes field to given value.

### HasAllowedNodes

`func (o *V12EventChannels) HasAllowedNodes() bool`

HasAllowedNodes returns a boolean if a field has been set.

### GetEnabled

`func (o *V12EventChannels) GetEnabled() bool`

GetEnabled returns the Enabled field if non-nil, zero value otherwise.

### GetEnabledOk

`func (o *V12EventChannels) GetEnabledOk() (*bool, bool)`

GetEnabledOk returns a tuple with the Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabled

`func (o *V12EventChannels) SetEnabled(v bool)`

SetEnabled sets Enabled field to given value.

### HasEnabled

`func (o *V12EventChannels) HasEnabled() bool`

HasEnabled returns a boolean if a field has been set.

### GetExcludedNodes

`func (o *V12EventChannels) GetExcludedNodes() []int32`

GetExcludedNodes returns the ExcludedNodes field if non-nil, zero value otherwise.

### GetExcludedNodesOk

`func (o *V12EventChannels) GetExcludedNodesOk() (*[]int32, bool)`

GetExcludedNodesOk returns a tuple with the ExcludedNodes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExcludedNodes

`func (o *V12EventChannels) SetExcludedNodes(v []int32)`

SetExcludedNodes sets ExcludedNodes field to given value.

### HasExcludedNodes

`func (o *V12EventChannels) HasExcludedNodes() bool`

HasExcludedNodes returns a boolean if a field has been set.

### GetId

`func (o *V12EventChannels) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12EventChannels) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12EventChannels) SetId(v int32)`

SetId sets Id field to given value.

### HasId

`func (o *V12EventChannels) HasId() bool`

HasId returns a boolean if a field has been set.

### GetName

`func (o *V12EventChannels) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V12EventChannels) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V12EventChannels) SetName(v string)`

SetName sets Name field to given value.


### GetParameters

`func (o *V12EventChannels) GetParameters() V12EventChannelsParameters`

GetParameters returns the Parameters field if non-nil, zero value otherwise.

### GetParametersOk

`func (o *V12EventChannels) GetParametersOk() (*V12EventChannelsParameters, bool)`

GetParametersOk returns a tuple with the Parameters field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetParameters

`func (o *V12EventChannels) SetParameters(v V12EventChannelsParameters)`

SetParameters sets Parameters field to given value.

### HasParameters

`func (o *V12EventChannels) HasParameters() bool`

HasParameters returns a boolean if a field has been set.

### GetSystem

`func (o *V12EventChannels) GetSystem() bool`

GetSystem returns the System field if non-nil, zero value otherwise.

### GetSystemOk

`func (o *V12EventChannels) GetSystemOk() (*bool, bool)`

GetSystemOk returns a tuple with the System field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSystem

`func (o *V12EventChannels) SetSystem(v bool)`

SetSystem sets System field to given value.

### HasSystem

`func (o *V12EventChannels) HasSystem() bool`

HasSystem returns a boolean if a field has been set.

### GetType

`func (o *V12EventChannels) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *V12EventChannels) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *V12EventChannels) SetType(v string)`

SetType sets Type field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


