# V11NodeStatusNodeStatusServerStatusItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Connections** | Pointer to **int32** | Total number of connections from the cluster node to CAVA servers. | [optional] 
**GoodHeartbeats** | Pointer to **int32** | Number of good heartbeats exchanges between cluster node and CAVA server. | [optional] 
**HeartbeatRtt** | Pointer to **int32** | Average round trip time (ms) for heartbeat messages between cluster node and CAVA server. | [optional] 
**ScanRequests** | Pointer to **int32** | Total number of scan requests received by the CAVA server. | [optional] 
**ScanRtt** | Pointer to **int32** | Average round trip time (ms) for scan request completion. | [optional] 
**ServerName** | Pointer to **string** | Name of the CAVA server as per the configuration. | [optional] 
**ServerState** | Pointer to **string** | State of the CAVA server in string format. | [optional] 

## Methods

### NewV11NodeStatusNodeStatusServerStatusItem

`func NewV11NodeStatusNodeStatusServerStatusItem() *V11NodeStatusNodeStatusServerStatusItem`

NewV11NodeStatusNodeStatusServerStatusItem instantiates a new V11NodeStatusNodeStatusServerStatusItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11NodeStatusNodeStatusServerStatusItemWithDefaults

`func NewV11NodeStatusNodeStatusServerStatusItemWithDefaults() *V11NodeStatusNodeStatusServerStatusItem`

NewV11NodeStatusNodeStatusServerStatusItemWithDefaults instantiates a new V11NodeStatusNodeStatusServerStatusItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetConnections

`func (o *V11NodeStatusNodeStatusServerStatusItem) GetConnections() int32`

GetConnections returns the Connections field if non-nil, zero value otherwise.

### GetConnectionsOk

`func (o *V11NodeStatusNodeStatusServerStatusItem) GetConnectionsOk() (*int32, bool)`

GetConnectionsOk returns a tuple with the Connections field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetConnections

`func (o *V11NodeStatusNodeStatusServerStatusItem) SetConnections(v int32)`

SetConnections sets Connections field to given value.

### HasConnections

`func (o *V11NodeStatusNodeStatusServerStatusItem) HasConnections() bool`

HasConnections returns a boolean if a field has been set.

### GetGoodHeartbeats

`func (o *V11NodeStatusNodeStatusServerStatusItem) GetGoodHeartbeats() int32`

GetGoodHeartbeats returns the GoodHeartbeats field if non-nil, zero value otherwise.

### GetGoodHeartbeatsOk

`func (o *V11NodeStatusNodeStatusServerStatusItem) GetGoodHeartbeatsOk() (*int32, bool)`

GetGoodHeartbeatsOk returns a tuple with the GoodHeartbeats field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGoodHeartbeats

`func (o *V11NodeStatusNodeStatusServerStatusItem) SetGoodHeartbeats(v int32)`

SetGoodHeartbeats sets GoodHeartbeats field to given value.

### HasGoodHeartbeats

`func (o *V11NodeStatusNodeStatusServerStatusItem) HasGoodHeartbeats() bool`

HasGoodHeartbeats returns a boolean if a field has been set.

### GetHeartbeatRtt

`func (o *V11NodeStatusNodeStatusServerStatusItem) GetHeartbeatRtt() int32`

GetHeartbeatRtt returns the HeartbeatRtt field if non-nil, zero value otherwise.

### GetHeartbeatRttOk

`func (o *V11NodeStatusNodeStatusServerStatusItem) GetHeartbeatRttOk() (*int32, bool)`

GetHeartbeatRttOk returns a tuple with the HeartbeatRtt field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHeartbeatRtt

`func (o *V11NodeStatusNodeStatusServerStatusItem) SetHeartbeatRtt(v int32)`

SetHeartbeatRtt sets HeartbeatRtt field to given value.

### HasHeartbeatRtt

`func (o *V11NodeStatusNodeStatusServerStatusItem) HasHeartbeatRtt() bool`

HasHeartbeatRtt returns a boolean if a field has been set.

### GetScanRequests

`func (o *V11NodeStatusNodeStatusServerStatusItem) GetScanRequests() int32`

GetScanRequests returns the ScanRequests field if non-nil, zero value otherwise.

### GetScanRequestsOk

`func (o *V11NodeStatusNodeStatusServerStatusItem) GetScanRequestsOk() (*int32, bool)`

GetScanRequestsOk returns a tuple with the ScanRequests field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanRequests

`func (o *V11NodeStatusNodeStatusServerStatusItem) SetScanRequests(v int32)`

SetScanRequests sets ScanRequests field to given value.

### HasScanRequests

`func (o *V11NodeStatusNodeStatusServerStatusItem) HasScanRequests() bool`

HasScanRequests returns a boolean if a field has been set.

### GetScanRtt

`func (o *V11NodeStatusNodeStatusServerStatusItem) GetScanRtt() int32`

GetScanRtt returns the ScanRtt field if non-nil, zero value otherwise.

### GetScanRttOk

`func (o *V11NodeStatusNodeStatusServerStatusItem) GetScanRttOk() (*int32, bool)`

GetScanRttOk returns a tuple with the ScanRtt field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanRtt

`func (o *V11NodeStatusNodeStatusServerStatusItem) SetScanRtt(v int32)`

SetScanRtt sets ScanRtt field to given value.

### HasScanRtt

`func (o *V11NodeStatusNodeStatusServerStatusItem) HasScanRtt() bool`

HasScanRtt returns a boolean if a field has been set.

### GetServerName

`func (o *V11NodeStatusNodeStatusServerStatusItem) GetServerName() string`

GetServerName returns the ServerName field if non-nil, zero value otherwise.

### GetServerNameOk

`func (o *V11NodeStatusNodeStatusServerStatusItem) GetServerNameOk() (*string, bool)`

GetServerNameOk returns a tuple with the ServerName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServerName

`func (o *V11NodeStatusNodeStatusServerStatusItem) SetServerName(v string)`

SetServerName sets ServerName field to given value.

### HasServerName

`func (o *V11NodeStatusNodeStatusServerStatusItem) HasServerName() bool`

HasServerName returns a boolean if a field has been set.

### GetServerState

`func (o *V11NodeStatusNodeStatusServerStatusItem) GetServerState() string`

GetServerState returns the ServerState field if non-nil, zero value otherwise.

### GetServerStateOk

`func (o *V11NodeStatusNodeStatusServerStatusItem) GetServerStateOk() (*string, bool)`

GetServerStateOk returns a tuple with the ServerState field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServerState

`func (o *V11NodeStatusNodeStatusServerStatusItem) SetServerState(v string)`

SetServerState sets ServerState field to given value.

### HasServerState

`func (o *V11NodeStatusNodeStatusServerStatusItem) HasServerState() bool`

HasServerState returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


