# V10ClusterNodePartition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BlockSize** | Pointer to **int32** | The block size used for the reported partition information. | [optional] 
**Capacity** | Pointer to **int32** | Total blocks on this file system partition. | [optional] 
**ComponentDevices** | Pointer to **string** | Comma separated list of devices used for this file system partition. | [optional] 
**MountPoint** | Pointer to **string** | Directory on which this partition is mounted. | [optional] 
**PercentUsed** | Pointer to **string** | Used blocks on this file system partition, expressed as a percentage. | [optional] 
**Statfs** | Pointer to [**V10ClusterNodePartitionStatfs**](V10ClusterNodePartitionStatfs.md) |  | [optional] 
**Used** | Pointer to **int32** | Used blocks on this file system partition. | [optional] 

## Methods

### NewV10ClusterNodePartition

`func NewV10ClusterNodePartition() *V10ClusterNodePartition`

NewV10ClusterNodePartition instantiates a new V10ClusterNodePartition object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodePartitionWithDefaults

`func NewV10ClusterNodePartitionWithDefaults() *V10ClusterNodePartition`

NewV10ClusterNodePartitionWithDefaults instantiates a new V10ClusterNodePartition object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBlockSize

`func (o *V10ClusterNodePartition) GetBlockSize() int32`

GetBlockSize returns the BlockSize field if non-nil, zero value otherwise.

### GetBlockSizeOk

`func (o *V10ClusterNodePartition) GetBlockSizeOk() (*int32, bool)`

GetBlockSizeOk returns a tuple with the BlockSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBlockSize

`func (o *V10ClusterNodePartition) SetBlockSize(v int32)`

SetBlockSize sets BlockSize field to given value.

### HasBlockSize

`func (o *V10ClusterNodePartition) HasBlockSize() bool`

HasBlockSize returns a boolean if a field has been set.

### GetCapacity

`func (o *V10ClusterNodePartition) GetCapacity() int32`

GetCapacity returns the Capacity field if non-nil, zero value otherwise.

### GetCapacityOk

`func (o *V10ClusterNodePartition) GetCapacityOk() (*int32, bool)`

GetCapacityOk returns a tuple with the Capacity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCapacity

`func (o *V10ClusterNodePartition) SetCapacity(v int32)`

SetCapacity sets Capacity field to given value.

### HasCapacity

`func (o *V10ClusterNodePartition) HasCapacity() bool`

HasCapacity returns a boolean if a field has been set.

### GetComponentDevices

`func (o *V10ClusterNodePartition) GetComponentDevices() string`

GetComponentDevices returns the ComponentDevices field if non-nil, zero value otherwise.

### GetComponentDevicesOk

`func (o *V10ClusterNodePartition) GetComponentDevicesOk() (*string, bool)`

GetComponentDevicesOk returns a tuple with the ComponentDevices field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetComponentDevices

`func (o *V10ClusterNodePartition) SetComponentDevices(v string)`

SetComponentDevices sets ComponentDevices field to given value.

### HasComponentDevices

`func (o *V10ClusterNodePartition) HasComponentDevices() bool`

HasComponentDevices returns a boolean if a field has been set.

### GetMountPoint

`func (o *V10ClusterNodePartition) GetMountPoint() string`

GetMountPoint returns the MountPoint field if non-nil, zero value otherwise.

### GetMountPointOk

`func (o *V10ClusterNodePartition) GetMountPointOk() (*string, bool)`

GetMountPointOk returns a tuple with the MountPoint field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMountPoint

`func (o *V10ClusterNodePartition) SetMountPoint(v string)`

SetMountPoint sets MountPoint field to given value.

### HasMountPoint

`func (o *V10ClusterNodePartition) HasMountPoint() bool`

HasMountPoint returns a boolean if a field has been set.

### GetPercentUsed

`func (o *V10ClusterNodePartition) GetPercentUsed() string`

GetPercentUsed returns the PercentUsed field if non-nil, zero value otherwise.

### GetPercentUsedOk

`func (o *V10ClusterNodePartition) GetPercentUsedOk() (*string, bool)`

GetPercentUsedOk returns a tuple with the PercentUsed field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPercentUsed

`func (o *V10ClusterNodePartition) SetPercentUsed(v string)`

SetPercentUsed sets PercentUsed field to given value.

### HasPercentUsed

`func (o *V10ClusterNodePartition) HasPercentUsed() bool`

HasPercentUsed returns a boolean if a field has been set.

### GetStatfs

`func (o *V10ClusterNodePartition) GetStatfs() V10ClusterNodePartitionStatfs`

GetStatfs returns the Statfs field if non-nil, zero value otherwise.

### GetStatfsOk

`func (o *V10ClusterNodePartition) GetStatfsOk() (*V10ClusterNodePartitionStatfs, bool)`

GetStatfsOk returns a tuple with the Statfs field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatfs

`func (o *V10ClusterNodePartition) SetStatfs(v V10ClusterNodePartitionStatfs)`

SetStatfs sets Statfs field to given value.

### HasStatfs

`func (o *V10ClusterNodePartition) HasStatfs() bool`

HasStatfs returns a boolean if a field has been set.

### GetUsed

`func (o *V10ClusterNodePartition) GetUsed() int32`

GetUsed returns the Used field if non-nil, zero value otherwise.

### GetUsedOk

`func (o *V10ClusterNodePartition) GetUsedOk() (*int32, bool)`

GetUsedOk returns a tuple with the Used field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUsed

`func (o *V10ClusterNodePartition) SetUsed(v int32)`

SetUsed sets Used field to given value.

### HasUsed

`func (o *V10ClusterNodePartition) HasUsed() bool`

HasUsed returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


