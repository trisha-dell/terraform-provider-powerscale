# V10S3BucketExtendedExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Acl** | Pointer to [**[]V10S3BucketAclItem**](V10S3BucketAclItem.md) | Specifies an ordered list of S3 permissions. | [optional] 
**Description** | Pointer to **string** | Description for this S3 bucket. | [optional] 
**ObjectAclPolicy** | Pointer to **string** | Set behavior of modifying object acls | [optional] 

## Methods

### NewV10S3BucketExtendedExtended

`func NewV10S3BucketExtendedExtended() *V10S3BucketExtendedExtended`

NewV10S3BucketExtendedExtended instantiates a new V10S3BucketExtendedExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10S3BucketExtendedExtendedWithDefaults

`func NewV10S3BucketExtendedExtendedWithDefaults() *V10S3BucketExtendedExtended`

NewV10S3BucketExtendedExtendedWithDefaults instantiates a new V10S3BucketExtendedExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAcl

`func (o *V10S3BucketExtendedExtended) GetAcl() []V10S3BucketAclItem`

GetAcl returns the Acl field if non-nil, zero value otherwise.

### GetAclOk

`func (o *V10S3BucketExtendedExtended) GetAclOk() (*[]V10S3BucketAclItem, bool)`

GetAclOk returns a tuple with the Acl field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAcl

`func (o *V10S3BucketExtendedExtended) SetAcl(v []V10S3BucketAclItem)`

SetAcl sets Acl field to given value.

### HasAcl

`func (o *V10S3BucketExtendedExtended) HasAcl() bool`

HasAcl returns a boolean if a field has been set.

### GetDescription

`func (o *V10S3BucketExtendedExtended) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V10S3BucketExtendedExtended) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V10S3BucketExtendedExtended) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *V10S3BucketExtendedExtended) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetObjectAclPolicy

`func (o *V10S3BucketExtendedExtended) GetObjectAclPolicy() string`

GetObjectAclPolicy returns the ObjectAclPolicy field if non-nil, zero value otherwise.

### GetObjectAclPolicyOk

`func (o *V10S3BucketExtendedExtended) GetObjectAclPolicyOk() (*string, bool)`

GetObjectAclPolicyOk returns a tuple with the ObjectAclPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetObjectAclPolicy

`func (o *V10S3BucketExtendedExtended) SetObjectAclPolicy(v string)`

SetObjectAclPolicy sets ObjectAclPolicy field to given value.

### HasObjectAclPolicy

`func (o *V10S3BucketExtendedExtended) HasObjectAclPolicy() bool`

HasObjectAclPolicy returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


