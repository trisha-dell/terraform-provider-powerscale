# V10ClusterNodeStatusPowersupplies

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Count** | Pointer to **int32** | Count of how many power supplies are supported. | [optional] 
**Failures** | Pointer to **int32** | Count of how many power supplies have failed. | [optional] 
**HasCff** | Pointer to **bool** | Does this node have a CFF power supply. | [optional] 
**Status** | Pointer to **string** | A descriptive status string for this node&#39;s power supplies. | [optional] 
**Supplies** | Pointer to [**[]V10ClusterNodeStatusPowersuppliesSupply**](V10ClusterNodeStatusPowersuppliesSupply.md) | List of this node&#39;s power supplies. | [optional] 
**SupportsCff** | Pointer to **bool** | Does this node support CFF power supplies. | [optional] 

## Methods

### NewV10ClusterNodeStatusPowersupplies

`func NewV10ClusterNodeStatusPowersupplies() *V10ClusterNodeStatusPowersupplies`

NewV10ClusterNodeStatusPowersupplies instantiates a new V10ClusterNodeStatusPowersupplies object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeStatusPowersuppliesWithDefaults

`func NewV10ClusterNodeStatusPowersuppliesWithDefaults() *V10ClusterNodeStatusPowersupplies`

NewV10ClusterNodeStatusPowersuppliesWithDefaults instantiates a new V10ClusterNodeStatusPowersupplies object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCount

`func (o *V10ClusterNodeStatusPowersupplies) GetCount() int32`

GetCount returns the Count field if non-nil, zero value otherwise.

### GetCountOk

`func (o *V10ClusterNodeStatusPowersupplies) GetCountOk() (*int32, bool)`

GetCountOk returns a tuple with the Count field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCount

`func (o *V10ClusterNodeStatusPowersupplies) SetCount(v int32)`

SetCount sets Count field to given value.

### HasCount

`func (o *V10ClusterNodeStatusPowersupplies) HasCount() bool`

HasCount returns a boolean if a field has been set.

### GetFailures

`func (o *V10ClusterNodeStatusPowersupplies) GetFailures() int32`

GetFailures returns the Failures field if non-nil, zero value otherwise.

### GetFailuresOk

`func (o *V10ClusterNodeStatusPowersupplies) GetFailuresOk() (*int32, bool)`

GetFailuresOk returns a tuple with the Failures field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFailures

`func (o *V10ClusterNodeStatusPowersupplies) SetFailures(v int32)`

SetFailures sets Failures field to given value.

### HasFailures

`func (o *V10ClusterNodeStatusPowersupplies) HasFailures() bool`

HasFailures returns a boolean if a field has been set.

### GetHasCff

`func (o *V10ClusterNodeStatusPowersupplies) GetHasCff() bool`

GetHasCff returns the HasCff field if non-nil, zero value otherwise.

### GetHasCffOk

`func (o *V10ClusterNodeStatusPowersupplies) GetHasCffOk() (*bool, bool)`

GetHasCffOk returns a tuple with the HasCff field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHasCff

`func (o *V10ClusterNodeStatusPowersupplies) SetHasCff(v bool)`

SetHasCff sets HasCff field to given value.

### HasHasCff

`func (o *V10ClusterNodeStatusPowersupplies) HasHasCff() bool`

HasHasCff returns a boolean if a field has been set.

### GetStatus

`func (o *V10ClusterNodeStatusPowersupplies) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V10ClusterNodeStatusPowersupplies) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V10ClusterNodeStatusPowersupplies) SetStatus(v string)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V10ClusterNodeStatusPowersupplies) HasStatus() bool`

HasStatus returns a boolean if a field has been set.

### GetSupplies

`func (o *V10ClusterNodeStatusPowersupplies) GetSupplies() []V10ClusterNodeStatusPowersuppliesSupply`

GetSupplies returns the Supplies field if non-nil, zero value otherwise.

### GetSuppliesOk

`func (o *V10ClusterNodeStatusPowersupplies) GetSuppliesOk() (*[]V10ClusterNodeStatusPowersuppliesSupply, bool)`

GetSuppliesOk returns a tuple with the Supplies field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSupplies

`func (o *V10ClusterNodeStatusPowersupplies) SetSupplies(v []V10ClusterNodeStatusPowersuppliesSupply)`

SetSupplies sets Supplies field to given value.

### HasSupplies

`func (o *V10ClusterNodeStatusPowersupplies) HasSupplies() bool`

HasSupplies returns a boolean if a field has been set.

### GetSupportsCff

`func (o *V10ClusterNodeStatusPowersupplies) GetSupportsCff() bool`

GetSupportsCff returns the SupportsCff field if non-nil, zero value otherwise.

### GetSupportsCffOk

`func (o *V10ClusterNodeStatusPowersupplies) GetSupportsCffOk() (*bool, bool)`

GetSupportsCffOk returns a tuple with the SupportsCff field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSupportsCff

`func (o *V10ClusterNodeStatusPowersupplies) SetSupportsCff(v bool)`

SetSupportsCff sets SupportsCff field to given value.

### HasSupportsCff

`func (o *V10ClusterNodeStatusPowersupplies) HasSupportsCff() bool`

HasSupportsCff returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


