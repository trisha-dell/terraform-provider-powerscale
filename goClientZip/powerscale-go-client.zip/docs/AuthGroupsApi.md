# \AuthGroupsApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateAuthGroupsv1GroupMember**](AuthGroupsApi.md#CreateAuthGroupsv1GroupMember) | **Post** /platform/1/auth/groups/{Group}/members | 
[**ListAuthGroupsv1GroupMembers**](AuthGroupsApi.md#ListAuthGroupsv1GroupMembers) | **Get** /platform/1/auth/groups/{Group}/members | 



## CreateAuthGroupsv1GroupMember

> CreateResponse CreateAuthGroupsv1GroupMember(ctx, group).V1GroupMember(v1GroupMember).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    group := "group_example" // string | 
    v1GroupMember := *openapiclient.NewV1AuthAccessAccessItemFileGroup() // V1AuthAccessAccessItemFileGroup | 
    zone := "zone_example" // string | Filter group members by zone. (optional)
    provider := "provider_example" // string | Filter group members by provider. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthGroupsApi.CreateAuthGroupsv1GroupMember(context.Background(), group).V1GroupMember(v1GroupMember).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthGroupsApi.CreateAuthGroupsv1GroupMember``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthGroupsv1GroupMember`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthGroupsApi.CreateAuthGroupsv1GroupMember`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**group** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthGroupsv1GroupMemberRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1GroupMember** | [**V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) |  | 
 **zone** | **string** | Filter group members by zone. | 
 **provider** | **string** | Filter group members by provider. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthGroupsv1GroupMembers

> V1GroupMembers ListAuthGroupsv1GroupMembers(ctx, group).ResolveNames(resolveNames).Resume(resume).Limit(limit).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    group := "group_example" // string | 
    resolveNames := true // bool | Resolve names of personas. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    zone := "zone_example" // string | Filter group members by zone. (optional)
    provider := "provider_example" // string | Filter group members by provider. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthGroupsApi.ListAuthGroupsv1GroupMembers(context.Background(), group).ResolveNames(resolveNames).Resume(resume).Limit(limit).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthGroupsApi.ListAuthGroupsv1GroupMembers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthGroupsv1GroupMembers`: V1GroupMembers
    fmt.Fprintf(os.Stdout, "Response from `AuthGroupsApi.ListAuthGroupsv1GroupMembers`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**group** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListAuthGroupsv1GroupMembersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **resolveNames** | **bool** | Resolve names of personas. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **zone** | **string** | Filter group members by zone. | 
 **provider** | **string** | Filter group members by provider. | 

### Return type

[**V1GroupMembers**](V1GroupMembers.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

