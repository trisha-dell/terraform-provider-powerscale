# V10ClusterFirmwareStatusNode

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Devices** | Pointer to [**[]V10ClusterFirmwareDeviceNodeDevice**](V10ClusterFirmwareDeviceNodeDevice.md) | List of the firmware status for hardware components on the node. | [optional] 
**Error** | Pointer to **string** | Error message, if the HTTP status returned from this node was not 200. | [optional] 
**Id** | Pointer to **int32** | Node ID (Device Number) of a node. | [optional] 
**Lnn** | Pointer to **int32** | Logical Node Number (LNN) of a node. | [optional] 
**NodeUnavailable** | Pointer to **bool** | Node is unavailable. | [optional] 
**Status** | Pointer to **int32** | Status of the HTTP response from this node if not 200.  If 200, this field does not appear. | [optional] 

## Methods

### NewV10ClusterFirmwareStatusNode

`func NewV10ClusterFirmwareStatusNode() *V10ClusterFirmwareStatusNode`

NewV10ClusterFirmwareStatusNode instantiates a new V10ClusterFirmwareStatusNode object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterFirmwareStatusNodeWithDefaults

`func NewV10ClusterFirmwareStatusNodeWithDefaults() *V10ClusterFirmwareStatusNode`

NewV10ClusterFirmwareStatusNodeWithDefaults instantiates a new V10ClusterFirmwareStatusNode object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDevices

`func (o *V10ClusterFirmwareStatusNode) GetDevices() []V10ClusterFirmwareDeviceNodeDevice`

GetDevices returns the Devices field if non-nil, zero value otherwise.

### GetDevicesOk

`func (o *V10ClusterFirmwareStatusNode) GetDevicesOk() (*[]V10ClusterFirmwareDeviceNodeDevice, bool)`

GetDevicesOk returns a tuple with the Devices field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDevices

`func (o *V10ClusterFirmwareStatusNode) SetDevices(v []V10ClusterFirmwareDeviceNodeDevice)`

SetDevices sets Devices field to given value.

### HasDevices

`func (o *V10ClusterFirmwareStatusNode) HasDevices() bool`

HasDevices returns a boolean if a field has been set.

### GetError

`func (o *V10ClusterFirmwareStatusNode) GetError() string`

GetError returns the Error field if non-nil, zero value otherwise.

### GetErrorOk

`func (o *V10ClusterFirmwareStatusNode) GetErrorOk() (*string, bool)`

GetErrorOk returns a tuple with the Error field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetError

`func (o *V10ClusterFirmwareStatusNode) SetError(v string)`

SetError sets Error field to given value.

### HasError

`func (o *V10ClusterFirmwareStatusNode) HasError() bool`

HasError returns a boolean if a field has been set.

### GetId

`func (o *V10ClusterFirmwareStatusNode) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V10ClusterFirmwareStatusNode) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V10ClusterFirmwareStatusNode) SetId(v int32)`

SetId sets Id field to given value.

### HasId

`func (o *V10ClusterFirmwareStatusNode) HasId() bool`

HasId returns a boolean if a field has been set.

### GetLnn

`func (o *V10ClusterFirmwareStatusNode) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V10ClusterFirmwareStatusNode) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V10ClusterFirmwareStatusNode) SetLnn(v int32)`

SetLnn sets Lnn field to given value.

### HasLnn

`func (o *V10ClusterFirmwareStatusNode) HasLnn() bool`

HasLnn returns a boolean if a field has been set.

### GetNodeUnavailable

`func (o *V10ClusterFirmwareStatusNode) GetNodeUnavailable() bool`

GetNodeUnavailable returns the NodeUnavailable field if non-nil, zero value otherwise.

### GetNodeUnavailableOk

`func (o *V10ClusterFirmwareStatusNode) GetNodeUnavailableOk() (*bool, bool)`

GetNodeUnavailableOk returns a tuple with the NodeUnavailable field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodeUnavailable

`func (o *V10ClusterFirmwareStatusNode) SetNodeUnavailable(v bool)`

SetNodeUnavailable sets NodeUnavailable field to given value.

### HasNodeUnavailable

`func (o *V10ClusterFirmwareStatusNode) HasNodeUnavailable() bool`

HasNodeUnavailable returns a boolean if a field has been set.

### GetStatus

`func (o *V10ClusterFirmwareStatusNode) GetStatus() int32`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V10ClusterFirmwareStatusNode) GetStatusOk() (*int32, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V10ClusterFirmwareStatusNode) SetStatus(v int32)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V10ClusterFirmwareStatusNode) HasStatus() bool`

HasStatus returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


