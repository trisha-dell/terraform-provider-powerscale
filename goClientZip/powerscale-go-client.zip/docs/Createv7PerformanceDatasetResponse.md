# Createv7PerformanceDatasetResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Unique identifier for the configured dataset. | 
**Name** | **string** | The name of the performance dataset. If a name is not specified then a default name is assigned. The default name will be an underscore separated list of the performance metrics and filters used to configure the dataset. | 
**Statkey** | **string** | Key for use in viewing associated raw statistics under the endpoints /statistics/history and /statistics/current. | 
**StatsSummaryUri** | **string** | URI used to view associated summary statistics. | 

## Methods

### NewCreatev7PerformanceDatasetResponse

`func NewCreatev7PerformanceDatasetResponse(id int32, name string, statkey string, statsSummaryUri string, ) *Createv7PerformanceDatasetResponse`

NewCreatev7PerformanceDatasetResponse instantiates a new Createv7PerformanceDatasetResponse object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev7PerformanceDatasetResponseWithDefaults

`func NewCreatev7PerformanceDatasetResponseWithDefaults() *Createv7PerformanceDatasetResponse`

NewCreatev7PerformanceDatasetResponseWithDefaults instantiates a new Createv7PerformanceDatasetResponse object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *Createv7PerformanceDatasetResponse) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *Createv7PerformanceDatasetResponse) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *Createv7PerformanceDatasetResponse) SetId(v int32)`

SetId sets Id field to given value.


### GetName

`func (o *Createv7PerformanceDatasetResponse) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *Createv7PerformanceDatasetResponse) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *Createv7PerformanceDatasetResponse) SetName(v string)`

SetName sets Name field to given value.


### GetStatkey

`func (o *Createv7PerformanceDatasetResponse) GetStatkey() string`

GetStatkey returns the Statkey field if non-nil, zero value otherwise.

### GetStatkeyOk

`func (o *Createv7PerformanceDatasetResponse) GetStatkeyOk() (*string, bool)`

GetStatkeyOk returns a tuple with the Statkey field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatkey

`func (o *Createv7PerformanceDatasetResponse) SetStatkey(v string)`

SetStatkey sets Statkey field to given value.


### GetStatsSummaryUri

`func (o *Createv7PerformanceDatasetResponse) GetStatsSummaryUri() string`

GetStatsSummaryUri returns the StatsSummaryUri field if non-nil, zero value otherwise.

### GetStatsSummaryUriOk

`func (o *Createv7PerformanceDatasetResponse) GetStatsSummaryUriOk() (*string, bool)`

GetStatsSummaryUriOk returns a tuple with the StatsSummaryUri field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatsSummaryUri

`func (o *Createv7PerformanceDatasetResponse) SetStatsSummaryUri(v string)`

SetStatsSummaryUri sets StatsSummaryUri field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


