# V11ClusterPatchPatchesPatch

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Comment** | Pointer to **string** | A long comment about the patch. | [optional] 
**Conflicts** | Pointer to **[]string** | Other patches that this patch conflicts with. | [optional] 
**Dependencies** | Pointer to **[]string** | Other patches that this patch depends on. | [optional] 
**Description** | Pointer to **string** | A short description of the patch. | [optional] 
**Files** | Pointer to [**[]V16HealthcheckDefinitionFile**](V16HealthcheckDefinitionFile.md) | The files contained in this patch. | [optional] 
**Id** | Pointer to **string** | A unique identifier for the patch. | [optional] 
**Name** | Pointer to **string** | The name of the patch. | [optional] 
**Nodes** | Pointer to **[]int32** | The nodes that this patch is installed on. | [optional] 
**Reboot** | Pointer to **string** | Describes the reboot requirements | [optional] 
**Services** | Pointer to [**[]V16HealthcheckDefinitionService**](V16HealthcheckDefinitionService.md) | The services affected during the patch deployment | [optional] 
**Status** | Pointer to **string** | The installation status of this patch on the cluster. | [optional] 

## Methods

### NewV11ClusterPatchPatchesPatch

`func NewV11ClusterPatchPatchesPatch() *V11ClusterPatchPatchesPatch`

NewV11ClusterPatchPatchesPatch instantiates a new V11ClusterPatchPatchesPatch object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11ClusterPatchPatchesPatchWithDefaults

`func NewV11ClusterPatchPatchesPatchWithDefaults() *V11ClusterPatchPatchesPatch`

NewV11ClusterPatchPatchesPatchWithDefaults instantiates a new V11ClusterPatchPatchesPatch object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetComment

`func (o *V11ClusterPatchPatchesPatch) GetComment() string`

GetComment returns the Comment field if non-nil, zero value otherwise.

### GetCommentOk

`func (o *V11ClusterPatchPatchesPatch) GetCommentOk() (*string, bool)`

GetCommentOk returns a tuple with the Comment field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetComment

`func (o *V11ClusterPatchPatchesPatch) SetComment(v string)`

SetComment sets Comment field to given value.

### HasComment

`func (o *V11ClusterPatchPatchesPatch) HasComment() bool`

HasComment returns a boolean if a field has been set.

### GetConflicts

`func (o *V11ClusterPatchPatchesPatch) GetConflicts() []string`

GetConflicts returns the Conflicts field if non-nil, zero value otherwise.

### GetConflictsOk

`func (o *V11ClusterPatchPatchesPatch) GetConflictsOk() (*[]string, bool)`

GetConflictsOk returns a tuple with the Conflicts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetConflicts

`func (o *V11ClusterPatchPatchesPatch) SetConflicts(v []string)`

SetConflicts sets Conflicts field to given value.

### HasConflicts

`func (o *V11ClusterPatchPatchesPatch) HasConflicts() bool`

HasConflicts returns a boolean if a field has been set.

### GetDependencies

`func (o *V11ClusterPatchPatchesPatch) GetDependencies() []string`

GetDependencies returns the Dependencies field if non-nil, zero value otherwise.

### GetDependenciesOk

`func (o *V11ClusterPatchPatchesPatch) GetDependenciesOk() (*[]string, bool)`

GetDependenciesOk returns a tuple with the Dependencies field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDependencies

`func (o *V11ClusterPatchPatchesPatch) SetDependencies(v []string)`

SetDependencies sets Dependencies field to given value.

### HasDependencies

`func (o *V11ClusterPatchPatchesPatch) HasDependencies() bool`

HasDependencies returns a boolean if a field has been set.

### GetDescription

`func (o *V11ClusterPatchPatchesPatch) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V11ClusterPatchPatchesPatch) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V11ClusterPatchPatchesPatch) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *V11ClusterPatchPatchesPatch) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetFiles

`func (o *V11ClusterPatchPatchesPatch) GetFiles() []V16HealthcheckDefinitionFile`

GetFiles returns the Files field if non-nil, zero value otherwise.

### GetFilesOk

`func (o *V11ClusterPatchPatchesPatch) GetFilesOk() (*[]V16HealthcheckDefinitionFile, bool)`

GetFilesOk returns a tuple with the Files field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFiles

`func (o *V11ClusterPatchPatchesPatch) SetFiles(v []V16HealthcheckDefinitionFile)`

SetFiles sets Files field to given value.

### HasFiles

`func (o *V11ClusterPatchPatchesPatch) HasFiles() bool`

HasFiles returns a boolean if a field has been set.

### GetId

`func (o *V11ClusterPatchPatchesPatch) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V11ClusterPatchPatchesPatch) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V11ClusterPatchPatchesPatch) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V11ClusterPatchPatchesPatch) HasId() bool`

HasId returns a boolean if a field has been set.

### GetName

`func (o *V11ClusterPatchPatchesPatch) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V11ClusterPatchPatchesPatch) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V11ClusterPatchPatchesPatch) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V11ClusterPatchPatchesPatch) HasName() bool`

HasName returns a boolean if a field has been set.

### GetNodes

`func (o *V11ClusterPatchPatchesPatch) GetNodes() []int32`

GetNodes returns the Nodes field if non-nil, zero value otherwise.

### GetNodesOk

`func (o *V11ClusterPatchPatchesPatch) GetNodesOk() (*[]int32, bool)`

GetNodesOk returns a tuple with the Nodes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodes

`func (o *V11ClusterPatchPatchesPatch) SetNodes(v []int32)`

SetNodes sets Nodes field to given value.

### HasNodes

`func (o *V11ClusterPatchPatchesPatch) HasNodes() bool`

HasNodes returns a boolean if a field has been set.

### GetReboot

`func (o *V11ClusterPatchPatchesPatch) GetReboot() string`

GetReboot returns the Reboot field if non-nil, zero value otherwise.

### GetRebootOk

`func (o *V11ClusterPatchPatchesPatch) GetRebootOk() (*string, bool)`

GetRebootOk returns a tuple with the Reboot field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReboot

`func (o *V11ClusterPatchPatchesPatch) SetReboot(v string)`

SetReboot sets Reboot field to given value.

### HasReboot

`func (o *V11ClusterPatchPatchesPatch) HasReboot() bool`

HasReboot returns a boolean if a field has been set.

### GetServices

`func (o *V11ClusterPatchPatchesPatch) GetServices() []V16HealthcheckDefinitionService`

GetServices returns the Services field if non-nil, zero value otherwise.

### GetServicesOk

`func (o *V11ClusterPatchPatchesPatch) GetServicesOk() (*[]V16HealthcheckDefinitionService, bool)`

GetServicesOk returns a tuple with the Services field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServices

`func (o *V11ClusterPatchPatchesPatch) SetServices(v []V16HealthcheckDefinitionService)`

SetServices sets Services field to given value.

### HasServices

`func (o *V11ClusterPatchPatchesPatch) HasServices() bool`

HasServices returns a boolean if a field has been set.

### GetStatus

`func (o *V11ClusterPatchPatchesPatch) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V11ClusterPatchPatchesPatch) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V11ClusterPatchPatchesPatch) SetStatus(v string)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V11ClusterPatchPatchesPatch) HasStatus() bool`

HasStatus returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


