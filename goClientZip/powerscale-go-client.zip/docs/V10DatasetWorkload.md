# V10DatasetWorkload

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MetricValues** | [**V10DatasetFilterMetricValues**](V10DatasetFilterMetricValues.md) |  | 
**Name** | Pointer to **string** | The name of the workload. User specified. | [optional] 

## Methods

### NewV10DatasetWorkload

`func NewV10DatasetWorkload(metricValues V10DatasetFilterMetricValues, ) *V10DatasetWorkload`

NewV10DatasetWorkload instantiates a new V10DatasetWorkload object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10DatasetWorkloadWithDefaults

`func NewV10DatasetWorkloadWithDefaults() *V10DatasetWorkload`

NewV10DatasetWorkloadWithDefaults instantiates a new V10DatasetWorkload object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMetricValues

`func (o *V10DatasetWorkload) GetMetricValues() V10DatasetFilterMetricValues`

GetMetricValues returns the MetricValues field if non-nil, zero value otherwise.

### GetMetricValuesOk

`func (o *V10DatasetWorkload) GetMetricValuesOk() (*V10DatasetFilterMetricValues, bool)`

GetMetricValuesOk returns a tuple with the MetricValues field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetricValues

`func (o *V10DatasetWorkload) SetMetricValues(v V10DatasetFilterMetricValues)`

SetMetricValues sets MetricValues field to given value.


### GetName

`func (o *V10DatasetWorkload) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V10DatasetWorkload) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V10DatasetWorkload) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V10DatasetWorkload) HasName() bool`

HasName returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


