# V11NodeStatusError

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Code** | Pointer to **string** | The error code. | [optional] 
**Field** | Pointer to **string** | The field with the error if applicable. | [optional] 
**Id** | Pointer to **int32** | Node ID (Device Number) of a node. | [optional] 
**Lnn** | Pointer to **int32** | Logical Node Number (LNN) of a node. | [optional] 
**Message** | Pointer to **string** | The error message. | [optional] 
**Status** | Pointer to **int32** | HTTP Status code returned by this node. | [optional] 

## Methods

### NewV11NodeStatusError

`func NewV11NodeStatusError() *V11NodeStatusError`

NewV11NodeStatusError instantiates a new V11NodeStatusError object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11NodeStatusErrorWithDefaults

`func NewV11NodeStatusErrorWithDefaults() *V11NodeStatusError`

NewV11NodeStatusErrorWithDefaults instantiates a new V11NodeStatusError object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCode

`func (o *V11NodeStatusError) GetCode() string`

GetCode returns the Code field if non-nil, zero value otherwise.

### GetCodeOk

`func (o *V11NodeStatusError) GetCodeOk() (*string, bool)`

GetCodeOk returns a tuple with the Code field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCode

`func (o *V11NodeStatusError) SetCode(v string)`

SetCode sets Code field to given value.

### HasCode

`func (o *V11NodeStatusError) HasCode() bool`

HasCode returns a boolean if a field has been set.

### GetField

`func (o *V11NodeStatusError) GetField() string`

GetField returns the Field field if non-nil, zero value otherwise.

### GetFieldOk

`func (o *V11NodeStatusError) GetFieldOk() (*string, bool)`

GetFieldOk returns a tuple with the Field field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetField

`func (o *V11NodeStatusError) SetField(v string)`

SetField sets Field field to given value.

### HasField

`func (o *V11NodeStatusError) HasField() bool`

HasField returns a boolean if a field has been set.

### GetId

`func (o *V11NodeStatusError) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V11NodeStatusError) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V11NodeStatusError) SetId(v int32)`

SetId sets Id field to given value.

### HasId

`func (o *V11NodeStatusError) HasId() bool`

HasId returns a boolean if a field has been set.

### GetLnn

`func (o *V11NodeStatusError) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V11NodeStatusError) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V11NodeStatusError) SetLnn(v int32)`

SetLnn sets Lnn field to given value.

### HasLnn

`func (o *V11NodeStatusError) HasLnn() bool`

HasLnn returns a boolean if a field has been set.

### GetMessage

`func (o *V11NodeStatusError) GetMessage() string`

GetMessage returns the Message field if non-nil, zero value otherwise.

### GetMessageOk

`func (o *V11NodeStatusError) GetMessageOk() (*string, bool)`

GetMessageOk returns a tuple with the Message field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMessage

`func (o *V11NodeStatusError) SetMessage(v string)`

SetMessage sets Message field to given value.

### HasMessage

`func (o *V11NodeStatusError) HasMessage() bool`

HasMessage returns a boolean if a field has been set.

### GetStatus

`func (o *V11NodeStatusError) GetStatus() int32`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V11NodeStatusError) GetStatusOk() (*int32, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V11NodeStatusError) SetStatus(v int32)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V11NodeStatusError) HasStatus() bool`

HasStatus returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


