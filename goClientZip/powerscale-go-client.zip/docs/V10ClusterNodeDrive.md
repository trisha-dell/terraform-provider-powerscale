# V10ClusterNodeDrive

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BayGroup** | Pointer to **string** | The name of the bay group this drive belongs to. | [optional] 
**Baynum** | Pointer to **int32** | Numerical representation of this drive&#39;s bay. | [optional] 
**Blocks** | Pointer to **int32** | Number of blocks on this drive. | [optional] 
**Chassis** | Pointer to **int32** | The chassis number which contains this drive. | [optional] 
**Devname** | Pointer to **string** | This drive&#39;s device name. | [optional] 
**Firmware** | Pointer to [**V10ClusterNodeDriveFirmware**](V10ClusterNodeDriveFirmware.md) |  | [optional] 
**FormatProgress** | Pointer to **int32** | Drive format progress percentage. | [optional] 
**Handle** | Pointer to **int32** | Drive_d&#39;s handle representation for this driveIf we fail to retrieve the handle for this drive from drive_d: -1 | [optional] 
**InterfaceType** | Pointer to **string** | String representation of this drive&#39;s interface type. | [optional] 
**Lnum** | Pointer to **int32** | This drive&#39;s logical drive number in IFS. | [optional] 
**Locnstr** | Pointer to **string** | String representation of this drive&#39;s physical location. | [optional] 
**LogicalBlockLength** | Pointer to **int32** | Size of a logical block on this drive. | [optional] 
**MediaType** | Pointer to **string** | String representation of this drive&#39;s media type. | [optional] 
**Model** | Pointer to **string** | This drive&#39;s manufacturer and model. | [optional] 
**PendingActions** | Pointer to **[]string** | This drive&#39;s current outstanding actions. For example, \&quot;add\&quot; or \&quot;firmware_update\&quot;. | [optional] 
**PhysicalBlockLength** | Pointer to **int32** | Size of a physical block on this drive. | [optional] 
**Present** | Pointer to **bool** | Indicates whether this drive is physically present in the node. | [optional] 
**Purpose** | Pointer to **string** | This drive&#39;s purpose in the DRV state machine. | [optional] 
**PurposeDescription** | Pointer to **string** | Description of this drive&#39;s purpose. | [optional] 
**Serial** | Pointer to **string** | Serial number for this drive. | [optional] 
**UiState** | Pointer to **string** | This drive&#39;s state as presented to the UI. | [optional] 
**Wwn** | Pointer to **string** | The drive&#39;s &#39;worldwide name&#39; from its NAA identifiers. | [optional] 
**XLoc** | Pointer to **int32** | This drive&#39;s x-axis grid location. | [optional] 
**YLoc** | Pointer to **int32** | This drive&#39;s y-axis grid location. | [optional] 

## Methods

### NewV10ClusterNodeDrive

`func NewV10ClusterNodeDrive() *V10ClusterNodeDrive`

NewV10ClusterNodeDrive instantiates a new V10ClusterNodeDrive object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeDriveWithDefaults

`func NewV10ClusterNodeDriveWithDefaults() *V10ClusterNodeDrive`

NewV10ClusterNodeDriveWithDefaults instantiates a new V10ClusterNodeDrive object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBayGroup

`func (o *V10ClusterNodeDrive) GetBayGroup() string`

GetBayGroup returns the BayGroup field if non-nil, zero value otherwise.

### GetBayGroupOk

`func (o *V10ClusterNodeDrive) GetBayGroupOk() (*string, bool)`

GetBayGroupOk returns a tuple with the BayGroup field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBayGroup

`func (o *V10ClusterNodeDrive) SetBayGroup(v string)`

SetBayGroup sets BayGroup field to given value.

### HasBayGroup

`func (o *V10ClusterNodeDrive) HasBayGroup() bool`

HasBayGroup returns a boolean if a field has been set.

### GetBaynum

`func (o *V10ClusterNodeDrive) GetBaynum() int32`

GetBaynum returns the Baynum field if non-nil, zero value otherwise.

### GetBaynumOk

`func (o *V10ClusterNodeDrive) GetBaynumOk() (*int32, bool)`

GetBaynumOk returns a tuple with the Baynum field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBaynum

`func (o *V10ClusterNodeDrive) SetBaynum(v int32)`

SetBaynum sets Baynum field to given value.

### HasBaynum

`func (o *V10ClusterNodeDrive) HasBaynum() bool`

HasBaynum returns a boolean if a field has been set.

### GetBlocks

`func (o *V10ClusterNodeDrive) GetBlocks() int32`

GetBlocks returns the Blocks field if non-nil, zero value otherwise.

### GetBlocksOk

`func (o *V10ClusterNodeDrive) GetBlocksOk() (*int32, bool)`

GetBlocksOk returns a tuple with the Blocks field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBlocks

`func (o *V10ClusterNodeDrive) SetBlocks(v int32)`

SetBlocks sets Blocks field to given value.

### HasBlocks

`func (o *V10ClusterNodeDrive) HasBlocks() bool`

HasBlocks returns a boolean if a field has been set.

### GetChassis

`func (o *V10ClusterNodeDrive) GetChassis() int32`

GetChassis returns the Chassis field if non-nil, zero value otherwise.

### GetChassisOk

`func (o *V10ClusterNodeDrive) GetChassisOk() (*int32, bool)`

GetChassisOk returns a tuple with the Chassis field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChassis

`func (o *V10ClusterNodeDrive) SetChassis(v int32)`

SetChassis sets Chassis field to given value.

### HasChassis

`func (o *V10ClusterNodeDrive) HasChassis() bool`

HasChassis returns a boolean if a field has been set.

### GetDevname

`func (o *V10ClusterNodeDrive) GetDevname() string`

GetDevname returns the Devname field if non-nil, zero value otherwise.

### GetDevnameOk

`func (o *V10ClusterNodeDrive) GetDevnameOk() (*string, bool)`

GetDevnameOk returns a tuple with the Devname field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDevname

`func (o *V10ClusterNodeDrive) SetDevname(v string)`

SetDevname sets Devname field to given value.

### HasDevname

`func (o *V10ClusterNodeDrive) HasDevname() bool`

HasDevname returns a boolean if a field has been set.

### GetFirmware

`func (o *V10ClusterNodeDrive) GetFirmware() V10ClusterNodeDriveFirmware`

GetFirmware returns the Firmware field if non-nil, zero value otherwise.

### GetFirmwareOk

`func (o *V10ClusterNodeDrive) GetFirmwareOk() (*V10ClusterNodeDriveFirmware, bool)`

GetFirmwareOk returns a tuple with the Firmware field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFirmware

`func (o *V10ClusterNodeDrive) SetFirmware(v V10ClusterNodeDriveFirmware)`

SetFirmware sets Firmware field to given value.

### HasFirmware

`func (o *V10ClusterNodeDrive) HasFirmware() bool`

HasFirmware returns a boolean if a field has been set.

### GetFormatProgress

`func (o *V10ClusterNodeDrive) GetFormatProgress() int32`

GetFormatProgress returns the FormatProgress field if non-nil, zero value otherwise.

### GetFormatProgressOk

`func (o *V10ClusterNodeDrive) GetFormatProgressOk() (*int32, bool)`

GetFormatProgressOk returns a tuple with the FormatProgress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFormatProgress

`func (o *V10ClusterNodeDrive) SetFormatProgress(v int32)`

SetFormatProgress sets FormatProgress field to given value.

### HasFormatProgress

`func (o *V10ClusterNodeDrive) HasFormatProgress() bool`

HasFormatProgress returns a boolean if a field has been set.

### GetHandle

`func (o *V10ClusterNodeDrive) GetHandle() int32`

GetHandle returns the Handle field if non-nil, zero value otherwise.

### GetHandleOk

`func (o *V10ClusterNodeDrive) GetHandleOk() (*int32, bool)`

GetHandleOk returns a tuple with the Handle field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHandle

`func (o *V10ClusterNodeDrive) SetHandle(v int32)`

SetHandle sets Handle field to given value.

### HasHandle

`func (o *V10ClusterNodeDrive) HasHandle() bool`

HasHandle returns a boolean if a field has been set.

### GetInterfaceType

`func (o *V10ClusterNodeDrive) GetInterfaceType() string`

GetInterfaceType returns the InterfaceType field if non-nil, zero value otherwise.

### GetInterfaceTypeOk

`func (o *V10ClusterNodeDrive) GetInterfaceTypeOk() (*string, bool)`

GetInterfaceTypeOk returns a tuple with the InterfaceType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInterfaceType

`func (o *V10ClusterNodeDrive) SetInterfaceType(v string)`

SetInterfaceType sets InterfaceType field to given value.

### HasInterfaceType

`func (o *V10ClusterNodeDrive) HasInterfaceType() bool`

HasInterfaceType returns a boolean if a field has been set.

### GetLnum

`func (o *V10ClusterNodeDrive) GetLnum() int32`

GetLnum returns the Lnum field if non-nil, zero value otherwise.

### GetLnumOk

`func (o *V10ClusterNodeDrive) GetLnumOk() (*int32, bool)`

GetLnumOk returns a tuple with the Lnum field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnum

`func (o *V10ClusterNodeDrive) SetLnum(v int32)`

SetLnum sets Lnum field to given value.

### HasLnum

`func (o *V10ClusterNodeDrive) HasLnum() bool`

HasLnum returns a boolean if a field has been set.

### GetLocnstr

`func (o *V10ClusterNodeDrive) GetLocnstr() string`

GetLocnstr returns the Locnstr field if non-nil, zero value otherwise.

### GetLocnstrOk

`func (o *V10ClusterNodeDrive) GetLocnstrOk() (*string, bool)`

GetLocnstrOk returns a tuple with the Locnstr field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLocnstr

`func (o *V10ClusterNodeDrive) SetLocnstr(v string)`

SetLocnstr sets Locnstr field to given value.

### HasLocnstr

`func (o *V10ClusterNodeDrive) HasLocnstr() bool`

HasLocnstr returns a boolean if a field has been set.

### GetLogicalBlockLength

`func (o *V10ClusterNodeDrive) GetLogicalBlockLength() int32`

GetLogicalBlockLength returns the LogicalBlockLength field if non-nil, zero value otherwise.

### GetLogicalBlockLengthOk

`func (o *V10ClusterNodeDrive) GetLogicalBlockLengthOk() (*int32, bool)`

GetLogicalBlockLengthOk returns a tuple with the LogicalBlockLength field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLogicalBlockLength

`func (o *V10ClusterNodeDrive) SetLogicalBlockLength(v int32)`

SetLogicalBlockLength sets LogicalBlockLength field to given value.

### HasLogicalBlockLength

`func (o *V10ClusterNodeDrive) HasLogicalBlockLength() bool`

HasLogicalBlockLength returns a boolean if a field has been set.

### GetMediaType

`func (o *V10ClusterNodeDrive) GetMediaType() string`

GetMediaType returns the MediaType field if non-nil, zero value otherwise.

### GetMediaTypeOk

`func (o *V10ClusterNodeDrive) GetMediaTypeOk() (*string, bool)`

GetMediaTypeOk returns a tuple with the MediaType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMediaType

`func (o *V10ClusterNodeDrive) SetMediaType(v string)`

SetMediaType sets MediaType field to given value.

### HasMediaType

`func (o *V10ClusterNodeDrive) HasMediaType() bool`

HasMediaType returns a boolean if a field has been set.

### GetModel

`func (o *V10ClusterNodeDrive) GetModel() string`

GetModel returns the Model field if non-nil, zero value otherwise.

### GetModelOk

`func (o *V10ClusterNodeDrive) GetModelOk() (*string, bool)`

GetModelOk returns a tuple with the Model field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetModel

`func (o *V10ClusterNodeDrive) SetModel(v string)`

SetModel sets Model field to given value.

### HasModel

`func (o *V10ClusterNodeDrive) HasModel() bool`

HasModel returns a boolean if a field has been set.

### GetPendingActions

`func (o *V10ClusterNodeDrive) GetPendingActions() []string`

GetPendingActions returns the PendingActions field if non-nil, zero value otherwise.

### GetPendingActionsOk

`func (o *V10ClusterNodeDrive) GetPendingActionsOk() (*[]string, bool)`

GetPendingActionsOk returns a tuple with the PendingActions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPendingActions

`func (o *V10ClusterNodeDrive) SetPendingActions(v []string)`

SetPendingActions sets PendingActions field to given value.

### HasPendingActions

`func (o *V10ClusterNodeDrive) HasPendingActions() bool`

HasPendingActions returns a boolean if a field has been set.

### GetPhysicalBlockLength

`func (o *V10ClusterNodeDrive) GetPhysicalBlockLength() int32`

GetPhysicalBlockLength returns the PhysicalBlockLength field if non-nil, zero value otherwise.

### GetPhysicalBlockLengthOk

`func (o *V10ClusterNodeDrive) GetPhysicalBlockLengthOk() (*int32, bool)`

GetPhysicalBlockLengthOk returns a tuple with the PhysicalBlockLength field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPhysicalBlockLength

`func (o *V10ClusterNodeDrive) SetPhysicalBlockLength(v int32)`

SetPhysicalBlockLength sets PhysicalBlockLength field to given value.

### HasPhysicalBlockLength

`func (o *V10ClusterNodeDrive) HasPhysicalBlockLength() bool`

HasPhysicalBlockLength returns a boolean if a field has been set.

### GetPresent

`func (o *V10ClusterNodeDrive) GetPresent() bool`

GetPresent returns the Present field if non-nil, zero value otherwise.

### GetPresentOk

`func (o *V10ClusterNodeDrive) GetPresentOk() (*bool, bool)`

GetPresentOk returns a tuple with the Present field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPresent

`func (o *V10ClusterNodeDrive) SetPresent(v bool)`

SetPresent sets Present field to given value.

### HasPresent

`func (o *V10ClusterNodeDrive) HasPresent() bool`

HasPresent returns a boolean if a field has been set.

### GetPurpose

`func (o *V10ClusterNodeDrive) GetPurpose() string`

GetPurpose returns the Purpose field if non-nil, zero value otherwise.

### GetPurposeOk

`func (o *V10ClusterNodeDrive) GetPurposeOk() (*string, bool)`

GetPurposeOk returns a tuple with the Purpose field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPurpose

`func (o *V10ClusterNodeDrive) SetPurpose(v string)`

SetPurpose sets Purpose field to given value.

### HasPurpose

`func (o *V10ClusterNodeDrive) HasPurpose() bool`

HasPurpose returns a boolean if a field has been set.

### GetPurposeDescription

`func (o *V10ClusterNodeDrive) GetPurposeDescription() string`

GetPurposeDescription returns the PurposeDescription field if non-nil, zero value otherwise.

### GetPurposeDescriptionOk

`func (o *V10ClusterNodeDrive) GetPurposeDescriptionOk() (*string, bool)`

GetPurposeDescriptionOk returns a tuple with the PurposeDescription field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPurposeDescription

`func (o *V10ClusterNodeDrive) SetPurposeDescription(v string)`

SetPurposeDescription sets PurposeDescription field to given value.

### HasPurposeDescription

`func (o *V10ClusterNodeDrive) HasPurposeDescription() bool`

HasPurposeDescription returns a boolean if a field has been set.

### GetSerial

`func (o *V10ClusterNodeDrive) GetSerial() string`

GetSerial returns the Serial field if non-nil, zero value otherwise.

### GetSerialOk

`func (o *V10ClusterNodeDrive) GetSerialOk() (*string, bool)`

GetSerialOk returns a tuple with the Serial field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSerial

`func (o *V10ClusterNodeDrive) SetSerial(v string)`

SetSerial sets Serial field to given value.

### HasSerial

`func (o *V10ClusterNodeDrive) HasSerial() bool`

HasSerial returns a boolean if a field has been set.

### GetUiState

`func (o *V10ClusterNodeDrive) GetUiState() string`

GetUiState returns the UiState field if non-nil, zero value otherwise.

### GetUiStateOk

`func (o *V10ClusterNodeDrive) GetUiStateOk() (*string, bool)`

GetUiStateOk returns a tuple with the UiState field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUiState

`func (o *V10ClusterNodeDrive) SetUiState(v string)`

SetUiState sets UiState field to given value.

### HasUiState

`func (o *V10ClusterNodeDrive) HasUiState() bool`

HasUiState returns a boolean if a field has been set.

### GetWwn

`func (o *V10ClusterNodeDrive) GetWwn() string`

GetWwn returns the Wwn field if non-nil, zero value otherwise.

### GetWwnOk

`func (o *V10ClusterNodeDrive) GetWwnOk() (*string, bool)`

GetWwnOk returns a tuple with the Wwn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWwn

`func (o *V10ClusterNodeDrive) SetWwn(v string)`

SetWwn sets Wwn field to given value.

### HasWwn

`func (o *V10ClusterNodeDrive) HasWwn() bool`

HasWwn returns a boolean if a field has been set.

### GetXLoc

`func (o *V10ClusterNodeDrive) GetXLoc() int32`

GetXLoc returns the XLoc field if non-nil, zero value otherwise.

### GetXLocOk

`func (o *V10ClusterNodeDrive) GetXLocOk() (*int32, bool)`

GetXLocOk returns a tuple with the XLoc field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetXLoc

`func (o *V10ClusterNodeDrive) SetXLoc(v int32)`

SetXLoc sets XLoc field to given value.

### HasXLoc

`func (o *V10ClusterNodeDrive) HasXLoc() bool`

HasXLoc returns a boolean if a field has been set.

### GetYLoc

`func (o *V10ClusterNodeDrive) GetYLoc() int32`

GetYLoc returns the YLoc field if non-nil, zero value otherwise.

### GetYLocOk

`func (o *V10ClusterNodeDrive) GetYLocOk() (*int32, bool)`

GetYLocOk returns a tuple with the YLoc field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetYLoc

`func (o *V10ClusterNodeDrive) SetYLoc(v int32)`

SetYLoc sets YLoc field to given value.

### HasYLoc

`func (o *V10ClusterNodeDrive) HasYLoc() bool`

HasYLoc returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


