# V10SummaryWorkloadWorkloadItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BytesIn** | **float32** | Count of bytes-in per second. | 
**BytesOut** | **float32** | Count of bytes-out per second. | 
**Cpu** | **float32** | The number (across all cores) of micro-seconds per second. | 
**DomainId** | Pointer to **string** | The IFS domain of the path which the operation was requested on. | [optional] 
**Error** | Pointer to **string** | Report any errors during id resolution. | [optional] 
**ExportId** | Pointer to **float32** | The ID of the NFS export through which the operation was requested. | [optional] 
**GroupId** | Pointer to **float32** | Group ID of the group that initiated the operation. | [optional] 
**GroupSid** | Pointer to **string** | Group SID of the group that initiated the operation. | [optional] 
**Groupname** | Pointer to **string** | The resolved text name of the group that initiated the operation. | [optional] 
**JobType** | Pointer to **string** | The canonical name for the job followed by phase in brackets, ie. &#39;AVscan[1]&#39;, etc... | [optional] 
**L2** | **float32** | L2 cache hits per second. | 
**L3** | **float32** | L3 cache hits per second. | 
**LocalAddress** | Pointer to **string** | The IP address of the host receiving the operation request. | [optional] 
**LocalName** | Pointer to **string** | The resolved text name of the LocalAddr, if resolution can be performed. | [optional] 
**Node** | **float32** | The node on which the operation was performed or 0 for cluster scoped statistics. | 
**Ops** | **float32** | Operations per second. | 
**Path** | Pointer to **string** | The path which the operation was requestion on. | [optional] 
**Protocol** | Pointer to **string** | The protocol of the operation. | [optional] 
**Reads** | **float32** | Disk read operations per second. | 
**RemoteAddress** | Pointer to **string** | The IP address of the host sending the operation request. | [optional] 
**RemoteName** | Pointer to **string** | The resolved text name of the RemoteAddr, if resolution can be performed. | [optional] 
**ShareName** | Pointer to **string** | The name of the SMB share through which the operation was requested. | [optional] 
**SystemName** | Pointer to **string** | The process name, job ID, etc... | [optional] 
**Time** | **int32** | Unix Epoch time in seconds that statistic was collected. | 
**UserId** | Pointer to **float32** | User ID of the user who initiated the operation. | [optional] 
**UserSid** | Pointer to **string** | User SID of the user who initiated the operation. | [optional] 
**Username** | Pointer to **string** | The resolved text name of the user who initiated the operation. | [optional] 
**WorkloadId** | Pointer to **int32** | ID of the workload (Pinned workloads only). | [optional] 
**WorkloadType** | Pointer to **string** | The type of workload output. | [optional] 
**Writes** | **float32** | Disk write operations per second. | 
**ZoneId** | Pointer to **float32** | Zone ID | [optional] 
**ZoneName** | Pointer to **string** | The resolved text zone name | [optional] 

## Methods

### NewV10SummaryWorkloadWorkloadItem

`func NewV10SummaryWorkloadWorkloadItem(bytesIn float32, bytesOut float32, cpu float32, l2 float32, l3 float32, node float32, ops float32, reads float32, time int32, writes float32, ) *V10SummaryWorkloadWorkloadItem`

NewV10SummaryWorkloadWorkloadItem instantiates a new V10SummaryWorkloadWorkloadItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10SummaryWorkloadWorkloadItemWithDefaults

`func NewV10SummaryWorkloadWorkloadItemWithDefaults() *V10SummaryWorkloadWorkloadItem`

NewV10SummaryWorkloadWorkloadItemWithDefaults instantiates a new V10SummaryWorkloadWorkloadItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBytesIn

`func (o *V10SummaryWorkloadWorkloadItem) GetBytesIn() float32`

GetBytesIn returns the BytesIn field if non-nil, zero value otherwise.

### GetBytesInOk

`func (o *V10SummaryWorkloadWorkloadItem) GetBytesInOk() (*float32, bool)`

GetBytesInOk returns a tuple with the BytesIn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBytesIn

`func (o *V10SummaryWorkloadWorkloadItem) SetBytesIn(v float32)`

SetBytesIn sets BytesIn field to given value.


### GetBytesOut

`func (o *V10SummaryWorkloadWorkloadItem) GetBytesOut() float32`

GetBytesOut returns the BytesOut field if non-nil, zero value otherwise.

### GetBytesOutOk

`func (o *V10SummaryWorkloadWorkloadItem) GetBytesOutOk() (*float32, bool)`

GetBytesOutOk returns a tuple with the BytesOut field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBytesOut

`func (o *V10SummaryWorkloadWorkloadItem) SetBytesOut(v float32)`

SetBytesOut sets BytesOut field to given value.


### GetCpu

`func (o *V10SummaryWorkloadWorkloadItem) GetCpu() float32`

GetCpu returns the Cpu field if non-nil, zero value otherwise.

### GetCpuOk

`func (o *V10SummaryWorkloadWorkloadItem) GetCpuOk() (*float32, bool)`

GetCpuOk returns a tuple with the Cpu field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCpu

`func (o *V10SummaryWorkloadWorkloadItem) SetCpu(v float32)`

SetCpu sets Cpu field to given value.


### GetDomainId

`func (o *V10SummaryWorkloadWorkloadItem) GetDomainId() string`

GetDomainId returns the DomainId field if non-nil, zero value otherwise.

### GetDomainIdOk

`func (o *V10SummaryWorkloadWorkloadItem) GetDomainIdOk() (*string, bool)`

GetDomainIdOk returns a tuple with the DomainId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDomainId

`func (o *V10SummaryWorkloadWorkloadItem) SetDomainId(v string)`

SetDomainId sets DomainId field to given value.

### HasDomainId

`func (o *V10SummaryWorkloadWorkloadItem) HasDomainId() bool`

HasDomainId returns a boolean if a field has been set.

### GetError

`func (o *V10SummaryWorkloadWorkloadItem) GetError() string`

GetError returns the Error field if non-nil, zero value otherwise.

### GetErrorOk

`func (o *V10SummaryWorkloadWorkloadItem) GetErrorOk() (*string, bool)`

GetErrorOk returns a tuple with the Error field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetError

`func (o *V10SummaryWorkloadWorkloadItem) SetError(v string)`

SetError sets Error field to given value.

### HasError

`func (o *V10SummaryWorkloadWorkloadItem) HasError() bool`

HasError returns a boolean if a field has been set.

### GetExportId

`func (o *V10SummaryWorkloadWorkloadItem) GetExportId() float32`

GetExportId returns the ExportId field if non-nil, zero value otherwise.

### GetExportIdOk

`func (o *V10SummaryWorkloadWorkloadItem) GetExportIdOk() (*float32, bool)`

GetExportIdOk returns a tuple with the ExportId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExportId

`func (o *V10SummaryWorkloadWorkloadItem) SetExportId(v float32)`

SetExportId sets ExportId field to given value.

### HasExportId

`func (o *V10SummaryWorkloadWorkloadItem) HasExportId() bool`

HasExportId returns a boolean if a field has been set.

### GetGroupId

`func (o *V10SummaryWorkloadWorkloadItem) GetGroupId() float32`

GetGroupId returns the GroupId field if non-nil, zero value otherwise.

### GetGroupIdOk

`func (o *V10SummaryWorkloadWorkloadItem) GetGroupIdOk() (*float32, bool)`

GetGroupIdOk returns a tuple with the GroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupId

`func (o *V10SummaryWorkloadWorkloadItem) SetGroupId(v float32)`

SetGroupId sets GroupId field to given value.

### HasGroupId

`func (o *V10SummaryWorkloadWorkloadItem) HasGroupId() bool`

HasGroupId returns a boolean if a field has been set.

### GetGroupSid

`func (o *V10SummaryWorkloadWorkloadItem) GetGroupSid() string`

GetGroupSid returns the GroupSid field if non-nil, zero value otherwise.

### GetGroupSidOk

`func (o *V10SummaryWorkloadWorkloadItem) GetGroupSidOk() (*string, bool)`

GetGroupSidOk returns a tuple with the GroupSid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupSid

`func (o *V10SummaryWorkloadWorkloadItem) SetGroupSid(v string)`

SetGroupSid sets GroupSid field to given value.

### HasGroupSid

`func (o *V10SummaryWorkloadWorkloadItem) HasGroupSid() bool`

HasGroupSid returns a boolean if a field has been set.

### GetGroupname

`func (o *V10SummaryWorkloadWorkloadItem) GetGroupname() string`

GetGroupname returns the Groupname field if non-nil, zero value otherwise.

### GetGroupnameOk

`func (o *V10SummaryWorkloadWorkloadItem) GetGroupnameOk() (*string, bool)`

GetGroupnameOk returns a tuple with the Groupname field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupname

`func (o *V10SummaryWorkloadWorkloadItem) SetGroupname(v string)`

SetGroupname sets Groupname field to given value.

### HasGroupname

`func (o *V10SummaryWorkloadWorkloadItem) HasGroupname() bool`

HasGroupname returns a boolean if a field has been set.

### GetJobType

`func (o *V10SummaryWorkloadWorkloadItem) GetJobType() string`

GetJobType returns the JobType field if non-nil, zero value otherwise.

### GetJobTypeOk

`func (o *V10SummaryWorkloadWorkloadItem) GetJobTypeOk() (*string, bool)`

GetJobTypeOk returns a tuple with the JobType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetJobType

`func (o *V10SummaryWorkloadWorkloadItem) SetJobType(v string)`

SetJobType sets JobType field to given value.

### HasJobType

`func (o *V10SummaryWorkloadWorkloadItem) HasJobType() bool`

HasJobType returns a boolean if a field has been set.

### GetL2

`func (o *V10SummaryWorkloadWorkloadItem) GetL2() float32`

GetL2 returns the L2 field if non-nil, zero value otherwise.

### GetL2Ok

`func (o *V10SummaryWorkloadWorkloadItem) GetL2Ok() (*float32, bool)`

GetL2Ok returns a tuple with the L2 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetL2

`func (o *V10SummaryWorkloadWorkloadItem) SetL2(v float32)`

SetL2 sets L2 field to given value.


### GetL3

`func (o *V10SummaryWorkloadWorkloadItem) GetL3() float32`

GetL3 returns the L3 field if non-nil, zero value otherwise.

### GetL3Ok

`func (o *V10SummaryWorkloadWorkloadItem) GetL3Ok() (*float32, bool)`

GetL3Ok returns a tuple with the L3 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetL3

`func (o *V10SummaryWorkloadWorkloadItem) SetL3(v float32)`

SetL3 sets L3 field to given value.


### GetLocalAddress

`func (o *V10SummaryWorkloadWorkloadItem) GetLocalAddress() string`

GetLocalAddress returns the LocalAddress field if non-nil, zero value otherwise.

### GetLocalAddressOk

`func (o *V10SummaryWorkloadWorkloadItem) GetLocalAddressOk() (*string, bool)`

GetLocalAddressOk returns a tuple with the LocalAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLocalAddress

`func (o *V10SummaryWorkloadWorkloadItem) SetLocalAddress(v string)`

SetLocalAddress sets LocalAddress field to given value.

### HasLocalAddress

`func (o *V10SummaryWorkloadWorkloadItem) HasLocalAddress() bool`

HasLocalAddress returns a boolean if a field has been set.

### GetLocalName

`func (o *V10SummaryWorkloadWorkloadItem) GetLocalName() string`

GetLocalName returns the LocalName field if non-nil, zero value otherwise.

### GetLocalNameOk

`func (o *V10SummaryWorkloadWorkloadItem) GetLocalNameOk() (*string, bool)`

GetLocalNameOk returns a tuple with the LocalName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLocalName

`func (o *V10SummaryWorkloadWorkloadItem) SetLocalName(v string)`

SetLocalName sets LocalName field to given value.

### HasLocalName

`func (o *V10SummaryWorkloadWorkloadItem) HasLocalName() bool`

HasLocalName returns a boolean if a field has been set.

### GetNode

`func (o *V10SummaryWorkloadWorkloadItem) GetNode() float32`

GetNode returns the Node field if non-nil, zero value otherwise.

### GetNodeOk

`func (o *V10SummaryWorkloadWorkloadItem) GetNodeOk() (*float32, bool)`

GetNodeOk returns a tuple with the Node field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNode

`func (o *V10SummaryWorkloadWorkloadItem) SetNode(v float32)`

SetNode sets Node field to given value.


### GetOps

`func (o *V10SummaryWorkloadWorkloadItem) GetOps() float32`

GetOps returns the Ops field if non-nil, zero value otherwise.

### GetOpsOk

`func (o *V10SummaryWorkloadWorkloadItem) GetOpsOk() (*float32, bool)`

GetOpsOk returns a tuple with the Ops field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOps

`func (o *V10SummaryWorkloadWorkloadItem) SetOps(v float32)`

SetOps sets Ops field to given value.


### GetPath

`func (o *V10SummaryWorkloadWorkloadItem) GetPath() string`

GetPath returns the Path field if non-nil, zero value otherwise.

### GetPathOk

`func (o *V10SummaryWorkloadWorkloadItem) GetPathOk() (*string, bool)`

GetPathOk returns a tuple with the Path field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPath

`func (o *V10SummaryWorkloadWorkloadItem) SetPath(v string)`

SetPath sets Path field to given value.

### HasPath

`func (o *V10SummaryWorkloadWorkloadItem) HasPath() bool`

HasPath returns a boolean if a field has been set.

### GetProtocol

`func (o *V10SummaryWorkloadWorkloadItem) GetProtocol() string`

GetProtocol returns the Protocol field if non-nil, zero value otherwise.

### GetProtocolOk

`func (o *V10SummaryWorkloadWorkloadItem) GetProtocolOk() (*string, bool)`

GetProtocolOk returns a tuple with the Protocol field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProtocol

`func (o *V10SummaryWorkloadWorkloadItem) SetProtocol(v string)`

SetProtocol sets Protocol field to given value.

### HasProtocol

`func (o *V10SummaryWorkloadWorkloadItem) HasProtocol() bool`

HasProtocol returns a boolean if a field has been set.

### GetReads

`func (o *V10SummaryWorkloadWorkloadItem) GetReads() float32`

GetReads returns the Reads field if non-nil, zero value otherwise.

### GetReadsOk

`func (o *V10SummaryWorkloadWorkloadItem) GetReadsOk() (*float32, bool)`

GetReadsOk returns a tuple with the Reads field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReads

`func (o *V10SummaryWorkloadWorkloadItem) SetReads(v float32)`

SetReads sets Reads field to given value.


### GetRemoteAddress

`func (o *V10SummaryWorkloadWorkloadItem) GetRemoteAddress() string`

GetRemoteAddress returns the RemoteAddress field if non-nil, zero value otherwise.

### GetRemoteAddressOk

`func (o *V10SummaryWorkloadWorkloadItem) GetRemoteAddressOk() (*string, bool)`

GetRemoteAddressOk returns a tuple with the RemoteAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemoteAddress

`func (o *V10SummaryWorkloadWorkloadItem) SetRemoteAddress(v string)`

SetRemoteAddress sets RemoteAddress field to given value.

### HasRemoteAddress

`func (o *V10SummaryWorkloadWorkloadItem) HasRemoteAddress() bool`

HasRemoteAddress returns a boolean if a field has been set.

### GetRemoteName

`func (o *V10SummaryWorkloadWorkloadItem) GetRemoteName() string`

GetRemoteName returns the RemoteName field if non-nil, zero value otherwise.

### GetRemoteNameOk

`func (o *V10SummaryWorkloadWorkloadItem) GetRemoteNameOk() (*string, bool)`

GetRemoteNameOk returns a tuple with the RemoteName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemoteName

`func (o *V10SummaryWorkloadWorkloadItem) SetRemoteName(v string)`

SetRemoteName sets RemoteName field to given value.

### HasRemoteName

`func (o *V10SummaryWorkloadWorkloadItem) HasRemoteName() bool`

HasRemoteName returns a boolean if a field has been set.

### GetShareName

`func (o *V10SummaryWorkloadWorkloadItem) GetShareName() string`

GetShareName returns the ShareName field if non-nil, zero value otherwise.

### GetShareNameOk

`func (o *V10SummaryWorkloadWorkloadItem) GetShareNameOk() (*string, bool)`

GetShareNameOk returns a tuple with the ShareName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShareName

`func (o *V10SummaryWorkloadWorkloadItem) SetShareName(v string)`

SetShareName sets ShareName field to given value.

### HasShareName

`func (o *V10SummaryWorkloadWorkloadItem) HasShareName() bool`

HasShareName returns a boolean if a field has been set.

### GetSystemName

`func (o *V10SummaryWorkloadWorkloadItem) GetSystemName() string`

GetSystemName returns the SystemName field if non-nil, zero value otherwise.

### GetSystemNameOk

`func (o *V10SummaryWorkloadWorkloadItem) GetSystemNameOk() (*string, bool)`

GetSystemNameOk returns a tuple with the SystemName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSystemName

`func (o *V10SummaryWorkloadWorkloadItem) SetSystemName(v string)`

SetSystemName sets SystemName field to given value.

### HasSystemName

`func (o *V10SummaryWorkloadWorkloadItem) HasSystemName() bool`

HasSystemName returns a boolean if a field has been set.

### GetTime

`func (o *V10SummaryWorkloadWorkloadItem) GetTime() int32`

GetTime returns the Time field if non-nil, zero value otherwise.

### GetTimeOk

`func (o *V10SummaryWorkloadWorkloadItem) GetTimeOk() (*int32, bool)`

GetTimeOk returns a tuple with the Time field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTime

`func (o *V10SummaryWorkloadWorkloadItem) SetTime(v int32)`

SetTime sets Time field to given value.


### GetUserId

`func (o *V10SummaryWorkloadWorkloadItem) GetUserId() float32`

GetUserId returns the UserId field if non-nil, zero value otherwise.

### GetUserIdOk

`func (o *V10SummaryWorkloadWorkloadItem) GetUserIdOk() (*float32, bool)`

GetUserIdOk returns a tuple with the UserId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUserId

`func (o *V10SummaryWorkloadWorkloadItem) SetUserId(v float32)`

SetUserId sets UserId field to given value.

### HasUserId

`func (o *V10SummaryWorkloadWorkloadItem) HasUserId() bool`

HasUserId returns a boolean if a field has been set.

### GetUserSid

`func (o *V10SummaryWorkloadWorkloadItem) GetUserSid() string`

GetUserSid returns the UserSid field if non-nil, zero value otherwise.

### GetUserSidOk

`func (o *V10SummaryWorkloadWorkloadItem) GetUserSidOk() (*string, bool)`

GetUserSidOk returns a tuple with the UserSid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUserSid

`func (o *V10SummaryWorkloadWorkloadItem) SetUserSid(v string)`

SetUserSid sets UserSid field to given value.

### HasUserSid

`func (o *V10SummaryWorkloadWorkloadItem) HasUserSid() bool`

HasUserSid returns a boolean if a field has been set.

### GetUsername

`func (o *V10SummaryWorkloadWorkloadItem) GetUsername() string`

GetUsername returns the Username field if non-nil, zero value otherwise.

### GetUsernameOk

`func (o *V10SummaryWorkloadWorkloadItem) GetUsernameOk() (*string, bool)`

GetUsernameOk returns a tuple with the Username field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUsername

`func (o *V10SummaryWorkloadWorkloadItem) SetUsername(v string)`

SetUsername sets Username field to given value.

### HasUsername

`func (o *V10SummaryWorkloadWorkloadItem) HasUsername() bool`

HasUsername returns a boolean if a field has been set.

### GetWorkloadId

`func (o *V10SummaryWorkloadWorkloadItem) GetWorkloadId() int32`

GetWorkloadId returns the WorkloadId field if non-nil, zero value otherwise.

### GetWorkloadIdOk

`func (o *V10SummaryWorkloadWorkloadItem) GetWorkloadIdOk() (*int32, bool)`

GetWorkloadIdOk returns a tuple with the WorkloadId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWorkloadId

`func (o *V10SummaryWorkloadWorkloadItem) SetWorkloadId(v int32)`

SetWorkloadId sets WorkloadId field to given value.

### HasWorkloadId

`func (o *V10SummaryWorkloadWorkloadItem) HasWorkloadId() bool`

HasWorkloadId returns a boolean if a field has been set.

### GetWorkloadType

`func (o *V10SummaryWorkloadWorkloadItem) GetWorkloadType() string`

GetWorkloadType returns the WorkloadType field if non-nil, zero value otherwise.

### GetWorkloadTypeOk

`func (o *V10SummaryWorkloadWorkloadItem) GetWorkloadTypeOk() (*string, bool)`

GetWorkloadTypeOk returns a tuple with the WorkloadType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWorkloadType

`func (o *V10SummaryWorkloadWorkloadItem) SetWorkloadType(v string)`

SetWorkloadType sets WorkloadType field to given value.

### HasWorkloadType

`func (o *V10SummaryWorkloadWorkloadItem) HasWorkloadType() bool`

HasWorkloadType returns a boolean if a field has been set.

### GetWrites

`func (o *V10SummaryWorkloadWorkloadItem) GetWrites() float32`

GetWrites returns the Writes field if non-nil, zero value otherwise.

### GetWritesOk

`func (o *V10SummaryWorkloadWorkloadItem) GetWritesOk() (*float32, bool)`

GetWritesOk returns a tuple with the Writes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWrites

`func (o *V10SummaryWorkloadWorkloadItem) SetWrites(v float32)`

SetWrites sets Writes field to given value.


### GetZoneId

`func (o *V10SummaryWorkloadWorkloadItem) GetZoneId() float32`

GetZoneId returns the ZoneId field if non-nil, zero value otherwise.

### GetZoneIdOk

`func (o *V10SummaryWorkloadWorkloadItem) GetZoneIdOk() (*float32, bool)`

GetZoneIdOk returns a tuple with the ZoneId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetZoneId

`func (o *V10SummaryWorkloadWorkloadItem) SetZoneId(v float32)`

SetZoneId sets ZoneId field to given value.

### HasZoneId

`func (o *V10SummaryWorkloadWorkloadItem) HasZoneId() bool`

HasZoneId returns a boolean if a field has been set.

### GetZoneName

`func (o *V10SummaryWorkloadWorkloadItem) GetZoneName() string`

GetZoneName returns the ZoneName field if non-nil, zero value otherwise.

### GetZoneNameOk

`func (o *V10SummaryWorkloadWorkloadItem) GetZoneNameOk() (*string, bool)`

GetZoneNameOk returns a tuple with the ZoneName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetZoneName

`func (o *V10SummaryWorkloadWorkloadItem) SetZoneName(v string)`

SetZoneName sets ZoneName field to given value.

### HasZoneName

`func (o *V10SummaryWorkloadWorkloadItem) HasZoneName() bool`

HasZoneName returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


