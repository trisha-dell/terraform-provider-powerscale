# Createv12LfnItemResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | Pointer to **int32** | Specifies the system-assigned ID for the long filename domain. | [optional] 
**Inherited** | Pointer to **bool** | Specifies if the file name length properties are inherited from a different path or not compared to the original query location. | [optional] 
**MaxBytes** | Pointer to **int32** | Specifies the maximum number of bytes the UTF-8 encoded filename can have. This may be more than the character limit as a single character could require up to 4 bytes to be encoded. | [optional] 
**MaxChars** | Pointer to **int32** | Specifies the maximum number of characters a filename can have. Each character will require between 1 and 4 bytes to encode. | [optional] 
**Path** | Pointer to **string** | Specifies the root path that the file name length properties apply to. Files in this directory and all sub-directories will inherit these settings unless overriden. | [optional] 
**Policy** | Pointer to **string** | Specifies the name length policy for bytes and chars. | [optional] 

## Methods

### NewCreatev12LfnItemResponse

`func NewCreatev12LfnItemResponse() *Createv12LfnItemResponse`

NewCreatev12LfnItemResponse instantiates a new Createv12LfnItemResponse object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev12LfnItemResponseWithDefaults

`func NewCreatev12LfnItemResponseWithDefaults() *Createv12LfnItemResponse`

NewCreatev12LfnItemResponseWithDefaults instantiates a new Createv12LfnItemResponse object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *Createv12LfnItemResponse) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *Createv12LfnItemResponse) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *Createv12LfnItemResponse) SetId(v int32)`

SetId sets Id field to given value.

### HasId

`func (o *Createv12LfnItemResponse) HasId() bool`

HasId returns a boolean if a field has been set.

### GetInherited

`func (o *Createv12LfnItemResponse) GetInherited() bool`

GetInherited returns the Inherited field if non-nil, zero value otherwise.

### GetInheritedOk

`func (o *Createv12LfnItemResponse) GetInheritedOk() (*bool, bool)`

GetInheritedOk returns a tuple with the Inherited field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInherited

`func (o *Createv12LfnItemResponse) SetInherited(v bool)`

SetInherited sets Inherited field to given value.

### HasInherited

`func (o *Createv12LfnItemResponse) HasInherited() bool`

HasInherited returns a boolean if a field has been set.

### GetMaxBytes

`func (o *Createv12LfnItemResponse) GetMaxBytes() int32`

GetMaxBytes returns the MaxBytes field if non-nil, zero value otherwise.

### GetMaxBytesOk

`func (o *Createv12LfnItemResponse) GetMaxBytesOk() (*int32, bool)`

GetMaxBytesOk returns a tuple with the MaxBytes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaxBytes

`func (o *Createv12LfnItemResponse) SetMaxBytes(v int32)`

SetMaxBytes sets MaxBytes field to given value.

### HasMaxBytes

`func (o *Createv12LfnItemResponse) HasMaxBytes() bool`

HasMaxBytes returns a boolean if a field has been set.

### GetMaxChars

`func (o *Createv12LfnItemResponse) GetMaxChars() int32`

GetMaxChars returns the MaxChars field if non-nil, zero value otherwise.

### GetMaxCharsOk

`func (o *Createv12LfnItemResponse) GetMaxCharsOk() (*int32, bool)`

GetMaxCharsOk returns a tuple with the MaxChars field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaxChars

`func (o *Createv12LfnItemResponse) SetMaxChars(v int32)`

SetMaxChars sets MaxChars field to given value.

### HasMaxChars

`func (o *Createv12LfnItemResponse) HasMaxChars() bool`

HasMaxChars returns a boolean if a field has been set.

### GetPath

`func (o *Createv12LfnItemResponse) GetPath() string`

GetPath returns the Path field if non-nil, zero value otherwise.

### GetPathOk

`func (o *Createv12LfnItemResponse) GetPathOk() (*string, bool)`

GetPathOk returns a tuple with the Path field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPath

`func (o *Createv12LfnItemResponse) SetPath(v string)`

SetPath sets Path field to given value.

### HasPath

`func (o *Createv12LfnItemResponse) HasPath() bool`

HasPath returns a boolean if a field has been set.

### GetPolicy

`func (o *Createv12LfnItemResponse) GetPolicy() string`

GetPolicy returns the Policy field if non-nil, zero value otherwise.

### GetPolicyOk

`func (o *Createv12LfnItemResponse) GetPolicyOk() (*string, bool)`

GetPolicyOk returns a tuple with the Policy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPolicy

`func (o *Createv12LfnItemResponse) SetPolicy(v string)`

SetPolicy sets Policy field to given value.

### HasPolicy

`func (o *Createv12LfnItemResponse) HasPolicy() bool`

HasPolicy returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


