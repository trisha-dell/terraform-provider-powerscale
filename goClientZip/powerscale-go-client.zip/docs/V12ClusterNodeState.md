# V12ClusterNodeState

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Readonly** | Pointer to [**V10ClusterNodeStateReadonly**](V10ClusterNodeStateReadonly.md) |  | [optional] 
**Servicelight** | Pointer to [**V12ClusterNodeStateServicelight**](V12ClusterNodeStateServicelight.md) |  | [optional] 
**Smartfail** | Pointer to [**V10ClusterNodeStateSmartfail**](V10ClusterNodeStateSmartfail.md) |  | [optional] 

## Methods

### NewV12ClusterNodeState

`func NewV12ClusterNodeState() *V12ClusterNodeState`

NewV12ClusterNodeState instantiates a new V12ClusterNodeState object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12ClusterNodeStateWithDefaults

`func NewV12ClusterNodeStateWithDefaults() *V12ClusterNodeState`

NewV12ClusterNodeStateWithDefaults instantiates a new V12ClusterNodeState object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetReadonly

`func (o *V12ClusterNodeState) GetReadonly() V10ClusterNodeStateReadonly`

GetReadonly returns the Readonly field if non-nil, zero value otherwise.

### GetReadonlyOk

`func (o *V12ClusterNodeState) GetReadonlyOk() (*V10ClusterNodeStateReadonly, bool)`

GetReadonlyOk returns a tuple with the Readonly field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadonly

`func (o *V12ClusterNodeState) SetReadonly(v V10ClusterNodeStateReadonly)`

SetReadonly sets Readonly field to given value.

### HasReadonly

`func (o *V12ClusterNodeState) HasReadonly() bool`

HasReadonly returns a boolean if a field has been set.

### GetServicelight

`func (o *V12ClusterNodeState) GetServicelight() V12ClusterNodeStateServicelight`

GetServicelight returns the Servicelight field if non-nil, zero value otherwise.

### GetServicelightOk

`func (o *V12ClusterNodeState) GetServicelightOk() (*V12ClusterNodeStateServicelight, bool)`

GetServicelightOk returns a tuple with the Servicelight field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServicelight

`func (o *V12ClusterNodeState) SetServicelight(v V12ClusterNodeStateServicelight)`

SetServicelight sets Servicelight field to given value.

### HasServicelight

`func (o *V12ClusterNodeState) HasServicelight() bool`

HasServicelight returns a boolean if a field has been set.

### GetSmartfail

`func (o *V12ClusterNodeState) GetSmartfail() V10ClusterNodeStateSmartfail`

GetSmartfail returns the Smartfail field if non-nil, zero value otherwise.

### GetSmartfailOk

`func (o *V12ClusterNodeState) GetSmartfailOk() (*V10ClusterNodeStateSmartfail, bool)`

GetSmartfailOk returns a tuple with the Smartfail field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmartfail

`func (o *V12ClusterNodeState) SetSmartfail(v V10ClusterNodeStateSmartfail)`

SetSmartfail sets Smartfail field to given value.

### HasSmartfail

`func (o *V12ClusterNodeState) HasSmartfail() bool`

HasSmartfail returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


