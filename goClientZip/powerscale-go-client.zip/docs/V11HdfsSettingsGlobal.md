# V11HdfsSettingsGlobal

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**GlobalSettings** | Pointer to [**V11HdfsSettingsGlobalGlobalSettings**](V11HdfsSettingsGlobalGlobalSettings.md) |  | [optional] 

## Methods

### NewV11HdfsSettingsGlobal

`func NewV11HdfsSettingsGlobal() *V11HdfsSettingsGlobal`

NewV11HdfsSettingsGlobal instantiates a new V11HdfsSettingsGlobal object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11HdfsSettingsGlobalWithDefaults

`func NewV11HdfsSettingsGlobalWithDefaults() *V11HdfsSettingsGlobal`

NewV11HdfsSettingsGlobalWithDefaults instantiates a new V11HdfsSettingsGlobal object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetGlobalSettings

`func (o *V11HdfsSettingsGlobal) GetGlobalSettings() V11HdfsSettingsGlobalGlobalSettings`

GetGlobalSettings returns the GlobalSettings field if non-nil, zero value otherwise.

### GetGlobalSettingsOk

`func (o *V11HdfsSettingsGlobal) GetGlobalSettingsOk() (*V11HdfsSettingsGlobalGlobalSettings, bool)`

GetGlobalSettingsOk returns a tuple with the GlobalSettings field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGlobalSettings

`func (o *V11HdfsSettingsGlobal) SetGlobalSettings(v V11HdfsSettingsGlobalGlobalSettings)`

SetGlobalSettings sets GlobalSettings field to given value.

### HasGlobalSettings

`func (o *V11HdfsSettingsGlobal) HasGlobalSettings() bool`

HasGlobalSettings returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


