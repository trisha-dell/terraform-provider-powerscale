# V12UpgradeClusterCommittedFeaturesGenBit

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Bits** | Pointer to **[]int32** |  | [optional] 
**Gen** | Pointer to **int32** |  | [optional] 

## Methods

### NewV12UpgradeClusterCommittedFeaturesGenBit

`func NewV12UpgradeClusterCommittedFeaturesGenBit() *V12UpgradeClusterCommittedFeaturesGenBit`

NewV12UpgradeClusterCommittedFeaturesGenBit instantiates a new V12UpgradeClusterCommittedFeaturesGenBit object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12UpgradeClusterCommittedFeaturesGenBitWithDefaults

`func NewV12UpgradeClusterCommittedFeaturesGenBitWithDefaults() *V12UpgradeClusterCommittedFeaturesGenBit`

NewV12UpgradeClusterCommittedFeaturesGenBitWithDefaults instantiates a new V12UpgradeClusterCommittedFeaturesGenBit object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBits

`func (o *V12UpgradeClusterCommittedFeaturesGenBit) GetBits() []int32`

GetBits returns the Bits field if non-nil, zero value otherwise.

### GetBitsOk

`func (o *V12UpgradeClusterCommittedFeaturesGenBit) GetBitsOk() (*[]int32, bool)`

GetBitsOk returns a tuple with the Bits field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBits

`func (o *V12UpgradeClusterCommittedFeaturesGenBit) SetBits(v []int32)`

SetBits sets Bits field to given value.

### HasBits

`func (o *V12UpgradeClusterCommittedFeaturesGenBit) HasBits() bool`

HasBits returns a boolean if a field has been set.

### GetGen

`func (o *V12UpgradeClusterCommittedFeaturesGenBit) GetGen() int32`

GetGen returns the Gen field if non-nil, zero value otherwise.

### GetGenOk

`func (o *V12UpgradeClusterCommittedFeaturesGenBit) GetGenOk() (*int32, bool)`

GetGenOk returns a tuple with the Gen field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGen

`func (o *V12UpgradeClusterCommittedFeaturesGenBit) SetGen(v int32)`

SetGen sets Gen field to given value.

### HasGen

`func (o *V12UpgradeClusterCommittedFeaturesGenBit) HasGen() bool`

HasGen returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


