# \StatisticsApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetStatisticsv10SummaryWorkload**](StatisticsApi.md#GetStatisticsv10SummaryWorkload) | **Get** /platform/10/statistics/summary/workload | 
[**GetStatisticsv14SummaryCloud**](StatisticsApi.md#GetStatisticsv14SummaryCloud) | **Get** /platform/14/statistics/summary/cloud | 
[**GetStatisticsv1StatisticsCurrent**](StatisticsApi.md#GetStatisticsv1StatisticsCurrent) | **Get** /platform/1/statistics/current | 
[**GetStatisticsv1StatisticsHistory**](StatisticsApi.md#GetStatisticsv1StatisticsHistory) | **Get** /platform/1/statistics/history | 
[**GetStatisticsv1StatisticsKey**](StatisticsApi.md#GetStatisticsv1StatisticsKey) | **Get** /platform/1/statistics/keys/{v1StatisticsKeyId} | 
[**GetStatisticsv1StatisticsKeys**](StatisticsApi.md#GetStatisticsv1StatisticsKeys) | **Get** /platform/1/statistics/keys | 
[**GetStatisticsv1StatisticsProtocols**](StatisticsApi.md#GetStatisticsv1StatisticsProtocols) | **Get** /platform/1/statistics/protocols | 
[**GetStatisticsv3StatisticsOperations**](StatisticsApi.md#GetStatisticsv3StatisticsOperations) | **Get** /platform/3/statistics/operations | 
[**GetStatisticsv3SummaryClient**](StatisticsApi.md#GetStatisticsv3SummaryClient) | **Get** /platform/3/statistics/summary/client | 
[**GetStatisticsv3SummaryDrive**](StatisticsApi.md#GetStatisticsv3SummaryDrive) | **Get** /platform/3/statistics/summary/drive | 
[**GetStatisticsv3SummaryHeat**](StatisticsApi.md#GetStatisticsv3SummaryHeat) | **Get** /platform/3/statistics/summary/heat | 
[**GetStatisticsv3SummaryProtocol**](StatisticsApi.md#GetStatisticsv3SummaryProtocol) | **Get** /platform/3/statistics/summary/protocol | 
[**GetStatisticsv3SummaryProtocolStats**](StatisticsApi.md#GetStatisticsv3SummaryProtocolStats) | **Get** /platform/3/statistics/summary/protocol-stats | 
[**GetStatisticsv3SummarySystem**](StatisticsApi.md#GetStatisticsv3SummarySystem) | **Get** /platform/3/statistics/summary/system | 
[**GetStatisticsv4SummaryWorkload**](StatisticsApi.md#GetStatisticsv4SummaryWorkload) | **Get** /platform/4/statistics/summary/workload | 
[**GetStatisticsv9SummaryWorkload**](StatisticsApi.md#GetStatisticsv9SummaryWorkload) | **Get** /platform/9/statistics/summary/workload | 



## GetStatisticsv10SummaryWorkload

> V10SummaryWorkload GetStatisticsv10SummaryWorkload(ctx).GroupSids(groupSids).Numeric(numeric).ExportIds(exportIds).Degraded(degraded).RemoteNames(remoteNames).ShareNames(shareNames).Paths(paths).Usernames(usernames).RemoteAddresses(remoteAddresses).JobTypes(jobTypes).ZoneIds(zoneIds).Groupnames(groupnames).Nodes(nodes).Sort(sort).DomainIds(domainIds).ZoneNames(zoneNames).LocalNames(localNames).UserIds(userIds).Totalby(totalby).LocalAddresses(localAddresses).Dataset(dataset).UserSids(userSids).Protocols(protocols).GroupIds(groupIds).Timeout(timeout).SystemNames(systemNames).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupSids := "groupSids_example" // string | A comma separated list. Only report statistics for groups specified by Group Security IDs, if configured.  (optional)
    numeric := true // bool | Do not resolve addresses and usernames to their human readable form(s). Default is false.  (optional)
    exportIds := "exportIds_example" // string | A comma separated list. Only report statistics for exports specified by id, if configured.  (optional)
    degraded := true // bool | Continue to report if some nodes do not respond. (optional)
    remoteNames := "remoteNames_example" // string | A comma separated list. Only report statistics for remote clients specified by resolved names, if configured.  (optional)
    shareNames := "shareNames_example" // string | A comma separated list. Only report statistics for shares specified by name, if configured.  (optional)
    paths := "paths_example" // string | A comma separated list. Only report statistics for paths specified by name, if configured.  (optional)
    usernames := "usernames_example" // string | A comma separated list. Only report statistics for users specified by resolved names, if configured.  (optional)
    remoteAddresses := "remoteAddresses_example" // string | A comma separated list. Only report statistics for remote clients specified by IP addresses, if configured.  (optional)
    jobTypes := []string{"Inner_example"} // []string | A comma separated list. Only report statistics for job(s) specified by type, if configured.  (optional)
    zoneIds := "zoneIds_example" // string | A comma separated list. Only report statistics for users in zone specified by id, if configured.  (optional)
    groupnames := "groupnames_example" // string | A comma separated list. Only report statistics for groups specified by resolved names, if configured.  (optional)
    nodes := "nodes_example" // string | A comma separated list. Specify node(s) for which statistics should be reported. Default is all. Zero (0) should be passed in as the sole argument to indicate local. (optional)
    sort := "sort_example" // string | Sort data by the specified comma-separated field(s). ( node | workload_id | system_name | user_id | user_sid | username | group_id | group_sid | groupname | domain_id | path | zone_id | zone_name | export_id | local_addr | local_name | remote_addr | remote_name | protocol | share_name | job_type | cpu | bytes_in | bytes_out | ops | reads | writes | l2 | l3 | latency_read | latency_write | latency_other | error). Prepend 'asc:' or 'desc:' to a field to change the sort direction.  (optional)
    domainIds := "domainIds_example" // string | A comma separated list. Only report statistics for domains specified by id, if configured.  (optional)
    zoneNames := "zoneNames_example" // string | A comma separated list. Only report statistics for users in zone specified by name, if configured.  (optional)
    localNames := "localNames_example" // string | A comma separated list. Only report statistics for local hosts specified by resolved names, if configured.  (optional)
    userIds := "userIds_example" // string | A comma separated list. Only report statistics for users specified by numeric UIDs, if configured.  (optional)
    totalby := "totalby_example" // string | A comma separated list specifying what should be unique. (node | system_name | user_id | user_sid | username | zone_id | zone_name | local_addr | local_name | remote_addr | remote_name | group_id | group_sid | groupname | domain_id | path | export_id | protocol | share_name | job_type). Aggregation is performed over all the fields not specified in the list. (optional)
    localAddresses := "localAddresses_example" // string | A comma separated list. Only report statistics for local hosts specified by IP addresses, if configured.  (optional)
    dataset := "dataset_example" // string | Report workload performance metrics for specified dataset. Default is 'System'. (optional)
    userSids := "userSids_example" // string | A comma separated list. Only report statistics for users specified by Security IDs, if configured.  (optional)
    protocols := "protocols_example" // string | A comma separated list. Default is all. (smb1, smb2, nfs3, nfs4 and s3 only at this time.) (optional)
    groupIds := "groupIds_example" // string | A comma separated list. Only report statistics for groups specified by numeric GIDs, if configured.  (optional)
    timeout := int32(56) // int32 | Timeout remote commands after NUM seconds, where NUM is the integer passed to the argument. (optional)
    systemNames := "systemNames_example" // string | A comma separated list. Only report statistics for systems specified by resolved names, if configured.  (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StatisticsApi.GetStatisticsv10SummaryWorkload(context.Background()).GroupSids(groupSids).Numeric(numeric).ExportIds(exportIds).Degraded(degraded).RemoteNames(remoteNames).ShareNames(shareNames).Paths(paths).Usernames(usernames).RemoteAddresses(remoteAddresses).JobTypes(jobTypes).ZoneIds(zoneIds).Groupnames(groupnames).Nodes(nodes).Sort(sort).DomainIds(domainIds).ZoneNames(zoneNames).LocalNames(localNames).UserIds(userIds).Totalby(totalby).LocalAddresses(localAddresses).Dataset(dataset).UserSids(userSids).Protocols(protocols).GroupIds(groupIds).Timeout(timeout).SystemNames(systemNames).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StatisticsApi.GetStatisticsv10SummaryWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStatisticsv10SummaryWorkload`: V10SummaryWorkload
    fmt.Fprintf(os.Stdout, "Response from `StatisticsApi.GetStatisticsv10SummaryWorkload`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetStatisticsv10SummaryWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **groupSids** | **string** | A comma separated list. Only report statistics for groups specified by Group Security IDs, if configured.  | 
 **numeric** | **bool** | Do not resolve addresses and usernames to their human readable form(s). Default is false.  | 
 **exportIds** | **string** | A comma separated list. Only report statistics for exports specified by id, if configured.  | 
 **degraded** | **bool** | Continue to report if some nodes do not respond. | 
 **remoteNames** | **string** | A comma separated list. Only report statistics for remote clients specified by resolved names, if configured.  | 
 **shareNames** | **string** | A comma separated list. Only report statistics for shares specified by name, if configured.  | 
 **paths** | **string** | A comma separated list. Only report statistics for paths specified by name, if configured.  | 
 **usernames** | **string** | A comma separated list. Only report statistics for users specified by resolved names, if configured.  | 
 **remoteAddresses** | **string** | A comma separated list. Only report statistics for remote clients specified by IP addresses, if configured.  | 
 **jobTypes** | **[]string** | A comma separated list. Only report statistics for job(s) specified by type, if configured.  | 
 **zoneIds** | **string** | A comma separated list. Only report statistics for users in zone specified by id, if configured.  | 
 **groupnames** | **string** | A comma separated list. Only report statistics for groups specified by resolved names, if configured.  | 
 **nodes** | **string** | A comma separated list. Specify node(s) for which statistics should be reported. Default is all. Zero (0) should be passed in as the sole argument to indicate local. | 
 **sort** | **string** | Sort data by the specified comma-separated field(s). ( node | workload_id | system_name | user_id | user_sid | username | group_id | group_sid | groupname | domain_id | path | zone_id | zone_name | export_id | local_addr | local_name | remote_addr | remote_name | protocol | share_name | job_type | cpu | bytes_in | bytes_out | ops | reads | writes | l2 | l3 | latency_read | latency_write | latency_other | error). Prepend &#39;asc:&#39; or &#39;desc:&#39; to a field to change the sort direction.  | 
 **domainIds** | **string** | A comma separated list. Only report statistics for domains specified by id, if configured.  | 
 **zoneNames** | **string** | A comma separated list. Only report statistics for users in zone specified by name, if configured.  | 
 **localNames** | **string** | A comma separated list. Only report statistics for local hosts specified by resolved names, if configured.  | 
 **userIds** | **string** | A comma separated list. Only report statistics for users specified by numeric UIDs, if configured.  | 
 **totalby** | **string** | A comma separated list specifying what should be unique. (node | system_name | user_id | user_sid | username | zone_id | zone_name | local_addr | local_name | remote_addr | remote_name | group_id | group_sid | groupname | domain_id | path | export_id | protocol | share_name | job_type). Aggregation is performed over all the fields not specified in the list. | 
 **localAddresses** | **string** | A comma separated list. Only report statistics for local hosts specified by IP addresses, if configured.  | 
 **dataset** | **string** | Report workload performance metrics for specified dataset. Default is &#39;System&#39;. | 
 **userSids** | **string** | A comma separated list. Only report statistics for users specified by Security IDs, if configured.  | 
 **protocols** | **string** | A comma separated list. Default is all. (smb1, smb2, nfs3, nfs4 and s3 only at this time.) | 
 **groupIds** | **string** | A comma separated list. Only report statistics for groups specified by numeric GIDs, if configured.  | 
 **timeout** | **int32** | Timeout remote commands after NUM seconds, where NUM is the integer passed to the argument. | 
 **systemNames** | **string** | A comma separated list. Only report statistics for systems specified by resolved names, if configured.  | 

### Return type

[**V10SummaryWorkload**](V10SummaryWorkload.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStatisticsv14SummaryCloud

> V14SummaryCloud GetStatisticsv14SummaryCloud(ctx).Sort(sort).Account(account).Timeout(timeout).Policy(policy).Nodes(nodes).Degraded(degraded).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | Sort data by the specified comma-separated field(s). ( account | policy | in | out | reads | writes | deletes | cloud | node). Prepend 'asc:' or 'desc:' to a field to change the sort direction.  (optional)
    account := "account_example" // string | Specify an account for which statistics should be reported. (optional)
    timeout := int32(56) // int32 | Timeout remote commands after NUM seconds. Defaults to 5 seconds. (optional)
    policy := "policy_example" // string | Specify a policy for which statistics should be reported. (optional)
    nodes := "nodes_example" // string | Specify node(s) for which statistics should be reported. Default is 'all'. Zero (0) should be passed in as the sole argument to indicate local. (optional)
    degraded := true // bool | Continue to report even if some nodes do not respond.Defaults to false. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StatisticsApi.GetStatisticsv14SummaryCloud(context.Background()).Sort(sort).Account(account).Timeout(timeout).Policy(policy).Nodes(nodes).Degraded(degraded).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StatisticsApi.GetStatisticsv14SummaryCloud``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStatisticsv14SummaryCloud`: V14SummaryCloud
    fmt.Fprintf(os.Stdout, "Response from `StatisticsApi.GetStatisticsv14SummaryCloud`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetStatisticsv14SummaryCloudRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | Sort data by the specified comma-separated field(s). ( account | policy | in | out | reads | writes | deletes | cloud | node). Prepend &#39;asc:&#39; or &#39;desc:&#39; to a field to change the sort direction.  | 
 **account** | **string** | Specify an account for which statistics should be reported. | 
 **timeout** | **int32** | Timeout remote commands after NUM seconds. Defaults to 5 seconds. | 
 **policy** | **string** | Specify a policy for which statistics should be reported. | 
 **nodes** | **string** | Specify node(s) for which statistics should be reported. Default is &#39;all&#39;. Zero (0) should be passed in as the sole argument to indicate local. | 
 **degraded** | **bool** | Continue to report even if some nodes do not respond.Defaults to false. | 

### Return type

[**V14SummaryCloud**](V14SummaryCloud.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStatisticsv1StatisticsCurrent

> V1StatisticsCurrent GetStatisticsv1StatisticsCurrent(ctx).Timeout(timeout).ShowNodes(showNodes).Keys(keys).Devid(devid).Substr(substr).Stale(stale).TypeInfo(typeInfo).Raw(raw).Key(key).Degraded(degraded).Nodes(nodes).DescInfo(descInfo).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    timeout := int32(56) // int32 | Time in seconds to wait for results from remote nodes. (optional)
    showNodes := true // bool | Shows the logical node number or LNN in addition to the devid. (optional)
    keys := []string{"Inner_example"} // []string | Multiple key names. Can be a comma separated list, or can be used more than one time to make queries for multiple keys. May be used in conjunction with 'substr'. Also works with 'key' arguments. (optional)
    devid := []string{"Inner_example"} // []string | Node devid to query. Either an <integer> or \"all\". Can be used more than one time to query multiple nodes. \"all\" queries all up nodes. 0 means query the local node. For \"cluster\" scoped keys, in any devid including 0 can be used. (optional)
    substr := true // bool | Used in conjunction with the 'keys' argument, alters the behavior of keys. Makes the 'keys' arg perform a partial match. Defaults to false. (optional)
    stale := true // bool | For internal use only, please do not use this. (optional)
    typeInfo := true // bool | The type ID is used by internal services. For internal use only, please do not use this. (optional)
    raw := true // bool | Causes the output to be in hex format. For internal use only, please do not use this. (optional)
    key := []string{"Inner_example"} // []string | One key name. Can be used more than one time to query multiple keys. Also works with 'keys' arguments. (optional)
    degraded := true // bool | If true, try to continue even if some stats are unavailable. In this case, errors will be present in the per-key returned data. (optional)
    nodes := []string{"Inner_example"} // []string | Specify node(s) for which statistics should be reported. One or more comma separated <integer(s)> specifying which node(s) to query, or \"all\". Specifying more than one node may have unspecified results for keys that begin with \"cluster\". (optional)
    descInfo := true // bool | Shows the description for the specified key(s). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StatisticsApi.GetStatisticsv1StatisticsCurrent(context.Background()).Timeout(timeout).ShowNodes(showNodes).Keys(keys).Devid(devid).Substr(substr).Stale(stale).TypeInfo(typeInfo).Raw(raw).Key(key).Degraded(degraded).Nodes(nodes).DescInfo(descInfo).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StatisticsApi.GetStatisticsv1StatisticsCurrent``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStatisticsv1StatisticsCurrent`: V1StatisticsCurrent
    fmt.Fprintf(os.Stdout, "Response from `StatisticsApi.GetStatisticsv1StatisticsCurrent`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetStatisticsv1StatisticsCurrentRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **timeout** | **int32** | Time in seconds to wait for results from remote nodes. | 
 **showNodes** | **bool** | Shows the logical node number or LNN in addition to the devid. | 
 **keys** | **[]string** | Multiple key names. Can be a comma separated list, or can be used more than one time to make queries for multiple keys. May be used in conjunction with &#39;substr&#39;. Also works with &#39;key&#39; arguments. | 
 **devid** | **[]string** | Node devid to query. Either an &lt;integer&gt; or \&quot;all\&quot;. Can be used more than one time to query multiple nodes. \&quot;all\&quot; queries all up nodes. 0 means query the local node. For \&quot;cluster\&quot; scoped keys, in any devid including 0 can be used. | 
 **substr** | **bool** | Used in conjunction with the &#39;keys&#39; argument, alters the behavior of keys. Makes the &#39;keys&#39; arg perform a partial match. Defaults to false. | 
 **stale** | **bool** | For internal use only, please do not use this. | 
 **typeInfo** | **bool** | The type ID is used by internal services. For internal use only, please do not use this. | 
 **raw** | **bool** | Causes the output to be in hex format. For internal use only, please do not use this. | 
 **key** | **[]string** | One key name. Can be used more than one time to query multiple keys. Also works with &#39;keys&#39; arguments. | 
 **degraded** | **bool** | If true, try to continue even if some stats are unavailable. In this case, errors will be present in the per-key returned data. | 
 **nodes** | **[]string** | Specify node(s) for which statistics should be reported. One or more comma separated &lt;integer(s)&gt; specifying which node(s) to query, or \&quot;all\&quot;. Specifying more than one node may have unspecified results for keys that begin with \&quot;cluster\&quot;. | 
 **descInfo** | **bool** | Shows the description for the specified key(s). | 

### Return type

[**V1StatisticsCurrent**](V1StatisticsCurrent.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStatisticsv1StatisticsHistory

> V1StatisticsHistory GetStatisticsv1StatisticsHistory(ctx).Begin(begin).Interval(interval).End(end).Timeout(timeout).Raw(raw).Keys(keys).Devid(devid).Substr(substr).Stale(stale).TypeInfo(typeInfo).MemoryOnly(memoryOnly).Key(key).Degraded(degraded).ShowNodes(showNodes).Resolution(resolution).Nodes(nodes).DescInfo(descInfo).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    begin := int32(56) // int32 | Earliest time (Unix epoch seconds) of interest. Negative times are interpreted as relative (before) now. (optional)
    interval := int32(56) // int32 | Minimum sampling interval time in seconds. If native statistics are higher resolution, data will be down-sampled. (optional)
    end := int32(56) // int32 | Latest time (Unix epoch seconds) of interest. Negative times are interpreted as relative (before) now. If not supplied, use now as the end time. (optional)
    timeout := int32(56) // int32 | Time in seconds to wait for results from remote nodes. (optional)
    raw := true // bool | Causes the output to be in hex format. For internal use only, please do not use this. (optional)
    keys := []string{"Inner_example"} // []string | Multiple key names. Can be a comma separated list, or can be used more than one time to make queries for multiple keys. May be used in conjunction with 'substr'. Also works with 'key' arguments. (optional)
    devid := []string{"Inner_example"} // []string | Node devid to query. Either an <integer> or \"all\". Can be used more than one time to query multiple nodes. \"all\" queries all up nodes. 0 means query the local node. For \"cluster\" scoped keys, in any devid including 0 can be used. (optional)
    substr := true // bool | Used in conjunction with the 'keys' argument, alters the behavior of keys. Makes the 'keys' arg perform a partial match. Defaults to false. (optional)
    stale := true // bool | For internal use only, please do not use this. (optional)
    typeInfo := true // bool | The type ID is used by internal services. For internal use only, please do not use this. (optional)
    memoryOnly := true // bool | Only use statistics sources that reside in memory (faster, but with less retention). (optional)
    key := []string{"Inner_example"} // []string | One key name. Can be used more than one time to query multiple keys. Also works with 'keys' arguments. (optional)
    degraded := true // bool | If true, try to continue even if some stats are unavailable. In this case, errors will be present in the per-key returned data. (optional)
    showNodes := true // bool | Shows the logical node number or LNN in addition to the devid. (optional)
    resolution := int32(56) // int32 | Synonymous with 'interval', if supplied supersedes interval. (optional)
    nodes := []string{"Inner_example"} // []string | Specify node(s) for which statistics should be reported. One or more comma separated <integer(s)> specifying which node(s) to query, or \"all\". Specifying more than one node may have unspecified results for keys that begin with \"cluster\". (optional)
    descInfo := true // bool | Shows the description for the specified key(s). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StatisticsApi.GetStatisticsv1StatisticsHistory(context.Background()).Begin(begin).Interval(interval).End(end).Timeout(timeout).Raw(raw).Keys(keys).Devid(devid).Substr(substr).Stale(stale).TypeInfo(typeInfo).MemoryOnly(memoryOnly).Key(key).Degraded(degraded).ShowNodes(showNodes).Resolution(resolution).Nodes(nodes).DescInfo(descInfo).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StatisticsApi.GetStatisticsv1StatisticsHistory``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStatisticsv1StatisticsHistory`: V1StatisticsHistory
    fmt.Fprintf(os.Stdout, "Response from `StatisticsApi.GetStatisticsv1StatisticsHistory`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetStatisticsv1StatisticsHistoryRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **begin** | **int32** | Earliest time (Unix epoch seconds) of interest. Negative times are interpreted as relative (before) now. | 
 **interval** | **int32** | Minimum sampling interval time in seconds. If native statistics are higher resolution, data will be down-sampled. | 
 **end** | **int32** | Latest time (Unix epoch seconds) of interest. Negative times are interpreted as relative (before) now. If not supplied, use now as the end time. | 
 **timeout** | **int32** | Time in seconds to wait for results from remote nodes. | 
 **raw** | **bool** | Causes the output to be in hex format. For internal use only, please do not use this. | 
 **keys** | **[]string** | Multiple key names. Can be a comma separated list, or can be used more than one time to make queries for multiple keys. May be used in conjunction with &#39;substr&#39;. Also works with &#39;key&#39; arguments. | 
 **devid** | **[]string** | Node devid to query. Either an &lt;integer&gt; or \&quot;all\&quot;. Can be used more than one time to query multiple nodes. \&quot;all\&quot; queries all up nodes. 0 means query the local node. For \&quot;cluster\&quot; scoped keys, in any devid including 0 can be used. | 
 **substr** | **bool** | Used in conjunction with the &#39;keys&#39; argument, alters the behavior of keys. Makes the &#39;keys&#39; arg perform a partial match. Defaults to false. | 
 **stale** | **bool** | For internal use only, please do not use this. | 
 **typeInfo** | **bool** | The type ID is used by internal services. For internal use only, please do not use this. | 
 **memoryOnly** | **bool** | Only use statistics sources that reside in memory (faster, but with less retention). | 
 **key** | **[]string** | One key name. Can be used more than one time to query multiple keys. Also works with &#39;keys&#39; arguments. | 
 **degraded** | **bool** | If true, try to continue even if some stats are unavailable. In this case, errors will be present in the per-key returned data. | 
 **showNodes** | **bool** | Shows the logical node number or LNN in addition to the devid. | 
 **resolution** | **int32** | Synonymous with &#39;interval&#39;, if supplied supersedes interval. | 
 **nodes** | **[]string** | Specify node(s) for which statistics should be reported. One or more comma separated &lt;integer(s)&gt; specifying which node(s) to query, or \&quot;all\&quot;. Specifying more than one node may have unspecified results for keys that begin with \&quot;cluster\&quot;. | 
 **descInfo** | **bool** | Shows the description for the specified key(s). | 

### Return type

[**V1StatisticsHistory**](V1StatisticsHistory.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStatisticsv1StatisticsKey

> V1StatisticsKeysExtended GetStatisticsv1StatisticsKey(ctx, v1StatisticsKeyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1StatisticsKeyId := "v1StatisticsKeyId_example" // string | List key meta-data.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StatisticsApi.GetStatisticsv1StatisticsKey(context.Background(), v1StatisticsKeyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StatisticsApi.GetStatisticsv1StatisticsKey``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStatisticsv1StatisticsKey`: V1StatisticsKeysExtended
    fmt.Fprintf(os.Stdout, "Response from `StatisticsApi.GetStatisticsv1StatisticsKey`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1StatisticsKeyId** | **string** | List key meta-data. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetStatisticsv1StatisticsKeyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1StatisticsKeysExtended**](V1StatisticsKeysExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStatisticsv1StatisticsKeys

> V1StatisticsKeys GetStatisticsv1StatisticsKeys(ctx).Count(count).Limit(limit).Queryable(queryable).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    count := true // bool | Only count matching keys, do not return meta-data. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    queryable := true // bool | Only list keys that can/cannot be queries. Default is true. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StatisticsApi.GetStatisticsv1StatisticsKeys(context.Background()).Count(count).Limit(limit).Queryable(queryable).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StatisticsApi.GetStatisticsv1StatisticsKeys``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStatisticsv1StatisticsKeys`: V1StatisticsKeys
    fmt.Fprintf(os.Stdout, "Response from `StatisticsApi.GetStatisticsv1StatisticsKeys`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetStatisticsv1StatisticsKeysRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **count** | **bool** | Only count matching keys, do not return meta-data. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **queryable** | **bool** | Only list keys that can/cannot be queries. Default is true. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1StatisticsKeys**](V1StatisticsKeys.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStatisticsv1StatisticsProtocols

> V1StatisticsProtocols GetStatisticsv1StatisticsProtocols(ctx).Type_(type_).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    type_ := "type__example" // string | Specifies whether internal, external, or all protocols should be returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StatisticsApi.GetStatisticsv1StatisticsProtocols(context.Background()).Type_(type_).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StatisticsApi.GetStatisticsv1StatisticsProtocols``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStatisticsv1StatisticsProtocols`: V1StatisticsProtocols
    fmt.Fprintf(os.Stdout, "Response from `StatisticsApi.GetStatisticsv1StatisticsProtocols`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetStatisticsv1StatisticsProtocolsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **type_** | **string** | Specifies whether internal, external, or all protocols should be returned. | 

### Return type

[**V1StatisticsProtocols**](V1StatisticsProtocols.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStatisticsv3StatisticsOperations

> V3StatisticsOperations GetStatisticsv3StatisticsOperations(ctx).Protocols(protocols).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    protocols := []string{"Inner_example"} // []string | A comma separated list. Only report operations for specified protocol(s). Default is all.  (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StatisticsApi.GetStatisticsv3StatisticsOperations(context.Background()).Protocols(protocols).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StatisticsApi.GetStatisticsv3StatisticsOperations``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStatisticsv3StatisticsOperations`: V3StatisticsOperations
    fmt.Fprintf(os.Stdout, "Response from `StatisticsApi.GetStatisticsv3StatisticsOperations`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetStatisticsv3StatisticsOperationsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **protocols** | **[]string** | A comma separated list. Only report operations for specified protocol(s). Default is all.  | 

### Return type

[**V3StatisticsOperations**](V3StatisticsOperations.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStatisticsv3SummaryClient

> V3SummaryClient GetStatisticsv3SummaryClient(ctx).Sort(sort).Totalby(totalby).UserNames(userNames).RemoteAddresses(remoteAddresses).Numeric(numeric).LocalNames(localNames).UserIds(userIds).Classes(classes).Timeout(timeout).LocalAddresses(localAddresses).Degraded(degraded).RemoteNames(remoteNames).Nodes(nodes).Protocols(protocols).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | Sort data by the specified comma-separated field(s). (num_operations | operation_rate | in_max | in_min | in | in_avg | out_max | out_min | out | out_avg | time_max | time_min | time_avg | node | protocol | class | user_id | user_name | local_addr | local_name | remote_addr | remote_name) Prepend 'asc:' or 'desc:' to a field to change the sort direction.  (optional)
    totalby := "totalby_example" // string | A comma separated list specifying what should be unique. (node | protocol | class | local_addr | local_name | remote_addr | remote_name | user_id | user_name | devid). Aggregation is performed over all the fields not specified in the list. (optional)
    userNames := "userNames_example" // string | A comma separated list. Only report statistics for operations requested by users with resolved names enumerated.  (optional)
    remoteAddresses := "remoteAddresses_example" // string | A comma separated list. Only report statistics for operations requested by the remote clients with dotted-quad IP addresses enumerated.  (optional)
    numeric := true // bool | Do not resolve hostnames and usernames to their human readable form(s). Default is false.  (optional)
    localNames := "localNames_example" // string | A comma separated list. Only report statistics for operations handled by the local hosts with resolved names enumerated.  (optional)
    userIds := "userIds_example" // string | A comma separated list. Only report statistics for operations requested by users with numeric UIDs enumerated.  (optional)
    classes := "classes_example" // string | A comma separated list. Default is all. (other | write | read | namespace_read | namespace_write) (optional)
    timeout := int32(56) // int32 | Timeout remote commands after NUM seconds, where NUM is the integer passed to the argument. (optional)
    localAddresses := "localAddresses_example" // string | A comma separated list. Only report statistics for operations handled by the local hosts with dotted-quad IP addresses enumerated.  (optional)
    degraded := true // bool | Continue to report if some nodes do not respond. (optional)
    remoteNames := "remoteNames_example" // string | A comma separated list. Only report statistics for operations requested by the remote clients with resolved names enumerated.  (optional)
    nodes := "nodes_example" // string | A comma separated list. Specify node(s) for which statistics should be reported. Default is all. Zero (0) should be passed in as the sole argument to indicate local. (optional)
    protocols := "protocols_example" // string | A comma separated list. Default is all. (nfs3 | smb1 | nlm | ftp | http | siq | smb2 | nfs4 | nfsrdma | papi | jobd | irp | lsass_in | lsass_out | hdfs | s3 | internal | external) (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StatisticsApi.GetStatisticsv3SummaryClient(context.Background()).Sort(sort).Totalby(totalby).UserNames(userNames).RemoteAddresses(remoteAddresses).Numeric(numeric).LocalNames(localNames).UserIds(userIds).Classes(classes).Timeout(timeout).LocalAddresses(localAddresses).Degraded(degraded).RemoteNames(remoteNames).Nodes(nodes).Protocols(protocols).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StatisticsApi.GetStatisticsv3SummaryClient``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStatisticsv3SummaryClient`: V3SummaryClient
    fmt.Fprintf(os.Stdout, "Response from `StatisticsApi.GetStatisticsv3SummaryClient`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetStatisticsv3SummaryClientRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | Sort data by the specified comma-separated field(s). (num_operations | operation_rate | in_max | in_min | in | in_avg | out_max | out_min | out | out_avg | time_max | time_min | time_avg | node | protocol | class | user_id | user_name | local_addr | local_name | remote_addr | remote_name) Prepend &#39;asc:&#39; or &#39;desc:&#39; to a field to change the sort direction.  | 
 **totalby** | **string** | A comma separated list specifying what should be unique. (node | protocol | class | local_addr | local_name | remote_addr | remote_name | user_id | user_name | devid). Aggregation is performed over all the fields not specified in the list. | 
 **userNames** | **string** | A comma separated list. Only report statistics for operations requested by users with resolved names enumerated.  | 
 **remoteAddresses** | **string** | A comma separated list. Only report statistics for operations requested by the remote clients with dotted-quad IP addresses enumerated.  | 
 **numeric** | **bool** | Do not resolve hostnames and usernames to their human readable form(s). Default is false.  | 
 **localNames** | **string** | A comma separated list. Only report statistics for operations handled by the local hosts with resolved names enumerated.  | 
 **userIds** | **string** | A comma separated list. Only report statistics for operations requested by users with numeric UIDs enumerated.  | 
 **classes** | **string** | A comma separated list. Default is all. (other | write | read | namespace_read | namespace_write) | 
 **timeout** | **int32** | Timeout remote commands after NUM seconds, where NUM is the integer passed to the argument. | 
 **localAddresses** | **string** | A comma separated list. Only report statistics for operations handled by the local hosts with dotted-quad IP addresses enumerated.  | 
 **degraded** | **bool** | Continue to report if some nodes do not respond. | 
 **remoteNames** | **string** | A comma separated list. Only report statistics for operations requested by the remote clients with resolved names enumerated.  | 
 **nodes** | **string** | A comma separated list. Specify node(s) for which statistics should be reported. Default is all. Zero (0) should be passed in as the sole argument to indicate local. | 
 **protocols** | **string** | A comma separated list. Default is all. (nfs3 | smb1 | nlm | ftp | http | siq | smb2 | nfs4 | nfsrdma | papi | jobd | irp | lsass_in | lsass_out | hdfs | s3 | internal | external) | 

### Return type

[**V3SummaryClient**](V3SummaryClient.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStatisticsv3SummaryDrive

> V3SummaryDrive GetStatisticsv3SummaryDrive(ctx).Sort(sort).Degraded(degraded).Type_(type_).Nodes(nodes).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | Sort data by the specified comma-separated field(s). (drive_id | type | xfers_in | bytes_in | xfer_size_in | xfers_out | bytes_out | xfer_size_out | access_latency | access_slow | iosched_latency | iosched_queue | busy | used_bytes_percent | used_inodes). Prepend 'asc:' or 'desc:' to a field to change the sort direction.  (optional)
    degraded := true // bool | Continue to report if some nodes do not respond. (optional)
    type_ := "type__example" // string | Specify drive type(s) for which statistics should be reported. (optional)
    nodes := "nodes_example" // string | A comma separated list. Specify node(s) for which statistics should be reported. Default is all. Zero (0) should be passed in as the sole argument to indicate local. (optional)
    timeout := int32(56) // int32 | Timeout remote commands after NUM seconds, where NUM is the integer passed to the argument. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StatisticsApi.GetStatisticsv3SummaryDrive(context.Background()).Sort(sort).Degraded(degraded).Type_(type_).Nodes(nodes).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StatisticsApi.GetStatisticsv3SummaryDrive``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStatisticsv3SummaryDrive`: V3SummaryDrive
    fmt.Fprintf(os.Stdout, "Response from `StatisticsApi.GetStatisticsv3SummaryDrive`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetStatisticsv3SummaryDriveRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | Sort data by the specified comma-separated field(s). (drive_id | type | xfers_in | bytes_in | xfer_size_in | xfers_out | bytes_out | xfer_size_out | access_latency | access_slow | iosched_latency | iosched_queue | busy | used_bytes_percent | used_inodes). Prepend &#39;asc:&#39; or &#39;desc:&#39; to a field to change the sort direction.  | 
 **degraded** | **bool** | Continue to report if some nodes do not respond. | 
 **type_** | **string** | Specify drive type(s) for which statistics should be reported. | 
 **nodes** | **string** | A comma separated list. Specify node(s) for which statistics should be reported. Default is all. Zero (0) should be passed in as the sole argument to indicate local. | 
 **timeout** | **int32** | Timeout remote commands after NUM seconds, where NUM is the integer passed to the argument. | 

### Return type

[**V3SummaryDrive**](V3SummaryDrive.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStatisticsv3SummaryHeat

> V3SummaryHeat GetStatisticsv3SummaryHeat(ctx).Sort(sort).Convertlin(convertlin).Totalby(totalby).Pathdepth(pathdepth).Numeric(numeric).Events(events).Maxpath(maxpath).Classes(classes).Timeout(timeout).Nodes(nodes).Degraded(degraded).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | Sort data by the specified comma-separated field(s). (operation_rate | node | event_name | class_name | lin | path). Prepend 'asc:' or 'desc:' to a field to change the sort direction.  (optional)
    convertlin := true // bool | Convert lin to hex. Default is true.  (optional)
    totalby := "totalby_example" // string | A comma separated list specifying what should be unique. (node | event_name | event_class | operation_rate | path | lin). Aggregation is performed over all the fields not specified in the list. (optional)
    pathdepth := int32(56) // int32 | Squash paths to this directory depth. Defaults to none, i.e. the paths are not limited (subject to the system limits). (optional)
    numeric := true // bool | Do not resolve LINs into filenames. Default is false.  (optional)
    events := "events_example" // string | A comma separated list. Default is all. Only report specified event types(s). (blocked | contended | deadlocked | getattr | link | lock | lookup | read | rename | setattr | unlink | write). (optional)
    maxpath := int32(56) // int32 | Maximum bytes allocated for looking up a path. An ASCII character is 1 byte (it may be more for other types of encoding). The default is 4096 bytes. Zero (0) means unlimited (subject to the system limits). (optional)
    classes := "classes_example" // string | A comma separated list. Default is all. (other | write | read | namespace_read | namespace_write). (optional)
    timeout := int32(56) // int32 | Timeout remote commands after NUM seconds, where NUM is the integer passed to the argument. (optional)
    nodes := "nodes_example" // string | A comma separated list. Specify node(s) for which statistics should be reported. Default is all. Zero (0) should be passed in as the sole argument to indicate local. (optional)
    degraded := true // bool | Continue to report if some nodes do not respond. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StatisticsApi.GetStatisticsv3SummaryHeat(context.Background()).Sort(sort).Convertlin(convertlin).Totalby(totalby).Pathdepth(pathdepth).Numeric(numeric).Events(events).Maxpath(maxpath).Classes(classes).Timeout(timeout).Nodes(nodes).Degraded(degraded).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StatisticsApi.GetStatisticsv3SummaryHeat``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStatisticsv3SummaryHeat`: V3SummaryHeat
    fmt.Fprintf(os.Stdout, "Response from `StatisticsApi.GetStatisticsv3SummaryHeat`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetStatisticsv3SummaryHeatRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | Sort data by the specified comma-separated field(s). (operation_rate | node | event_name | class_name | lin | path). Prepend &#39;asc:&#39; or &#39;desc:&#39; to a field to change the sort direction.  | 
 **convertlin** | **bool** | Convert lin to hex. Default is true.  | 
 **totalby** | **string** | A comma separated list specifying what should be unique. (node | event_name | event_class | operation_rate | path | lin). Aggregation is performed over all the fields not specified in the list. | 
 **pathdepth** | **int32** | Squash paths to this directory depth. Defaults to none, i.e. the paths are not limited (subject to the system limits). | 
 **numeric** | **bool** | Do not resolve LINs into filenames. Default is false.  | 
 **events** | **string** | A comma separated list. Default is all. Only report specified event types(s). (blocked | contended | deadlocked | getattr | link | lock | lookup | read | rename | setattr | unlink | write). | 
 **maxpath** | **int32** | Maximum bytes allocated for looking up a path. An ASCII character is 1 byte (it may be more for other types of encoding). The default is 4096 bytes. Zero (0) means unlimited (subject to the system limits). | 
 **classes** | **string** | A comma separated list. Default is all. (other | write | read | namespace_read | namespace_write). | 
 **timeout** | **int32** | Timeout remote commands after NUM seconds, where NUM is the integer passed to the argument. | 
 **nodes** | **string** | A comma separated list. Specify node(s) for which statistics should be reported. Default is all. Zero (0) should be passed in as the sole argument to indicate local. | 
 **degraded** | **bool** | Continue to report if some nodes do not respond. | 

### Return type

[**V3SummaryHeat**](V3SummaryHeat.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStatisticsv3SummaryProtocol

> V3SummaryProtocol GetStatisticsv3SummaryProtocol(ctx).Operations(operations).Sort(sort).Totalby(totalby).Zero(zero).Classes(classes).Timeout(timeout).Degraded(degraded).Nodes(nodes).Protocols(protocols).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    operations := "operations_example" // string | Specify operation(s) for which statistics should be reported (See the cli command: 'isi statistics list operations', for a total list). Default is all.  (optional)
    sort := "sort_example" // string | Sort data by the specified comma-separated field(s). (time | operation_count | operation_rate | in_max | in_min | in | in_avg | in_standard_dev | out_max | out_min | out | out_avg | out_standard_dev | time_max | time_min | time_avg | time_standard_dev | node | protocol | class | operation). Prepend 'asc:' or 'desc:' to a field to change the sort direction.  (optional)
    totalby := "totalby_example" // string | A comma separated list specifying what should be unique. (node | protocol | class | operation). Aggregation is performed over all the fields not specified in the list. (optional)
    zero := true // bool | Show table entries with no values. (optional)
    classes := "classes_example" // string | A comma separated list. Default is all. (other | write | read | create | delete | namespace_read | namespace_write | file_state | session_state). (optional)
    timeout := int32(56) // int32 | Timeout remote commands after NUM seconds, where NUM is the integer passed to the argument. (optional)
    degraded := true // bool | Continue to report if some nodes do not respond. (optional)
    nodes := "nodes_example" // string | A comma separated list. Specify node(s) for which statistics should be reported. Default is all. Zero (0) should be passed in as the sole argument to indicate local. (optional)
    protocols := "protocols_example" // string | A comma separated list. Default is all external protocols. (nfs3 | smb1 | nlm | ftp | http | siq | smb2 | nfs4 | nfsrdma | papi | jobd | irp | lsass_in | lsass_out | hdfs | s3 | all | internal | external) (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StatisticsApi.GetStatisticsv3SummaryProtocol(context.Background()).Operations(operations).Sort(sort).Totalby(totalby).Zero(zero).Classes(classes).Timeout(timeout).Degraded(degraded).Nodes(nodes).Protocols(protocols).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StatisticsApi.GetStatisticsv3SummaryProtocol``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStatisticsv3SummaryProtocol`: V3SummaryProtocol
    fmt.Fprintf(os.Stdout, "Response from `StatisticsApi.GetStatisticsv3SummaryProtocol`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetStatisticsv3SummaryProtocolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **operations** | **string** | Specify operation(s) for which statistics should be reported (See the cli command: &#39;isi statistics list operations&#39;, for a total list). Default is all.  | 
 **sort** | **string** | Sort data by the specified comma-separated field(s). (time | operation_count | operation_rate | in_max | in_min | in | in_avg | in_standard_dev | out_max | out_min | out | out_avg | out_standard_dev | time_max | time_min | time_avg | time_standard_dev | node | protocol | class | operation). Prepend &#39;asc:&#39; or &#39;desc:&#39; to a field to change the sort direction.  | 
 **totalby** | **string** | A comma separated list specifying what should be unique. (node | protocol | class | operation). Aggregation is performed over all the fields not specified in the list. | 
 **zero** | **bool** | Show table entries with no values. | 
 **classes** | **string** | A comma separated list. Default is all. (other | write | read | create | delete | namespace_read | namespace_write | file_state | session_state). | 
 **timeout** | **int32** | Timeout remote commands after NUM seconds, where NUM is the integer passed to the argument. | 
 **degraded** | **bool** | Continue to report if some nodes do not respond. | 
 **nodes** | **string** | A comma separated list. Specify node(s) for which statistics should be reported. Default is all. Zero (0) should be passed in as the sole argument to indicate local. | 
 **protocols** | **string** | A comma separated list. Default is all external protocols. (nfs3 | smb1 | nlm | ftp | http | siq | smb2 | nfs4 | nfsrdma | papi | jobd | irp | lsass_in | lsass_out | hdfs | s3 | all | internal | external) | 

### Return type

[**V3SummaryProtocol**](V3SummaryProtocol.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStatisticsv3SummaryProtocolStats

> V3SummaryProtocolStats GetStatisticsv3SummaryProtocolStats(ctx).Degraded(degraded).Protocol(protocol).Nodes(nodes).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    degraded := true // bool | Continue to report if some nodes do not respond. (optional)
    protocol := "protocol_example" // string | A single protocol. Default is nfs3. (nfs3 | smb1 | nlm | ftp | http | siq | smb2 | nfs4 | nfsrdma | papi | jobd | irp | lsass_in | lsass_out | hdfs | s3) (optional)
    nodes := "nodes_example" // string | A comma separated list. Specify node(s) for which statistics should be reported. Default is all. Zero (0) should be passed in as the sole argument to indicate local. (optional)
    timeout := int32(56) // int32 | Timeout remote commands after NUM seconds, where NUM is the integer passed to the argument. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StatisticsApi.GetStatisticsv3SummaryProtocolStats(context.Background()).Degraded(degraded).Protocol(protocol).Nodes(nodes).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StatisticsApi.GetStatisticsv3SummaryProtocolStats``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStatisticsv3SummaryProtocolStats`: V3SummaryProtocolStats
    fmt.Fprintf(os.Stdout, "Response from `StatisticsApi.GetStatisticsv3SummaryProtocolStats`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetStatisticsv3SummaryProtocolStatsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **degraded** | **bool** | Continue to report if some nodes do not respond. | 
 **protocol** | **string** | A single protocol. Default is nfs3. (nfs3 | smb1 | nlm | ftp | http | siq | smb2 | nfs4 | nfsrdma | papi | jobd | irp | lsass_in | lsass_out | hdfs | s3) | 
 **nodes** | **string** | A comma separated list. Specify node(s) for which statistics should be reported. Default is all. Zero (0) should be passed in as the sole argument to indicate local. | 
 **timeout** | **int32** | Timeout remote commands after NUM seconds, where NUM is the integer passed to the argument. | 

### Return type

[**V3SummaryProtocolStats**](V3SummaryProtocolStats.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStatisticsv3SummarySystem

> V3SummarySystem GetStatisticsv3SummarySystem(ctx).Sort(sort).Oprates(oprates).Degraded(degraded).Nodes(nodes).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | Sort data by the specified comma-separated field(s). (time | node | cpu | smb | ftp | http | nfs | hdfs | s3 | total | net_in | net_out | disk_in). Prepend 'asc:' or 'desc:' to a field to change the sort direction.  (optional)
    oprates := true // bool | Display protocol operation rate statistics rather than the default throughput statistics. (optional)
    degraded := true // bool | Continue to report if some nodes do not respond. (optional)
    nodes := "nodes_example" // string | A comma separated list. Specify node(s) for which statistics should be reported. Default is all. Zero (0) should be passed in as the sole argument to indicate local. (optional)
    timeout := int32(56) // int32 | Timeout remote commands after NUM seconds, where NUM is the integer passed to the argument. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StatisticsApi.GetStatisticsv3SummarySystem(context.Background()).Sort(sort).Oprates(oprates).Degraded(degraded).Nodes(nodes).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StatisticsApi.GetStatisticsv3SummarySystem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStatisticsv3SummarySystem`: V3SummarySystem
    fmt.Fprintf(os.Stdout, "Response from `StatisticsApi.GetStatisticsv3SummarySystem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetStatisticsv3SummarySystemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | Sort data by the specified comma-separated field(s). (time | node | cpu | smb | ftp | http | nfs | hdfs | s3 | total | net_in | net_out | disk_in). Prepend &#39;asc:&#39; or &#39;desc:&#39; to a field to change the sort direction.  | 
 **oprates** | **bool** | Display protocol operation rate statistics rather than the default throughput statistics. | 
 **degraded** | **bool** | Continue to report if some nodes do not respond. | 
 **nodes** | **string** | A comma separated list. Specify node(s) for which statistics should be reported. Default is all. Zero (0) should be passed in as the sole argument to indicate local. | 
 **timeout** | **int32** | Timeout remote commands after NUM seconds, where NUM is the integer passed to the argument. | 

### Return type

[**V3SummarySystem**](V3SummarySystem.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStatisticsv4SummaryWorkload

> V4SummaryWorkload GetStatisticsv4SummaryWorkload(ctx).GroupSids(groupSids).Numeric(numeric).Dataset(dataset).Degraded(degraded).ShareNames(shareNames).Paths(paths).Usernames(usernames).RemoteAddresses(remoteAddresses).JobTypes(jobTypes).ZoneIds(zoneIds).Groupnames(groupnames).UserSids(userSids).Sort(sort).DomainIds(domainIds).ZoneNames(zoneNames).LocalNames(localNames).UserIds(userIds).Totalby(totalby).LocalAddresses(localAddresses).RemoteNames(remoteNames).Nodes(nodes).Protocols(protocols).GroupIds(groupIds).Timeout(timeout).SystemNames(systemNames).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupSids := "groupSids_example" // string | A comma separated list. Only report statistics for groups specified by Group Security IDs, if configured.  (optional)
    numeric := true // bool | Do not resolve addresses and usernames to their human readable form(s). Default is false.  (optional)
    dataset := "dataset_example" // string | Report workload performance metrics for specified dataset. Default is 'System'. (optional)
    degraded := true // bool | Continue to report if some nodes do not respond. (optional)
    shareNames := "shareNames_example" // string | A comma separated list. Only report statistics for shares specified by name, if configured.  (optional)
    paths := "paths_example" // string | A comma separated list. Only report statistics for paths specified by name, if configured.  (optional)
    usernames := "usernames_example" // string | A comma separated list. Only report statistics for users specified by resolved names, if configured.  (optional)
    remoteAddresses := "remoteAddresses_example" // string | A comma separated list. Only report statistics for remote clients specified by IP addresses, if configured.  (optional)
    jobTypes := []string{"Inner_example"} // []string | A comma separated list. Only report statistics for job(s) specified by type, if configured.  (optional)
    zoneIds := "zoneIds_example" // string | A comma separated list. Only report statistics for users in zone specified by id, if configured.  (optional)
    groupnames := "groupnames_example" // string | A comma separated list. Only report statistics for groups specified by resolved names, if configured.  (optional)
    userSids := "userSids_example" // string | A comma separated list. Only report statistics for users specified by Security IDs, if configured.  (optional)
    sort := "sort_example" // string | Sort data by the specified comma-separated field(s). ( node | workload_id | system_name | user_id | user_sid | username | group_id | group_sid | groupname | domain_id | path | zone_id | zone_name | local_addr | local_name | remote_addr | remote_name | protocol | share_name | job_type | cpu | bytes_in | bytes_out | ops | reads | writes | l2 | l3 | latency_read | latency_write | latency_other | error). Prepend 'asc:' or 'desc:' to a field to change the sort direction.  (optional)
    domainIds := "domainIds_example" // string | A comma separated list. Only report statistics for domains specified by id, if configured.  (optional)
    zoneNames := "zoneNames_example" // string | A comma separated list. Only report statistics for users in zone specified by name, if configured.  (optional)
    localNames := "localNames_example" // string | A comma separated list. Only report statistics for local hosts specified by resolved names, if configured.  (optional)
    userIds := "userIds_example" // string | A comma separated list. Only report statistics for users specified by numeric UIDs, if configured.  (optional)
    totalby := "totalby_example" // string | A comma separated list specifying what should be unique. (node | system_name | user_id | user_sid | username | zone_id | zone_name | local_addr | local_name | remote_addr | remote_name | group_id | group_sid | groupname | domain_id | path | protocol | share_name | job_type). Aggregation is performed over all the fields not specified in the list. (optional)
    localAddresses := "localAddresses_example" // string | A comma separated list. Only report statistics for local hosts specified by IP addresses, if configured.  (optional)
    remoteNames := "remoteNames_example" // string | A comma separated list. Only report statistics for remote clients specified by resolved names, if configured.  (optional)
    nodes := "nodes_example" // string | A comma separated list. Specify node(s) for which statistics should be reported. Default is all. Zero (0) should be passed in as the sole argument to indicate local. (optional)
    protocols := "protocols_example" // string | A comma separated list. Default is all. (smb1 and smb2 only at this time.) (optional)
    groupIds := "groupIds_example" // string | A comma separated list. Only report statistics for groups specified by numeric GIDs, if configured.  (optional)
    timeout := int32(56) // int32 | Timeout remote commands after NUM seconds, where NUM is the integer passed to the argument. (optional)
    systemNames := "systemNames_example" // string | A comma separated list. Only report statistics for systems specified by resolved names, if configured.  (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StatisticsApi.GetStatisticsv4SummaryWorkload(context.Background()).GroupSids(groupSids).Numeric(numeric).Dataset(dataset).Degraded(degraded).ShareNames(shareNames).Paths(paths).Usernames(usernames).RemoteAddresses(remoteAddresses).JobTypes(jobTypes).ZoneIds(zoneIds).Groupnames(groupnames).UserSids(userSids).Sort(sort).DomainIds(domainIds).ZoneNames(zoneNames).LocalNames(localNames).UserIds(userIds).Totalby(totalby).LocalAddresses(localAddresses).RemoteNames(remoteNames).Nodes(nodes).Protocols(protocols).GroupIds(groupIds).Timeout(timeout).SystemNames(systemNames).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StatisticsApi.GetStatisticsv4SummaryWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStatisticsv4SummaryWorkload`: V4SummaryWorkload
    fmt.Fprintf(os.Stdout, "Response from `StatisticsApi.GetStatisticsv4SummaryWorkload`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetStatisticsv4SummaryWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **groupSids** | **string** | A comma separated list. Only report statistics for groups specified by Group Security IDs, if configured.  | 
 **numeric** | **bool** | Do not resolve addresses and usernames to their human readable form(s). Default is false.  | 
 **dataset** | **string** | Report workload performance metrics for specified dataset. Default is &#39;System&#39;. | 
 **degraded** | **bool** | Continue to report if some nodes do not respond. | 
 **shareNames** | **string** | A comma separated list. Only report statistics for shares specified by name, if configured.  | 
 **paths** | **string** | A comma separated list. Only report statistics for paths specified by name, if configured.  | 
 **usernames** | **string** | A comma separated list. Only report statistics for users specified by resolved names, if configured.  | 
 **remoteAddresses** | **string** | A comma separated list. Only report statistics for remote clients specified by IP addresses, if configured.  | 
 **jobTypes** | **[]string** | A comma separated list. Only report statistics for job(s) specified by type, if configured.  | 
 **zoneIds** | **string** | A comma separated list. Only report statistics for users in zone specified by id, if configured.  | 
 **groupnames** | **string** | A comma separated list. Only report statistics for groups specified by resolved names, if configured.  | 
 **userSids** | **string** | A comma separated list. Only report statistics for users specified by Security IDs, if configured.  | 
 **sort** | **string** | Sort data by the specified comma-separated field(s). ( node | workload_id | system_name | user_id | user_sid | username | group_id | group_sid | groupname | domain_id | path | zone_id | zone_name | local_addr | local_name | remote_addr | remote_name | protocol | share_name | job_type | cpu | bytes_in | bytes_out | ops | reads | writes | l2 | l3 | latency_read | latency_write | latency_other | error). Prepend &#39;asc:&#39; or &#39;desc:&#39; to a field to change the sort direction.  | 
 **domainIds** | **string** | A comma separated list. Only report statistics for domains specified by id, if configured.  | 
 **zoneNames** | **string** | A comma separated list. Only report statistics for users in zone specified by name, if configured.  | 
 **localNames** | **string** | A comma separated list. Only report statistics for local hosts specified by resolved names, if configured.  | 
 **userIds** | **string** | A comma separated list. Only report statistics for users specified by numeric UIDs, if configured.  | 
 **totalby** | **string** | A comma separated list specifying what should be unique. (node | system_name | user_id | user_sid | username | zone_id | zone_name | local_addr | local_name | remote_addr | remote_name | group_id | group_sid | groupname | domain_id | path | protocol | share_name | job_type). Aggregation is performed over all the fields not specified in the list. | 
 **localAddresses** | **string** | A comma separated list. Only report statistics for local hosts specified by IP addresses, if configured.  | 
 **remoteNames** | **string** | A comma separated list. Only report statistics for remote clients specified by resolved names, if configured.  | 
 **nodes** | **string** | A comma separated list. Specify node(s) for which statistics should be reported. Default is all. Zero (0) should be passed in as the sole argument to indicate local. | 
 **protocols** | **string** | A comma separated list. Default is all. (smb1 and smb2 only at this time.) | 
 **groupIds** | **string** | A comma separated list. Only report statistics for groups specified by numeric GIDs, if configured.  | 
 **timeout** | **int32** | Timeout remote commands after NUM seconds, where NUM is the integer passed to the argument. | 
 **systemNames** | **string** | A comma separated list. Only report statistics for systems specified by resolved names, if configured.  | 

### Return type

[**V4SummaryWorkload**](V4SummaryWorkload.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStatisticsv9SummaryWorkload

> V10SummaryWorkload GetStatisticsv9SummaryWorkload(ctx).GroupSids(groupSids).Numeric(numeric).ExportIds(exportIds).Degraded(degraded).RemoteNames(remoteNames).ShareNames(shareNames).Paths(paths).Usernames(usernames).RemoteAddresses(remoteAddresses).JobTypes(jobTypes).ZoneIds(zoneIds).Groupnames(groupnames).Nodes(nodes).Sort(sort).DomainIds(domainIds).ZoneNames(zoneNames).LocalNames(localNames).UserIds(userIds).Totalby(totalby).LocalAddresses(localAddresses).Dataset(dataset).UserSids(userSids).Protocols(protocols).GroupIds(groupIds).Timeout(timeout).SystemNames(systemNames).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupSids := "groupSids_example" // string | A comma separated list. Only report statistics for groups specified by Group Security IDs, if configured.  (optional)
    numeric := true // bool | Do not resolve addresses and usernames to their human readable form(s). Default is false.  (optional)
    exportIds := "exportIds_example" // string | A comma separated list. Only report statistics for exports specified by id, if configured.  (optional)
    degraded := true // bool | Continue to report if some nodes do not respond. (optional)
    remoteNames := "remoteNames_example" // string | A comma separated list. Only report statistics for remote clients specified by resolved names, if configured.  (optional)
    shareNames := "shareNames_example" // string | A comma separated list. Only report statistics for shares specified by name, if configured.  (optional)
    paths := "paths_example" // string | A comma separated list. Only report statistics for paths specified by name, if configured.  (optional)
    usernames := "usernames_example" // string | A comma separated list. Only report statistics for users specified by resolved names, if configured.  (optional)
    remoteAddresses := "remoteAddresses_example" // string | A comma separated list. Only report statistics for remote clients specified by IP addresses, if configured.  (optional)
    jobTypes := []string{"Inner_example"} // []string | A comma separated list. Only report statistics for job(s) specified by type, if configured.  (optional)
    zoneIds := "zoneIds_example" // string | A comma separated list. Only report statistics for users in zone specified by id, if configured.  (optional)
    groupnames := "groupnames_example" // string | A comma separated list. Only report statistics for groups specified by resolved names, if configured.  (optional)
    nodes := "nodes_example" // string | A comma separated list. Specify node(s) for which statistics should be reported. Default is all. Zero (0) should be passed in as the sole argument to indicate local. (optional)
    sort := "sort_example" // string | Sort data by the specified comma-separated field(s). ( node | workload_id | system_name | user_id | user_sid | username | group_id | group_sid | groupname | domain_id | path | zone_id | zone_name | export_id | local_addr | local_name | remote_addr | remote_name | protocol | share_name | job_type | cpu | bytes_in | bytes_out | ops | reads | writes | l2 | l3 | latency_read | latency_write | latency_other | error). Prepend 'asc:' or 'desc:' to a field to change the sort direction.  (optional)
    domainIds := "domainIds_example" // string | A comma separated list. Only report statistics for domains specified by id, if configured.  (optional)
    zoneNames := "zoneNames_example" // string | A comma separated list. Only report statistics for users in zone specified by name, if configured.  (optional)
    localNames := "localNames_example" // string | A comma separated list. Only report statistics for local hosts specified by resolved names, if configured.  (optional)
    userIds := "userIds_example" // string | A comma separated list. Only report statistics for users specified by numeric UIDs, if configured.  (optional)
    totalby := "totalby_example" // string | A comma separated list specifying what should be unique. (node | system_name | user_id | user_sid | username | zone_id | zone_name | local_addr | local_name | remote_addr | remote_name | group_id | group_sid | groupname | domain_id | path | export_id | protocol | share_name | job_type). Aggregation is performed over all the fields not specified in the list. (optional)
    localAddresses := "localAddresses_example" // string | A comma separated list. Only report statistics for local hosts specified by IP addresses, if configured.  (optional)
    dataset := "dataset_example" // string | Report workload performance metrics for specified dataset. Default is 'System'. (optional)
    userSids := "userSids_example" // string | A comma separated list. Only report statistics for users specified by Security IDs, if configured.  (optional)
    protocols := "protocols_example" // string | A comma separated list. Default is all. (smb1, smb2, nfs3 and nfs4 only at this time.) (optional)
    groupIds := "groupIds_example" // string | A comma separated list. Only report statistics for groups specified by numeric GIDs, if configured.  (optional)
    timeout := int32(56) // int32 | Timeout remote commands after NUM seconds, where NUM is the integer passed to the argument. (optional)
    systemNames := "systemNames_example" // string | A comma separated list. Only report statistics for systems specified by resolved names, if configured.  (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StatisticsApi.GetStatisticsv9SummaryWorkload(context.Background()).GroupSids(groupSids).Numeric(numeric).ExportIds(exportIds).Degraded(degraded).RemoteNames(remoteNames).ShareNames(shareNames).Paths(paths).Usernames(usernames).RemoteAddresses(remoteAddresses).JobTypes(jobTypes).ZoneIds(zoneIds).Groupnames(groupnames).Nodes(nodes).Sort(sort).DomainIds(domainIds).ZoneNames(zoneNames).LocalNames(localNames).UserIds(userIds).Totalby(totalby).LocalAddresses(localAddresses).Dataset(dataset).UserSids(userSids).Protocols(protocols).GroupIds(groupIds).Timeout(timeout).SystemNames(systemNames).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StatisticsApi.GetStatisticsv9SummaryWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStatisticsv9SummaryWorkload`: V10SummaryWorkload
    fmt.Fprintf(os.Stdout, "Response from `StatisticsApi.GetStatisticsv9SummaryWorkload`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetStatisticsv9SummaryWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **groupSids** | **string** | A comma separated list. Only report statistics for groups specified by Group Security IDs, if configured.  | 
 **numeric** | **bool** | Do not resolve addresses and usernames to their human readable form(s). Default is false.  | 
 **exportIds** | **string** | A comma separated list. Only report statistics for exports specified by id, if configured.  | 
 **degraded** | **bool** | Continue to report if some nodes do not respond. | 
 **remoteNames** | **string** | A comma separated list. Only report statistics for remote clients specified by resolved names, if configured.  | 
 **shareNames** | **string** | A comma separated list. Only report statistics for shares specified by name, if configured.  | 
 **paths** | **string** | A comma separated list. Only report statistics for paths specified by name, if configured.  | 
 **usernames** | **string** | A comma separated list. Only report statistics for users specified by resolved names, if configured.  | 
 **remoteAddresses** | **string** | A comma separated list. Only report statistics for remote clients specified by IP addresses, if configured.  | 
 **jobTypes** | **[]string** | A comma separated list. Only report statistics for job(s) specified by type, if configured.  | 
 **zoneIds** | **string** | A comma separated list. Only report statistics for users in zone specified by id, if configured.  | 
 **groupnames** | **string** | A comma separated list. Only report statistics for groups specified by resolved names, if configured.  | 
 **nodes** | **string** | A comma separated list. Specify node(s) for which statistics should be reported. Default is all. Zero (0) should be passed in as the sole argument to indicate local. | 
 **sort** | **string** | Sort data by the specified comma-separated field(s). ( node | workload_id | system_name | user_id | user_sid | username | group_id | group_sid | groupname | domain_id | path | zone_id | zone_name | export_id | local_addr | local_name | remote_addr | remote_name | protocol | share_name | job_type | cpu | bytes_in | bytes_out | ops | reads | writes | l2 | l3 | latency_read | latency_write | latency_other | error). Prepend &#39;asc:&#39; or &#39;desc:&#39; to a field to change the sort direction.  | 
 **domainIds** | **string** | A comma separated list. Only report statistics for domains specified by id, if configured.  | 
 **zoneNames** | **string** | A comma separated list. Only report statistics for users in zone specified by name, if configured.  | 
 **localNames** | **string** | A comma separated list. Only report statistics for local hosts specified by resolved names, if configured.  | 
 **userIds** | **string** | A comma separated list. Only report statistics for users specified by numeric UIDs, if configured.  | 
 **totalby** | **string** | A comma separated list specifying what should be unique. (node | system_name | user_id | user_sid | username | zone_id | zone_name | local_addr | local_name | remote_addr | remote_name | group_id | group_sid | groupname | domain_id | path | export_id | protocol | share_name | job_type). Aggregation is performed over all the fields not specified in the list. | 
 **localAddresses** | **string** | A comma separated list. Only report statistics for local hosts specified by IP addresses, if configured.  | 
 **dataset** | **string** | Report workload performance metrics for specified dataset. Default is &#39;System&#39;. | 
 **userSids** | **string** | A comma separated list. Only report statistics for users specified by Security IDs, if configured.  | 
 **protocols** | **string** | A comma separated list. Default is all. (smb1, smb2, nfs3 and nfs4 only at this time.) | 
 **groupIds** | **string** | A comma separated list. Only report statistics for groups specified by numeric GIDs, if configured.  | 
 **timeout** | **int32** | Timeout remote commands after NUM seconds, where NUM is the integer passed to the argument. | 
 **systemNames** | **string** | A comma separated list. Only report statistics for systems specified by resolved names, if configured.  | 

### Return type

[**V10SummaryWorkload**](V10SummaryWorkload.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

