# V12HdfsLogLevel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Level** | Pointer to **string** | Setup the HDFS service log level for this node | [optional] 

## Methods

### NewV12HdfsLogLevel

`func NewV12HdfsLogLevel() *V12HdfsLogLevel`

NewV12HdfsLogLevel instantiates a new V12HdfsLogLevel object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12HdfsLogLevelWithDefaults

`func NewV12HdfsLogLevelWithDefaults() *V12HdfsLogLevel`

NewV12HdfsLogLevelWithDefaults instantiates a new V12HdfsLogLevel object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetLevel

`func (o *V12HdfsLogLevel) GetLevel() string`

GetLevel returns the Level field if non-nil, zero value otherwise.

### GetLevelOk

`func (o *V12HdfsLogLevel) GetLevelOk() (*string, bool)`

GetLevelOk returns a tuple with the Level field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLevel

`func (o *V12HdfsLogLevel) SetLevel(v string)`

SetLevel sets Level field to given value.

### HasLevel

`func (o *V12HdfsLogLevel) HasLevel() bool`

HasLevel returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


