# V10DatasetFilters

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Filters** | [**[]V10DatasetFilterExtended**](V10DatasetFilterExtended.md) |  | 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV10DatasetFilters

`func NewV10DatasetFilters(filters []V10DatasetFilterExtended, ) *V10DatasetFilters`

NewV10DatasetFilters instantiates a new V10DatasetFilters object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10DatasetFiltersWithDefaults

`func NewV10DatasetFiltersWithDefaults() *V10DatasetFilters`

NewV10DatasetFiltersWithDefaults instantiates a new V10DatasetFilters object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFilters

`func (o *V10DatasetFilters) GetFilters() []V10DatasetFilterExtended`

GetFilters returns the Filters field if non-nil, zero value otherwise.

### GetFiltersOk

`func (o *V10DatasetFilters) GetFiltersOk() (*[]V10DatasetFilterExtended, bool)`

GetFiltersOk returns a tuple with the Filters field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFilters

`func (o *V10DatasetFilters) SetFilters(v []V10DatasetFilterExtended)`

SetFilters sets Filters field to given value.


### GetResume

`func (o *V10DatasetFilters) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V10DatasetFilters) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V10DatasetFilters) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V10DatasetFilters) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V10DatasetFilters) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V10DatasetFilters) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V10DatasetFilters) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V10DatasetFilters) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


