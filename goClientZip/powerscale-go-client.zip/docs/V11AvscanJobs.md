# V11AvscanJobs

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Jobs** | Pointer to [**[]V11AvscanJobExtended**](V11AvscanJobExtended.md) |  | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV11AvscanJobs

`func NewV11AvscanJobs() *V11AvscanJobs`

NewV11AvscanJobs instantiates a new V11AvscanJobs object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11AvscanJobsWithDefaults

`func NewV11AvscanJobsWithDefaults() *V11AvscanJobs`

NewV11AvscanJobsWithDefaults instantiates a new V11AvscanJobs object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetJobs

`func (o *V11AvscanJobs) GetJobs() []V11AvscanJobExtended`

GetJobs returns the Jobs field if non-nil, zero value otherwise.

### GetJobsOk

`func (o *V11AvscanJobs) GetJobsOk() (*[]V11AvscanJobExtended, bool)`

GetJobsOk returns a tuple with the Jobs field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetJobs

`func (o *V11AvscanJobs) SetJobs(v []V11AvscanJobExtended)`

SetJobs sets Jobs field to given value.

### HasJobs

`func (o *V11AvscanJobs) HasJobs() bool`

HasJobs returns a boolean if a field has been set.

### GetResume

`func (o *V11AvscanJobs) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V11AvscanJobs) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V11AvscanJobs) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V11AvscanJobs) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V11AvscanJobs) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V11AvscanJobs) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V11AvscanJobs) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V11AvscanJobs) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


