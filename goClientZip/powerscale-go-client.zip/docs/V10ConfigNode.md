# V10ConfigNode

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Devid** | Pointer to **int32** | Node ID (Device Number) of a node. | [optional] 
**IpAddr** | **string** | IPv4 address in the format: xxx.xxx.xxx.xxx | 
**Lnn** | Pointer to **int32** | Logical Node Number (LNN) of a node. | [optional] 
**RemoteIpmiCapable** | Pointer to **bool** | True if the node supports the Remote IPMI Management feature | [optional] 
**Status** | Pointer to **string** | This field indicates if BMC version is good and if the feature is supported. | [optional] 

## Methods

### NewV10ConfigNode

`func NewV10ConfigNode(ipAddr string, ) *V10ConfigNode`

NewV10ConfigNode instantiates a new V10ConfigNode object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ConfigNodeWithDefaults

`func NewV10ConfigNodeWithDefaults() *V10ConfigNode`

NewV10ConfigNodeWithDefaults instantiates a new V10ConfigNode object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDevid

`func (o *V10ConfigNode) GetDevid() int32`

GetDevid returns the Devid field if non-nil, zero value otherwise.

### GetDevidOk

`func (o *V10ConfigNode) GetDevidOk() (*int32, bool)`

GetDevidOk returns a tuple with the Devid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDevid

`func (o *V10ConfigNode) SetDevid(v int32)`

SetDevid sets Devid field to given value.

### HasDevid

`func (o *V10ConfigNode) HasDevid() bool`

HasDevid returns a boolean if a field has been set.

### GetIpAddr

`func (o *V10ConfigNode) GetIpAddr() string`

GetIpAddr returns the IpAddr field if non-nil, zero value otherwise.

### GetIpAddrOk

`func (o *V10ConfigNode) GetIpAddrOk() (*string, bool)`

GetIpAddrOk returns a tuple with the IpAddr field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpAddr

`func (o *V10ConfigNode) SetIpAddr(v string)`

SetIpAddr sets IpAddr field to given value.


### GetLnn

`func (o *V10ConfigNode) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V10ConfigNode) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V10ConfigNode) SetLnn(v int32)`

SetLnn sets Lnn field to given value.

### HasLnn

`func (o *V10ConfigNode) HasLnn() bool`

HasLnn returns a boolean if a field has been set.

### GetRemoteIpmiCapable

`func (o *V10ConfigNode) GetRemoteIpmiCapable() bool`

GetRemoteIpmiCapable returns the RemoteIpmiCapable field if non-nil, zero value otherwise.

### GetRemoteIpmiCapableOk

`func (o *V10ConfigNode) GetRemoteIpmiCapableOk() (*bool, bool)`

GetRemoteIpmiCapableOk returns a tuple with the RemoteIpmiCapable field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemoteIpmiCapable

`func (o *V10ConfigNode) SetRemoteIpmiCapable(v bool)`

SetRemoteIpmiCapable sets RemoteIpmiCapable field to given value.

### HasRemoteIpmiCapable

`func (o *V10ConfigNode) HasRemoteIpmiCapable() bool`

HasRemoteIpmiCapable returns a boolean if a field has been set.

### GetStatus

`func (o *V10ConfigNode) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V10ConfigNode) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V10ConfigNode) SetStatus(v string)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V10ConfigNode) HasStatus() bool`

HasStatus returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


