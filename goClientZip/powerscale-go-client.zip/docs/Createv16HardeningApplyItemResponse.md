# Createv16HardeningApplyItemResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Message** | Pointer to **string** | Message text containing the result of the hardening action. | [optional] 

## Methods

### NewCreatev16HardeningApplyItemResponse

`func NewCreatev16HardeningApplyItemResponse() *Createv16HardeningApplyItemResponse`

NewCreatev16HardeningApplyItemResponse instantiates a new Createv16HardeningApplyItemResponse object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev16HardeningApplyItemResponseWithDefaults

`func NewCreatev16HardeningApplyItemResponseWithDefaults() *Createv16HardeningApplyItemResponse`

NewCreatev16HardeningApplyItemResponseWithDefaults instantiates a new Createv16HardeningApplyItemResponse object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMessage

`func (o *Createv16HardeningApplyItemResponse) GetMessage() string`

GetMessage returns the Message field if non-nil, zero value otherwise.

### GetMessageOk

`func (o *Createv16HardeningApplyItemResponse) GetMessageOk() (*string, bool)`

GetMessageOk returns a tuple with the Message field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMessage

`func (o *Createv16HardeningApplyItemResponse) SetMessage(v string)`

SetMessage sets Message field to given value.

### HasMessage

`func (o *Createv16HardeningApplyItemResponse) HasMessage() bool`

HasMessage returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


