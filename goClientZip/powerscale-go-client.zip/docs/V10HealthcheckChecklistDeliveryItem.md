# V10HealthcheckChecklistDeliveryItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Address** | Pointer to **[]string** | Email addresses to send to. | [optional] 
**EmailHost** | Pointer to **string** | SMTP relay host. | [optional] 
**EmailPass** | Pointer to **string** | Password for SMTP authentication. | [optional] 
**EmailPort** | Pointer to **int32** | SMTP relay port - optional defaults to 25. | [optional] 
**EmailSecurity** | Pointer to **string** | Encryption protocol to use for SMTP. | [optional] 
**EmailUser** | Pointer to **string** | Username for SMTP authentication. | [optional] 
**Failonly** | **bool** | Only send failures | 
**Method** | **string** | Delivery method | 

## Methods

### NewV10HealthcheckChecklistDeliveryItem

`func NewV10HealthcheckChecklistDeliveryItem(failonly bool, method string, ) *V10HealthcheckChecklistDeliveryItem`

NewV10HealthcheckChecklistDeliveryItem instantiates a new V10HealthcheckChecklistDeliveryItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10HealthcheckChecklistDeliveryItemWithDefaults

`func NewV10HealthcheckChecklistDeliveryItemWithDefaults() *V10HealthcheckChecklistDeliveryItem`

NewV10HealthcheckChecklistDeliveryItemWithDefaults instantiates a new V10HealthcheckChecklistDeliveryItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAddress

`func (o *V10HealthcheckChecklistDeliveryItem) GetAddress() []string`

GetAddress returns the Address field if non-nil, zero value otherwise.

### GetAddressOk

`func (o *V10HealthcheckChecklistDeliveryItem) GetAddressOk() (*[]string, bool)`

GetAddressOk returns a tuple with the Address field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddress

`func (o *V10HealthcheckChecklistDeliveryItem) SetAddress(v []string)`

SetAddress sets Address field to given value.

### HasAddress

`func (o *V10HealthcheckChecklistDeliveryItem) HasAddress() bool`

HasAddress returns a boolean if a field has been set.

### GetEmailHost

`func (o *V10HealthcheckChecklistDeliveryItem) GetEmailHost() string`

GetEmailHost returns the EmailHost field if non-nil, zero value otherwise.

### GetEmailHostOk

`func (o *V10HealthcheckChecklistDeliveryItem) GetEmailHostOk() (*string, bool)`

GetEmailHostOk returns a tuple with the EmailHost field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEmailHost

`func (o *V10HealthcheckChecklistDeliveryItem) SetEmailHost(v string)`

SetEmailHost sets EmailHost field to given value.

### HasEmailHost

`func (o *V10HealthcheckChecklistDeliveryItem) HasEmailHost() bool`

HasEmailHost returns a boolean if a field has been set.

### GetEmailPass

`func (o *V10HealthcheckChecklistDeliveryItem) GetEmailPass() string`

GetEmailPass returns the EmailPass field if non-nil, zero value otherwise.

### GetEmailPassOk

`func (o *V10HealthcheckChecklistDeliveryItem) GetEmailPassOk() (*string, bool)`

GetEmailPassOk returns a tuple with the EmailPass field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEmailPass

`func (o *V10HealthcheckChecklistDeliveryItem) SetEmailPass(v string)`

SetEmailPass sets EmailPass field to given value.

### HasEmailPass

`func (o *V10HealthcheckChecklistDeliveryItem) HasEmailPass() bool`

HasEmailPass returns a boolean if a field has been set.

### GetEmailPort

`func (o *V10HealthcheckChecklistDeliveryItem) GetEmailPort() int32`

GetEmailPort returns the EmailPort field if non-nil, zero value otherwise.

### GetEmailPortOk

`func (o *V10HealthcheckChecklistDeliveryItem) GetEmailPortOk() (*int32, bool)`

GetEmailPortOk returns a tuple with the EmailPort field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEmailPort

`func (o *V10HealthcheckChecklistDeliveryItem) SetEmailPort(v int32)`

SetEmailPort sets EmailPort field to given value.

### HasEmailPort

`func (o *V10HealthcheckChecklistDeliveryItem) HasEmailPort() bool`

HasEmailPort returns a boolean if a field has been set.

### GetEmailSecurity

`func (o *V10HealthcheckChecklistDeliveryItem) GetEmailSecurity() string`

GetEmailSecurity returns the EmailSecurity field if non-nil, zero value otherwise.

### GetEmailSecurityOk

`func (o *V10HealthcheckChecklistDeliveryItem) GetEmailSecurityOk() (*string, bool)`

GetEmailSecurityOk returns a tuple with the EmailSecurity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEmailSecurity

`func (o *V10HealthcheckChecklistDeliveryItem) SetEmailSecurity(v string)`

SetEmailSecurity sets EmailSecurity field to given value.

### HasEmailSecurity

`func (o *V10HealthcheckChecklistDeliveryItem) HasEmailSecurity() bool`

HasEmailSecurity returns a boolean if a field has been set.

### GetEmailUser

`func (o *V10HealthcheckChecklistDeliveryItem) GetEmailUser() string`

GetEmailUser returns the EmailUser field if non-nil, zero value otherwise.

### GetEmailUserOk

`func (o *V10HealthcheckChecklistDeliveryItem) GetEmailUserOk() (*string, bool)`

GetEmailUserOk returns a tuple with the EmailUser field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEmailUser

`func (o *V10HealthcheckChecklistDeliveryItem) SetEmailUser(v string)`

SetEmailUser sets EmailUser field to given value.

### HasEmailUser

`func (o *V10HealthcheckChecklistDeliveryItem) HasEmailUser() bool`

HasEmailUser returns a boolean if a field has been set.

### GetFailonly

`func (o *V10HealthcheckChecklistDeliveryItem) GetFailonly() bool`

GetFailonly returns the Failonly field if non-nil, zero value otherwise.

### GetFailonlyOk

`func (o *V10HealthcheckChecklistDeliveryItem) GetFailonlyOk() (*bool, bool)`

GetFailonlyOk returns a tuple with the Failonly field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFailonly

`func (o *V10HealthcheckChecklistDeliveryItem) SetFailonly(v bool)`

SetFailonly sets Failonly field to given value.


### GetMethod

`func (o *V10HealthcheckChecklistDeliveryItem) GetMethod() string`

GetMethod returns the Method field if non-nil, zero value otherwise.

### GetMethodOk

`func (o *V10HealthcheckChecklistDeliveryItem) GetMethodOk() (*string, bool)`

GetMethodOk returns a tuple with the Method field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMethod

`func (o *V10HealthcheckChecklistDeliveryItem) SetMethod(v string)`

SetMethod sets Method field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


