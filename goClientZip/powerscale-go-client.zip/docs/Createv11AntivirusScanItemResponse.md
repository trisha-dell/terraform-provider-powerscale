# Createv11AntivirusScanItemResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ReportId** | Pointer to **string** | The ID for the report for this scan. A report ID will be generated if one is not provided.  | [optional] 
**Result** | Pointer to **string** | The result of the scan. | [optional] 

## Methods

### NewCreatev11AntivirusScanItemResponse

`func NewCreatev11AntivirusScanItemResponse() *Createv11AntivirusScanItemResponse`

NewCreatev11AntivirusScanItemResponse instantiates a new Createv11AntivirusScanItemResponse object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev11AntivirusScanItemResponseWithDefaults

`func NewCreatev11AntivirusScanItemResponseWithDefaults() *Createv11AntivirusScanItemResponse`

NewCreatev11AntivirusScanItemResponseWithDefaults instantiates a new Createv11AntivirusScanItemResponse object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetReportId

`func (o *Createv11AntivirusScanItemResponse) GetReportId() string`

GetReportId returns the ReportId field if non-nil, zero value otherwise.

### GetReportIdOk

`func (o *Createv11AntivirusScanItemResponse) GetReportIdOk() (*string, bool)`

GetReportIdOk returns a tuple with the ReportId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReportId

`func (o *Createv11AntivirusScanItemResponse) SetReportId(v string)`

SetReportId sets ReportId field to given value.

### HasReportId

`func (o *Createv11AntivirusScanItemResponse) HasReportId() bool`

HasReportId returns a boolean if a field has been set.

### GetResult

`func (o *Createv11AntivirusScanItemResponse) GetResult() string`

GetResult returns the Result field if non-nil, zero value otherwise.

### GetResultOk

`func (o *Createv11AntivirusScanItemResponse) GetResultOk() (*string, bool)`

GetResultOk returns a tuple with the Result field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResult

`func (o *Createv11AntivirusScanItemResponse) SetResult(v string)`

SetResult sets Result field to given value.

### HasResult

`func (o *Createv11AntivirusScanItemResponse) HasResult() bool`

HasResult returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


