# V11HdfsSettingsGlobalGlobalSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ServiceEnabled** | Pointer to **bool** | Globally enable or disable HDFS service. | [optional] 

## Methods

### NewV11HdfsSettingsGlobalGlobalSettings

`func NewV11HdfsSettingsGlobalGlobalSettings() *V11HdfsSettingsGlobalGlobalSettings`

NewV11HdfsSettingsGlobalGlobalSettings instantiates a new V11HdfsSettingsGlobalGlobalSettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11HdfsSettingsGlobalGlobalSettingsWithDefaults

`func NewV11HdfsSettingsGlobalGlobalSettingsWithDefaults() *V11HdfsSettingsGlobalGlobalSettings`

NewV11HdfsSettingsGlobalGlobalSettingsWithDefaults instantiates a new V11HdfsSettingsGlobalGlobalSettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetServiceEnabled

`func (o *V11HdfsSettingsGlobalGlobalSettings) GetServiceEnabled() bool`

GetServiceEnabled returns the ServiceEnabled field if non-nil, zero value otherwise.

### GetServiceEnabledOk

`func (o *V11HdfsSettingsGlobalGlobalSettings) GetServiceEnabledOk() (*bool, bool)`

GetServiceEnabledOk returns a tuple with the ServiceEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServiceEnabled

`func (o *V11HdfsSettingsGlobalGlobalSettings) SetServiceEnabled(v bool)`

SetServiceEnabled sets ServiceEnabled field to given value.

### HasServiceEnabled

`func (o *V11HdfsSettingsGlobalGlobalSettings) HasServiceEnabled() bool`

HasServiceEnabled returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


