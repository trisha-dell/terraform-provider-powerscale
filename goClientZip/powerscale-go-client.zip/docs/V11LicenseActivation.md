# V11LicenseActivation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ElmsErrors** | Pointer to [**[]V11LicenseActivationElmsError**](V11LicenseActivationElmsError.md) | An array of licenses not included in activation file. | [optional] 
**LastActionTime** | Pointer to **int32** | Number of days before a license expires. | [optional] 
**Status** | **string** | The state of activation. File creating, created, submitted, awaiting license, error, or approved. | 
**TransactionId** | Pointer to **string** | The license activation transaction ID | [optional] 

## Methods

### NewV11LicenseActivation

`func NewV11LicenseActivation(status string, ) *V11LicenseActivation`

NewV11LicenseActivation instantiates a new V11LicenseActivation object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11LicenseActivationWithDefaults

`func NewV11LicenseActivationWithDefaults() *V11LicenseActivation`

NewV11LicenseActivationWithDefaults instantiates a new V11LicenseActivation object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetElmsErrors

`func (o *V11LicenseActivation) GetElmsErrors() []V11LicenseActivationElmsError`

GetElmsErrors returns the ElmsErrors field if non-nil, zero value otherwise.

### GetElmsErrorsOk

`func (o *V11LicenseActivation) GetElmsErrorsOk() (*[]V11LicenseActivationElmsError, bool)`

GetElmsErrorsOk returns a tuple with the ElmsErrors field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetElmsErrors

`func (o *V11LicenseActivation) SetElmsErrors(v []V11LicenseActivationElmsError)`

SetElmsErrors sets ElmsErrors field to given value.

### HasElmsErrors

`func (o *V11LicenseActivation) HasElmsErrors() bool`

HasElmsErrors returns a boolean if a field has been set.

### GetLastActionTime

`func (o *V11LicenseActivation) GetLastActionTime() int32`

GetLastActionTime returns the LastActionTime field if non-nil, zero value otherwise.

### GetLastActionTimeOk

`func (o *V11LicenseActivation) GetLastActionTimeOk() (*int32, bool)`

GetLastActionTimeOk returns a tuple with the LastActionTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastActionTime

`func (o *V11LicenseActivation) SetLastActionTime(v int32)`

SetLastActionTime sets LastActionTime field to given value.

### HasLastActionTime

`func (o *V11LicenseActivation) HasLastActionTime() bool`

HasLastActionTime returns a boolean if a field has been set.

### GetStatus

`func (o *V11LicenseActivation) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V11LicenseActivation) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V11LicenseActivation) SetStatus(v string)`

SetStatus sets Status field to given value.


### GetTransactionId

`func (o *V11LicenseActivation) GetTransactionId() string`

GetTransactionId returns the TransactionId field if non-nil, zero value otherwise.

### GetTransactionIdOk

`func (o *V11LicenseActivation) GetTransactionIdOk() (*string, bool)`

GetTransactionIdOk returns a tuple with the TransactionId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTransactionId

`func (o *V11LicenseActivation) SetTransactionId(v string)`

SetTransactionId sets TransactionId field to given value.

### HasTransactionId

`func (o *V11LicenseActivation) HasTransactionId() bool`

HasTransactionId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


